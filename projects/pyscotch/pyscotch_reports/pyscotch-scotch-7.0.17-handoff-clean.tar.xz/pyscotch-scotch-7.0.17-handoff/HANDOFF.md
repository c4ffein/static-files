# Handoff: the Scotch 7.0.17 analysis, for the next Claude instance

Read this file first and you should not need to re-derive anything. It is written for an agent picking up
the work at the next Scotch release (7.0.18 or later), or answering questions about 7.0.17, without
re-spending the tokens this cost (roughly 15M tokens over three sessions, 49 agent launches).

## 0. Where the results live (pinned)

The conclusions are in the PyScotch repository, pinned below to the release that carries them, so the
links survive later moves of the folders. This archive holds the process behind them (section 1).

- Repository: https://github.com/c4ffein/pyscotch
- Pinned at: tag `v7.0.7` = commit `b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8`. Use the full id, not the tag: a tag can be moved.
- Offline: `git clone https://github.com/c4ffein/pyscotch.git && git -C pyscotch checkout b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8`

Every repository path in section 1 is a link at that commit. The links break only if that commit
disappears from GitHub (history rewritten and force-pushed, repository deleted or made private).

## 1. What exists and where

**In the PyScotch repository (committed, released as pyscotch 7.0.7, links pinned at `b7a5b0b03fc0`):**

| Path | What |
|---|---|
| [`upstream/reports/7.0.17/findings.json`](https://github.com/c4ffein/pyscotch/blob/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/reports/7.0.17/findings.json) | 350 findings: the 192 leads of R. Perry's review of Scotch 7.0.16, re-verified against 7.0.17, plus 158 defects PyScotch found (ids `PS-*` from the first pass, `PS2-<group>-<n>` from the second). One entry per id; other groups' views under `also`. |
| [`upstream/reports/7.0.17/patches/<group>/`](https://github.com/c4ffein/pyscotch/tree/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/reports/7.0.17/patches) | 246 commits (`git format-patch`) on v7.0.17, one folder per audit group |
| [`upstream/reports/7.0.17/series/`](https://github.com/c4ffein/pyscotch/tree/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/reports/7.0.17/series) | the same fixes as ONE series of 240 patches (2 duplicates dropped) that applies on v7.0.17 with a plain `git am` |
| [`upstream/reports/7.0.17/alt/<group>/`](https://github.com/c4ffein/pyscotch/tree/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/reports/7.0.17/alt) | 289 alternative diffs (the options not chosen) |
| [`upstream/reports/7.0.17/groups/<group>/`](https://github.com/c4ffein/pyscotch/tree/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/reports/7.0.17/groups) | each audit group's `SUMMARY.md`, raw `audit.json`, `extra.json` |
| [`upstream/reports/7.0.17/{qa.json,order.txt,meta.json,blocking.json}`](https://github.com/c4ffein/pyscotch/tree/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/reports/7.0.17) | build-and-test matrix; group apply order (G10 last); report metadata; the curated list of findings blocking the next PyScotch release (SEP-13, PS2-G08-1) |
| [`upstream/repro/<group>/`](https://github.com/c4ffein/pyscotch/tree/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/upstream/repro) | reproducer kits, once, outside any version. A finding's `repro` field is `<group>/<id>`. Kits share a harness under `<group>/common/` (89 files use `../common`), so they stay grouped. |
| [`scripts/gen_upstream_report.py`](https://github.com/c4ffein/pyscotch/blob/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/scripts/gen_upstream_report.py) | `ingest`, `merge-audit` (`--check-apply`, `--order`, `--repro-root`), `build` (HTML/PDF/email report) |
| [`docs/site/gen_analysis.py`](https://github.com/c4ffein/pyscotch/blob/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/docs/site/gen_analysis.py) | renders the tracker sub-site from `upstream/reports/<newest>/` + `upstream/repro/`; run by `.github/workflows/docs.yml` after `docs/site/build.py` |
| [`tests/pyscotch_base/test_upstream_report.py`](https://github.com/c4ffein/pyscotch/blob/b7a5b0b03fc06ec6b9bfca2c32d6acf3b3b007d8/tests/pyscotch_base/test_upstream_report.py) | 18 tests of the pipeline |

Public site: https://c4ffein.github.io/pyscotch/analysis/ (dashboard), reached from the docs footer "Tracker".

**In this archive (not in the repository):**

| Path | What |
|---|---|
| `HANDOFF.md` | this file |
| `prompts.md`, `prompts.json` | all 49 agent launches and 37 messages sent to agents, verbatim, in order, without times |
| `infra/` | the brief every second-pass agent followed (`BRIEF.md`), the patch style checklist (`STYLE.md`), the mechanical style checker (`stylecheck.py`), the 30 groups (`groups.json`) and their digests (`groups/<G>.md`, review text removed: it is cited by id, never redistributed) |
| `decisions.md` | the 17 open decisions for the PyScotch maintainer, in three themes, plus reported-but-unpatched follow-ups |
| `qa/` | full logs of `make check`, `ptcheck`, `escheck` on pristine and patched trees, 32- and 64-bit; `qa.json`; QA tools (`digest_summary.py` compact digest viewer, `apply_diag.py` apply/collision diagnostic, `shoot.sh` headless screenshots) |
| `git/scotch-7.0.17-combined-240.bundle` | the 240 commits as a git bundle (prerequisite: tag v7.0.17). `git fetch <bundle> combined2:combined` in a Scotch clone. Author and commit dates are all set to 2026-10-13 00:00 UTC, so commit ids differ from the `From <id>` lines in `series/`; content, messages and `git patch-id` are identical. Match commits by patch-id (`git cherry`), not by id. |
| `firstpass/` | the first pass's raw per-area findings (review titles removed); `ingest` reads these |
| `transcripts/<session>/subagents/` | all 49 subagent transcripts (JSONL), timestamps removed. Grep them; do not read them whole. They contain the review's text, which the agents read. |

Sessions: `2360bf25-...` first pass (Sonnet 5.5); `087f3d41-...` second pass wave 1 (Fable 5.1, died,
see 6); `2ec737e7-...` waves 2-3, merge, QA, site, release. Only the subagent transcripts are included, with
every timestamp removed; the main sessions (the maintainer's own messages) are not. API request ids are
removed, and API message and tool-call ids are replaced by consistent placeholders (`msg_000123`,
`toolu_000456`): links between records are kept.

## 2. Method (what to keep doing)

1. **First pass** (cheap model, one agent per review area): status of each lead in the new version, a few
   fix options, sketches. Never trusted as is: its labels were inconsistent, and its MPI hang readings are
   unreliable (its driver used `MPI_Init`, not `MPI_Init_thread(MPI_THREAD_MULTIPLE)`, so folded coarsening
   hung at random).
2. **Second pass** (Fable 5.1, one agent per GROUP of 5-9 findings sharing source files, 30 groups): each
   agent re-verifies at runtime (ASan+UBSan builds, 32- and 64-bit `Gnum`, fault injection by LD_PRELOAD,
   mpirun with 15 s timeouts, ThreadSanitizer where threads matter), hunts the same pattern tree-wide, writes
   at least two real diffs, and turns the recommended one into a maintainer-grade commit (`STYLE.md`: one
   commit per defect, twins fixed, dead fields removed, test added in `src/check` when there is a natural
   home, header `to :` date and copyright year bumped, 0 warnings, `git am` on a fresh clone).
3. **Routing between groups is most of the orchestration work.** Every finished group's `SUMMARY.md` lists
   leads in other groups' files; forward them in the next launch prompt (or by `SendMessage` to a running
   agent). `prompts.md` shows every forward that was made.
4. **Late groups build on the combined series** of the finished ones (`git am combined-series/*.patch; git
   tag base-combined; ...; git format-patch base-combined`), and the merge applies groups in `order.txt`.
5. **Merge and QA**: `merge-audit --check-apply <scotch.git> --order order.txt --repro-root upstream/repro`
   dedupes identical patches by `git patch-id`, applies everything 3-way, exports one series and proves it
   with a plain `git am`. Then build the combined tree on both integer sizes and run `check`, `ptcheck`,
   `escheck` ONE TREE AT A TIME (see 6), against a pristine baseline built the same way.

## 3. Numbers (7.0.17)

- 192 review leads: 159 still present in 7.0.17, 18 fixed upstream, 13 partially fixed, 2 not bugs.
  178 verified by running, 11 partly, 3 by source reading only.
- 240 distinct commits from 30 groups. QA on the combined tree: 0 warnings (32/64-bit); `check`, `ptcheck`,
  `escheck` all pass with 0 sanitizer reports on both sizes. Pristine 7.0.17 under the same builds fails
  `check_scotch_arch_build` (leak) and shows 26 (64-bit) UBSan reports in `check`.
- Cost per group: 300k-600k tokens, 35-55 minutes. Usage limits hit three times; see 6.

## 4. Doing the next Scotch version (7.0.18)

1. `make bump SCOTCH=7.0.18` (gated) for PyScotch itself; `release-watch` in `scotch-build.yml` flags new tags.
2. Clone Scotch at the new tag. Check which of the 240 commits upstream merged:
   `git cherry v7.0.18 combined` against the bundle, or re-apply `series/` with `git am -3` and look at what
   becomes empty. A merged commit's findings become `fixed`.
3. For the still-open findings only: re-run a second pass on the groups that still have open items, with the
   SAME brief (`infra/BRIEF.md`) adapted to the new base, and the group digests regenerated from
   `findings.json` (the review text is no longer needed: our own titles and evidence suffice). Agents rebase
   their group's patches; most will apply 3-way unchanged.
4. Write `upstream/reports/7.0.18/` with `merge-audit` (new `findings.json` from the previous one; history
   is computed across version folders), a new `blocking.json`, `qa.json` from the new QA run. Kits in
   `upstream/repro/` are updated in place, not copied.
5. The site picks the newest version folder automatically; the dashboard gains a history column.

## 5. Decisions still open (see `decisions.md`)

The ones that recur and should be settled once: unconditional release-build agreements between MPI ranks
(the maintainer compiles them out; the series adds them in G07, G18, G19, G21, G22, G24); the edge-load
sum convention (changes printed numbers PyScotch's own tests pin); mesh label uniqueness; the halo-sync
out-of-memory hang (PS-DGR-2, alt B untested); the never-read fixed-seed context option (PS2-G06-1).

## 6. Lessons that cost real time

- **Never move a running Claude Code process to another terminal** (reptyr): the TTY swap silently drops the
  stdin watch; output still draws, keys never arrive, permission dialogs cannot be answered; a repair
  attempt killed the process and its agents. To survive a terminal close, start `claude` inside `dtach`
  from the beginning.
- **Usage limits** stop every running agent but not the session: after the reset, `SendMessage` each
  stopped agent ("continue where you stopped; your work dir is on disk") and it resumes from its transcript.
  A killed session can be resumed with `claude -r <session-id>`; in-flight shell commands are lost.
- **Scotch's check suite writes to a shared `/tmp`**: two suites run concurrently produce false failures
  (gotst/gout). Run them one tree at a time.
- **Scotch's library link rule used `$?`**: an incremental `make scotch` produced a library with 3 of 1387
  symbols. Fixed by G30's first commit; on a pristine tree, delete the `.so` before relinking.
- **MPI test drivers need `MPI_Init_thread(MPI_THREAD_MULTIPLE)`** with threaded Scotch, or folded
  coarsening hangs at random.
- **Alphabetical group order is not apply order**: a group based on bare v7.0.17 that sorts early breaks
  later groups' pre-images. Use `order.txt`.
- **Some patches end up in the same file from two groups**: three groups committed the identical
  `archCmpltw` fix; `git patch-id` dedupe handles it. Conflicts that need a human: test-list additions in
  `src/check/CMakeLists.txt` and Makefile dependency lines (resolved by hand, written back to the group).
- **Headers**: agents forget the copyright year more than the date; check every modified file on the final
  tree and fold fixes in with `git commit --fixup` + `rebase --autosquash`.
- **Screenshots in a root-less container**: Playwright's Chromium needs 17 system libs, fonts and more than
  64 MB of `/dev/shm`; download the Debian packages as a user (`apt-get -o Dir::State=... download`),
  `dpkg-deb -x`, point `LD_LIBRARY_PATH`, `FONTCONFIG_FILE`, `TMPDIR`; launch with `--disable-dev-shm-usage`.
  
- **The maintainer of PyScotch makes the commits.** Prepare, verify on an export of the would-be commit
  (`GIT_INDEX_FILE=tmp git add -A; git write-tree; git archive | tar -x`), and hand over.
- **Scratch is huge and disposable**: per-group build trees (7.7 GB), clones (0.8 GB), core dumps. Only the
  source-level reproducers matter, and they are in the repository.
