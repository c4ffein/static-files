# Every agent launch and every message sent to an agent, in order
Extracted from the session transcripts. Launches are `Agent`; resumes after usage limits and forwarded leads are `SendMessage`. Times removed.

## 1. Agent · Verify COR findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is COR (28 findings: core utilities, strategy parser, target architectures).
```

## 2. Agent · Verify GRA findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is GRA (27 findings: sequential graphs, ordering, k-way mapping).
```

## 3. Agent · Verify SEP findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is SEP (23 findings: bipartitioning, separators, meshes). Note: the threaded bgraphBipartGg() nondeterminism/seeding-race issue is already known to us and handled elsewhere; if a SEP finding touches bgraph_bipart_gg.c, still report its status but say whether it is that known issue.
```

## 4. Agent · Verify API findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is API (24 findings: public C API and Fortran wrappers).
```

## 5. Agent · Verify DGR findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is DGR (22 findings: distributed graph and mesh core, PT-Scotch). Multi-rank reproduction needs mpirun --oversubscribe; MPI error-path findings may require injected failures, in which case be explicit that you read the source instead.
```

## 6. Agent · Verify DMO findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is DMO (19 findings: distributed mapping and ordering, PT-Scotch). Multi-rank reproduction needs mpirun --oversubscribe; MPI error-path findings may require injected failures, in which case be explicit that you read the source instead.
```

## 7. Agent · Verify CLI findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is CLI (24 findings: CLI tools, esMUMPS, METIS/ParMETIS shim). You will need to build the shim/esmumps targets in your own copy of the asan tree.
```

## 8. Agent · Verify BLD findings on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief.md and follow it exactly. Your PREFIX is BLD (25 findings: build system, tests, CI). For CMake findings you can run cmake in a scratch build dir against a COPY of the 7.0.17 source. Do not touch any CI secret or contact any network service; for the Sonar-token finding, verify from the script text only.
```

## 9. SendMessage · COR: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your COR verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = COR) and do parts A and B.
```

## 10. SendMessage · GRA: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your GRA verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = GRA) and do parts A and B.
```

## 11. SendMessage · SEP: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your SEP verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = SEP) and do parts A and B.
```

## 12. SendMessage · API: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your API verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = API) and do parts A and B.
```

## 13. SendMessage · DGR: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your DGR verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = DGR) and do parts A and B.
```

## 14. SendMessage · DMO: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your DMO verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = DMO) and do parts A and B.
```

## 15. SendMessage · CLI: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your CLI verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = CLI) and do parts A and B.
```

## 16. SendMessage · BLD: enrich findings with own titles

_first pass (Sonnet 5.5)_

```
Follow-up for your BLD verification: please read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/followup.md (PREFIX = BLD) and do parts A and B.
```

## 17. Agent · Audit COR area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = COR (core utilities, strategy parser, target architectures; 28 leads). Note the strategy parser and the architecture loaders are classic variant-hunt territory: sweep every arch_*.c loader and every parser/lexer action for the same defect patterns.
```

## 18. Agent · Audit GRA area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = GRA (sequential graphs, ordering, k-way mapping; 27 leads). Sweep every graph_io_*.c loader (Scotch, Chaco, Matrix Market, Harwell-Boeing, ...) for the same trusting-input patterns.
```

## 19. Agent · Audit SEP area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = SEP (bipartitioning, separators, meshes; 23 leads). The threaded bgraphBipartGg() seeding race / SCOTCH_DETERMINISTIC issue is already known and patched on our side (SEP-13): still verify it, but concentrate your variant hunt on the OTHER threaded bipartitioners (diffusion, genetic, FM) and on the mesh code.
```

## 20. Agent · Audit API area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = API (public C API and Fortran wrappers; 24 leads). Sweep EVERY library_*.c and library_*_f.c wrapper for the same patterns (unwrapped context handles, by-value Fortran scalars, argument order, symbol case), and compare every public prototype in scotch.h / ptscotch.h against what the library really exports (nm -D).
```

## 21. Agent · Audit DGR area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = DGR (distributed graph and mesh core, PT-Scotch; 22 leads). Use mpirun --oversubscribe and a malloc/realloc fault-injection shim (LD_PRELOAD) for the allocation-failure and rank-asymmetry findings; do actually run them this time where feasible. Sweep every dgraph_*/dmesh_* routine for the rank-asymmetric early return before a collective.
```

## 22. Agent · Audit DMO area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = DMO (distributed mapping and ordering, PT-Scotch; 19 leads). Use mpirun --oversubscribe and a malloc/realloc fault-injection shim (LD_PRELOAD) for allocation-failure findings; do actually run them where feasible. Sweep every hdgraph_*/kdgraph_*/vdgraph_*/bdgraph_*/dorder_* routine for the same patterns.
```

## 23. Agent · Audit CLI area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = CLI (command-line tools, esMUMPS, METIS/ParMETIS shim; 24 leads). Build the shim/esmumps targets in your own copy of the asan tree. Sweep EVERY tool in src/scotch (gmk_*, amk_*, gout_*, gcv, atst, ...) and EVERY METIS/ParMETIS wrapper for the same patterns, and diff the shim's argument handling against the METIS 5 / ParMETIS 4 headers' documented conventions (NULL vs Fortran null pointers, options[] semantics, ubvec, ncon).
```

## 24. Agent · Audit BLD area on 7.0.17

_first pass (Sonnet 5.5)_

```
Read /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/brief_audit.md and follow it exactly. PREFIX = BLD (build system, tests, CI; 25 leads). The first pass could not run CMake (not installed). You probably can: try `uv pip install --target SCRATCH/work2/BLD/cmake cmake` (PyPI ships a cmake wheel) and use it on a COPY of the 7.0.17 source, so the CMake findings are actually run. Do not touch any CI secret or contact any service other than the package index; judge the Sonar-token finding from the script text. Sweep every tests/ program (src/check, src/libscotch/test_*) for tests that cannot fail (exit 0 on bad results), by mutation where you can.
```

## 25. Agent · G01 arch-sub-dist audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G01-arch-sub-dist. Items: COR-02, COR-03, COR-04, COR-05, PS-COR-3, COR-27 (target-architecture loaders: arch.c, arch_sub.c, arch_dist.c/.h, arch_cmplt.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G01-arch-sub-dist.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (COR-02 was fixed there by d555f2c: study how).

Group-specific notes: COR-03/COR-04/PS-COR-3 are all in archSubArchLoad/archSubArchBuild/archSubArchFree; the maintainer would most likely want ONE coherent ownership protocol for the sub-architecture's inner Arch and tables, not three guards. COR-05 (dist) raises a design question: allocate and own the inner Arch, or reject 'dist' in target files; give both as real diffs and argue which he would take (look at how arch_dist is used from library_arch.c and gmap's -b / dist options). COR-27 is in archCmpltMatchMate; check whether the alternate pass is reachable at all. Verify the test_scotch_arch / check_prog_atst / check_prog_amk targets after your series, and add malformed-target cases to test_scotch_arch.c only if that file's style allows it naturally.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 26. Agent · G04 strategy-parser audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G04-strategy-parser. Items: COR-01, COR-22, COR-23, COR-12, COR-26, COR-13, COR-25 (strategy parser: parser_yy.y, parser_ll.l, parser.c, parser.h).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G04-strategy-parser.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (COR-12 e1700d7 and COR-25 a94688c were fixed there: study how, and check them for completeness).

Group-specific notes: the parser files are bison/flex sources; the tree also ships pre-generated "last_resort" parser files (see commit 38cbde4 "Update last_resort parser files for v7.0.17") — find out whether a patch to parser_yy.y / parser_ll.l must also regenerate those files to be mergeable, and do what the maintainer does. COR-01 (NULL context in the error action), COR-22 (strategy value stored into a non-strategy parameter slot) and COR-23 (leaked partial nodes on abort) all touch the same mid-rule/error machinery: the maintainer would want one coherent design, not three patches that fight; think about the error-recovery state as a whole. For COR-13 (test-expression printer parenthesisation) build a differential check: parse, print, re-parse, compare for a corpus of expressions. For COR-26 (modulus by zero, unchecked literal conversion) the check_strat_seq / check_strat_par targets and a mutated-strategy fuzz loop (the first pass ran 2264 mutations) are your evidence. Run check_strat_seq, check_strat_par, check_scotch_graph_map, check_scotch_graph_order after your series.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 27. Agent · G12 overlap-kgraph-rb audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G12-overlap-kgraph-rb. Items: SEP-01, SEP-17, API-22, GRA-01, GRA-21, GRA-23, GRA-05 (wgraph_part_rb.c, library_graph_part_ovl.c, kgraph_map_rb*.c, mapping.c, kgraph_band.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G12-overlap-kgraph-rb.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch.

Group-specific notes: GRA-01 (hash table sized from vflonbr instead of vfixnbr -> infinite probe loop with zero-weight fixed vertices) looks like a one-token fix; make sure it is the WHOLE fix (hash fill ratio, every sizing site in kgraph_map_rb.c and kgraph_map_rb_map.c / kgraph_map_rb_part.c) and write a test with fixed vertices of weight zero for check_scotch_graph_map (test_scotch_graph_map.c may be a natural home; BLD-16, owned by another group, says that test is lax — do not fix BLD-16, just add your case in the file's style). GRA-05 (remap to more parts: SEGV in archCmpltDomIncl from kgraph_band.c) and GRA-23 (invalid terminal domain accepted) are both about remapping; the shipped test_scotch_graph_map_copy / check_prog_gpart_remap targets are your regression harness. SEP-01 / SEP-17 are in wgraphPartRb: an empty part after bipartition; the maintainer's bgraph/kgraph code has a pattern for "empty part" recursion — find it and mirror it. API-22 is the overlap viewer continuing on NULL after an out-of-memory message; fault injection with an LD_PRELOAD malloc settles it. Run check_scotch_graph_map, check_scotch_graph_map_copy, check_scotch_graph_part_ovl, check_prog_gpart, check_prog_gpart_overlap, check_prog_gpart_remap, check_prog_gmap after your series.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 28. Agent · G13 kgraph-fm-df-bd audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G13-kgraph-fm-df-bd. Items: GRA-02, GRA-17, GRA-12, GRA-18, GRA-19, GRA-20, GRA-16 (kgraph_map_fm.c, kgraph_map_df.c, kgraph_cost.c, kgraph_map_bd.c/.h, plus the bit-set shift sites of GRA-16 in hgraph_order_cp.c, hmesh_order_cp.c, library_dgraph_map_stat.c, mesh_induce_sepa.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G13-kgraph-fm-df-bd.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (GRA-16 was fixed there by 6a00c51 "apply left shifts to unsigned integers in bit sets": verify that fix is complete across the whole tree, i.e. grep every `1 << ` / `<<=` on a signed operand that can reach 31 or 63).

Group-specific notes: GRA-02 (k-way FM keeps a stale domnnbr after its fallback strategy creates more domains -> heap overflow) is high severity and reachable from the default strategy under imbalance; the first pass's fix "refresh domnnbr after the fallback" must be checked against every later use of the saved count in kgraphMapFm (and GRA-17, table growth ignoring a failed realloc, is in the same routine: one coherent error-handling design for the hash table growth). GRA-12 (diffusion band mapping skipping its thread barriers when an anchor is isolated -> hang) needs a threaded run (SCOTCH_PTHREAD is on in the build; use a graph that makes an anchor isolated); GRA-18 (copy from the wrong buffer after the pass swap, results depend on pass count) is a silent-wrong-result bug: build a differential test (1 pass vs 2 passes vs expected). GRA-19 / GRA-20 are dead-code / self-comparison bugs: the fix must make the intended check live and you must show a case where it now triggers. Run check_scotch_graph_map, check_prog_gmap, check_prog_gpart, check_scotch_graph_order, check_scotch_mesh_graph after your series, in both 32-bit and 64-bit trees.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 29. Agent · G14 graph-loaders audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G14-graph-loaders. Items: GRA-04, GRA-10, GRA-07, GRA-08, GRA-11, GRA-24, GRA-09, PS-API-5 (graph_io.c, graph_io_mmkt.c, graph_io_chac.c, graph_io_habo.c, graph_io_scot.c, graph_check.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G14-graph-loaders.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (GRA-04/GRA-10 were partially addressed by febaef7 "Prevent reading negative graph edge values": study exactly what it rejects and what it still lets through).

Group-specific notes: these are all file loaders that trust file contents; the maintainer's febaef7 shows how he validates (where in the read loop, which errorPrint text). Your series should give graphLoad2 ONE coherent validation of labels and edge ends (range, base, duplicates where cheap) rather than scattered guards, and apply the same discipline to the Chaco, Matrix Market and Harwell-Boeing loaders (GRA-07/08/11/24). These loaders are also fuzz targets: write a small mutation fuzzer over the shipped .grf / .mtx / .chac / .rsa samples in src/check/data and run it against the ASan build before and after (count sanitizer hits; the brief's first-pass harness did 2264 strategy mutations, do the same here for files). PS-API-5 (graph check accepts duplicate labels) raises a design question: is it graphCheck's job, or the loader's? Look at how vlbltax is used downstream (graphLoad2's label-to-index step, gout, gmap -o) before deciding; give both options. GRA-09 (geometry loader keeps the dimension count in a local) is a silent-empty-output bug: show the saved geometry before and after. Run check_prog_gbase, check_prog_gmk, check_prog_gout, check_scotch_graph_dump, check_prog_gpart and the gcv conversion checks after your series.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 30. Agent · G25 metis-graph-part audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G25-metis-graph-part. Items: CLI-02, CLI-03, CLI-06, CLI-07, CLI-08, CLI-19 (src/libscotchmetis/metis_graph_part.c, metis_options.c, metis_graph_order.c, parmetis_dgraph_part.c for the shared converters).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G25-metis-graph-part.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch.

Group-specific notes: this is the METIS v5 / v3 compatibility layer; the libscotchmetis directory builds TWO libraries (libscotchmetisv3, libscotchmetisv5) from the same sources with -DSCOTCH_METIS_VERSION, and the ParMETIS layer (parmetis_dgraph_part.c) shares the ubvec / weight conversion problem (CLI-03, CLI-07, CLI-08). The maintainer would want ONE shared helper for "METIS ubvec / tpwgts / vwgt -> Scotch imbalance and loads" used by all entry points, not per-call patches; the first pass sketched one — check whether it belongs in metis_graph_part.c, in a new file, or in an existing common file, and how the Makefile and CMakeLists must list it. CLI-02 (NULL ubvec dereference) and CLI-06 (options arrays filled with -1 hang or crash) are crashes reachable from every METIS caller: test with test_libmetis.c (check_libmetis_v3, check_libmetis_v5, check_libmetis_dual_*) and extend that test program with the NULL-ubvec, ncon>1 and options=-1 cases in its style. CLI-03 is a silent-quality bug (1.05 requested, ~2x allowed): measure imbalance before/after on a real partition. CLI-19 (edge cut vs volume objective swapped depending on vsize) needs a differential check against what libmetis documents (METIS_OBJTYPE_VOL). Consult the official METIS 5.1 manual semantics from memory; state what you assume. Run check_libmetis_v3, check_libmetis_v5, check_libmetis_dual_v3, check_libmetis_dual_v5, check_libparmetis_v3 after your series, in the 32-bit and 64-bit trees.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 31. Agent · G18 dgraph-fold-redist audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G18-dgraph-fold-redist. Items: DGR-01, DGR-02, DGR-22, PS-DGR-4, DGR-04, DGR-14, DGR-10, API-04 (dgraph_fold.c, dgraph_fold_comm.c, dgraph.c, dgraph_redist.c, dgraph_gather_all.c, library_dgraph_gather.c, library_dgraph_redist.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G18-dgraph-fold-redist.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch. Pay special attention to his 7.0.17 commits 3c9b3ab "Rework error handling and structure of dgraphInduce()", 0635547 (hdgraphGather), 3436099 (hdgraphInduce), 7e17084 / 0a05434 (dgraphFoldComm), b10825d (parameter check in SCOTCH_dgraphRedist), 73229e6 (overflow check in commGatherv): they show exactly how he now structures collective error handling (the "reduglbtab" / status-gate idiom, where the collective agreement goes, what gets freed where). Your fold / redist / gather patches must use the same structure, not a different one.

Group-specific notes: DGR-01 (fold receiver aborts after senders posted edge data: undrained requests, peers hang, use-after-free) is high and needs a collective status gate BEFORE the point of no return; DGR-02 (folded graph baseval stays 0 while arrays are offset) is in the same routine; PS-DGR-4 says fold error exits are not collective in release builds: these three are one design problem, solve it once. DGR-04 (caller-permuted redistribution corrupts the graph: in-place unpack in destination order over a shared buffer) is a silent-corruption bug through a public API; test_scotch_dgraph_redist.c is the natural home for a permutation case: add one and prove pristine fails it (dgraphCheck on the result) and patched passes. DGR-22 (Gnum lengths passed as int MPI counts) interacts with the 64-bit build; show the overflow boundary. For MPI faults use mpirun --oversubscribe -np 3/4 with ASAN_OPTIONS=detect_leaks=0; for allocation failures write an LD_PRELOAD malloc that fails on rank R at call N (the brief asks for it). Run check_scotch_dgraph_redist, check_scotch_dgraph_check, check_scotch_dgraph_induce, check_scotch_dgraph_order, check_prog_dgmap-style targets (grep CHECKPTSCOTCH) after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 32. Agent · G08 bgraph-gg-gain audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G08-bgraph-gg-gain. Items: SEP-06, SEP-11, SEP-13, SEP-19, SEP-20, PS-SEP-3 (bgraph_bipart_gg.c/.h, gain.c/.h, and the ABS sites of SEP-20 across bgraph_bipart_fm.c, bgraph_bipart_ga.c, bgraph_bipart_st.c, vgraph_separate_fm.c, vmesh_separate_fm.c, wgraph_part_rb.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G08-bgraph-gg-gain.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (SEP-06 2d94960, SEP-19 fd6c780, SEP-20 f545452 were fixed there: verify completeness, e.g. grep every abs( on a Gnum/Anum in the whole tree).

Group-specific notes: SEP-13 is the one PyScotch cares most about: the threaded bgraphBipartGg() seeds worker PRNGs from state thread 0 is concurrently advancing, and ignores SCOTCH_DETERMINISTIC; PyScotch ships infra/scotch-7.0.17-bgraph-bipart-gg-determinism.patch as a behavioural patch (read it, and the status text in /home/dev/workspace/pyscotch/upstream/QUESTIONS_FOR_SCOTCH_TEAM.md around the "bgraphBipartGg" entry, read-only). Your job is to turn that into something the maintainer would merge: question every choice in it (the `descptr != NULL` guard; collapsing to one thread when deterministic vs. seeding all workers deterministically and keeping the threads — look at how graphMatchInit / kgraph_map_df / bgraph_bipart_df handle CONTEXTOPTIONNUMDETERMINISTIC in 7.0.17 and copy THAT idiom; the new randdat field in BgraphBipartGgThread and whether contdat/contptr juggling can be simplified; the removed intRandSpawn in the worker), produce the minimal coherent commit, and prove it with: ThreadSanitizer (infra/tsan shows how the first pass built one; rebuild your own at -O1 -fsanitize=thread on your tree) on gpart with 4 threads, and N fresh-process determinism runs (SCOTCH_DETERMINISTIC=1, 2 and 4 threads, 30 runs each: one distinct partition). SEP-11 (tied communication loads resolved by signed imbalance across threads) is in the same reduction: fix in the same series and show a case. PS-SEP-3 (gainTablAddLog writes the file-static gainLinkDummy sentinel from several threads): decide between a per-table sentinel, a thread-local one, or making the write conditional; measure (TSan) and argue what he would take given gain.h's structure. Run check_scotch_graph_map, check_prog_gpart, check_prog_gmap, check_common_random, check_common_thread, check_scotch_context after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 33. Agent · G09 bgraph-df-ga-fm audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G09-bgraph-df-ga-fm. Items: SEP-05, SEP-14, SEP-04, SEP-12, SEP-09, SEP-10, PS-SEP-5, GRA-26 (bgraph_bipart_df.c, bgraph_bipart_ga.c, bgraph_bipart_fm.c, bgraph.c, bgraph_check.c, bgraph_bipart_ml.c / kgraph_map_ml.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G09-bgraph-df-ga-fm.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (SEP-05 f37f70d was fixed there: verify completeness).

Group-specific notes: another agent (G08) owns bgraph_bipart_gg.c/.h and gain.c/.h; do not patch those files (if you find something there, report it in extra.json with a note). SEP-04 (genetic crossover modulo zero on a 2-vertex graph) and SEP-12 (genetic threads read parents while others overwrite the shared sort table; shared random state) are both in bgraph_bipart_ga.c: a ThreadSanitizer build (-O1 -fsanitize=thread, see infra/tsan for how the first pass built one) is your evidence for SEP-12, and the per-thread PRNG idiom that G08 is establishing in bgraphBipartGg (spawn worker generators in the launcher with intRandSpawn before contextThreadLaunch; thread 0 only when CONTEXTOPTIONNUMDETERMINISTIC is set, as graphMatchInit does) is what the maintainer will expect here too: mirror it, do not invent a second idiom. SEP-14 (diffusion NaN branch indexing past the thread-local range; allocation failure leaving a garbage result): fault injection with an LD_PRELOAD malloc, and a graph that produces NaN. SEP-09 (FM keeps probing a hash table it just freed after failed growth): fault injection on the memRealloc. SEP-10 / PS-SEP-5 (bgraphZero adds fixed load to part 0 unlike init and the checker; bgraphSwal recomputes both fixed loads): decide ONE convention for compload0 vs fixed loads across bgraph.c, bgraph_check.c, bgraph_bipart_zr.c, bgraph_store.c and every method that recomputes loads, and make the checker enforce it under SCOTCH_DEBUG_BGRAPH2; prove with a fixed-vertex mapping run under a debug build. GRA-26 (non-zero offset applied to a NULL pointer on base-1 graphs, UBSan): grep the whole tree for the `tab - baseval` on a possibly-NULL array pattern and settle whether the maintainer's convention is "guard at the site" or "never compute the tax for NULL tabs"; look at how 7.0.17 code handles velotax/vlbltax NULL cases. Run check_scotch_graph_map, check_prog_gpart, check_prog_gmap, check_scotch_graph_order, check_scotch_context after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 34. SendMessage · Forward PS2-G08-2 lead to G12 agent

_second pass, wave 1 (Fable 5.1)_

```
Extra lead for your group (kgraph_map_rb*): the G08 agent found that kgraph_map_rb_part.c:316 (7.0.17) splits the context with a second random stream whenever >= 2 threads are available, regardless of CONTEXTOPTIONNUMDETERMINISTIC, so with SCOTCH_DETERMINISTIC=1 a 1-thread run differs from a >= 2-thread run even after bgraphBipartGg is fixed (G08 made 2 == 4 == 8 threads identical; 1 still differs). G08 recorded it as PS2-G08-2 and did not patch it (your files). Please treat it as one of your items: verify it (gpart -b with SCOTCH_DETERMINISTIC=1 at 1 vs 2 threads, same seed), look at how graphMatchInit / contextThreadLaunch handle the deterministic option in 7.0.17 and at common_context.c's split routine, and give the maintainer the two real options ("do not split when deterministic" vs "document that deterministic means >= 2 threads") with your recommendation and a patch for the recommended one if you are confident. Record it in your extra.json as PS2-G12-n with related_ids ["SEP-13"].
```

## 35. Agent · G11 mesh-struct-io audit

_second pass, wave 1 (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G11-mesh-struct-io. Items: SEP-07, PS-SEP-1, SEP-23, SEP-21, SEP-08, API-08, SEP-16, API-06, API-12 (mesh.h, mesh.c, hmesh.c, hmesh_mesh.c, mesh_io.c, mesh_io_habo.c, mesh_io_scot.c, library_mesh.c, library_mesh_io_habo_f.c, library_mesh_graph.c, library_graph_dump.c, library_dmesh_dgraph.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G11-mesh-struct-io.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (SEP-07 by 813ef60 "variable type"?/check the right commit, SEP-21 f36ab36, API-06 6a030db, API-12 partially by the same: verify each for completeness; API-12 says graph-dump and mesh/dmesh builder handles still skip CONTEXTOBJECT unwrapping).

Group-specific notes from the already-finished graph-loader agent (G14): it fixed GRA-09 in graph_io_scot.c (geometry loader keeps the dimension count in a local, so the saved geometry is empty) and says meshGeomLoadScot in mesh_io_scot.c has the IDENTICAL defect, and that meshLoad (mesh_io.c) trusts header counts the way graphLoad did before its patch 0001 (negative / out-of-range values indexing arrays). Its patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G14-graph-loaders/patches/ — read 0001 and 0006 and make your mesh fixes the exact twins (same validation placement, same errorPrint wording pattern), so the maintainer sees one discipline. PS-SEP-1 (mesh flag values for "vertex arrays grouped" and "free other arrays" collide in mesh.h, freeing an invalid pointer) is an enum/flag design fix: check every user of MESHFREE* / MESHVERTGROUP flags across mesh*.c, hmesh*.c, dmesh*.c, library_mesh*.c and the Fortran wrappers before renumbering; prove the double/invalid free with a build that groups the arrays. SEP-23 (mesh and halo-mesh rebasing leave load arrays and halo end array on the old base) wants a gbase-style round-trip test (mbase? check what tools exist: mcv, mtst, mord) in src/check in the file's style. SEP-08 / API-08 / SEP-16 are the Harwell-Boeing and Scotch-geometry mesh loaders: fuzz them with a small mutation loop over src/check/data/*.msh / *.rsa like G14 did (its fuzzer is in its work dir; reuse it). Run check_prog_mmk, check_prog_mcv, check_prog_mord, check_scotch_mesh_graph, check_scotch_mesh_build_f, check_scotch_graph_dump after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 36. Agent · G09 bgraph-df-ga-fm audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G09-bgraph-df-ga-fm. Items: SEP-05, SEP-14, SEP-04, SEP-12, SEP-09, SEP-10, PS-SEP-5, GRA-26 (bgraph_bipart_df.c, bgraph_bipart_ga.c, bgraph_bipart_fm.c, bgraph.c, bgraph_check.c, bgraph_bipart_ml.c / kgraph_map_ml.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G09-bgraph-df-ga-fm.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (SEP-05 f37f70d was fixed there: verify completeness).

Group-specific notes: another agent (G08) owns bgraph_bipart_gg.c/.h and gain.c/.h; do not patch those files (if you find something there, report it in extra.json with a note). G08 has FINISHED: its series is in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G08-bgraph-gg-gain/patches/ and its SUMMARY.md is next to it; read them, because the per-thread PRNG idiom it established in bgraphBipartGg (spawn worker generators in the launcher with intRandSpawn before contextThreadLaunch; thread 0 only when CONTEXTOPTIONNUMDETERMINISTIC is set, as graphMatchInit does) is what the maintainer will expect here too: mirror it exactly, do not invent a second idiom. SEP-04 (genetic crossover modulo zero on a 2-vertex graph) and SEP-12 (genetic threads read parents while others overwrite the shared sort table; shared random state) are both in bgraph_bipart_ga.c: a ThreadSanitizer build (-O1 -fsanitize=thread, see infra/tsan for how the first pass built one) is your evidence for SEP-12. SEP-14 (diffusion NaN branch indexing past the thread-local range; allocation failure leaving a garbage result): fault injection with an LD_PRELOAD malloc, and a graph that produces NaN. SEP-09 (FM keeps probing a hash table it just freed after failed growth): fault injection on the memRealloc. SEP-10 / PS-SEP-5 (bgraphZero adds fixed load to part 0 unlike init and the checker; bgraphSwal recomputes both fixed loads): decide ONE convention for compload0 vs fixed loads across bgraph.c, bgraph_check.c, bgraph_bipart_zr.c, bgraph_store.c and every method that recomputes loads, and make the checker enforce it under SCOTCH_DEBUG_BGRAPH2; prove with a fixed-vertex mapping run under a debug build. GRA-26 (non-zero offset applied to a NULL pointer on base-1 graphs, UBSan): grep the whole tree for the `tab - baseval` on a possibly-NULL array pattern and settle whether the maintainer's convention is "guard at the site" or "never compute the tax for NULL tabs"; look at how 7.0.17 code handles velotax/vlbltax NULL cases. Run check_scotch_graph_map, check_prog_gpart, check_prog_gmap, check_scotch_graph_order, check_scotch_context after your series, 32-bit and 64-bit.

A previous agent for this group was killed mid-run; its partial work dir was moved to .../scratchpad/work/_dead/G09-bgraph-df-ga-fm.*/ (no deliverables were written). You may look at it for leftovers (build trees, reproducers) but you start from scratch in a fresh $WORK and verify everything yourself.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 37. Agent · G11 mesh-struct-io audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G11-mesh-struct-io. Items: SEP-07, PS-SEP-1, SEP-23, SEP-21, SEP-08, API-08, SEP-16, API-06, API-12 (mesh.h, mesh.c, hmesh.c, hmesh_mesh.c, mesh_io.c, mesh_io_habo.c, mesh_io_scot.c, library_mesh.c, library_mesh_io_habo_f.c, library_mesh_graph.c, library_graph_dump.c, library_dmesh_dgraph.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G11-mesh-struct-io.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (SEP-07 by 813ef60 "variable type"?/check the right commit, SEP-21 f36ab36, API-06 6a030db, API-12 partially by the same: verify each for completeness; API-12 says graph-dump and mesh/dmesh builder handles still skip CONTEXTOBJECT unwrapping).

Group-specific notes from the already-finished graph-loader agent (G14): it fixed GRA-09 in graph_io_scot.c (geometry loader keeps the dimension count in a local, so the saved geometry is empty) and says meshGeomLoadScot in mesh_io_scot.c has the IDENTICAL defect, and that meshLoad (mesh_io.c) trusts header counts the way graphLoad did before its patch 0001 (negative / out-of-range values indexing arrays). Its patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G14-graph-loaders/patches/ — read 0001 and 0006 and make your mesh fixes the exact twins (same validation placement, same errorPrint wording pattern), so the maintainer sees one discipline. PS-SEP-1 (mesh flag values for "vertex arrays grouped" and "free other arrays" collide in mesh.h, freeing an invalid pointer) is an enum/flag design fix: check every user of MESHFREE* / MESHVERTGROUP flags across mesh*.c, hmesh*.c, dmesh*.c, library_mesh*.c and the Fortran wrappers before renumbering; prove the double/invalid free with a build that groups the arrays. SEP-23 (mesh and halo-mesh rebasing leave load arrays and halo end array on the old base) wants a gbase-style round-trip test (mbase? check what tools exist: mcv, mtst, mord) in src/check in the file's style. SEP-08 / API-08 / SEP-16 are the Harwell-Boeing and Scotch-geometry mesh loaders: fuzz them with a small mutation loop over src/check/data/*.msh / *.rsa like G14 did (its fuzzer is in its work dir; reuse it). Run check_prog_mmk, check_prog_mcv, check_prog_mord, check_scotch_mesh_graph, check_scotch_mesh_build_f, check_scotch_graph_dump after your series, 32-bit and 64-bit.

A previous agent for this group was killed mid-run; its partial work dir was moved to .../scratchpad/work/_dead/G11-mesh-struct-io.*/ (no deliverables were written). You may look at it for leftovers (build trees, reproducers, a rep.py helper) but you start from scratch in a fresh $WORK and verify everything yourself.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 38. Agent · G18 dgraph-fold-redist audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G18-dgraph-fold-redist. Items: DGR-01, DGR-02, DGR-22, PS-DGR-4, DGR-04, DGR-14, DGR-10, API-04 (dgraph_fold.c, dgraph_fold_comm.c, dgraph.c, dgraph_redist.c, dgraph_gather_all.c, library_dgraph_gather.c, library_dgraph_redist.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G18-dgraph-fold-redist.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch. Pay special attention to his 7.0.17 commits 3c9b3ab "Rework error handling and structure of dgraphInduce()", 0635547 (hdgraphGather), 3436099 (hdgraphInduce), 7e17084 / 0a05434 (dgraphFoldComm), b10825d (parameter check in SCOTCH_dgraphRedist), 73229e6 (overflow check in commGatherv): they show exactly how he now structures collective error handling (the "reduglbtab" / status-gate idiom, where the collective agreement goes, what gets freed where). Your fold / redist / gather patches must use the same structure, not a different one.

Group-specific notes: DGR-01 (fold receiver aborts after senders posted edge data: undrained requests, peers hang, use-after-free) is high and needs a collective status gate BEFORE the point of no return; DGR-02 (folded graph baseval stays 0 while arrays are offset) is in the same routine; PS-DGR-4 says fold error exits are not collective in release builds: these three are one design problem, solve it once. DGR-04 (caller-permuted redistribution corrupts the graph: in-place unpack in destination order over a shared buffer) is a silent-corruption bug through a public API; test_scotch_dgraph_redist.c is the natural home for a permutation case: add one and prove pristine fails it (dgraphCheck on the result) and patched passes. DGR-22 (Gnum lengths passed as int MPI counts) interacts with the 64-bit build; show the overflow boundary. For MPI faults use mpirun --oversubscribe -np 3/4 with ASAN_OPTIONS=detect_leaks=0; for allocation failures write an LD_PRELOAD malloc that fails on rank R at call N (the brief asks for it). Run check_scotch_dgraph_redist, check_scotch_dgraph_check, check_scotch_dgraph_induce, check_scotch_dgraph_order, check_prog_dgmap-style targets (grep CHECKPTSCOTCH) after your series, 32-bit and 64-bit.

A previous agent for this group was killed in its LAST step: its work dir was moved to .../scratchpad/work/_dead/G18-dgraph-fold-redist.*/ and contains an audit.json, 7 exported patches, alt diffs, reproducers (including an LD_PRELOAD fault-injection shim "fishim" and a scan.sh driver under repro/common) but NO SUMMARY.md, so its series was never re-applied/validated and its extra.json is missing. Treat all of it as CLAIMS, like the first pass: read it, reuse what you verify (the fault-injection tooling in particular), redo every verification yourself, and produce your own complete deliverables in a fresh $WORK. Do not just copy its patches: audit each one against the brief and STYLE.md and fix what is wrong.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 39. Agent · G02 arch-tleaf-hcub-build audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G02-arch-tleaf-hcub-build. Items: COR-06, COR-19, PS-API-3, API-10, PS-API-2, PS-API-4, CLI-24 (arch_tleaf.c/.h, arch_hcub.c/.h, library_arch.c, library.h for the builders; src/scotch/amk_hy.c, gmk_hy.c, gmk_ub2.c, amk_fft2.c, amk_ccc.c for CLI-24), PLUS the tree-leaf half of COR-07 (archTleafArchLoad: levlnbr lower bound, size-product overflow, sizetab leak on error; the meshXD half of COR-07 belongs to G03).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G02-arch-tleaf-hcub-build.md  (your items; COR-07 is in groups/G03-arch-mesh-deco-misc.md, read that entry too)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (COR-19 c5baef9 "Set tighter boundary on hypercube dimension in archHcubArchLoad()" was fixed there for the bound only: the int shifts remain; study how he bounds and mirror it for tleaf/meshXD/builders).

Group-specific notes: G01 (arch.c, arch_sub.c, arch_dist.c, arch_cmplt.c) has FINISHED; its series is in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G01-arch-sub-dist/patches/ with a SUMMARY.md: read them first. It established the ownership/validation discipline for architecture loaders and builders (unconditional checks, loader rejects bad counts, builder publishes only on success) and touched archBuild2 in library_arch_build.c / library_arch.c; if any of your commits must touch a file G01 changed, apply G01's series on your branch first (git am) and base your commits on top, and say so in SUMMARY.md, so both series apply in order on v7.0.17. COR-06 (ltleaf permutation validated only in debug) and API-10 (builders skip the loaders' checks) and PS-API-4 (builders leave clasptr set with dangling arrays after a failed allocation) are one design: the maintainer would want ONE validation routine per architecture class shared by the file loader and the library builder (look at how archTleafArchLoad / SCOTCH_archTleaf / SCOTCH_archLtleaf duplicate code today, and how G01 structured archSub), with the builder's publish-on-success protocol G01 used. COR-19 / PS-API-3 / CLI-24 are all "int 1 << dim" on an Anum/SCOTCH_Num: grep the whole tree (libscotch, scotch tools, check) for every shift of a literal 1 by a user-controlled width and cover them all in one commit, following 6a00c51 (the maintainer's own bit-set shift fix) for the cast style; the 64-bit tree is where the 31..62 range matters, show it with UBSan. PS-API-2 (SCOTCH_archLtleaf exported but undeclared in library.h): check library.h, library_f.h, the Fortran wrapper and the man/doc for every arch builder, and whether a Fortran twin SCOTCH_FARCHLTLEAF exists or should (API-* Fortran consistency is G17's; just report in extra.json if a Fortran twin is missing). CLI-24: dimension bounds in the generators; the tools print usage via their own errorPrint idiom, keep it. Run check_scotch_arch, check_scotch_arch_deco, check_prog_amk, check_prog_atst, check_prog_gmk and check_prog_gmap targets after your series, 32-bit and 64-bit. Fuzz the target-file loaders (tleaf, ltleaf, hcub) with a small mutation loop over the shipped .tgt samples and sanity .tgt strings, ASan build, before and after, count sanitizer hits.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 40. Agent · G03 arch-mesh-deco-misc audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G03-arch-mesh-deco-misc. Items: COR-07 (its meshXD half only; the tree-leaf half is G02's), COR-14, COR-21, COR-16, PS-COR-1, COR-28, COR-20 (arch_mesh.c/.h, arch_deco.c/.h, arch_cmpltw.c, fibo.h, dummysizes.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G03-arch-mesh-deco-misc.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (COR-14 feecf0d "make archMeshXDomDist() consistent with mesh distances" was fixed there: verify completeness, e.g. archMeshXDomDist vs the 2D/3D versions and the matching code; d555f2c touched the sizetab leak indirectly).

Group-specific notes: two finished groups touched your neighbourhood. G01 (arch.c, arch_sub.c, arch_dist.c, arch_cmplt.c; series in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G01-arch-sub-dist/patches/ + SUMMARY.md) set the validation discipline for architecture loaders: unconditional checks, loader rejects bad counts with the maintainer's errorPrint wording, free everything on error. G25 (METIS shim) found PS2-G25-1: arch_cmpltw.c:184 frees the CALLER's weight array on a non-positive weight, and committed a fix as its patches/0001 in .../work/G25-metis-graph-part/; read it, verify it, and do NOT re-patch those lines: if your COR-21 work needs more in arch_cmpltw.c, apply G25's 0001 on your branch first and base on top, and say so in SUMMARY.md. COR-07 (meshXD dimnnbr lower bound; 'meshXD 0' reads c[-1]) and COR-21 (dimension products / weight sums overflow Anum in arch_mesh.c Mesh2/Mesh3/MeshX DomSize and arch_cmpltw.c) are one validation problem: ONE overflow-safe check at load time in the maintainer's style (look for an existing overflow idiom in the tree, e.g. 73229e6 commGatherv overflow check, or intLoad's debug check 6a552f9; do not invent a helper if one exists; if a small shared helper is the right thing, say where it goes and why). COR-16 (deco loader ignores archDecoArchBuild2's result; type-1 data never validated) and PS-COR-1 (terminal that is an ancestor of other terminals overflows the distance table) are the decomposition loader: make Build2's checks unconditional, propagate its result, validate the type-1 tree, and prove each with fuzzed .tgt files on the ASan build (mutation loop over shipped deco targets in src/check/data and the amk_* outputs; count hits before/after). COR-28 (fiboHeapDecreaseMacro names the caller's variables) is info: fix it only if the macro is still used and the fix is a pure rename; check every fibo user. COR-20 (dummysizes.c NULL file names, bogus debug block): dummysizes is the header generator run at build time; the fix must keep the build (both Makefile and CMake invoke it; check how) working, test it by building. Run check_scotch_arch, check_scotch_arch_deco, check_prog_amk, check_prog_atst, check_prog_acpl, check_prog_gmap after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 41. Agent · G05 strategy-tables-api audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G05-strategy-tables-api. Items: GRA-13, PS-DMO-2, GRA-06, GRA-15, API-07, API-23, CLI-01 (hgraph_order_st.c, the strategy tables of the other *_st.c files where the same defect pattern recurs, library_graph_map.c, library_graph_order.c, library_mesh_order.c, library_graph_part_ovl.c, library_dgraph_map.c, library_dgraph_order.c, library_arch_build.c, library_graph_coarsen.c, src/scotch/dgmap.c). You also own library_graph_map.c for two leads forwarded by finished groups (below).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G05-strategy-tables-api.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch.

Group-specific notes: GRA-13 (mdeg declared STRATPARAMDOUBLE but points at a Gnum) is a strategy-table typing bug: audit EVERY strategy parameter table in the tree (grep STRATPARAMDOUBLE / STRATPARAMINT / STRATPARAMSTRAT across *_st.c and library_*.c) for type/field mismatches, and write a compile-time or debug-time check if the maintainer's style allows (look at how parser.c validates tables under SCOTCH_DEBUG_PARSER). GRA-06 (conditional ordering strategy without else branch returns success with an unset ordering) and PS-DMO-2 (missing sequential-ordering parameter: warning then NULL strategy dereference) are the same family as G04's PS2-G04-strategy-parser-3 (NULL strategy defaults crash in b/n methods, fixed in G04's patches/0009 which touches bgraph_bipart_st.c, bdgraph_bipart_st.c, hdgraph_order_st.c). G04 has FINISHED: read /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G04-strategy-parser/SUMMARY.md and its patches 0002 (COR-01) and 0009 first; if your fix for GRA-06 / PS-DMO-2 touches hgraph_order_st.c or the same functions, apply G04's series on your branch first and base on top, and say so in SUMMARY.md; decide with evidence whether the maintainer's design is "reject at parse time" (parser) or "guard at use" (every *_st.c), and make all the *_st.c consistent with G04's choice, not a second idiom. GRA-15 (k-way FM fallback strategy leaked, result unchecked) is in kgraph_map_fm.c which G13 has FINISHED and patched for GRA-02 (its patches/0006 adds stratExit + error frees in that very spot): read .../work/G13-kgraph-fm-df-bd/patches/0006 and SUMMARY.md, verify whether GRA-15 is now fully covered by it; if yes, status it accordingly with that patch as the reference and do not re-patch; if something is missing, base on top of G13's series. API-07 (sprintf of a double into 32/64-byte stack buffers in all strategy builders, stack overflow with balrat = 1e300) is high-impact and reachable from PyScotch: ONE commit covering all 8 sites, with the format the maintainer would keep (check what the generated strings must parse back as: parser_ll.l's number grammar decides whether %g is acceptable; %lf with 1e300 is 300+ chars; also reject non-finite / negative ratios with the documented error code), and a test in test_scotch_graph_map.c / test_strat_*.c style. API-23 (ignored *Init results; coarsen returns 1 instead of 2 on context failure): fault injection with LD_PRELOAD malloc; one commit, consistent return codes per the library doc (check doc/src/ptscotch? the manual's statement on return values). CLI-01 (dgmap/dgpart discard -m): the fix is in src/scotch/dgmap.c mirroring dgord.c; add the same guard pattern wherever the tools rebuild defaults after parsing (grep stratDgraph*Build / stratGraph*Build in src/scotch). Forwarded leads you own: (a) PS2-G12-2 from G12: a mapping strategy with no initial-mapping method leaves parttax NULL and crashes in library_graph_map.c; G12 left an alt diff in .../work/G12-overlap-kgraph-rb/alt/PS2-G12-2-a*.diff tested only in a scratch tree; verify, decide, commit. (b) PS2-G13-1 from G13: graphMapCompute2 (library_graph_map.c:294-295) calls mapTerm unconditionally after an error path; see .../work/G13-kgraph-fm-df-bd/SUMMARY.md line ~30 and its extra.json for details; verify, decide, commit. Report both in your extra.json under their original ids. Run check_scotch_graph_order, check_scotch_graph_map, check_scotch_graph_map_copy, check_scotch_mesh_order, check_scotch_graph_part_ovl, check_strat_seq, check_strat_par, check_scotch_graph_coarsen, check_prog_dgmap / check_prog_dgpart style targets (grep CHECKPTSCOTCH) after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 42. Agent · G06 threads-context audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G06-threads-context. Items: COR-09, COR-10, COR-11, COR-24, API-02 (common_thread.c/.h, common_context.c/.h, library_context.c, library_context_f.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G06-threads-context.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (API-02 0f793bf "dynamic option setting strategy sets the proper parameters and returns the proper error" was fixed there: verify completeness, including SCOTCH_contextOptionParse's return value, the Fortran wrapper, and the doc).

Group-specific notes: this group is the thread/context core that PyScotch cares most about (the deterministic mode). Two finished groups built on it: G08 (bgraph_bipart_gg.c: per-thread PRNG spawned in the launcher with intRandSpawn; thread 0 only under CONTEXTOPTIONNUMDETERMINISTIC, as graphMatchInit does) and G12 (patches/0009: the recursive-bipartitioning context split in kgraph_map_rb_part.c ignored the deterministic option; G08 flagged this as PS2-G08-2, a design question "do not split the context when deterministic vs document >= 2 threads"). Read /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G08-bgraph-gg-gain/SUMMARY.md and .../work/G12-overlap-kgraph-rb/SUMMARY.md + patches/0009, then judge PS2-G08-2 from the common_context.c side: what contextSplit / contextThreadLaunchSplit should guarantee under the deterministic option, whether G12's fix is where the maintainer would put it or whether it belongs in common_context.c; do not re-patch kgraph_map_rb_part.c; if the right fix is in common_context.c, write it and say in SUMMARY.md how it relates to G12's 0009 (both? either?). Record this as an item in extra.json under id PS2-G08-2 (verdict + patch or alt). COR-09 (pthread_create failure hangs in a startup barrier sized for the original count; desctab leaked) and COR-10 (thread count 0 from SCOTCH_PTHREAD_NUMBER=0 hangs) are the same init routine: one coherent creation/teardown protocol (count what actually started; release the barrier with that count; destroy mutex/condvar on every path), proven with an LD_PRELOAD pthread_create that fails on the N-th call, and with the env var set to 0, under a build with COMMON_PTHREAD; also check threadContextInit2 / contextThreadImport paths. COR-11 (imported thread context restores an affinity mask that was never saved): reproduce by pinning the harness thread and watching sched_getaffinity after contextExit; decide between "save on import" and "no-restore exit path" by looking at how the maintainer structured threadProcessStateSave/Restore and its callers. COR-24 (explicit core table numbered differently from automatic placement; setaffinity result ignored): needs a cpuset to show; use taskset in the container and document exactly what you observed; if the container has no affinity support, say so (needs: other-platform) and give the diff anyway. Run check_common_thread, check_common_random, check_scotch_context, check_scotch_graph_map (with SCOTCH_PTHREAD_NUMBER 1, 2, 4 and SCOTCH_DETERMINISTIC=1) after your series, 32-bit and 64-bit; ThreadSanitizer build (-O1 -fsanitize=thread, see infra/tsan) for the barrier changes.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 43. Agent · G07 common-misc audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G07-common-misc. Items: COR-08, COR-15, COR-18, PS-SEP-6, COR-17, PS-COR-2 (common_file_compress.c, common_file_decompress.c, common_file.c, common_integer.c/.h, common.h for the random helpers, comm.c/.h).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G07-common-misc.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (COR-15 6a552f9 "Check overflow in intLoad() in debug mode": debug-only and claimed incomplete; COR-18 64ec683 "make all pseudo-random generators distinct across MPI processes": claimed fixed; COR-17 73229e6 "Add overflow check in commGatherv()": adds checks but keeps rank-local early exits, which is PS-COR-2; b41893e made intRandVal 64-bit wide, which is PS-SEP-6's context. Verify each for completeness.)

Group-specific notes: COR-15 (intLoad wraps on overflow; every loader relies on it) is the single most important item here because the finished loader groups (G14 graph loaders, G01 arch loaders, G11 mesh loaders in progress) added range checks that an overflowing intLoad can bypass: read /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G14-graph-loaders/SUMMARY.md and its patches/0001 to see what they assume from intLoad, then decide what the maintainer would do: an unconditional overflow check in intLoad (cost: measure on a large .grf load, before/after, since he put it under COMMON_DEBUG for a reason: find out whether that reason was performance by reading the commit and the guide), with the exact failure semantics (return 0 = error, value untouched?) that all callers already handle; cover intLoad's twins (the 64-bit variant, the string parsers in the tools, SCOTCH_Num parsing in library_*.c via sscanf/strtol if any) in the same commit; prove with the 'cmplt 4294967298' and the digit-string fuzz on both int sizes. COR-17 and PS-COR-2 (commGatherv/commScatterv return early on one rank before the collective) are one design: the maintainer's new status-gate idiom in 7.0.17 (3c9b3ab dgraphInduce, 7e17084/0a05434 dgraphFoldComm) shows how he agrees on errors collectively; G18 (dgraph fold/redist, running now) owns the callers in dgraph_*.c and must not patch comm.c, you own comm.c: make the wrappers themselves collective-safe (Allreduce of the error code before the collective, scalar range checks), with a cost note, and prove the hang on pristine with mpirun --oversubscribe -np 3 and an injected overflow / malloc failure on one rank (LD_PRELOAD shim that fails on rank R at call N; G18's dead predecessor left such a shim "fishim" in .../work/_dead/G18-dgraph-fold-redist.*/repro/common/ that you may reuse after reading it). COR-08 (fork-mode compression deadlocks with several compressed files; children exit() flushes parent stdio twice) needs a build WITHOUT COMMON_PTHREAD (edit Makefile.inc in a copy of the build tree) and two .gz outputs; fix with close-on-exec / closing sibling pipe ends and _exit(); check the decompress twin and the pthread path for the same inherited-fd problem. COR-18 (per-rank seed collisions): verify 64ec683 by actually printing per-rank streams under mpirun -np 4 with COMMON_RANDOM_FIXED_SEED on and off; status accordingly. PS-SEP-6 (intRandVal2 casts the 64-bit generator result through 32-bit UINT): check every caller that slices the value by bits (bgraphBipartGaLoop etc.) and whether dropping the cast changes results (determinism tests across versions matter to the maintainer: say whether shipped reference outputs change). Run check_common_file_compress, check_common_random, check_common_thread, check_prog_gbase/gcv with .gz/.bz2/.xz inputs (which libraries are available in the build: check Makefile.inc), check_scotch_dgraph_check / check_scotch_dgraph_grow / check_scotch_dgraph_redist for comm.c, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 44. SendMessage · Resume G09 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 45. SendMessage · Resume G11 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 46. SendMessage · Resume G18 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 47. SendMessage · Resume G02 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 48. SendMessage · Resume G03 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 49. SendMessage · Resume G05 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 50. SendMessage · Resume G06 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 51. SendMessage · Resume G07 after rate-limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and any files you already created are still on disk (check them rather than redoing them). Carry the whole task through to the deliverables listed in your original instructions (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 52. Agent · G10 mesh-separators audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G10-mesh-separators. Items: SEP-02, SEP-15, SEP-22, SEP-03, SEP-18, PS-SEP-2, PS-SEP-4 (mesh_induce_sepa.c, hmesh_order_nd.c, vmesh_separate_ml.c, vmesh_separate_fm.c, mesh_coarsen.c, vgraph_separate_fm.c, wgraph_part_fm.c, and hall_order_hd.c / hmesh_order_hd.c for PS-SEP-4).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G10-mesh-separators.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (SEP-18's mesh_coarsen.c print was removed by 0328b08 "Clean-up": verify; the wgraph_part_fm.c 'OUCH' print and the vmesh_separate_fm.c:155 one remain).

Group-specific notes: another agent (G11) is running NOW on mesh.h, mesh.c, hmesh.c, hmesh_mesh.c, mesh_io*.c, library_mesh*.c: do not patch those files; if your fix needs a change there (e.g. a mesh flag or a checker), put it in alt/ and report it in extra.json with a note naming G11. SEP-02 (meshInduceSepa reads node loads from the element-load array: ASan heap overflow from SCOTCH_meshOrder on an element-weighted mesh) is high and reachable from the public API: fix, and add an element- and node-weighted mesh ordering case to test_scotch_mesh_order.c? (check what exists: src/check has test_scotch_mesh_graph, mesh order tests; put the case where the file's style allows, with the mesh built in code like the existing tests). SEP-15 (hmeshOrderNd frees an interior pointer of a grouped allocation) and SEP-22 (error-path leaks, ignored return values in vgraphSeparateFm / meshInduceSepa / hmeshOrderNd) are the same error-handling discipline: one coherent cleanup per routine in the maintainer's goto/label style (look at how 7.0.17's 3c9b3ab restructured dgraphInduce for his current idiom), proven with LD_PRELOAD malloc fault injection on mord / SCOTCH_meshOrder. SEP-03 (mesh coarsening never reports failure to shrink: default SCOTCH_meshOrder on 300 disjoint triangles overflows the stack) is high: mirror graphCoarsen's coarrat / coarnbr contract exactly in meshCoarsen (read graph_coarsen.c for the return-value convention and the callers vmesh_separate_ml.c / hmesh_order_* that must handle "1 = could not coarsen"), and report matcher allocation failures; PS-SEP-4 (default ordering on disjoint-element meshes aborts with 'hallOrderHdR2Halmd: internal error (2)', cause not analysed) is probably the same family: analyse it properly, root-cause it, decide whether it is a halo-minimum-degree bug or a consequence of SEP-03, and give it its own status and patch if it is separate. PS-SEP-2 (vmeshSeparateFmResize prints and calls exit(1) after realloc: 'hertnum no longer valid'): this is unfinished code in a library; find a mesh that triggers the resize (large separator, small initial hash), then either finish the hash-table translation the way vgraphSeparateFmResize / bgraphBipartFmResize do it (mirror that code) or make the failure a proper error return; argue which the maintainer wants. SEP-18: delete the stray prints and turn the savenbr test in wgraphPartFm into a real check (look at what the bound should be and whether the write can overrun: fuzz with gpart -o / overlap partitioning). Run check_scotch_mesh_graph, check_prog_mord, check_prog_mmk, check_prog_mtst, check_scotch_graph_order, check_scotch_graph_part_ovl, check_prog_gpart_overlap, check_prog_gord after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 53. Agent · G15 order-io-seq-misc audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G15-order-io-seq-misc. Items: GRA-03, CLI-23, PS-BLD-1, GRA-25, GRA-22, GRA-14, GRA-27 (order_io.c, order_check.c, library_graph_order*.c for the order side; src/esmumps/order_io.c; hgraph_order_cp.c, hgraph_order_bl.c; graph_coarsen.c; graph_dump.c). You also own one forwarded lead: the ordering-side deterministic context split (PS2-G08-2-b, below), in hgraph_order_nd.c and hmesh_order_nd.c.

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G15-order-io-seq-misc.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (hgraph_order_cp.c was touched by 6a00c51 for bit sets only; GRA-22's indexing was changed by a90b1cb in 7.0.11: read that commit's intent before deciding what "correct" is).

Group-specific notes: GRA-03 (orderLoad trusts the vertex count and the permutation values in the file: ASan writes) and CLI-23 (esMUMPS orderLoad/orderSave: same, plus lost write errors) are twins: the finished loader group G14 (/tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G14-graph-loaders/patches/0001 + SUMMARY.md) set the validation discipline (where the checks go in the read loop, the errorPrint wording); make the ordering loaders the exact twins, in one commit, with a mutation fuzz over saved .ord files (G14's fuzzer is in its work dir, reuse it) on the ASan build before/after; add a malformed-ordering case to test_scotch_graph_order.c? check whether that test has a load step; if not, say why no test. PS-BLD-1 (SCOTCH_graphOrderCheck validates peritab but never the user's permtab): decide whether orderCheck should check consistency of permtab against peritab (cheap, O(n)); look at what the maintainer's orderCheck checks today and what the manual promises for SCOTCH_graphOrderCheck. GRA-25 (hgraphOrderCp leaks the coarse ordering tree on failure): fault injection; one cleanup path. GRA-22 (hgraphOrderBl sums weights in vertex order, not ordering order: blocks unbalanced on weighted graphs): this is a silent wrong-result lead where the first pass proposed a rewrite; be careful: read a90b1cb (7.0.11) to learn what the maintainer intended, build a differential test (weighted graph, block sizes with and without the fix, against the documented semantics of the 'b' method's cmin/cmax/strat), and prefer the minimal correct fix over a rewrite unless the rewrite is what he would do. GRA-14 (graphCoarsen2 reports success after out-of-memory: dangling verttax, ignored retuval, double free in graphExit) is medium and the coarsener is used by everything: fault injection on every allocation in graph_coarsen.c (sequential and threaded paths), one coherent error contract, and check how the other finished groups' callers (G12 kgraph_map_rb, G13, G08 bgraph_bipart_ml) consume the return value so the contract matches. GRA-27 (graphDump typo delotab/edlotab): fix, and compile a dumped graph with edge loads to prove it (check_scotch_graph_dump exists: see whether it covers edge loads; extend if natural). Forwarded lead PS2-G08-2-b, from the finished thread/context group G06: under SCOTCH_DETERMINISTIC=1 the nested-dissection ordering still differs between 1, 2 and 4 threads because hgraph_order_nd.c and hmesh_order_nd.c split the context with a second random stream, the same defect G12 fixed for kgraph_map_rb_part.c (its patches/0009 in .../work/G12-overlap-kgraph-rb/). G06 left a TESTED alternative in .../work/G06-threads-context/alt/PS2-G08-2-b*.diff (gord 1==2==4 threads with it) and explained in its SUMMARY.md why the fix belongs at the callers, not in common_context.c. Read those, verify, and turn it into a maintainer-grade commit in your series mirroring G12's 0009 exactly (same idiom, same wording), with 30 fresh-process determinism runs at 1, 2, 4 threads on gord as proof; report it in extra.json under id PS2-G08-2. Note: another agent (G10, mesh separators) is running NOW and patches hmesh_order_nd.c's ERROR path (SEP-15); your change is in its context-split hunk; if .../work/G10-mesh-separators/patches/ exists when you commit, apply G10's series first and base on top, and say so in SUMMARY.md; otherwise keep your hunk minimal so both apply. Run check_scotch_graph_order, check_scotch_graph_order_f? (grep the Makefile), check_scotch_graph_dump, check_scotch_graph_coarsen, check_prog_gord, check_prog_gotst, check_libesmumps, check_prog_gcv after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 54. Agent · G16 library-seq-api audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G16-library-seq-api. Items: API-03, API-14, API-16, PS-API-1, API-19, API-21, API-18, PS-API-7 (library_graph_map_view.c, library_graph_map_io.c, library_graph.c (graphStat), library_dgraph_stat.c, library_dgraph_map_view.c). Plus one forwarded lead: PS2-G03-2 from the finished group G03 (graphMapView2 clamps a low value; see .../work/G03-arch-mesh-deco-misc/extra.json and SUMMARY.md).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G16-library-seq-api.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (API-03 d604eb1 "preserve parttax array by using auxiliary part index array" was fixed there: verify completeness across MapView, RemapView and the Raw variants, and check that the distance computations now use the ORIGINAL part numbers, which was the second half of the lead).

Group-specific notes: another agent (G05) is running NOW on library_graph_map.c, library_graph_order.c and the strategy builders: do not patch those files. API-14 (part diameter off by one, base-1 last vertex never a root, -1 OOM return added to the average), API-16 (remap migration distance always zero: both domains from the old mapping), PS-API-1 (old-mapping array not base-adjusted in remap view: stack overflow on base-1 graphs) and PS2-G03-2 are all in library_graph_map_view.c: one coherent series on top of d604eb1, each proven with a differential test (small path graph with a known dilation / diameter / migration distance; the review gives exact expected values: use them), and fix the Fortran and Raw twins. The map-view output values are consumed by PyScotch's test bench and by gmap -v: say in SUMMARY.md exactly which printed numbers change for the shipped check data, because the maintainer will ask. API-19 (graphStat and dgraphStat report the edge-load sum at two scales) is a documented-output change: read the manual's definition of the statistic (doc/src/scotch/s_l.tex, SCOTCH_graphStat) and the gtst / dgtst outputs, choose the convention the doc supports, make both sequential and distributed agree, and update the doc if its wording is what changes. API-21 (SCOTCH_graphTabLoad reads one past mappsorttab): prove with ASan on a mapping file with duplicate labels. API-18 / PS-API-7 (distributed map view CommDelta formula wrong; histogram division without zero guard): make library_dgraph_map_view.c compute the same quantities as the sequential view, with a differential run (same graph, same mapping, gmap -v vs dgmap -v on 1 process must print identical statistics: make that your test and say whether it holds after your series). Run check_scotch_graph_map, check_scotch_graph_map_copy, check_prog_gmap, check_prog_gtst, check_prog_dgmap, check_prog_dgtst, check_scotch_dgraph_map? (grep the Makefile for the dgraph map/stat targets), check_scotch_graph_map_f? after your series, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 55. Agent · G17 fortran-wrappers audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G17-fortran-wrappers. Items: API-01, API-05, API-09, API-11, PS-API-6, API-13, API-24, BLD-20 (src/libscotch/library_*_f.c, library_f.h / library_pt_f.h, doc/src/scotch/s_l.tex and doc/src/ptscotch/p_l.tex Fortran sections, src/check/test_libmetis_dual_f.f90.in and the other *_f.f90 tests). Plus one forwarded lead from the finished group G02: PS2-G02-2, the documented Fortran twin scotchfarchltleaf is missing (G02 added the C declaration of SCOTCH_archLtleaf in library.h in its patches/0001 and left an alt diff for the Fortran wrapper in .../work/G02-arch-tleaf-hcub-build/alt/; read its SUMMARY.md).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G17-fortran-wrappers.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (API-01 259f38a "restore parameter order when calling from Fortran" and API-05 b189b87 "dereference integer values passed from the Fortran API" were fixed there: verify completeness by auditing EVERY wrapper, not just the named ones).

Group-specific notes: this group is a systematic audit, not five isolated fixes. Build a table of every documented Fortran routine (parse the two .tex manuals' Fortran synopses) against every SCOTCH_FORTRAN macro invocation in src/libscotch/*_f.c: name case (API-09 class), argument count and order (API-01 class), by-value scalars (API-05 class), int* vs SCOTCH_Num* / SCOTCH_Idx* (API-13 class), missing trailing ierr (API-11 class), documented-but-missing wrappers (API-24 + PS2-G02-2), wrappers-without-doc, and doc-vs-C ordering mismatches (PS-API-6). Write that table as a script in $WORK/repro/ (so the maintainer can re-run it) and make it the evidence for the whole group; cover PT-Scotch (library_dgraph*_f.c, library_dmesh*_f.c) and libscotchmetis's Fortran entry points if any. Then: one commit per defect class in the maintainer's style (look at how 259f38a and b189b87 are written: subject style, which files each touched, whether he bumped the .tex), with the doc change in the same commit when the doc is what's wrong. For API-24 (13 documented routines with no wrapper) decide per routine: add the wrapper (when the C routine is a plain function, mirror the neighbouring wrapper) or fix the manual; argue which he would do (check whether the missing ones were ever in older versions: git log -S in the clone). A Fortran compiler: check whether gfortran exists in the container (which gfortran; the check Makefile has *_f targets); if it does, run check_scotch_graph_part_f? / the *_f check targets (grep '_f' in src/check/Makefile) for the wrappers you touch and the BLD-20 test change; if it does not, say so plainly in needs (external-dependency) and verify the C side by compiling a C caller that calls the wrapper symbol with the Fortran calling convention. BLD-20 (Fortran METIS dual test checks no results): mirror the C test's range checks in the .f90.in file's style, and its CMake twin if the test list differs. Run the sequential and PT check targets touching the wrappers you change (32-bit and 64-bit, both link against the wrappers), plus check_libmetis_dual_f? if buildable.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 56. Agent · G19 dgraph-build-induce audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G19-dgraph-build-induce. Items: DGR-05, DGR-12, DGR-06, PS-DGR-3, DGR-11, DGR-08, DGR-18, DGR-21 (dgraph_build.c, dgraph_build_grid3d.c, dgraph_build_hcub.c, dgraph_induce.c, dgraph_check.c, dgraph_ghst.c, dgraph_match_check.c, library_dgraph_build*.c, library_dgraph_induce.c, library_dgraph_check.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G19-dgraph-build-induce.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch. Pay special attention to 3c9b3ab "Rework error handling and structure of dgraphInduce()" (it restructured dgraphInduce2 but kept the faulty prefix-sum comparison of DGR-06: understand his new structure before touching it), 0635547 / 3436099 (hdgraph twins), 73229e6 (commGatherv overflow check).

Group-specific notes: the finished group G18 (dgraph fold / redist / gather; series in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G18-dgraph-fold-redist/ with SUMMARY.md and a reusable LD_PRELOAD rank/call fault-injection harness under repro/common/) established how collective error agreement is written in this tree now (the reduglbtab status gate before the point of no return, one cleanup label); read its SUMMARY.md and patches 0002/0003 first and use the SAME structure for dgraphBuild2/3 (DGR-05: error flags of the upper ranks missed because the Allgather stores pairs; DGR-12: label translation assumes a compact edge array and never reports untranslated labels), dgraphInduce2 (DGR-06: tests procdsptab instead of proccnttab; PS-DGR-3: unchecked shrinking memRealloc then rebase: UBSan null offset), dgraphGhst2 (DGR-08: continues after reporting a local allocation failure, second reduction). Prove each hang/crash with the harness on mpirun --oversubscribe -np 3/4 (the failing rank's return vs the peers' blocking collective is the evidence; a 15 s timeout = HANG), on pristine and patched. DGR-11 (dgraphCheck never validates edge-end ranges; ends inside numbering holes read out of bounds; edge loads checked only with a ghost array) is the checker PyScotch's test bench relies on: make SCOTCH_dgraphCheck reject what it should, keep its cost linear, add cases to test_scotch_dgraph_check.c (malformed distributed graph built in code), and say what previously-accepted inputs now fail. DGR-18 (grid builder sets DGRAPHFREETABS before the build: double free on late failure) and DGR-21 (match check loop bound vs base) are small; DGR-21 is debug-only, verify under -DSCOTCH_DEBUG_DGRAPH2 with baseval 1. Collision notes: the finished group G02 (patches/0003 in .../work/G02-arch-tleaf-hcub-build/) cast an int shift in dgraph_build_hcub.c; if you touch that file, apply G02's series first on your branch and base on top, and say so in SUMMARY.md. The running group G20 owns dgraph_io_load.c and dgraph_halo.c (dgraphHaloSync2's OOM hang, PS-DGR-2, is theirs); G21 (not started) owns dgraph_band*.c, dgraph_coarsen.c, dgraph_match*.c except dgraph_match_check.c; put anything you find there in extra.json with a note. Run check_scotch_dgraph_check, check_scotch_dgraph_induce, check_scotch_dgraph_grow, check_scotch_dgraph_band, check_scotch_dgraph_coarsen, check_scotch_dgraph_redist, check_scotch_dgraph_order, check_prog_dgtst, check_prog_dgmap-style (grep CHECKPTSCOTCH in the check Makefile) after your series, 32-bit and 64-bit, -np 1, 2, 3 and 4.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 57. Agent · G20 dgraph-io-dmesh audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G20-dgraph-io-dmesh. Items: DGR-03, DGR-19, DGR-15, DGR-16, DGR-20, CLI-04, PS-DGR-2 (dgraph_io_load.c, dgraph_io_save.c, dgraph_halo.c, dmesh_io_load.c, dmesh.c, dmesh_dgraph.c, dmapping_io.c, src/libscotchmetis/adm2dgr.c + its CMakeLists.txt line). Plus three forwarded leads: (a) from the finished loader group G14: dgraphLoadCent / dgraphLoadDist share graphLoad's unchecked label / edge-end / degree reads (negative or out-of-range values indexing arrays); G14's patches/0001 in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/G14-graph-loaders/ is the model: make the distributed loaders its exact twins (same validation placement, same errorPrint wording), one discipline; (b) from the finished group G05 (extra PS2-G05-...-1, see .../work/G05-strategy-tables-api/extra.json): dmapSave in dmapping_io.c:256 dereferences a NULL part array on an incomplete -m strategy; (c) from the finished group G18: its fault injection on redistribution still hangs inside dgraphHaloSync2 (dgraph_halo.c), which is your PS-DGR-2 (halo sync allocation failure is local only; peers hang); G18's harness (LD_PRELOAD rank/call fault shim + scan driver under .../work/G18-dgraph-fold-redist/repro/common/) reproduces it: reuse it.

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G20-dgraph-io-dmesh.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (febaef7 "Prevent reading negative graph edge values" is his loader-validation style; 3c9b3ab / 7e17084 / 0a05434 his collective error-handling style; G18's SUMMARY.md explains how it applied the latter).

Group-specific notes: DGR-03 (dgraphLoadCent: header errors never broadcast, all ranks continue with garbage; sprintf of the property value into char[4]) is high and reachable from any user file through dgload / SCOTCH_dgraphLoad: fix the status gate (reduglbtab[0]) and the format, then fuzz the distributed loaders with a mutation loop over src/check/data/*.grf through SCOTCH_dgraphLoad on -np 1, 2, 3 (reuse G14's mutfuzz.py from its work dir; MPI with ASan: ASAN_OPTIONS=detect_leaks=0, 15 s timeout = HANG) before and after; count hits. DGR-19 (abort path leaves Isends pending, extra message to the refusing rank): prove with a receiver that answers TAGBAD (fault-inject its allocation) and MPI_Waitall. DGR-15 / DGR-16 / DGR-20 are the dmesh loader and dual-graph builder: DGR-16 was judged not-a-bug by the first pass (branch unreachable): verify that claim adversarially with a crafted .adm file; DGR-20 (hash resize result ignored: infinite loop on failure; other allocation failures return before peers' MPI_Alltoall): fault injection, collective-safe exit in the status-gate idiom. CLI-04 (adm2dgr keeps running after errors in CMake builds because it links the returning error library; memAlloc/free mismatch; MPI_COMM_WORLD vs proccomm): check both build systems' link lines for every tool in src/libscotchmetis and src/scotch (is this the only tool with the mismatch? grep), and pick the fix the maintainer would (make the CMake twin match the Makefile; or make the tool robust to a returning error handler, which is what his other tools do: check dgtst.c / dgmap.c). Collision notes: G19 (running now) owns dgraph_build*.c, dgraph_induce.c, dgraph_check.c, dgraph_ghst.c; G21 (not started) owns dgraph_band*.c, dgraph_coarsen.c, dgraph_match*.c; G24 owns hdgraph*; if a fix lands in their files put it in alt/ and extra.json with a note. Run check_scotch_dgraph_check, check_scotch_dgraph_redist, check_scotch_dgraph_grow, check_scotch_dgraph_band, check_prog_dgtst, check_prog_dgord, check_prog_dgmap, check_prog_dgscat / dggath (grep CHECKPTSCOTCH), check_libparmetis_v3, and the dmesh targets if any (grep dmesh in src/check), after your series, 32-bit and 64-bit, -np 1, 2, 3, 4.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (git format-patch series on v7.0.17), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 58. SendMessage · Resume G19 after Fable limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them). Carry the task through to all deliverables (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 59. SendMessage · Resume G10 after Fable limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them). Carry the task through to all deliverables (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 60. SendMessage · Resume G15 after Fable limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them). Carry the task through to all deliverables (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 61. SendMessage · Resume G16 after Fable limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them). Carry the task through to all deliverables (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 62. SendMessage · Resume G17 after Fable limit cutoff

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them). Carry the task through to all deliverables (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 63. SendMessage · Forward G17's grid-builder lead to G19

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Forwarded lead for your file dgraph_build_grid3d.c, from the finished Fortran group G17 (extra PS2-G17-1 in .../work/G17-fortran-wrappers/extra.json, alt diff in its alt/): SCOTCH_dgraphBuildGrid3D's parameter checks are debug-only, and an increment value of 0 reaches a division: SIGFPE through the public API. You already own DGR-18 in that file: audit this claim, and if it holds, cover it in the same commit or its own, and report it in your extra.json under id PS2-G17-1. Do not change your other deliverables because of this message.
```

## 64. SendMessage · Resume G10 after limit cutoff and session restart

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit and the session was restarted since. Continue exactly where you stopped. Your $WORK is intact on disk: the git tree in $WORK/scotch already carries two commits on top of v7.0.17 (the node-load fix for meshInduceSepa and the element bit-array sizing fix) and your tools/ helpers exist; check the tree state and your repro dirs rather than redoing them. Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 65. Agent · G21 dgraph-band-coarsen audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G21-dgraph-band-coarsen. Items: DGR-07, DGR-09, DGR-17, API-17, API-20, PS-DGR-5, DGR-13, PS-DGR-1, API-15 (dgraph_band.c, dgraph_band_grow.c, dgraph_coarsen.c, dgraph_match.c, dgraph_match_sync_coll.c, dgraph_match_sync_ptop.c, library_dgraph_band.c, library_dgraph_grow.c, library_dgraph_coarsen.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G21-dgraph-band-coarsen.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (3c9b3ab dgraphInduce, 7e17084/0a05434 dgraphFoldComm show his collective error-handling idiom).

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/ when you need the reasoning behind a change. Commits in the combined series that touched your neighbourhood: G19's "check all local vertices for matching in dgraphMatchCheck()" (dgraph_match_check.c is G19's, do not re-patch it) and G19's "stop dgraphGhst2() after a local allocation failure" (dgraph_ghst.c is G19's); G17 added Fortran wrappers for dgraphGrow in a new library_dgraph_grow_f.c.

Group-specific notes: G18 (fold/redist) and G19 (build/induce/ghst) established how collective error agreement is now written in this tree (reduglbtab status gate before the point of no return, one cleanup label, agreement on every rank); read .../work/G18-dgraph-fold-redist/SUMMARY.md and .../work/G19-dgraph-build-induce/SUMMARY.md first and use the SAME structure for DGR-13 (coarsening and matching return on local allocation failure before peers' collectives: the first pass proposed hoisting the small work allocations into the Init functions, whose errors are already agreed on: judge that against the maintainer's idiom), PS-DGR-1 (dgraphCoarsen calls MatchInit after a failed CoarsenInit: NULL dereference), DGR-09 / API-17 (dgraphBand and SCOTCH_dgraphBand are two copies of the same code with the same out-of-memory defects: NULL store into procdsptab, uninitialised free, int-sized scratch for Gnum values, free with the wrong base: decide whether the maintainer would de-duplicate the two copies or fix both; look at why library_dgraph_band.c has its own copy), DGR-07 (point-to-point grow frees the caller's base-adjusted array; Coll variant has the NULL guard Ptop lacks), DGR-17 (Coll debug bound ignores the grow multiplier: debug build), API-20 / PS-DGR-5 (SCOTCH_dgraphGrow returns without CONTEXTEXIT on ghost failure, wrong message name). API-15 (library_dgraph_coarsen.c:163 memCpy with a NULL source when folding gives an empty local multinode array) is the ONE remaining UBSan report in the combined tree's full ptcheck suite: fix it and show the suite is clean. Reuse G18's LD_PRELOAD rank/call fault-injection harness (.../work/G18-dgraph-fold-redist/repro/common/) for every allocation failure, mpirun --oversubscribe -np 3/4, 15 s timeout = HANG, pristine vs patched. The halo-sync OOM hang (PS-DGR-2, dgraph_halo.c) is G20's: it left two alternatives, do not patch dgraph_halo.c; if your fault injection still hangs there, say so. Run check_scotch_dgraph_band, check_scotch_dgraph_grow, check_scotch_dgraph_coarsen, check_scotch_dgraph_check, check_scotch_dgraph_induce, check_scotch_dgraph_redist, check_scotch_dgraph_order, check_prog_dgmap / dgord / dgpart style (grep CHECKPTSCOTCH) after your series, 32-bit and 64-bit, -np 1, 2, 3, 4; then the whole `make ptcheck`.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 66. Agent · G22 bdgraph audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G22-bdgraph. Items: DMO-09, DMO-11, DMO-18, DMO-19, DMO-03, DMO-10, PS-DMO-3 (bdgraph.c/.h, bdgraph_bipart_ml.c, bdgraph_bipart_sq.c, bdgraph_bipart_ex.c, bdgraph_bipart_bd.c, bdgraph_bipart_df.c, bdgraph_bipart_st.c, bdgraph_gather_all.c, bdgraph_store.c, bdgraph_check.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G22-bdgraph.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (DMO-10 f545452 "use size-agnostic macro instead of bounded-size library ABS routine" claimed fixed: verify completeness across bdgraph*, vdgraph*, kdgraph*).

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. Commits in the combined series that touched YOUR files: G13's "apply left shifts to unsigned integers in remaining bit sets" (bdgraph_bipart_bd.c and bdgraph_bipart_ex.c: check whether PS-DMO-3, the 1 << 31 at bdgraph_bipart_bd.c:343/382/388, is now fully covered; if yes, status it as covered by that patch, no duplicate commit); G04's "set default empty strategies for all strategy parameters" (bdgraph_bipart_st.c).

Group-specific notes: DMO-03 (bdgraphBipartSq tests the local failure count instead of the global one, never tests the allocation flag: mismatched collectives at the coarsest levels of the DEFAULT dgraphMap strategy) is the important one: it runs in every PT-Scotch mapping; use the status-gate idiom established by G18/G19 (read .../work/G18-dgraph-fold-redist/SUMMARY.md) and G18's LD_PRELOAD rank/call fault-injection harness (.../work/G18-dgraph-fold-redist/repro/common/) to show the hang on pristine and the clean return on all ranks patched. DMO-09 (the 'bal' strategy variable is stale or uninitialised after ml / sq / z and gather: ranks can branch differently in a user strategy and run different collectives) and DMO-11 (best-partition reductions compare signed imbalance): both have twins in vdgraph_separate_ml.c / vdgraph_separate_sq.c which belong to G23 (running now): patch the bdgraph sites, put the vdgraph twins in alt/ and extra.json with a note naming G23; likewise DMO-04's bdgraph_bipart_df.c half (diffusion encodes allocation failure as -1 inside summed degrees, masked by MPI_SUM) is YOURS: G23 does vdgraph_separate_df.c; make the two identical in design (same reduction slot layout). DMO-18 (copy-paste errors in debug-only code across hdgraph_fold.c, vdgraph_separate_*, hdgraph_order_st.c): only the bdgraph_bipart_ml.c instance is yours; list the others in extra.json for G23/G24. DMO-19 (unreachable external-gain code with indexing and accounting errors): a design question (fix the dead code so it is right when enabled, or fail loudly, or delete it): give real diffs for two options and argue what the maintainer would take given bdgraph.c's "TODO: Compute" comments. Debug-build verification with -DSCOTCH_DEBUG_BDGRAPH2 for DMO-09/DMO-18. Run check_scotch_dgraph_check, check_scotch_dgraph_order, check_prog_dgmap, check_prog_dgpart (grep CHECKPTSCOTCH), 32-bit and 64-bit, -np 1, 2, 3, 4, then the whole `make ptcheck`.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 67. Agent · G23 vdgraph-dorder audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G23-vdgraph-dorder. Items: DMO-05, DMO-12, PS-DMO-1, DMO-04 (its vdgraph_separate_df.c half; the bdgraph_bipart_df.c half is G22's), DMO-14, DMO-15, DMO-02, DMO-13 (vdgraph*.c/.h, vdgraph_separate_*.c, dorder*.c, dorder_io*.c, dorder_tree_dist.c, library_dgraph_order_tree_dist.c, dmapping_io.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G23-vdgraph-dorder.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (4290e22, pre-7.0.16, fixed the based-gather bug in dmapping_io.c: DMO-02 says dorder_io.c / dorder_io_tree.c never got the same fix: make them the exact twins of that commit).

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. Commits in the combined series near your files: G05's strategy-string buffer fix touched library_dgraph_order.c; G17 added Fortran wrappers in library_dgraph_order_f.c.

Group-specific notes: forwarded lead you now own: PS2-G05-1 / G20's note: dmapSave (dmapping_io.c:256) dereferences a NULL part array on an incomplete -m strategy; G20 left a guard in .../work/G20-dgraph-io-dmesh/alt/ (read its SUMMARY.md); verify and commit it together with DMO-15 (the dmapSave validity test that can never fire: && instead of ||, wrong bound) as one coherent validation of what dmapSave accepts. DMO-02 (vertex-label gathers in dorderSave / dorderSaveTree not based: commGatherv writes past the allocation with baseval 1; output shifted by one): prove with a base-1 graph on -np 3 under ASan, pristine vs patched, and check dorder_io_block.c for the same (DMO-13 is there: rangtab leak, write errors hidden). DMO-04 (vdgraphSeparateDf hides out-of-memory in a summed reduction and then uses freed memory): G22 (running now) does the bdgraph_bipart_df.c twin; both must end up with the SAME reduction-slot design: read G22's work dir if it has written anything, otherwise follow the G18/G19 status-gate idiom (.../work/G18-dgraph-fold-redist/SUMMARY.md) and say in SUMMARY.md that G22 must match. DMO-11's vdgraph sites (best-separator reduction on signed imbalance in vdgraph_separate_ml.c / _sq.c) and DMO-09-style stale strategy variables in vdgraph: G22 will forward them; cover them in your series. DMO-05 (uncoarsening leaks the exchange buffer on the all-invalid path: a NORMAL fallback that repeats at many nested-dissection levels), DMO-12 / PS-DMO-1 (store/restore and the zero method lose local part loads after a '|' selection: wrong anchor loads): one convention for what VdgraphStore saves, enforced by vdgraphCheck under SCOTCH_DEBUG_VDGRAPH2, proven with the first pass's instrumented strategy on -np 3. DMO-14 (CblkDist returns 1 on error instead of a negative value, documented): fix the library and check the manual text. Use G18's LD_PRELOAD rank/call fault-injection harness (.../work/G18-dgraph-fold-redist/repro/common/) for allocation failures; mpirun --oversubscribe -np 3/4; 15 s timeout = HANG. Run check_scotch_dgraph_order, check_prog_dgord, check_prog_dgmap, check_scotch_dgraph_check, check_prog_dgscat/dggath (grep CHECKPTSCOTCH) after your series, 32-bit and 64-bit, -np 1, 2, 3, 4, then the whole `make ptcheck`.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 68. Agent · G24 hdgraph audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G24-hdgraph. Items: DMO-01, DMO-16, PS-DMO-4, DMO-06, DMO-07, DMO-08, PS-DMO-5, DMO-17 (hdgraph*.c/.h: hdgraph_fold.c, hdgraph_gather.c, hdgraph_induce.c, hdgraph_order_nd.c, hdgraph_order_sq.c, hdgraph_order_st.c, hdgraph_check.c; kdgraph_map_rb.c, kdgraph_map_rb_part.c, kdgraph_map_rb_map.c). Plus two forwarded leads from the finished group G18: PS2-G18-1 (hdgraphInduceList assigns an unchecked memRealloc result, hdgraph_induce.c:302-304; NULL edge array then read by hdgraphFold2) and PS2-G18-3 (hdgraphOrderNd2 halves disagree on failure in release builds after a fold, hdgraph_order_nd.c:301-307); see .../work/G18-dgraph-fold-redist/extra.json and its alt/ diffs.

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G24-hdgraph.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (DMO-01 4ebcc6f "use proper message displacement and count" claimed fixed: verify on -np 3 with a weighted graph; DMO-08: 0635547 reworked hdgraphGather's error handling: check whether the uninitialised verthaltax free survived it; 3436099 hdgraphInduce).

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. Commits in the combined series that touched YOUR files, which you must read before anything else: G18's "make error handling of dgraphFold2() and hdgraphFold2() collective", "set base value of folded graphs before attaching based arrays", "rework error handling of dgraphGatherAll2()" (also hdgraph_gather.c) and "check that message sizes fit in MPI count arguments" (hdgraph_fold.c): PS-DMO-4 (fold error exits not collective in release builds) and parts of DMO-16 (fold error-path leaks) may now be FIXED BY G18's series: verify at runtime with G18's fault-injection harness (.../work/G18-dgraph-fold-redist/repro/common/), and if so, status them as covered by G18's patch (name it) with no duplicate commit; G04's "set default empty strategies" and G05's two ordering-table fixes touched hdgraph_order_st.c.

Group-specific notes: DMO-06 (leaf ordering failures dropped: SCOTCH_dgraphOrderCompute reports success, dorderSave can wait forever for the missing fragment), DMO-07 (dorderNew result not checked in nested dissection: every rank crashes), PS-DMO-5 (halo ordering wrapper returns only the root's status), PS2-G18-3 (halves disagree on failure in release builds): one coherent error-propagation design for hdgraphOrderNd / Sq / St in the G18/G19 status-gate idiom, proven with injected failures on -np 3 (15 s timeout = HANG), pristine vs patched; this is the path PyScotch's parallel ordering tests exercise. DMO-16's kdgraph_map_rb_part.c leaks and DMO-18's hdgraph instances (wrong debug macro / function name in hdgraph_fold.c:891, && vs || in hdgraph_order_st.c:190) are yours; G22 will forward the DMO-18 list. DMO-17 (parallel mapping onto non-complete targets reaches a stub): the first pass said not-a-bug; verify the documentation really says so (p_l.tex SCOTCH_dgraphMap), and if the manual promises more than the code does, that is a doc item: say which. Run check_scotch_dgraph_order, check_prog_dgord, check_prog_dgmap, check_prog_dgpart, check_scotch_dgraph_check (grep CHECKPTSCOTCH) after your series, 32-bit and 64-bit, -np 1, 2, 3, 4, then the whole `make ptcheck`.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 69. Agent · G26 metis-dual-esmumps audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G26-metis-dual-esmumps. Items: CLI-05, CLI-15, CLI-09, CLI-10, CLI-22, BLD-19, BLD-17 (src/libscotchmetis/metis_graph_part_dual.c, metis_graph_dual.c, parmetis_dgraph_dual.c, parmetis_dgraph_order.c; src/esmumps/esmumps.c, test_esmumps.c, library_esmumps_f.c, src/check/test_libesmumps.c; src/Makefile and src/esmumps/Makefile for BLD-17).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G26-metis-dual-esmumps.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch.

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. Commits in the combined series that touched YOUR files, read them first: G25's METIS series (one shared V5 helper for the partitioning parameters, a new metis_options.c/.h option helper, and a hunk in metis_graph_part_dual.c for the options; G25's SUMMARY.md says explicitly that PartMeshDual's own vsize/OBJTYPE output selection and its NULL - baseval, i.e. CLI-05, are YOUR lines); G20's adm2dgr fix (error library linking) in src/libscotchmetis; G15's esMUMPS orderLoad validation in src/esmumps/order_io.c; G17 made the Fortran METIS dual test check its results.

Group-specific notes: CLI-05 (METIS_PartMeshDual applies the Fortran 'null' convention to some arguments but not vwgt / vsize: stack overflow through the scalar ne read as an array; graphBuild result ignored): normalise the null-pointer convention ONCE at the top with G25's helpers in mind (do not add a second convention), and add the case to test_libmetis.c's dual tests in the file's style; CLI-15 (dual-graph helpers leave dangling pointers, mix malloc/memFree, leak on the SCOTCH_DEBUG_ALL return) with LD_PRELOAD malloc fault injection; CLI-09 (ParMETIS_V3_NodeND returns METIS_ERROR on valid runs when the process count is not a power of two, and METIS_OK on failed ones): define the status from the Compute/Perm results, prove with -np 3 (not a power of two) that the order is complete and the status now says so, and check what ParMETIS documents for the sizes array; CLI-10 / CLI-22 (esmumps2 ignores every failure and returns success; the test driver and the Fortran wrapper disagree on the sign convention): choose the MUMPS-style convention the manual/doc of esMUMPS supports, make esmumps.c, library_esmumps_f.c and test_esmumps.c agree, fault-inject to show garbage output on pristine; BLD-19 (esmumpsv test path is dead: ESMUMPS_HAS_ESMUMPSV defined nowhere): enable it in both build systems or remove it, following what the Makefile does for the other esmumps targets; BLD-17 (make -j: esmumps and ptesmumps sub-makes race in the same directory): reproduce with `make -j8 esmumps ptesmumps` on a clean copy several times, fix in src/Makefile + src/esmumps/Makefile, and verify the CI invocation (ci/build_makefile.sh) still builds; G30 (running now) owns the CI scripts and the other Makefiles' dependency bugs: do not edit ci/ or src/libscotchmetis/Makefile (BLD-11 is theirs). Run check_libmetis_v3/v5, check_libmetis_dual_v3/v5, check_libparmetis_v3, check_libesmumps, check_prog_dgord? (grep the check Makefile), 32-bit and 64-bit, then `make escheck` and the metis part of `make check`.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 70. Agent · G27 seq-tools audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G27-seq-tools. Items: CLI-11, CLI-12, CLI-16, CLI-17, CLI-13, CLI-14, CLI-18 (src/scotch/amk_grf.c, gout_o.c, gout_c.c, atst.c, gcv.c, gmk_m2.c, gotst.c; src/libscotch/arch_deco_build.c for CLI-11's callee). Plus one forwarded lead from the finished group G15: PS2-G15-6, gotst ignores the status of its ordering load (src/scotch/gotst.c; see .../work/G15-order-io-seq-misc/extra.json and alt/).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G27-seq-tools.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch.

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. Commits in the combined series that touched src/scotch: G02's "shift architecture-sized values, not ints, by hypercube dimensions" (amk_hy.c, amk_fft2.c, amk_ccc.c, gmk_hy.c, gmk_ub2.c: per-tool dimension bounds) and G05's dgmap.c fix. Another agent (G28, running now) owns gmap.c / gpart help text, gscat.c usage, the dg* tools' MPI_Finalize paths and the man pages: do not touch those; put anything you find there in extra.json with a note naming G28.

Group-specific notes: these are all user-facing tools with base-1 and option-parsing bugs: for EACH tool build a tiny differential test (base-0 vs base-1 input, gbase converts; expected output identical modulo the base) and record the commands in repro/, because the maintainer will ask "how do I know this did not change the output". CLI-11 (amk_grf -l passes 0-based indices into arch_deco_build.c which indexes with the graph base: out-of-bounds read; unlabelled lists never range-checked): decide whether the fix belongs in the tool, in archDecoArchBuild's parameter validation (G01 / G03 set the validation discipline for architecture builders: read .../work/G01-arch-sub-dist/SUMMARY.md and .../work/G03-arch-mesh-deco-misc/SUMMARY.md and do not collide with their arch_deco*.c commits in the combined series), or both. CLI-12 / CLI-16 (gout Inventor, VTK and Tulip outputs wrong or crashing for base-1 graphs: look at EVERY output format in gout_o.c for the same un-basing mistake, not only the three named), CLI-17 (gout option parser dereferences NULL on an unterminated option list: fuzz the -O parser with a small mutation loop). CLI-13 (atst initialises its minimum with an unsigned shift that gives -1 on 32-bit SCOTCH_Num): is there a SCOTCH_NUMMAX? grep how the library defines GNUMMAX and what the public header offers; the fix must work for both int sizes, prove with both trees. CLI-14 (gcv accepts any unknown output format letter: table bound tests the wrong table), CLI-18 (gmk_m2 -e -t header arc count wrong for small tori: produced files fail to load): count arcs the way the generator writes them, test every small dimension pair 1..4 x 1..4 and load each result with gtst (that is your regression evidence; add a check_prog_gmk case if the file's style allows). PS2-G15-6 (gotst ignores the load status): fix in the same style as the other tools' error handling (errorPrint + exit). Run check_prog_amk, check_prog_amk_grf, check_prog_atst, check_prog_gcv? (grep), check_prog_gout, check_prog_gmk, check_prog_gotst, check_prog_gbase, check_prog_gtst after your series, 32-bit and 64-bit, then the whole `make check`.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 71. Agent · G28 tools-docs-tests audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G28-tools-docs-tests. Items: CLI-20, CLI-21, BLD-23, BLD-22, BLD-18, BLD-04, BLD-16, BLD-15 (src/scotch/gmap.c help text; the PT-Scotch tools' early-exit paths in dgmap.c, dgord.c, dgscat.c, dggath.c, dgtst.c and src/libscotch/library_error_exit.c; src/scotch/gscat.c usage; man/man1/*.1.txt and their generated .1 files; src/check/Makefile's CHECKSCOTCH list; src/check/test_scotch_graph_order.c, test_scotch_graph_map.c, test_scotch_mesh_graph.c).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G28-tools-docs-tests.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch.

BASE (differs from the brief's setup, and matters most for YOU because every finished group added tests): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. In the combined series: G15 changed test_scotch_graph_order.c (load round trip + invalid files), G12 changed test_scotch_graph_map.c (zero-load fixed-vertex case), G11 changed test_scotch_mesh_graph.c, G16 added test_scotch_graph_map_view, G11/G07/G09/G19/G12 added check targets to src/check/Makefile and CMakeLists.txt, G17 and G06 and G15 edited the manuals (doc/src/scotch/s_l.tex, p_l.tex). Read those diffs (git log -p base-combined -- src/check doc man) before touching the same files. Another agent (G27, running now) owns the other sequential tools (amk_grf, gout, atst, gcv, gmk_m2, gotst); G30 owns src/check/CMakeLists.txt's test definitions (BLD-05/08/10), ci/ and the Makefile dependency bugs; G29 owns the CMake source lists: if your fix needs a line in CMakeLists.txt (e.g. the CMake twin of BLD-18's missing check target), add it minimally and say so in SUMMARY.md so the QA merge can reconcile.

Group-specific notes: BLD-04 / BLD-16 / BLD-15 are the test-strictness items PyScotch cares about most (the test bench inherits these tests): test_scotch_graph_order's checker only prints and then indexes with the bad value (G15 added cases there: keep them working), test_scotch_graph_map accepts unmapped vertices and never checks fixed vertices (G12's SUMMARY.md explicitly left BLD-16 to you), test_scotch_mesh_graph exits 0 on a failed graph check; make each test FAIL on a wrong result in the test_libmetis.c idiom, and PROVE each one by feeding it a deliberately wrong result (a tiny corruption in a scratch copy) before and after. CLI-21 (PT-Scotch tools skip MPI_Finalize on help/version exits; errorPrint exits without MPI_Abort so peers hang on a bad file): the library_error_exit.c half is in the error-exit library used by every PT tool: decide whether MPI_Abort belongs there (what does the maintainer's libptscotcherrexit do today? there is a PT variant: read it), prove the hang with a bad file on one rank, -np 3, 15 s timeout. CLI-20 / BLD-23 / BLD-22 (help text and man pages contradict the code): generate the option table from the tools' usage strings with a script in repro/ and diff it against man/man1/*.1.txt for EVERY tool, not only the three named; man pages are generated from .1.txt (check how: man/Makefile?); fix the sources and regenerate the way the maintainer does. BLD-18 (check_prog_mcv missing from CHECKSCOTCH): audit the whole list against the defined check_* targets and the CMake test list, in both directions. Run the whole `make check` and `make ptcheck` after your series, 32-bit and 64-bit, and the corrupted-result proofs.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 72. Agent · G29 cmake-sources-config audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G29-cmake-sources-config. Items: BLD-01, BLD-02, BLD-12, BLD-13, BLD-24, BLD-25, BLD-06, PS-BLD-2 (CMakeLists.txt at the root, src/CMakeLists.txt, src/libscotch/CMakeLists.txt source lists and compile definitions, src/libscotchmetis/CMakeLists.txt, cmake/SCOTCHConfig.cmake.in, README.md / INSTALL.txt where they state the CMake minimum).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G29-cmake-sources-config.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (look at how he edits CMake files in that range, if at all, for style).

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. In the combined series, G17 added a new source file library_dgraph_grow_f.c and registered it in src/libscotch/Makefile and CMakeLists.txt, G25 added metis_options.c/.h to src/libscotchmetis's Makefile and CMakeLists.txt, G20 changed adm2dgr's link line in src/libscotchmetis/CMakeLists.txt: read those diffs (git log -p base-combined -- '*CMakeLists.txt' '*Makefile*') first. Other agents running now: G30 owns src/check/CMakeLists.txt's test definitions, the Fortran-header and .f90.in custom-command dependencies in src/libscotch/CMakeLists.txt and src/check/CMakeLists.txt (BLD-09, BLD-10), src/libscotchmetis/Makefile (BLD-11), ci/ and .gitlab-ci.yml; G28 owns src/check/Makefile's check list. Stay out of those lines; if a fix of yours needs a CI job (BLD-01 asks for a CI check that diffs the Makefile object list against the CMake source list), write the checker script under src/ or ci/ as a NEW file and describe in SUMMARY.md the one-line job G30 should add; do not edit .gitlab-ci.yml.

Group-specific notes: cmake IS needed for this group: check `which cmake` and its version first. If cmake exists: configure and build the tree with CMake into a scratch dir (both 32-bit and INTSIZE=64, with and without SCOTCH_NAME_SUFFIX, with and without BUILD_LIBESMUMPS), run `nm` on the resulting libscotch for the five missing symbols of BLD-01 (SCOTCH_contextBindMesh and the Fortran wrappers), run a consumer project's find_package(SCOTCH) against a suffixed install for BLD-02, run a parallel build repeatedly for BLD-12 (metis.h race), inspect the exported target's INTERFACE_COMPILE_DEFINITIONS for BLD-24, and run `cmake -P` snippets for BLD-06 / PS-BLD-2 (the Open MPI regex) and BLD-25 (the stray brace). If cmake is NOT available, say so in `needs` (external-dependency) for every item, do the strongest source-only verification you can (e.g. the Makefile-vs-CMake source list diff for BLD-01 is pure text work: do it and ship the script), and still write the patches. BLD-13 (cmake_minimum_required 3.10 vs features needing 3.14/3.18): list every construct with its minimum version (cmake --help-command / docs from memory, state your assumptions), then either raise the minimum (and README/INSTALL) or replace the constructs: argue which the maintainer would take given what his CI images run (ci/ files tell you). Run the Makefile builds and `make check` for anything you change in a Makefile too, 32-bit and 64-bit.

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 73. Agent · G30 cmake-tests-make-ci audit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_ · model fable

```
You are the agent for GROUP=G30-cmake-tests-make-ci. Items: BLD-05, BLD-08, BLD-09, BLD-10, BLD-11, BLD-03, BLD-07, BLD-14, BLD-21 (src/check/CMakeLists.txt test definitions and the suffix_fortran_file helper; the scotchf.h / ptscotchf.h custom commands in src/libscotch/CMakeLists.txt; src/libscotchmetis/Makefile; ci/*.sh and .gitlab-ci.yml; src/Make.inc/Makefile.inc.* templates). Plus one lead from PyScotch's own experience with this tree, to audit as a candidate PS2 finding: every one of our 20 agents had to delete the stale libscotch.so / libptscotch.so before rebuilding after a source edit, because src/libscotch/Makefile's shared-library link rule uses `$?` (only the changed objects are relinked into the .so, so an incremental `make scotch` produces a library missing most symbols and every tool then fails to link); verify it, find every rule with the same pattern (libscotch, libptscotch, libscotchmetis, libesmumps, static vs shared), and fix it the way the maintainer would (read how the other library rules are written and what Make.inc expects).

Read, in this order, then follow them exactly:
1. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/BRIEF.md  (the full brief: context, paths, build/test recipes, what to do per item, output schema)
2. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/STYLE.md
3. /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/groups/G30-cmake-tests-make-ci.md  (your items)
4. Sections 2 and 3 of /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra/scotch_maint7.0.txt, and the maintainer's own fixes in infra/upstream_7.0.16_to_7.0.17.patch (7.0.17 changed ci/test_cmake.sh: read that commit for his CI style).

BASE (differs from the brief's setup): 20 groups have finished and their 142 commits are combined into ONE series at /tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad/combined-series/ (read-only; applies on v7.0.17 with plain git am). After cloning as the brief says, run `git am <that dir>/*.patch && git tag base-combined`, then commit your work on top and export ONLY your commits with `git format-patch -o $WORK/patches base-combined`. Copy and build the build trees AFTER applying (remove the stale .so files first, as the brief says: that is the very defect above). Say in SUMMARY.md that your series is based on the combined series. The finished groups' SUMMARY.md and patches are in /tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>/. In the combined series several groups added tests to src/check/CMakeLists.txt and src/check/Makefile (G11, G07, G09, G19, G12, G16, G17): read `git log -p base-combined -- src/check/CMakeLists.txt` before editing it. Other agents running now: G29 owns the CMake SOURCE lists, compile definitions, SCOTCHConfig.cmake.in, the CMake minimum version and src/CMakeLists.txt's option handling (it may leave a new checker script for the Makefile-vs-CMake source lists and will describe in its SUMMARY.md the CI job line it needs: if .../work/G29-cmake-sources-config/SUMMARY.md exists when you reach BLD-14, wire that job into .gitlab-ci.yml in your CI commit; otherwise note it); G28 owns src/check/Makefile's CHECKSCOTCH list and the test programs' strictness; G26 owns src/Makefile's esmumps/ptesmumps dependency (BLD-17) and src/esmumps/Makefile. Stay out of those.

Group-specific notes: BLD-03 is a SECRET-HANDLING item (the Sonar token is expanded into a file archived as a CI artifact): never write or echo any real token value anywhere; the patch moves the token to the environment / -Dsonar.token and drops the file and the -X logs from artifacts; the recommendation to rotate the token goes in notes and SUMMARY.md, not in a commit message. BLD-07 (pipe into tee without pipefail: build failures masked in CI) and BLD-14 (CI never really tests 64-bit integers on 64-bit hosts; CMake matrix never sets INTSIZE / suffix / deterministic): one CI commit, with a dry-run proof (run the scripts locally with a deliberately broken source and show the old script says green). BLD-05 / BLD-08 / BLD-10 / BLD-09 (CMake test definitions: gmtst without -o checks nothing; dgscat/dggath chained with ';' so only the final compare counts; suffix_fortran_file depends on an undefined ${file}; scotchf.h depends on the wrong template): cmake availability decides what you can run (check `which cmake`; if absent, say so in `needs` and verify by reading plus by writing the equivalent shell commands); for BLD-08 prove with a stale output file that the test passes while both programs fail. BLD-11 (parmetis_dgraph_dual_f lacks its parmetis.h prerequisite): reproduce with a clean `make -j8` several times, fix, and audit every rule in src/libscotchmetis/Makefile for the same omission. BLD-21 (Make.inc templates define macro names the code never tests: COMMON_WINDOWS vs COMMON_OS_WINDOWS, COMMON_FILE_COMPRESS_BZ vs _BZ2): grep every -D in src/Make.inc/* against the macros the sources actually test, both directions, and fix all of them. Run the Makefile build and `make check` / `make ptcheck` after your series, 32-bit and 64-bit, from a CLEAN copy and again incrementally after touching one source file (that incremental build must now succeed without deleting the .so files).

Deliverables: $WORK/audit.json, $WORK/extra.json, $WORK/patches/*.patch (your commits on top of the combined series), $WORK/alt/*.diff, $WORK/repro/<ID>/, $WORK/SUMMARY.md, exactly as the brief specifies. Final message: at most 12 lines.
```

## 74. SendMessage · Resume G10 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 75. SendMessage · Resume G21 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 76. SendMessage · Resume G22 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 77. SendMessage · Resume G23 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 78. SendMessage · Resume G24 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 79. SendMessage · Resume G26 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 80. SendMessage · Resume G27 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 81. SendMessage · Resume G28 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 82. SendMessage · Resume G29 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing; background CMake builds you started may have died with the interruption). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 83. SendMessage · Resume G30 after session limit

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Your run was interrupted by an API usage limit, which has now reset. Continue exactly where you stopped: your $WORK and everything you already wrote are on disk (check them rather than redoing them; a shell command that was running when you stopped may have been cut off, rerun it if its output is missing). Carry the task through to all deliverables (audit.json, extra.json, patches/ exported with format-patch base-combined, alt/, repro/, SUMMARY.md), then send your final message of at most 12 lines.
```

## 84. SendMessage · Forward G29's CI hook request to G30

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Forwarded from the finished group G29 (its SUMMARY.md is in .../work/G29-cmake-sources-config/): its patch 0005 adds a script ci/check_sources.sh that diffs the Makefile object lists against the CMake source lists (BLD-01). It asks you to wire it into the CI build in your CI commit: add `./ci/check_sources.sh || fatal` to ci/build_cmake.sh (check its exact calling convention in G29's patch before adding the line, and apply G29's series on your branch first if you need the script present to test the hook; say so in SUMMARY.md). G29 also recorded PS2-G29-4 (a suffixed CMake build with tests fails to link) as belonging to your test-template lines: read its extra.json entry and cover it if it holds. Do not change your other deliverables because of this message.
```

## 85. SendMessage · Forward G22's vdgraph twins to G23

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Forwarded from the finished group G22 (bdgraph; its SUMMARY.md, extra.json and alt/ are in .../work/G22-bdgraph/): it fixed DMO-11 (best-partition reductions compare signed imbalance: ABS applied at the producers) in bdgraph_bipart_ml.c / _sq.c and DMO-18 (debug-only copy-paste errors: unconditional default case) in bdgraph, and left the vdgraph_separate_ml.c / vdgraph_separate_sq.c twins as alt diffs (alt/DMO-11-* and alt/DMO-18-*). Those files are yours: verify the twins, make them identical in design to G22's committed versions (read its patches 0005 and 0006), and commit them in your series, reporting them in audit.json/extra.json under the original ids with a note that the bdgraph half is G22's. Also note G22's DMO-04 design (its patches 0001/0002 for bdgraphBipartSq/GatherAll agreement) so your vdgraphSeparateDf reduction-slot layout matches. Do not change your other deliverables because of this message.
```

## 86. SendMessage · Tell G24 about G23's commit in its file

_second pass, waves 2-3, resumes, forwarded leads (Fable 5.1)_

```
Forwarded from the finished group G23 (vdgraph/dorder; its SUMMARY.md, extra.json and patches are in .../work/G23-vdgraph-dorder/): (1) its LAST commit, patches/0010, patches kdgraph_map_rb_part.c (PS2-G23-2: kdgraphMapRbPartSequ leaves a NULL fragment part array for any r{...} strategy without seq=, which crashes SCOTCH_dgraphMap in dmapTerm); that file is yours: read the commit, and either base your own kdgraph_map_rb_part.c changes on top of it (apply G23's series before yours and say so in SUMMARY.md) or keep your hunks away from it so both apply; do not re-fix the same defect. (2) PS2-G23-4, an unchecked shrinking memRealloc, is in your files too: see its extra.json entry and cover it if it holds. (3) A caveat worth knowing: G23 found that the first pass's MPI test driver used MPI_Init instead of MPI_Init_thread(MPI_THREAD_MULTIPLE), so fold-dup coarsening hangs at random with it: if any of your hang readings come from such a driver, redo them with MPI_Init_thread. Do not change your other deliverables because of this message.
```
