import sys, re, json
# Compact view of a group digest: the review lead (verbatim block) + first-pass status/location/preferred option.
for path in sys.argv[1:]:
    text = open(path).read()
    print("########", path.rsplit('/',1)[-1])
    for sec in re.split(r'\n=+\n## ', text)[1:]:
        item_id, _, body = sec.partition('\n')
        m = re.search(r'### Third-party review entry.*?\n```\n(.*?)\n```', body, re.S)
        lead = m.group(1).strip() if m else '(no review entry)'
        print(f"--- {item_id.strip()}")
        print(lead[:900])
        m = re.search(r'### First pass.*?\n```json\n(.*?)\n```', body, re.S)
        if m:
            try:
                j = json.loads(m.group(1))
                pref = [o.get('label') for o in j.get('fix_options', []) if o.get('preferred')]
                print(f"FIRST PASS: status={j.get('status')} method={j.get('method')} sev={j.get('claimed_severity')} loc={str(j.get('location'))[:120]}")
                print(f"  title={j.get('our_title')}")
                print(f"  preferred={pref} upstream={str(j.get('upstream_change'))[:100]}")
                if j.get('needs'): print(f"  needs={j.get('needs')}: {str(j.get('needs_note'))[:150]}")
            except Exception as e:
                print("FIRST PASS: (json parse failed)", e)
        else:
            m = re.search(r'```json\n(.*?)\n```', body, re.S)
            if m:
                try:
                    j = json.loads(m.group(1)); pref=[o.get('label') for o in j.get('fix_options',[]) if o.get('preferred')]
                    print(f"FIRST-PASS-ONLY: sev={j.get('severity')} status={j.get('status')} method={j.get('method')} loc={str(j.get('location'))[:120]}")
                    print(f"  title={j.get('our_title')}"); print(f"  evidence={str(j.get('evidence'))[:400]}"); print(f"  preferred={pref}")
                except Exception as e: print("FIRST-PASS-ONLY: (json parse failed)")
            else: print("FIRST PASS: (none)")
