#!/bin/bash
# Screenshot a docs URL with the bundled Playwright Chromium, using the locally extracted libs + fonts (no root).
# usage: shoot.sh URL OUT.png [full]
S=/tmp/claude-1000/-home-dev-workspace-pyscotch/2ec737e7-7dd0-4e32-802c-b7a3a51c1910/scratchpad; X=$S/aptlocal
export LD_LIBRARY_PATH=$X/root/usr/lib/x86_64-linux-gnu FONTCONFIG_FILE=$X/fc/fonts.conf TMPDIR=/home/dev/tmp-chrome
cd /home/dev/workspace/pyscotch && .venv/bin/python - "$1" "$2" "$3" <<'PY'
import sys; from playwright.sync_api import sync_playwright
url,out,full=sys.argv[1],sys.argv[2],bool(sys.argv[3]) if len(sys.argv)>3 else False
with sync_playwright() as p:
    b=p.chromium.launch(args=["--no-sandbox","--disable-gpu","--disable-dev-shm-usage"]); pg=b.new_page(viewport={"width":1280,"height":860}); pg.goto(url, wait_until="load"); pg.wait_for_timeout(300); pg.screenshot(path=out, full_page=full); b.close(); print(out)
PY
