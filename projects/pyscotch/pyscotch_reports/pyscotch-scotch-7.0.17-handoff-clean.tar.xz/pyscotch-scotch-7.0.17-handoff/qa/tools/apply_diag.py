import json, subprocess, sys, tempfile, shutil, os
from pathlib import Path
dest = Path(sys.argv[1]); scotch_git = sys.argv[2]; mode = sys.argv[3]  # "plain" or "3way"
data = json.load(open(dest / "findings.json"))
tmp = Path(tempfile.mkdtemp(prefix="apply-diag-")); s = tmp / "s"
subprocess.run(["git", "-c", "advice.detachedHead=false", "clone", "-q", "--shared", scotch_git, str(s)], check=True)
g = ["git", "-C", str(s)]
subprocess.run(g + ["checkout", "-q", "v" + data["scotch_version"]], check=True)
subprocess.run(g + ["config", "user.name", "check"]); subprocess.run(g + ["config", "user.email", "c@i"])
seen_ids = {}
applied = []  # (file, touched files)
for p in data["series"]:
    f = (dest / p["file"]).resolve()
    pid = subprocess.run(["git", "patch-id", "--stable"], input=open(f).read(), capture_output=True, text=True).stdout.split()[0]
    if pid in seen_ids:
        print(f"DUP     {p['file']}  == {seen_ids[pid]}"); continue
    seen_ids[pid] = p["file"]
    args = g + ["am", "-q"] + (["-3"] if mode == "3way" else []) + [str(f)]
    r = subprocess.run(args, capture_output=True, text=True)
    if r.returncode == 0:
        touched = subprocess.run(g + ["show", "--name-only", "--format=", "HEAD"], capture_output=True, text=True).stdout.split()
        applied.append((p["file"], touched))
        note = "3WAY-OK" if ("3-way" in r.stderr or "Falling back" in r.stderr) else "ok     "
        if note != "ok     ": print(f"{note} {p['file']}")
        continue
    conf = subprocess.run(g + ["diff", "--name-only", "--diff-filter=U"], capture_output=True, text=True).stdout.split()
    if not conf:  # plain mode: find files from the patch
        conf = [l[6:] for l in open(f) if l.startswith("+++ b/")]
    print(f"FAIL    {p['file']}")
    for c in conf:
        earlier = [a for a, t in applied if c in t]
        print(f"          {c}  <- earlier: {', '.join(e.split('/')[1] + '/' + e.split('/')[2][:4] for e in earlier) or 'none (patch base mismatch)'}")
    subprocess.run(g + ["am", "--abort"], capture_output=True)
print(f"applied {len(applied)} of {len(data['series'])}")
shutil.rmtree(tmp, ignore_errors=True)
