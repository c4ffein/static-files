# What a patch must look like to be merged as-is by the Scotch maintainer

The bar: the patch is what François Pellegrini would have committed himself, or better.
Read INFRA/scotch_maint7.0.txt sections 2 (Coding style) and 3 (Naming conventions) in full before
writing a line of C. Then read INFRA/upstream_7.0.16_to_7.0.17.patch: it contains all 51 of his
commits between 7.0.16 and 7.0.17, 25 of them fixes for this same review. That file is the ground
truth for "how he fixes things": copy its habits.

## Commit shape (one commit per logical defect)
- Subject, his format:  `Bugfix: <imperative, lower-case after the colon> [report R. Perry]`
  for a defect that comes from the review; `[report PyScotch]` for a PS-* defect we found ourselves.
  Cleanups, tests and docs get no `Bugfix:` prefix (e.g. `Remove useless structure definition`,
  `Add parameter check to `SCOTCH_dgraphRedist()``). He quotes routine names with backticks.
  A multi-id commit lists the ids in the body, one per line, as `Refs: COR-03, COR-04`.
- Body: short, factual. What was wrong, what the fix does. No marketing.
- Each touched `.c`/`.h`/`.y`/`.l` file: in its header history block, bump the `to   :` date
  of the LAST version block to `13 oct 2026` (keep the column alignment). He does this in every commit:
  ```
  -/**                                 to   : 11 jul 2026     **/
  +/**                                 to   : 13 oct 2026     **/
  ```
  If the last version block is not `7.0`, add nothing else; just bump the date.
- Author: the clone is configured as `PyScotch <pyscotch@noreply.invalid>`; the user will set the
  real author before sending. Do not sign off.

## Code
- Two-space indent, no tabs, no trailing whitespace, no C++ `//` comments.
- `if (x)`, `for (...)`, `funcName (arg)` — a space before the opening parenthesis of a call or keyword.
  No space inside parentheses. `return (1);`, `return (NULL);`, `return;`.
- Opening brace on the keyword line; closing brace alone on its line; `else` on its own line:
  ```
  if (x != NULL) {
    ...
  }
  else {
    ...
  }
  ```
  `else if` stays on one line.
- Line comments `/* ... */` start at column 50 (0-based) when the code is shorter, else one space
  after the code; consecutive comment terminators aligned; text starts with an upper-case letter,
  imperative, no final punctuation: `/* If class has loading function */`.
  Header-file field comments: `/*+ Text +*/`, aligned the same way.
- Declarations at the top of the block, type column aligned (look at the surrounding function).
  Variable names follow section 3 of the guide (`vertnum`, `vertnnd`, `edgeptr`, `hashsiz`...).
- `errorPrint ("routineName: message")` with the C routine name as the prefix, lower-case message,
  no final period; `errorPrintW` for warnings; a `#ifdef SCOTCH_DEBUG_XXX2` block for checks that are
  purely internal consistency, an unconditional check for anything a user file or API call controls.
- Error paths: the repo uses `goto fail` / `fail:` labels (lower-case, column 0, numbered `fail1`,
  `fail2` by order of definition) when it avoids duplicated cleanup, and `memFree` / `memFreeGroup`
  / `xxxExit` in reverse order of acquisition. Return 1 for "cannot" and 2 for "error" where the
  surrounding code distinguishes them; otherwise what the callers test.
- Keep 32-bit and 64-bit `Gnum`/`Anum` in mind: use `ABS`, `MIN`, `MAX`, `intRandVal` family,
  `(Gnum) 1 << n` on the right type, `GNUMSTRING`, `%" GNUMSTRING "` in formats.
- `memAlloc`/`memAllocGroup`/`memRealloc`/`memFree` never the libc ones.
- Public API (`library*.c`): every exported routine has a Fortran twin (`library*_f.c`) and an
  entry in `library.h` / `library_f.h`; the `CONTEXTOBJECT`/`CONTEXTCONTAINER` macros unwrap
  context containers; the PT-Scotch twin in `library_d*.c` usually mirrors the sequential one.
- The sequential/distributed twins (`graph_*`/`dgraph_*`, `hgraph`/`hdgraph`, `bgraph`/`bdgraph`,
  `vgraph`/`vdgraph`, `kgraph`/`kdgraph`, `mesh`/`dmesh`) and the METIS v3/v5 twins must receive
  the same fix when they share the defect. A fix that leaves the twin broken is incomplete.

## What he deletes in the same commit (and so must you)
- A struct field, local variable, parameter, macro, `#include`, label, or error path that your
  change has made unused. `git grep` the symbol over the whole tree before and after.
- A debug-only check made redundant by a new unconditional one.
- A comment that no longer describes the code.

## What he adds in the same commit (and so must you)
- The regression test, when `src/check/` has a natural home (one more case in an existing
  `test_*.c`, one more line in a `check_prog_*` rule in `src/check/Makefile` and `CMakeLists.txt`
  twin). Follow the exact style of the file; run it.
- The documentation update when a behaviour, option or message that is documented changes
  (`doc/`, `src/scotch/*.1.txt` man sources, comments in `library.h`).

## Self-check before `git format-patch`
- `python3 -I INFRA/stylecheck.py <files you touched>` reports nothing.
- `git diff --check` reports nothing (tabs, trailing whitespace).
- Builds with zero new warnings in both the 32-bit and the 64-bit `Gnum` build.
- Relevant `check_*` targets pass; your reproducer passes; the pristine reproducer still fails.
- `git grep` shows no now-unused symbol you introduced or orphaned.
