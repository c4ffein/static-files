# BRIEF — second, thorough pass over one group of Scotch 7.0.17 findings, ending in maintainer-grade patches

You are one of 30 agents. Each owns a GROUP of 5-9 findings that live in the same source files, so
that the patches you write do not collide with another agent's. Your group name and its item list are
in the message that spawned you; the item digest is `INFRA/groups/<GROUP>.md`.

## Context
PyScotch (Python binding + independent test bench for Scotch) received a third-party review of Scotch
7.0.16 (192 leads by R. Perry, commit b748bc4). Scotch 7.0.17 shipped on 7-9 Oct 2026 and fixed some
of them. A first pass by other agents (fast, one agent per review area) gave each lead a status against
7.0.17, a few fix options and, for many, a diff. It also found 28 new defects (PS-*). That first pass was
never audited, its labels are inconsistent, its diffs are sketches, and none of it is in a shape the Scotch
maintainer (François Pellegrini) could merge.

We will send the maintainer one report per Scotch version with, for every finding: its status in 7.0.17,
how we verified it, two or more fix options, and ONE recommended patch that he can `git am` without
touching it. The quality bar, in the user's words: "the patches must be the same or better than what he
would have done himself". Concretely: if your fix stops using a struct field, the field goes away in the
same commit; if the twin routine (distributed / Fortran / METIS v5) has the same bug, it is fixed in the
same series; if a documented behaviour changes, the doc changes; if `src/check` has a natural home for a
regression test, the test is added. Read `INFRA/STYLE.md` and the maintainer's guide before coding.

The review is a set of LEADS, not truth. The first pass is a set of CLAIMS, not truth. You are the
reviewer of both. "inconclusive" with a precise reason is a fine status; a guess is not. Thoroughness
beats speed: this job is expected to take you a long time. Do not spawn sub-agents.

## Paths
```
INFRA=/tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/infra   (read-only)
WORK=/tmp/claude-1000/-home-dev-workspace-pyscotch/087f3d41-a5d8-4b0a-9260-769d70cf8179/scratchpad/work/<GROUP>   (yours; create it)
```
Never write under `/home/dev/workspace/pyscotch` (no edits, no git commands that change state there).
Never run `make` inside `INFRA/`. Run Python as `python3 -I`.

INFRA contents:
- `groups/<GROUP>.md`  your items: the review's lead text (verbatim), the first pass's JSON entry, and where
  the first pass's harness / diffs are (`firstpass_work/<AREA>/`, diffs in `.../diffs/`).
- `v7.0.17/`  pristine 7.0.17 source tree (read-only).
- `scotch.git/`  git clone at tag v7.0.17 (tags v7.0.16, v7.0.17 available; upstream master == v7.0.17).
  Clone it; never commit in it.
- `asan/`  ASan+UBSan `-O0 -g` build of pristine 7.0.17 (libscotch, libptscotch, scotch tools, metis v3/v5,
  parmetis; `bin/`, `lib/`, `include/`, built in `src/`). 32-bit `Gnum`. Copy it; never `make` in it.
- `tsan/`  a ThreadSanitizer build pair (pristine and with the PyScotch patch) left by the first pass.
- `upstream_7.0.16_to_7.0.17.patch`  all 51 upstream commits with diffs: the maintainer's own fixes for 25
  of these leads. Your primary style reference. `git -C $WORK/scotch log -p v7.0.16..v7.0.17` is the same.
- `scotch_maint7.0.txt`  the maintainer's guide (text). Sections 2 and 3 are mandatory reading.
- `STYLE.md`  our distilled checklist of what a mergeable patch looks like. `stylecheck.py`  mechanical checks.
- `review.txt`  the whole third-party review (for cross-references to other ids).
- `firstpass_findings/`  the first pass's raw JSON per area (`<AREA>.json`, `.enrich.json`, `.new.json`).
- `scotch-7.0.17-bgraph-bipart-gg-determinism.patch`  the patch PyScotch currently ships (SEP-13 related).

## Setup (copy-paste)
```
GROUP=<GROUP>; INFRA=...; WORK=.../work/$GROUP; mkdir -p $WORK/patches $WORK/alt $WORK/repro
git clone -q --shared $INFRA/scotch.git $WORK/scotch && git -C $WORK/scotch checkout -q -b $GROUP v7.0.17
git -C $WORK/scotch config user.name PyScotch; git -C $WORK/scotch config user.email pyscotch@noreply.invalid
cp -r $INFRA/asan $WORK/build          # the build tree (has src/Makefile.inc); edit sources in $WORK/scotch, mirror them here
```
Edit in `$WORK/scotch/src/...` (the git tree). Mirror and rebuild with:
```
cp -r $WORK/scotch/src/. $WORK/build/src/           # (no rsync on this box; cp -r of the src dir is fine)
rm -f $WORK/build/src/libscotch/libscotch.so $WORK/build/src/libscotch/libptscotch.so $WORK/build/lib/libscotch.so $WORK/build/lib/libptscotch.so
make -C $WORK/build/src -j4 scotch ptscotch > $WORK/build.log 2>&1 || tail -40 $WORK/build.log
grep -c "warning:" $WORK/build.log                  # pristine gives 0 at these flags; yours must too
```
The `rm` is needed: the library link rule uses `$?`, so a stale `.so` relinks only the changed objects and
every tool then fails to link (this is itself a build-system lead; the BLD groups know).
esMUMPS: `make -C $WORK/build/src esmumps ptesmumps`. Other build flags: edit `$WORK/build/src/Makefile.inc`.
A 64-bit `Gnum` build (required for every patch, compile + the tests that matter):
```
cp -r $INFRA/asan $WORK/build64 && sed -i 's/^CFLAGS\(\s*\)=/CFLAGS\1= -DINTSIZE64 -DIDXSIZE64/' $WORK/build64/src/Makefile.inc
make -C $WORK/build64/src clean >/dev/null 2>&1; rm -f $WORK/build64/lib/*.so $WORK/build64/bin/*; make -C $WORK/build64/src -j4 scotch ptscotch > $WORK/build64.log 2>&1
```
Running things:
```
export LD_LIBRARY_PATH=$WORK/build/lib     # or build64/lib
export UBSAN_OPTIONS=print_stacktrace=1
ASAN_OPTIONS=detect_leaks=0 mpirun --oversubscribe -np 3 ...     # MPI itself leaks; keep leak detection on for sequential runs
```
Single `src/check` targets (first `make -C $WORK/build/src/check realclean` to drop stale binaries):
```
make -C $WORK/build/src/check CC=gcc CCD=gcc SCOTCHLIBS="-lscotch -lscotcherr" METISLIB="-lscotchmetis" check_scotch_arch
CF="$(grep '^CFLAGS' $WORK/build/src/Makefile.inc | cut -d= -f2-)"
make -C $WORK/build/src/check CFLAGS="$CF -DSCOTCH_PTSCOTCH" CC=mpicc CCD=mpicc SCOTCHLIBS="-lptscotch -lscotch -lptscotcherr" METISLIB="-lptscotchparmetis" check_scotch_dgraph_check
make -C $WORK/build/src/check CC=gcc CCD=gcc SCOTCHLIBS="-lesmumps -lscotch -lscotcherr" check_libesmumps
```
Target names: `grep '^check_' $INFRA/v7.0.17/src/check/Makefile`. The CMake twin of the test list is
`src/check/CMakeLists.txt`. Debug builds: add `-DSCOTCH_DEBUG_ALL` (or the module's `SCOTCH_DEBUG_XXX2`) to CFLAGS.

## For every item in your group
1. Locate it in 7.0.17 (line numbers in the review are 7.0.16 and have shifted). Check
   `git -C $WORK/scotch log -p v7.0.16..v7.0.17 -- <file>`: touched? by which commit, doing what?
2. Decide the status yourself, from the code and from running it:
   `still-present | fixed-in-7.0.17 | partially-fixed | not-a-bug | inconclusive`.
   For a lead already marked fixed, verify the fix is COMPLETE: same pattern elsewhere in the file, in the
   twin module, in the Fortran wrapper, in the other METIS version; an incomplete upstream fix is
   `partially-fixed` with the remaining instances listed.
3. Method, strict: `ran` (the core claim exercised at runtime against 7.0.17, you observed the defect or
   its absence), `partly-run` (say in `read_only` which part was only read), `source-read` (say in
   `why_not_run` what stopped you: forced allocation failure, other platform, external tool, unreachable
   path...). Prefer running. Write minimal C reproducers (keep them in `$WORK/repro/<ID>/`), use the
   shipped tools, the sanitizer builds, `-DSCOTCH_DEBUG_*`, fault injection (an `LD_PRELOAD` malloc
   that fails on the N-th call is cheap to write and settles most "alloc-injection" items; do it).
   Record exact commands and the first lines of the sanitizer or program output.
4. Severity, your own: high / medium / low / info, on reachability (user file, public API argument,
   default strategy, internal-only) and impact (crash, memory corruption, silent wrong result, hang, leak,
   diagnostic). Say in one clause why it differs from the review's rating when it does.
5. Review the review: mechanism, location, reproducer, and its own "Fix:" line. Would that fix work as
   written? Is it incomplete? Would it introduce a new bug? Be specific.
6. Review the first pass, adversarially, AFTER forming your own view: wrong status / method / evidence /
   location; a "preferred" option that is wrong, incomplete, or not what the maintainer would do; a diff
   in `firstpass_work/<AREA>/diffs/` that does not match its sketch; dead code or state it leaves behind;
   instances it missed; a claimed "maintainer idiom" that the tree does not support.
7. Variant hunt and neighbours: extract the defect's pattern (`abs()` on a `Gnum`; `1 << n` on an int;
   a loader trusting a header count; a release-only check; an early return before a collective; an
   unchecked `memAlloc`/`memRealloc`; a freed-then-used table; a based/un-based mix-up...) and `git grep`
   the whole tree for it: `src/libscotch`, `src/libscotchmetis`, `src/scotch`, `src/esmumps`, `src/check`,
   and the twins. Read the whole function and +-150 lines around each location. Report every instance:
   same defect elsewhere (then your patch must cover it) or a new defect (`extra.json`). Only things you
   SAW, with `file:line` and a quote.
8. Fix options: at least two genuinely different ones (minimal guard vs structural; at the source vs at
   the caller; reject vs repair). For each: label, what it does, a real unified diff against v7.0.17
   (file under `$WORK/alt/<ID>-<letter>-<slug>.diff`), what you tested with it, and trade-offs
   (behaviour change, ABI, performance, risk, platform). Then choose: which one would the maintainer
   take, and why — name the precedent (a commit in the 7.0.16..7.0.17 range, or an idiom in the tree,
   with `file:line`). The recommended option is the one you turn into a commit.
9. The recommended fix as a maintainer-grade commit on your branch, per `STYLE.md`:
   - one commit per logical defect (several ids may be one defect: one commit, ids listed in the body;
     one id may be several separable defects: several commits);
   - covers all instances found in step 7, and the twins;
   - removes what it makes unused; adds the test when there is a natural home (and its CMake twin);
     updates docs when behaviour or messages documented elsewhere change;
   - header `to :` dates bumped to `13 oct 2026`; `python3 -I $INFRA/stylecheck.py` and `git diff --check` clean;
   - builds with zero warnings in the 32-bit and the 64-bit trees; the reproducer passes; the relevant
     `check_*` targets pass (run the whole `check` and `ptcheck` subsets that touch your files, not one);
   - the series is exported with `git -C $WORK/scotch format-patch -o $WORK/patches v7.0.17` and
     re-applied on a fresh `git clone --shared $INFRA/scotch.git` with `git am` to prove it applies.
   If an item is `fixed-in-7.0.17` (completely) or `not-a-bug`, no patch. If `inconclusive`, write the
   patch only if you are confident in the fix from the source; say so.
10. If a fix is not something you can make mergeable (needs a design decision only the maintainer can
   take, or a platform you do not have), say exactly that in `notes`, give the best alternative diffs in
   `alt/`, and do not pretend.

## Output (strict; validate every JSON with `python3 -I -c 'import json,sys;json.load(open(sys.argv[1]))' FILE`)
`$WORK/audit.json` — a JSON array, one object per item, in the group's order, keys exactly:
```
id, our_title (<= 14 words, your own wording of the defect as seen in 7.0.17; never the review's title),
status, method, ran (exact commands + first lines of output; "" if none), read_only, why_not_run,
severity, severity_note, location_7_0_17 (file:line, 7.0.17), evidence (quoted 7.0.17 lines),
upstream_change (commit hash + one line, or ""), review_accuracy (string; "accurate" or what is wrong),
first_pass_critique (string; "" only if the first pass was fully right),
extra_instances: [ {location, quote, covered_by_patch: bool} ],
fix_options: [ {label, summary, diff_file (path under $WORK/alt or $WORK/patches), tested (what you ran; "untested: why"),
                tradeoffs, preferred: bool, maintainer_fit (why he would / would not take it, with precedent)} ],
patch_files: [ "$WORK/patches/NNNN-....patch", ... ]  (the commits that fix this id; may be shared between ids),
cleanup_done (what now-unused things the patch removes, or "none needed", or "NOT DONE: why"),
test_added (file + what it checks, or "" + why not),
docs_updated (file or ""),
needs ("" if ran; else one of alloc-injection | mpi-fault | other-platform | 64bit-build | debug-build | external-dependency | none-found),
needs_note, notes
```
`$WORK/extra.json` — array of defects NOT in the review nor in the first pass (ids `PS2-<GROUP>-n`):
`{ local_id, our_title, severity, status, method, ran, read_only, why_not_run, location_7_0_17, evidence,
   related_ids: [...], fix_options: [...same shape...], patch_files: [...] }`. Empty array if none.
`$WORK/patches/*.patch` — the `git format-patch` series. `$WORK/alt/*.diff` — the alternatives.
`$WORK/repro/<ID>/` — reproducers with a `README` of the exact commands (pristine fails, patched passes).
`$WORK/SUMMARY.md` — <= 40 lines: one line per id (`ID status method severity -> patch file or '-'`),
the three most important facts, what you could not do and why, and anything the user must decide.

Your final message to me: at most 12 lines, the same content as SUMMARY.md's head. No long prose; the
files are the deliverable.
