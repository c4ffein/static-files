# G04-strategy-parser

Items: COR-01, COR-22, COR-23, COR-12, COR-26, COR-13, COR-25



===================================================================
## COR-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-01",
 "area": "COR",
 "our_title": "Nested strategy parameter syntax error reaches error action with parser context cleared to NULL",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser_yy.y:458-487 (mid-rule NULLing at 461-464, error alternative at 482-488)",
 "evidence": "Command: st 'r{sep=m{asc=b{:width=3}}}'  (st.c -> SCOTCH_stratGraphMap) against pristine ASan lib.\nOutput: 'ERROR: stratParserParse: invalid strategy string, line 1, column 15, at \":width=3}}}\"' then\n'parser_yy.y:485:45: runtime error: member access within null pointer of type const struct StratParamTab' / 'AddressSanitizer: SEGV on unknown address 0x000000000008 ... #0 _SCOTCHyyparse parser_yy.y:485 #1 stratParserParse parser_yy.y:819 #2 stratInit parser.c:112 #3 SCOTCH_stratGraphMap'.\nQuoted 7.0.17 code: lines 461-464 '($<SAVE>$).strat = penvptr->straptr; ($<SAVE>$).param = penvptr->paraptr; penvptr->straptr = NULL; penvptr->paraptr = NULL;' and line 484-486 'errorPrint (... penvptr->paraptr->nameptr, penvptr->straptr->tablptr->...)'.\nPrevalence: I mutated 4 valid strategies (random delete/insert/replace of 1-3 chars, 2264 runs via GraphMap/GraphOrder/MeshOrder): 66 runs hit this crash on pristine 7.0.17 (member access via NULL penvptr->straptr (parser_yy.y:485:72) or NULL paraptr (485:45)); 0 on the patched tree. Harness (all under work/COR): archload.c = SCOTCH_archLoad() on a one-line .tgt file, linked against the pristine ASan+UBSan libscotch.so (32-bit INT, release, no COMMON_DEBUG/SCOTCH_DEBUG_*); st.c = SCOTCH_stratGraphMap/GraphOrder/MeshOrder + stratSave. Patched tree (fixes tested): work/COR/fix (copy of the ASan build with the patches; diffs in work/COR/diffs/).",
 "upstream_change": "",
 "review_accuracy": "accurate (crash, location, reproducer string and mechanism all confirmed; the review's 'Fix' of guarding NULL works)",
 "fix_options": [
  {
   "label": "A. NULL-guard the error message (minimal)",
   "summary": "In the 'error' alternative of PARAMVAL test penvptr->paraptr/straptr for NULL and print a generic message without parameter/method names, then YYABORT.",
   "patch_sketch": "@@ parser_yy.y  (| error action)\n-                errorPrint (\"stratParserParse: invalid value for parameter \\\"%s\\\" of method \\\"%s\\\", line %d, column %d, before \\\"%s\\\"\",\n-                            penvptr->paraptr->nameptr, penvptr->straptr->tablptr->methtab[...].nameptr,\n-                            (@1).libenum, (@1).cobenum, (@1).tebeptr);\n+                if ((penvptr->paraptr != NULL) && (penvptr->straptr != NULL))\n+                  errorPrint (\"... invalid value for parameter \\\"%s\\\" of method \\\"%s\\\", line %d, column %d, before \\\"%s\\\"\", ...);\n+                else\n+                  errorPrint (\"stratParserParse: invalid value for strategy parameter, line %d, column %d, before \\\"%s\\\"\",\n+                              (@1).libenum, (@1).cobenum, (@1).tebeptr);\n                 YYABORT;",
   "tradeoffs": "Tested: built patched parser (bison regenerated), the reproducer now prints a clean error and returns 1; 2264 mutated-strategy runs: 0 sanitizer hits (vs 66). No behaviour change on valid input. The message for the nested case is less specific (no parameter name), which is inherent: the mid-rule action has cleared the context.",
   "preferred": true
  },
  {
   "label": "B. Save/restore context around error recovery instead of clearing it",
   "summary": "Keep the outer (straptr,paraptr) in the SAVE semantic value and have the error action restore them from a %parse-param/penvptr stack slot (e.g. push on penvptr in the mid-rule, pop in the final action and in a new 'error' path) so the old message is always printable.",
   "patch_sketch": "ParserEnv gets 'struct {Strat *s; const StratParamTab *p;} saved[N]; int depth;'; mid-rule: saved[depth++] = {straptr,paraptr}; final action: depth--; error action prints saved[depth-1] when depth>0.",
   "tradeoffs": "Keeps the precise message but adds state to ParserEnv and must be kept in sync on every YYABORT path; more invasive than A for a diagnostic. Not tested.",
   "preferred": false
  },
  {
   "label": "C. Drop the secondary message",
   "summary": "Make the PARAMVAL 'error' alternative just YYABORT; yyerror() already printed 'invalid strategy string, line, column, at ...'.",
   "patch_sketch": "-              | error { errorPrint (...); YYABORT; }\n+              | error { YYABORT; }",
   "tradeoffs": "Smallest diff and no NULL-prone expression, but loses the 'invalid value for parameter X of method Y' hint in the non-nested case where it is valid today.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: it mirrors the 7.0.17 commit d555f2c for COR-02 (add 'if (x != NULL)' guard in front of an unconditional call; the maintainers' idiom for these error paths is a local NULL guard, not restructuring).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-22",
 "area": "COR",
 "our_title": "Strategy value is stored into any parameter slot without checking parameter type",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser_yy.y:457-481 (third PARAMVAL alternative: mid-rule + STRATSELECT, store at ~478-480)",
 "evidence": "The review's mechanism ('after error recovery') is imprecise: no error is needed. The grammar accepts a strategy as the value of ANY parameter and the final action stores the Strat* without checking paraptr->typeval == STRATPARAMSTRAT. Command: st 'n{sep=m{vert=/(vert>1)?f;g}}' o  (vert is an INT parameter of method m) -> 'ret=0' and the saved strategy shows 'n{sep=m{asc=,low=,type=h,vert=944,rat=0.8},ole=,ose=}' (vert = low 32 bits of the stored pointer, varies with ASLR); LeakSanitizer then reports 104 bytes allocated at parser_yy.y:288 (the Strat tree whose only pointer was written over the int). So an error-free parse silently corrupts the method data (8-byte store over a 4-byte slot, overlapping the adjacent field) and leaks. The UBSan 'misaligned store' report only appears when the slot is not 8-byte aligned. In the 66 crashing mutations I saw, COR-01's NULL dereference fires first on malformed input.",
 "upstream_change": "",
 "review_accuracy": "mechanism imprecise (no error recovery needed; the type is simply never checked); impact and fix direction (check typeval, abort on mismatch) are right",
 "fix_options": [
  {
   "label": "A. Reject non-strategy parameters in the mid-rule action",
   "summary": "At the start of the empty mid-rule (before the sub-strategy is parsed) test penvptr->paraptr->typeval != STRATPARAMSTRAT and abort with an error naming the parameter and method.",
   "patch_sketch": "              |\n              {\n+               if (penvptr->paraptr->typeval != STRATPARAMSTRAT) {\n+                 errorPrint (\"stratParserParse: parameter \\\"%s\\\" of method \\\"%s\\\" does not accept a strategy\", paraptr->nameptr, methtab[...].nameptr);\n+                 YYABORT;\n+               }\n                ($<SAVE>$).strat = penvptr->straptr; ...",
   "tradeoffs": "Tested: the reproducer now fails with 'parameter \"vert\" of method \"m\" does not accept a strategy'; valid strategies (all defaults, 'sep=m{...}', nested asc/low) unchanged; no leak. Checking before parsing also avoids building (and leaking) the sub-tree. Note the existing code uses typeval == STRATPARAMSTRAT at line 371 (not masked with ~STRATPARAMDEPRECATED); a deprecated strategy parameter would be rejected here - none exist today.",
   "preferred": true
  },
  {
   "label": "B. Check in the final action and free the tree",
   "summary": "Keep parsing, but in the action after STRATSELECT test the type, call stratExit($2) and YYABORT on mismatch.",
   "patch_sketch": "if (penvptr->paraptr->typeval != STRATPARAMSTRAT) { stratExit ($2); YYABORT; }",
   "tradeoffs": "Works but parses a sub-strategy with the wrong tables (penvptr->stratab is only switched for strategy parameters, line 371) before rejecting it; slightly later error. Not tested.",
   "preferred": false
  },
  {
   "label": "C. Make the lexer/grammar type-directed",
   "summary": "Use distinct non-terminals per parameter type so a strategy can only follow '=' of a strategy parameter.",
   "patch_sketch": "split PARAMVAL into PARAMVALSTRAT/..., driven by the lexer start condition already set via PARSERLLBEGIN (stratmethtokentab).",
   "tradeoffs": "Principled but a grammar rewrite with bison conflicts risk; not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: same style as the existing 'invalid method parameter switch' check at parser_yy.y:396-401 (errorPrint + YYABORT in the action).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-23

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-23",
 "area": "COR",
 "our_title": "Parser abort paths drop partially built strategy nodes with no destructor",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser_yy.y (no %destructor; YYABORT sites at 180, 196, 225, 283-291, 498, 563, 698, 738); stratParserParse frees only penvdat.straptr (~lines 819-828)",
 "evidence": "Command: ASAN_OPTIONS=detect_leaks=1 st '(m{vert=100}|m{vert=)' -> LeakSanitizer: 'Direct leak of 104 byte(s) in 1 object(s) allocated from: #1 _SCOTCHyyparse parser_yy.y:288 #2 stratParserParse parser_yy.y:819 #3 stratInit parser.c:112 #4 SCOTCH_stratGraphMap'. Also the 104-byte tree in COR-22's reproducer. Other tested malformed strings (unknown parameter names, missing '}') did not leak, so the leak depends on where the error hits (method node already allocated at line 288 but not yet linked into penvdat.straptr).",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Add %destructor for STRAT and TEST values and remove the manual frees before YYABORT (preferred but invasive)",
   "summary": "Declare '%destructor { stratExit ($$); } <STRAT>' and '%destructor { stratTestExit ($$); } <TEST>'. Bison then frees discarded semantic values on error and YYABORT; delete the explicit stratExit/stratTestExit calls that precede YYABORT in actions (otherwise double free).",
   "patch_sketch": "%destructor { if (($$) != NULL) stratExit ($$); }     <STRAT>\n%destructor { if (($$) != NULL) stratTestExit ($$); }  <TEST>\nactions: remove 'stratExit ($1); stratTestExit ($3); ...' lines directly before YYABORT (about 10 sites).",
   "tradeoffs": "Standard bison practice and fixes all sites at once; but every action must be audited (manual frees + destructors would double free) and the method-node allocation at line 288 (kept in penvptr->straptr, not on the value stack) still needs explicit handling. Not tested - risky to patch blind.",
   "preferred": false
  },
  {
   "label": "B. Track in-flight nodes in ParserEnv (preferred for safety)",
   "summary": "Record every allocated Strat/StratTest that is not yet linked in a list owned by ParserEnv; when a node gets attached to its parent remove it; on failure stratParserParse frees whatever remains.",
   "patch_sketch": "ParserEnv += 'struct ParserPend_ * pendlist'; helper parserPendAdd/Remove; stratParserParse(): on failure walk pendlist and free.",
   "tradeoffs": "Independent of bison's stack semantics and of the many YYABORT paths; costs a little bookkeeping. Not tested.",
   "preferred": true
  },
  {
   "label": "C. Fix only the observed sites",
   "summary": "Free the method node (line 288) and partial cond/select nodes in the specific YYABORT paths that currently drop them.",
   "patch_sketch": "e.g. at the 'invalid method name' / 'out of memory (5)' paths: if (straptr != NULL) memFree (straptr);",
   "tradeoffs": "Smallest and least risky per fix but never complete; fuzzing will keep finding more. Not tested.",
   "preferred": false
  }
 ],
 "notes": "No option tested. Maintainers' idiom: explicit stratExit()/stratTestExit() before YYABORT already exists (see out-of-memory paths in the TESTOR/TESTAND actions) - so C in the existing style is the likely quick fix; B or A is the complete one.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-12",
 "area": "COR",
 "our_title": "Whitespace rule no longer advances strategy position twice",
 "claimed_severity": "medium",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser_ll.l:166 (rule is now '[ \\t\\n]*  ;')",
 "evidence": "7.0.17 parser_ll.l: '[ \\t\\n]*                    ;' (the explicit parserLocationUpdate call is gone, YY_USER_ACTION still updates once). Run: st '   r  {   sep   =  m  { asc  = b{x} } }' -> 'invalid method parameter name \"x\", line 1, column 34, before \"x} } }\"' (the position is right and the printed tail is the right substring); a multi-line variant reports 'line 4, column 2'. No out-of-range reads.",
 "upstream_change": "e1700d7 'Bugfix: do not count whitespaces twice in strategy strings [report R. Perry]' - exactly the review's fix.",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-26

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-26",
 "area": "COR",
 "our_title": "Test evaluation divides by unchecked modulus; numeric literals converted without range checks",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser.c:420-430 (STRATTESTMOD), parser_ll.l:136-141, 153 ((INT) atol / (INT) atof)",
 "evidence": "Modulo: gmap -m'r{sep=/(vert%0>1)?m;m}' g88.grf c4.tgt out.map -> 'parser.c:428:63: runtime error: division by zero / AddressSanitizer: FPE ... #0 _SCOTCHstratTestEval parser.c:428'. Also fires for 'vert%(0)'. INT_MIN % -1 would trap the same way (not exercised).\nLiterals: st '/(vert>99999999999999999999)?r;' -> ret=0 and the saved strategy shows '(vert)>(-1)' (atol saturates to LONG_MAX then (INT) truncation gives -1: silent wrong value); st 'r{sep=m{vert=1e30}}' -> saves 'vert=-2147483648' (double->INT conversion out of range is UB; default UBSan has no float-cast-overflow check, so no report); 'r{bal=1e400}' -> 'bal=inf'.",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Guard the modulus; reject out-of-range literals in the lexer",
   "summary": "In STRATTESTMOD: if the divisor is 0 -> errorPrint + o = 1 (and avoid INT_MIN % -1 by special-casing -1). In the lexer use strtol/strtod with errno/range checks and return an error token (or print and YYABORT) when the literal does not fit INT / double.",
   "patch_sketch": "parser.c:  else { if (testtab[1].data.val.valint == 0) { errorPrint (\"stratTestEval: modulo by zero\"); o = 1; break; }\n                          evalptr->data.val.valint = (testtab[1].data.val.valint == -1) ? 0 : (testtab[0].data.val.valint % testtab[1].data.val.valint); }\nparser_ll.l: errno = 0; l = strtol (yytext, &e, 10); if (errno != 0 || l < INTVALMIN || l > INTVALMAX) { errorPrint (...); return (YYerror-ish token); }",
   "tradeoffs": "Modulo guard tested: 'gmap -m...vert%0...' now exits with 'gmap: ERROR: stratTestEval: modulo by zero' (no SIGFPE); the lexer part is NOT implemented/tested. A division by zero in double arithmetic (fmod) just yields NaN and is not covered by the review.",
   "preferred": true
  },
  {
   "label": "B. Reject a literal zero divisor at parse time",
   "summary": "In the TESTEXPR3 '%' action, if $3 is a constant node with value 0, error out.",
   "patch_sketch": "if (($3)->testval == STRATTESTVAL && ($3)->data.val.valint == 0) { stratTestExit(..); YYABORT; }",
   "tradeoffs": "Catches the obvious case early but not 'vert%(vert-vert)'; runtime guard (A) is still required. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A; the runtime test sits next to the existing stratTestEvalCast error returns (o |= ...; if (o != 0) break;).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-13",
 "area": "COR",
 "our_title": "Test-expression printer chooses parenthesis table row backwards and ignores same-rank right operands",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser.c:551-552 (table) and 586-599 (use)",
 "evidence": "Command: st '/(vert>(10+2)*3)?r;' -> stratSave prints '(/((vert)>((10)+(2)*(3)))?(r{...});)'. 7.0.17 source parser.c:552 'strattestsavepa[2][2] = { { \"(\", \")\" }, { \"\", \"\" } };' with 'i = (child->testval < testptr->testval) ? 1 : 0' selecting row 1 (no parentheses) exactly when parentheses are required - confirmed inverted. '(10+2)*3' is saved as '(10)+(2)*(3)' which re-parses as 10+2*3=16 instead of 36. fprintf/right-operand return values are ignored (lines 587-596: 'stratTestSave (testtab[1], stream);' result dropped).\nImprecision in the review's 'swap the rows' Fix: swapping rows is necessary but not sufficient. The grammar (parser_yy.y:592-676) has '+','-' (TESTEXPR1) < '*' (TESTEXPR2) < '%' (TESTEXPR3), left-associative, and comparison operators are non-associative; enum order STRATTESTADD < SUB < MUL < MOD differs from the grammar's precedence classes (ADD and SUB are the same level; the right operand of a same-level operator needs parentheses: a-(b-c), a*(b%c)). A pure row swap would still emit wrong output for 'vert-(1-2)' (right operand of equal rank) and for ADD/SUB mixes.",
 "upstream_change": "",
 "review_accuracy": "partly imprecise: right diagnosis (inverted table), insufficient fix (swap alone does not handle same-rank right operands or ADD/SUB sharing a level)",
 "fix_options": [
  {
   "label": "A. Rank-based parenthesisation + propagate errors",
   "summary": "Introduce stratTestSaveRank(): ADD/SUB=1, MUL=2, MOD=3, VAL/VAR=4, logical/relational=0 (no parenthesized form in the grammar). Parenthesise the left child if rank(child) < rank(parent), the right child if rank(child) <= rank(parent) (left-associativity); OR the fprintf/recursive results into o.",
   "patch_sketch": "static int stratTestSaveRank (const StratTest * t) { switch (t->testval) { case STRATTESTADD: case STRATTESTSUB: return (1); case STRATTESTMUL: return (2); case STRATTESTMOD: return (3); case STRATTESTVAL: case STRATTESTVAR: return (4); default: return (0); } }\n ... binary case:\n   rankval = stratTestSaveRank (testptr);\n   i = ((rankval > 0) && (stratTestSaveRank (testtab[0]) <  rankval)) ? 1 : 0;   /* table rows swapped: index 1 = \"(\" \")\" */\n   o  = (fprintf (...strattestsavepa[i][0]) < 0); o |= stratTestSave (testtab[0], stream); o |= (fprintf (...[i][1]) < 0);\n   if (o == 0) { o = (fprintf (\"%c\", op) < 0); i = ((rankval > 0) && (stratTestSaveRank (testtab[1]) <= rankval)) ? 1 : 0; ... same for right ... }",
   "tradeoffs": "Tested (patched lib): '/(vert>(10+2)*3)?r;' saves as '(/(vert>(10+2)*3)?...)' (correct); '/(vert-(1-2)-(3%4*5)-(6*7%8))>0?r;' round-trips as 'vert-(1-2)-3%4*5-6*7%8>0'; '/(vert*(2+3)%(4*5))>1?r;' keeps its parentheses. Output text changes for existing strategies containing arithmetic in tests (fewer redundant parentheses on leaves: '(vert)>(1)' becomes 'vert>1'); anything comparing saved strings textually (golden files, PyScotch snapshot tests) will see diffs. Re-parsing the old output was already wrong, so no compatibility to keep.",
   "preferred": true
  },
  {
   "label": "B. Always parenthesise every non-leaf child (conservative)",
   "summary": "Keep the table idea but emit '(' ')' around any child that is not a VAL/VAR, regardless of rank.",
   "patch_sketch": "i = (child->testval < STRATTESTVAL) ? 1 : 0 for both operands (rows swapped); propagate errors as in A.",
   "tradeoffs": "Trivially correct for any associativity, few lines, but noisier output ('(vert-(1))-...') and still needs the error propagation. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A (correct and minimal output); B is what a maintainer would do for a quick fix. Idiom: strattestsaveop[]/strattestsavepa[] tables indexed by testval.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-25

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-25",
 "area": "COR",
 "our_title": "Newline detection in location tracking now tests the current character",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/parser.c:648",
 "evidence": "7.0.17 parser.c:648: 'if (textptr[textidx] == '\\n') {'. Run: st \"$(printf 'r{\\n\\n sep=m{asc=\\nb{x}}}')\" -> 'invalid method parameter name \"x\", line 4, column 2' (correct line). ",
 "upstream_change": "a94688c 'Bugfix: properly traverse sub-strings to account for newline characters [report R .Perry]'.",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)
