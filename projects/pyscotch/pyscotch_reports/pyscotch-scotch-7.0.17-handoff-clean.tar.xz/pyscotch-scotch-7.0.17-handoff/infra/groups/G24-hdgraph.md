# G24-hdgraph

Items: DMO-01, DMO-16, PS-DMO-4, DMO-06, DMO-07, DMO-08, PS-DMO-5, DMO-17



===================================================================
## DMO-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-01",
 "area": "DMO",
 "our_title": "Folded halo graph receives the last sender's vertex-load slice; fixed by per-receiver offset and count",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/hdgraph_fold.c:360-365",
 "evidence": "Built pristine v7.0.16 (git archive, same ASan flags) next to 7.0.17 and ran a vertex-weighted 4elt (4elt_w.grf, flags '001'): 'mpirun --oversubscribe -np N ./drv 4elt_w.grf o \"\"' (default PT-Scotch ordering strategy, SCOTCH_dgraphOrderCompute).\n7.0.16: np=3 -> AddressSanitizer heap-buffer-overflow (READ of size 4) in hallOrderHf.c:1057 (downstream use of the wrongly folded graph); np=5 and np=7 -> 'MPI_ERR_TRUNCATE: message truncated' abort.\n7.0.17: np=3,5,7 all complete, OrderCompute ret=0 on every rank, no sanitizer report.\n7.0.17 source now reads:\n  if (MPI_Isend (orggrafptr->s.veloloctax + fldvertidxtab[commnum],\n                 fldcommdattab[commnum].vertnbr, GNUM_MPI, fldcommdattab[commnum].procnum,\n                 TAGFOLD + TAGVELOLOCTAB, ...)\ni.e. exactly the review's suggested fix (same as dgraph_fold.c).",
 "upstream_change": "4ebcc6f 'Bugfix: use proper message displacement and count [completes scotch@2747e2ba; report R. Perry]' (hdgraph_fold.c, 7 lines)",
 "review_accuracy": "Accurate (mechanism, regression origin 2747e2b, and fix all match). Symptom detail: on 3 ranks the visible effect with ASan was a heap overflow in the later halo-ordering code, not an MPI error; truncation shows up from 5 ranks.",
 "fix_options": [],
 "notes": "The review's own 'Fix:' is what upstream applied. Same upstream release also fixed the neighbouring dgraphFoldComm sender/receiver flag (0a05434, 7e17084), which is not in this review's DMO list.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-16",
 "area": "DMO",
 "our_title": "Fold, nested-dissection and recursive-bipartition error exits skip freeing owned graphs and buffers",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Injected failures only produced hangs in release builds; a debug build (collective error checks) with injection would show leaks.",
 "location": "hdgraph_fold.c:285-296 (fail1 block frees fldcommdattab only for receivers), :321-325 (fail2 -> fail3/fail4), :925-937 (fail4 frees nothing but the folded graph; frees at :913/:923 are on the success path only) ; hdgraph_order_nd.c:410,427 (dorderNewSequ/dorderNew failure -> goto fail leaves indgrafdat01), :448-455 (fail:) ; kdgraph_map_rb_part.c:374,379,395-397 (cannot bipartition domain / ghost edge array / bdgraphBipartSt failure return without dgraphExit of grafptr->data.dgrfdat)",
 "evidence": "Source-read (no clean runtime proof):\nhdgraphFold2: the success path frees 'fldcommdattab' (:913) and the request/index group 'fldvertidxtab' (:923) just before fail4; every error jump (fail2 -> fail3/fail4, fail3 -> fail4) bypasses them, and fail4 only does 'hdgraphExit (fldgrafptr)' for receivers (:935-936). Pending MPI_Isend requests posted before the failure are never completed either.\nhdgraphOrderNd2: after 'hdgraphOrderNdFold (...)' succeeds, 'if ((cblkptr01 = dorderNewSequ (cblkptr)) == NULL) goto fail;' and the dorderNew twin (:427) jump to 'fail:' which frees vspgrafdat arrays and grafptr only; indgrafdat01 (centralised or distributed folded graph) is leaked.\nkdgraphMapRbPart2: 'errorPrint (\"cannot bipartition domain\"); return (1);' (:374), 'cannot compute ghost edge array ... return (1)' (:379) and 'if ((o != 0) || bdgraphBipartSt ... ) { bdgraphExit (&actgrafdat); return (1); }' (:395-397) never dgraphExit(&grafptr->data.dgrfdat) (owned at levels > 0).\nInjection attempt on hdgraphFold2 (FAILFN=_SCOTCHhdgraphFold2, FAILRANK in {0,1,2}, FAILSKIP 0..4, np=3): in all 11 cases where the injection fired (4 of the 15 attempts never reached an allocation) the failing rank prints 'out of memory (n)' and returns OrderCompute ret=1 while the OTHER ranks never return (blocked until the 60 s timeout) because in release builds chekglbval = cheklocval is not collective (#else of SCOTCH_DEBUG_HDGRAPH1); so a leak report could not be produced and the hang is a worse symptom than the leak. Tooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate on every listed path (each one re-read at 7.0.17). The review does not mention the release-build hang that accompanies the fold failure paths (non-collective error reduction).",
 "fix_options": [
  {
   "label": "A: route errors through owning cleanup labels",
   "summary": "hdgraphFold2: at fail4 (error case) free fldcommdattab and fldvertidxtab if non-NULL (set them to NULL after the success-path frees), after cancelling+waiting posted requests; hdgraphOrderNd2: on dorderNew/dorderNewSequ failure free indgrafdat01 according to its type before 'goto fail'; kdgraphMapRbPart2: call dgraphExit(&grafptr->data.dgrfdat) on the three early-return paths.",
   "patch_sketch": "--- hdgraph_fold.c\n   fail4:\n   ...\n   if (chekglbval != 0) {\n+    if (fldcommdattab != NULL) memFree (fldcommdattab);\n+    if (fldvertidxtab != NULL) { MPI_Waitall (requnbr, requtab, MPI_STATUSES_IGNORE); memFree (fldvertidxtab); }  /* see risk */\n     if ((fldcommtypval & DGRAPHFOLDCOMMRECV) != 0) hdgraphExit (fldgrafptr);\n--- hdgraph_order_nd.c (DIST/CENT cases)\n-      if ((cblkptr01 = dorderNew (...)) == NULL) goto fail;\n+      if ((cblkptr01 = dorderNew (...)) == NULL) { hdgraphExit (&indgrafdat01.data.dgrfdat); goto fail; }\n--- kdgraph_map_rb_part.c\n     errorPrint (\"kdgraphMapRbPart2: cannot compute ghost edge array\");\n+    dgraphExit (&grafptr->data.dgrfdat);\n     return (1);",
   "tradeoffs": "Complete, but the MPI_Waitall on error can itself hang when peers failed (a safer variant is MPI_Cancel + MPI_Wait, or leaking only the request group); each cleanup needs injection tests. Untested sketch.",
   "preferred": true
  },
  {
   "label": "B: free only what MPI cannot still reference",
   "summary": "Minimal: free fldcommdattab (not referenced by any request) at fail4 and the induced/folded graphs in nd/kdgraph, but deliberately leave the request group (it holds the Isend count buffers) in the failure case with a comment.",
   "patch_sketch": "   if (chekglbval != 0) {\n+    if (fldcommdattab != NULL) memFree (fldcommdattab);  /* not referenced by pending requests */\n     /* request group intentionally leaked: pending sends may still read fldedgecnptab */",
   "tradeoffs": "Avoids the Waitall-hang risk and the use-after-free hazard of freeing buffers under pending sends, at the price of still leaking one small group in a failure that is already catastrophic. Untested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A in spirit (the maintainers' idiom is 'failN:' labels freeing what is owned, see hdgraphGather and dgraph_fold.c), but fold-failure handling probably needs the collective-error issue fixed first.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## PS-DMO-4

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DMO-4",
 "our_title": "Fold error exits are not collective in release builds, leaving other ranks blocked",
 "severity": "medium",
 "status": "still-present",
 "method": "both",
 "location_7_0_17": "src/libscotch/hdgraph_fold.c:278-283 and 925-933 (#else branches set chekglbval = cheklocval)",
 "evidence": "Injected allocation failure in hdgraphFold2 on rank 0/1 (np=3): the failing rank printed 'out of memory (n)' and returned OrderCompute ret=1; the other ranks never returned (60 s timeout) in all 11 cases where the injection fired. Source: without SCOTCH_DEBUG_HDGRAPH1 the status is not reduced.",
 "related_review_ids": [
  "DMO-16"
 ],
 "fix_options": [
  {
   "label": "A: always reduce the status",
   "summary": "Make the Allreduce unconditional at fail1 (it precedes communications that peers will post).",
   "patch_sketch": "remove #ifdef SCOTCH_DEBUG_HDGRAPH1 around the MPI_Allreduce at line ~273",
   "tradeoffs": "One extra small collective per fold; repo avoids these deliberately.",
   "preferred": true
  },
  {
   "label": "B: document and accept",
   "summary": "Keep the design; document that allocation failures are fatal.",
   "patch_sketch": "comment only",
   "tradeoffs": "Hangs remain on OOM.",
   "preferred": false
  }
 ],
 "area": "DMO"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-06",
 "area": "DMO",
 "our_title": "Leaf ordering return codes are dropped, so compute call reports success with missing fragment",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "A forced allocation failure in the leaf ordering, as injected here, followed by perm/save to confirm downstream effects.",
 "location": "src/libscotch/hdgraph_order_nd.c:325-328 ; src/libscotch/hdgraph_order_st.c:206-207",
 "evidence": "Source (7.0.17): hdgraph_order_nd.c:325 'hdgraphOrderSt (grafptr, cblkptr, paraptr->ordstratlea);' ... 'return (0);' ; hdgraph_order_st.c:206 'hdgraphOrderSi (grafptr, cblkptr);' in STRATNODEEMPTY (result dropped, 'break', then 'return (o)' with o==0).\nReproduced with an injected allocation failure in the leaf ordering (np=3, strategy n{sep=z,ole=s,ose=s,osq=s} which makes the top-level node a leaf): FAILFN=_SCOTCHhdgraphOrderSi2 FAILRANK=1 './drv 4elt.grf o \"n{sep=z,ole=s,ose=s,osq=s}\"' prints '(1): ERROR: hdgraphOrderSi2: out of memory' and then 'rank 0/1/2: OrderCompute ret=0' on ALL ranks, followed by 'CblkDist=1' - i.e. SCOTCH_dgraphOrderCompute reports success although rank 1's fragment is missing. I did not run dorderPerm/dorderSave afterwards, so the review's downstream claims ('invalid parameters (2)', hang in dorderSave) are not verified.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate for the dropped return values (both sites). Downstream consequences (dorderPerm failing, dorderSave waiting forever) not verified.",
 "fix_options": [
  {
   "label": "A: propagate the results",
   "summary": "Keep o from hdgraphOrderSt in the leaf branch of hdgraphOrderNd2 and from hdgraphOrderSi in the STRATNODEEMPTY case. Tested: with the same injection rank 1 returns ret=1 (OrderCompute fails). Ranks 0 and 2 still return 0 because the leaf call is not collective (hdgraphOrderSi2 only checks across ranks when SCOTCH_DEBUG_HDGRAPH1 is set).",
   "patch_sketch": "--- a/src/libscotch/hdgraph_order_nd.c\n+++ b/src/libscotch/hdgraph_order_nd.c\n@@ -322,10 +322,10 @@\n     memFree (vspgrafdat.partgsttax + vspgrafdat.s.baseval); /* Free useless space */\n     memFree (vspgrafdat.fronloctab);\n \n-    hdgraphOrderSt (grafptr, cblkptr, paraptr->ordstratlea); /* Order this leaf */\n+    o = hdgraphOrderSt (grafptr, cblkptr, paraptr->ordstratlea); /* Order this leaf */\n     hdgraphExit    (grafptr);                     /* Free graph at this level   */\n     dorderDispose  (cblkptr);                     /* Clean up column block      */\n-    return (0);                                   /* Leaf has been processed    */\n+    return (o);                                   /* Leaf has been processed    */\n   }\n \n   vspvnumtab[0] = vspgrafdat.fronloctab + vspgrafdat.complocsize[2]; /* TRICK: build vertex lists within frontier array */\n@@ -360,6 +360,8 @@\n     Hdgraph             indgrafdat2;\n \n     cblkptr2 = dorderNew (cblkptr, grafptr->s.proccomm); /* Create separator node */\n+    if (cblkptr2 == NULL)\n+      goto fail;\n     cblkptr2->ordeglbval = cblkptr->ordeglbval + grafptr->s.vertglbnbr - vspgrafdat.compglbsize[2];\n     cblkptr2->vnodglbnbr = vspgrafdat.compglbsize[2];\n     cblkptr2->cblkfthnum = 2;\n\n--- a/src/libscotch/hdgraph_order_st.c\n+++ b/src/libscotch/hdgraph_order_st.c\n@@ -203,7 +203,7 @@\n       }\n       break;\n     case STRATNODEEMPTY :\n-      hdgraphOrderSi (grafptr, cblkptr);          /* Always maintain a consistent ordering */\n+      o = hdgraphOrderSi (grafptr, cblkptr);      /* Always maintain a consistent ordering */\n       break;\n     case STRATNODESELECT :\n       errorPrint (\"hdgraphOrderSt: selection operator not available for graph ordering strategies\");\n",
   "tradeoffs": "Two-line change, matches how every other call in the file uses 'o'. Does not make the error collective in release builds (pre-existing design: release builds skip the confirming Allreduce).",
   "preferred": true
  },
  {
   "label": "B: verify ordering completeness at the API",
   "summary": "In SCOTCH_dgraphOrderComputeList, after hdgraphOrderSt succeeds, Allreduce the sum of the local leaf vnodlocnbr (walk Dorder link list, as dorderCblkDist2 does) and compare to vnodglbnbr; return 1 collectively when fragments are missing. Catches any future dropped error, and makes the status collective.",
   "patch_sketch": "--- library_dgraph_order.c (after the hdgraphOrderSt call)\n+  if (dorderCheckComplete (&ordeptr->o) != 0) { errorPrint (STRINGIFY (SCOTCH_dgraphOrderComputeList) \": incomplete ordering\"); o = 1; }\n--- dorder.c\n+int dorderCheckComplete (const Dorder *);  /* sum leaf vnodlocnbr, MPI_Allreduce, compare with vnodglbnbr */",
   "tradeoffs": "Structural and collective, but costs one extra Allreduce plus a list walk per ordering call, adds a new internal function, and only detects the symptom (missing fragment), not the cause. Untested sketch.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: precedent is the neighbouring non-leaf paths in hdgraphOrderNd2 that already do 'if (o != 0) goto fail'.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-07",
 "area": "DMO",
 "our_title": "Separator column-block creation result is dereferenced without NULL check in nested dissection",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "Forced allocation failure in dorderNew, injected here.",
 "location": "src/libscotch/hdgraph_order_nd.c:362-364",
 "evidence": "Source (7.0.17):\n  cblkptr2 = dorderNew (cblkptr, grafptr->s.proccomm); /* Create separator node */\n  cblkptr2->ordeglbval = cblkptr->ordeglbval + ...;\nwith no NULL test (the two later dorderNew/dorderNewSequ calls in the same function are tested).\nReproduced with an injected allocation failure in dorderNew on rank 1 (second call, FAILSKIP=1; np=3, strategy st_df.txt): '(1): ERROR: dorderNew: cannot create new node' then 'hdgraph_order_nd.c:363:26: runtime error: member access within null pointer of type struct DorderCblk' and 'Caught signal 11 (Segmentation fault: address not mapped to object at address 0x2c)'. dorderNew is collective (Allreduce on the status) so every rank gets NULL and every rank crashes, as the review says.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "A: test and goto fail (review's fix)",
   "summary": "Add 'if (cblkptr2 == NULL) goto fail;' like the later calls. Tested: same injection now yields 'OrderCompute ret=1' on all ranks, no crash.",
   "patch_sketch": "--- a/src/libscotch/hdgraph_order_nd.c\n+++ b/src/libscotch/hdgraph_order_nd.c\n@@ -360,6 +360,8 @@\n     Hdgraph             indgrafdat2;\n \n     cblkptr2 = dorderNew (cblkptr, grafptr->s.proccomm); /* Create separator node */\n+    if (cblkptr2 == NULL)\n+      goto fail;\n     cblkptr2->ordeglbval = cblkptr->ordeglbval + grafptr->s.vertglbnbr - vspgrafdat.compglbsize[2];",
   "tradeoffs": "Trivial and idiomatic; the failure path then runs the existing 'fail:' cleanup (does not free the not-yet-folded induced graphs, see DMO-16).",
   "preferred": true
  },
  {
   "label": "B: create the separator node before mutating the parent",
   "summary": "Hoist the dorderNew for the separator above 'cblkptr->typeval = DORDERCBLKNEDI' so a failure happens while the parent column block is still a consistent leaf candidate, and fall back to ordering the whole graph as a leaf (like the 'could not separate more' branch) instead of failing.",
   "patch_sketch": "   (before 'cblkptr->typeval = DORDERCBLKNEDI;')\n+  if (vspgrafdat.compglbsize[2] != 0) {\n+    if ((cblkptr2 = dorderNew (cblkptr, grafptr->s.proccomm)) == NULL)\n+      goto leaf;                                  /* leaf: order graph as a single block */\n+  }",
   "tradeoffs": "Graceful degradation instead of error, but changes behaviour (silently worse ordering under memory pressure) and restructures the function; riskier. Untested.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-08",
 "area": "DMO",
 "our_title": "Gather error block frees uninitialised verthaltax and hgraphExit reads unset baseval after root allocation failure",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "Forced root allocation failure, injected here, plus pattern-initialised stack to expose it.",
 "location": "src/libscotch/hdgraph_gather.c:93 (verthaltax declared uninitialised), 146-212 (root allocations, 'goto fail'), 205-217 (error block)",
 "evidence": "7.0.17 source: 'Gnum * restrict verthaltax;' (:93, no initialiser). Root allocations 1-3 (:140-:178) 'goto fail' directly; the memAllocGroup that assigns verthaltax (:181-188) is skipped, then the common error block does 'if (verthaltax != NULL) memFree (verthaltax + dgrfptr->s.baseval);' and 'hgraphExit (cgrfptr)'. Also cgrfptr->s.baseval is only set at :167 (after allocation 3) while hgraphExit/graphFree use it to compute 'verttax + baseval' / 'edgetax + baseval'.\nStock ASan build: injected failure of the root's 2nd/3rd/4th memAlloc in _SCOTCHhdgraphGather (FAILRANK=0 FAILSKIP=1..3, np=3, st_df.txt) only shows the clean 'out of memory (1|2|3)' message and OrderCompute ret=1, because the stack slot happened to hold 0. With the library rebuilt with -ftrivial-auto-var-init=pattern (uninitialised locals become 0xFE..): FAILSKIP=1 -> 'AddressSanitizer: BUS on unknown address (pc ... bp 0xfefefefefefefeee)' from free() in _SCOTCHhdgraphGather+0x3220 (same for FAILSKIP=2). After the patch below both injections return cleanly (ret=1) under the same pattern-init build.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "0635547 'Rework error handling and structure of hdgraphGather()' (hdgraph_gather.c, +121/-124) restructured the function (the verthaltax allocation is now unconditional on each rank) but did not initialise verthaltax nor the Hgraph fields; the defect survives.",
 "review_accuracy": "Accurate in substance, but the sentence 'verthaltax is assigned only inside if (cheklocval == 0)' describes 7.0.16; in 7.0.17 the assignment is unconditional yet still skipped when the root's earlier 'goto fail' fires, so the uninitialised free is unchanged. The 'baseval never set' remark is also still true (set after alloc 3).",
 "fix_options": [
  {
   "label": "A: initialise verthaltax and the Hgraph fields that hgraphExit reads",
   "summary": "Declare 'verthaltax = NULL' and, right after setting flagval on the root, set baseval, verttax/vendtax/edgetax/vnumtax/velotax/vlbltax/edlotax/vnhdtax to their safe values. Tested under -ftrivial-auto-var-init=pattern with injections at root allocations 1,2,3 (previously BUS in free()): clean ret=1.",
   "patch_sketch": "--- a/src/libscotch/hdgraph_gather.c\n+++ b/src/libscotch/hdgraph_gather.c\n@@ -90,7 +90,7 @@\n   Gnum                vertlocnum;\n   Gnum                vertlocadj;                 /* Local vertex array adjust                  */\n   Gnum                vhallocnnd;\n-  Gnum * restrict     verthaltax;\n+  Gnum * restrict     verthaltax = NULL;\n   Gnum * restrict     edgehaltax;\n   Gnum                edgehalnum;\n   int                 rootnum;                    /* Index of root process                      */\n@@ -140,6 +140,15 @@\n     edgenbr = dgrfptr->s.edgeglbnbr + 2 * reduglbtab[3]; /* Twice since halo vertices will be created for real  */\n \n     cgrfptr->s.flagval = GRAPHFREEEDGE | GRAPHEDGEGROUP | GRAPHFREEVERT | GRAPHVERTGROUP; /* In case of premature freeing on error */\n+    cgrfptr->s.baseval = dgrfptr->s.baseval;      /* Set fields needed by hgraphExit() in case of premature freeing on error */\n+    cgrfptr->s.verttax = NULL;\n+    cgrfptr->s.vendtax = NULL;\n+    cgrfptr->s.edgetax = NULL;\n+    cgrfptr->s.vnumtax = NULL;\n+    cgrfptr->s.velotax = NULL;\n+    cgrfptr->s.vlbltax = NULL;\n+    cgrfptr->s.edlotax = NULL;\n+    cgrfptr->vnhdtax   = NULL;\n     recvcnttab = NULL;\n     if (memAllocGroup ((void **) (void *)\n                        &cgrfptr->s.verttax, (size_t) ((vertnbr + 1) * sizeof (Gnum)), /* Compact vertex array */\n",
   "tradeoffs": "Minimal and local; keeps hgraphExit() as the cleanup. Must be kept in sync if Hgraph gets new freed fields.",
   "preferred": true
  },
  {
   "label": "B: free by hand from tracked local pointers, no hgraphExit on partial graph",
   "summary": "Keep NULL-initialised locals for each allocation group (verttab group leader, edgetab, recvcnttab, verthaltax) and free them individually in the error block; call hgraphExit only once the Hgraph is fully built.",
   "patch_sketch": "+  Gnum * restrict  cgrverttab = NULL, cgredgetab = NULL;\n   ... after each successful alloc: remember the raw pointer ...\n   if (chekglbval != 0) {\n+    if (cgrverttab != NULL) memFree (cgrverttab);\n+    if (cgredgetab != NULL) memFree (cgredgetab);\n-    hgraphExit (cgrfptr);",
   "tradeoffs": "More explicit and independent of Hgraph internals, but more code and duplicates graphFree's group-leader logic; larger risk of a mismatch between raw and based pointers. Untested.",
   "preferred": false
  }
 ],
 "notes": "Initialisation of locals is also what the repo does for the sibling dmapSave ('Prevent Valgrind from yelling').",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## PS-DMO-5

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DMO-5",
 "our_title": "Halo ordering wrapper returns only the root rank's status",
 "severity": "info",
 "status": "still-present",
 "method": "both",
 "location_7_0_17": "src/libscotch/hdgraph_order_sq.c (hdgraphOrderSq: o set only when cgrfptr != NULL)",
 "evidence": "Source: 'o = 0; if (cgrfptr != NULL) o = hdgraphOrderSq2 (...)'. In the DMO-06 patched injection run rank 1 returned ret=1 while ranks 0 and 2 returned 0.",
 "related_review_ids": [
  "DMO-06"
 ],
 "fix_options": [
  {
   "label": "A: broadcast status",
   "summary": "Allreduce the status after the sequential ordering.",
   "patch_sketch": "MPI_Allreduce (&o, &og, 1, MPI_INT, MPI_MAX, proccomm)",
   "tradeoffs": "One collective per leaf.",
   "preferred": true
  },
  {
   "label": "B: leave as is",
   "summary": "Rely on higher levels.",
   "patch_sketch": "none",
   "tradeoffs": "Statuses stay inconsistent.",
   "preferred": false
  }
 ],
 "area": "DMO"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-17",
 "area": "DMO",
 "our_title": "Parallel mapping onto non-complete targets reaches a stub returning error, as documented",
 "claimed_severity": "info",
 "status": "not-a-bug",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kdgraph_map_rb.c:260-262 ; src/libscotch/kdgraph_map_rb_map.c:73-78",
 "evidence": "Reproduced: 'mpirun --oversubscribe -np 2 ./drv3 4elt.grf asan/tgt/h3.tgt' (hypercube target; drv3 = SCOTCH_dgraphMap with default strategy) -> '(0): ERROR: kdgraphMapRbMap: not implemented yet' / '(1): ... not implemented yet', 'dgraphMap ret=1' on both ranks, no hang. With asan/tgt/k16.tgt (cmplt 16) ret=0.\nThe limitation is documented: man/man1/dgmap.1 NOTE: 'dgmap cannot compute full static mappings as gmap(1) does, but only partitions (that is, mappings onto unweighted or weighted complete graphs). Target architectures other than the 'cmplt' and 'wcmplt' ones will lead to an error message.'",
 "upstream_change": "none",
 "review_accuracy": "Accurate as a description (and the review itself rates it Info/missing-feature); it is documented intended behaviour, hence not-a-bug. I could not check the PT-Scotch PDF manual (no pdf tools).",
 "fix_options": [],
 "notes": "Optional improvement if desired: reject non-archPart targets in SCOTCH_dgraphMapCompute before gathering/partitioning, or gather+kgraphMap+scatter (large feature). 'sub' and variable-sized targets (varcmplt) take the Part path.",
 "history": {
  "reported": "reported",
  "7.0.17": "not-a-bug"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)
