# G17-fortran-wrappers

Items: API-01, API-05, API-09, API-11, PS-API-6, API-13, API-24, BLD-20



===================================================================
## API-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-01",
 "area": "API",
 "our_title": "Fortran order-strategy builder now forwards flag and level arguments in the C order",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_order_f.c:338",
 "evidence": "7.0.17 line: '*revaptr = SCOTCH_stratGraphOrderBuild (straptr, *flagval, *levlnbr, *kbalval);'. Ran work/API/fort.c mode 0 (calls scotchfstratgraphorderbuild_ and SCOTCH_stratGraphOrderBuild with flagval=SCOTCH_STRATLEVELMAX, levlnbr=7, kbalval=0.1) against the ASan 7.0.17 libscotch: both strategy strings are byte-identical and contain '(levl)<(7)'.",
 "upstream_change": "259f38a Bugfix: restore parameter order when calling from Fortran [report R. Perry]",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-05",
 "area": "API",
 "our_title": "Fortran induce and band wrappers dereference scalar arguments before calling the C routines",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_induce_f.c:71-95; library_dgraph_band_f.c:72-80",
 "evidence": "7.0.17 declares vnumnbr, partval (induce) and fronlocnbr, distval (dgraphBand) as pointers and dereferences them. Ran work/API/ind.c (calls scotchfgraphinducelist_/scotchfgraphinducepart_ with pointers): ierr=0, induced graph vertnbr=2 edgenbr=2 in both cases, no ASan report. DGRAPHBAND checked by source diff only (needs MPI Fortran caller).",
 "upstream_change": "b189b87 Bugfix: dereference integer values passed from the Fortran API [report R. Perry]",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-09",
 "area": "API",
 "our_title": "Distributed stat Fortran wrapper's macro lowercase name is mixed-case, so exported symbol differs",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_dgraph_stat_f.c:70 (SCOTCH_FORTRAN (DGRAPHSTAT, Dgraphstat, (...)",
 "evidence": "Unchanged. 'nm -D asan/lib/libptscotch.so | grep -i fdgraphstat' prints only: SCOTCHFDGRAPHSTAT, scotchfDgraphstat, scotchfDgraphstat_, scotchfDgraphstat__ (no scotchfdgraphstat*). After changing the macro argument to 'dgraphstat' in the patched 64-bit build, nm lists scotchfdgraphstat, scotchfdgraphstat_, scotchfdgraphstat__.",
 "upstream_change": "",
 "review_accuracy": "accurate. Line number is 70, not 70-71 (cosmetic).",
 "fix_options": [
  {
   "label": "Fix the lower-case macro argument",
   "summary": "One-token change: SCOTCH_FORTRAN (DGRAPHSTAT, dgraphstat, (...)",
   "patch_sketch": "--- library_dgraph_stat_f.c\n+++ library_dgraph_stat_f.c\n@@ -68,7 +68,7 @@\n */\n \n SCOTCH_FORTRAN (                              \\\n-DGRAPHSTAT, Dgraphstat, (                     \\\n+DGRAPHSTAT, dgraphstat, (                     \\\n const SCOTCH_Dgraph * const grafptr,          \\\n SCOTCH_Num * const          velominptr,       \\\n SCOTCH_Num * const          velomaxptr,       \\\n",
   "tradeoffs": "Fixes link for lowercase callers. Callers that worked around it by calling 'Dgraphstat' (nobody documented that) would break; extremely unlikely.",
   "preferred": true
  },
  {
   "label": "Keep both spellings",
   "summary": "Also export a compatibility alias scotchfDgraphstat* that forwards to the corrected routine (second SCOTCH_FORTRAN with the old name).",
   "patch_sketch": "/* after the corrected wrapper */\nSCOTCH_FORTRAN (DGRAPHSTAT_COMPAT, Dgraphstat, (...same args...), (...)) { SCOTCHFDGRAPHSTAT (...); }",
   "tradeoffs": "Zero ABI break, but permanently carries a typo-named symbol into the ABI; maintainers rarely do this.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-11",
 "area": "API",
 "our_title": "Distributed mapping-stat Fortran wrapper lacks documented trailing error argument, drops return code",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_dgraph_map_stat_f.c:66-95",
 "evidence": "Unchanged. Doc p_l.tex:3124-3141 lists a trailing 'integer ierr'; wrapper (7.0.17) ends at cmexsumptr and does not store SCOTCH_dgraphMapStat's result. Ran work/API/dmv2.c (mpirun -np 2, calls scotchfdgraphmapstat_ with an extra int* initialised to -77) on the ASan 7.0.17: 'Fortran DGRAPHMAPSTAT ierr=-77 (never written)'. With the patch: ierr=0.",
 "upstream_change": "",
 "review_accuracy": "accurate (also note doc lists mapmax before mapmin while the C and wrapper order is mapmin, mapmax: a separate doc bug).",
 "fix_options": [
  {
   "label": "Add trailing int * revaptr and store the result",
   "summary": "Match every other wrapper (…, int * const revaptr) and '*revaptr = SCOTCH_dgraphMapStat (...)'.",
   "patch_sketch": "--- library_dgraph_map_stat_f.c\n+++ library_dgraph_map_stat_f.c\n@@ -81,14 +81,15 @@\n SCOTCH_Num                    cdsttab[256], \\\n SCOTCH_Num * const            cmlosumptr,   \\\n SCOTCH_Num * const            cmdisumptr,   \\\n-SCOTCH_Num * const            cmexsumptr),  \\\n+SCOTCH_Num * const            cmexsumptr,   \\\n+int * const                   revaptr),     \\\n (grafptr, mapptr, tgtnbrptr,                \\\n  mapnbrptr, mapminptr, mapmaxptr,           \\\n  mapavgptr, mapdltptr,\t\t            \\\n  ngbsumptr, ngbminptr, ngbmaxptr,           \\\n- cdstmaxptr, cdsttab, cmlosumptr, cmdisumptr, cmexsumptr))\n+ cdstmaxptr, cdsttab, cmlosumptr, cmdisumptr, cmexsumptr, revaptr))\n {\n-  SCOTCH_dgraphMapStat (grafptr, mapptr, tgtnbrptr,\n+  *revaptr = SCOTCH_dgraphMapStat (grafptr, mapptr, tgtnbrptr,\n                         mapnbrptr, mapminptr, mapmaxptr, mapavgptr, mapdltptr,\n                         ngbsumptr, ngbminptr, ngbmaxptr,\n                         cdstmaxptr, cdsttab,\n",
   "tradeoffs": "Fixes the documented interface; a caller compiled against the current ierr-less wrapper does not pass the extra argument, so it must be updated (but a caller written from the manual already passes it and is currently ignored). Tested via C call: ierr=0 written.",
   "preferred": true
  },
  {
   "label": "Fix the manual instead",
   "summary": "Remove ierr from the manual (p_l.tex) and keep the void wrapper.",
   "patch_sketch": "-                       & integer               & ierr)\n+                       & integer*{\\it num}     & cmexsum)",
   "tradeoffs": "Zero ABI change but leaves Fortran users unable to detect errors, inconsistent with all other wrappers; maintainers unlikely to choose.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-6

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-6",
 "our_title": "Manual lists mapmax before mapmin for Fortran DGRAPHMAPSTAT, unlike the C order",
 "severity": "info",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "doc/src/ptscotch/p_l.tex:3124-3141 vs library_dgraph_map_stat_f.c argument order",
 "evidence": "Manual Fortran synopsis: tgtnbr, mapnbr, mapmax, mapmin; C and the wrapper: tgtnbrptr, mapnbrptr, mapminptr, mapmaxptr.",
 "related_review_ids": [
  "API-11"
 ],
 "fix_options": [
  {
   "label": "Fix the manual",
   "summary": "Swap the two lines in p_l.tex.",
   "patch_sketch": "mapmin before mapmax",
   "tradeoffs": "Doc only.",
   "preferred": true
  },
  {
   "label": "Swap wrapper order",
   "summary": "Change the wrapper to match the manual.",
   "patch_sketch": "swap args",
   "tradeoffs": "Breaks existing Fortran callers.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-13",
 "area": "API",
 "our_title": "Architecture size Fortran wrapper stores a 64-bit count through a 32-bit int pointer",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_arch_f.c:217-224",
 "evidence": "Unchanged: 'int * const sizeptr ... *sizeptr = SCOTCH_archSize (archptr);'. Doc s_l.tex:1896-1897 declares 'integer*num archnbr'. Reproduced on a 64-bit-INT build of 7.0.17 (work/API/s64, -DINTSIZE64): linking the ORIGINAL library_arch_f.c object and calling scotchfarchsize_ on archCmplt(70000) with an int64 initialised to 0x5a5a5a5a5a5a5a5a gives 0x5a5a5a5a00011170 (upper half untouched). With SCOTCH_Num * the result is 0x11170. On the default 32-bit-INT build int == SCOTCH_Num so nothing is observable.",
 "upstream_change": "",
 "review_accuracy": "accurate (only matters when INTSIZE64). ARCHVAR keeps int * correctly (flag).",
 "fix_options": [
  {
   "label": "Declare sizeptr as SCOTCH_Num *",
   "summary": "One-line type change.",
   "patch_sketch": "--- library_arch_f.c\n+++ library_arch_f.c\n@@ -217,7 +217,7 @@\n SCOTCH_FORTRAN (                      \\\n ARCHSIZE, archsize, (                 \\\n SCOTCH_Arch * const         archptr,  \\\n-int * const                 sizeptr), \\\n+SCOTCH_Num * const          sizeptr), \\\n (archptr, sizeptr))\n {\n   *sizeptr = SCOTCH_archSize (archptr);\n",
   "tradeoffs": "Fixes the 64-bit case; no behaviour change for 32-bit builds. Same class of bug may exist for other *_f.c scalar outputs; worth a grep for 'int \\* const' outputs of Num type.",
   "preferred": true
  },
  {
   "label": "Add a SCOTCH_Num temporary",
   "summary": "Compute 'SCOTCH_Num sizeval = SCOTCH_archSize (...)' and store with an explicit cast to whichever type the manual specifies.",
   "patch_sketch": "SCOTCH_Num sizeval = SCOTCH_archSize (archptr);\n*sizeptr = sizeval;  /* sizeptr: SCOTCH_Num * */",
   "tradeoffs": "Equivalent; only useful if one wants to keep ABI-agnostic casts; no advantage.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-24

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-24",
 "area": "API",
 "our_title": "Thirteen Fortran routines listed in the manuals have no corresponding exported symbol",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "doc/src/scotch/s_l.tex (archbuild0 :1960, archbuild2 :2033, archltleaf :2179, graphorderload :5183, meshstat :5968, stratsizeof :6487, mapsizeof :7451, ordersizeof :7494); doc/src/ptscotch/p_l.tex (dgraphfree :2076, dgraphgrow :2143, dmeshfree :4129, dmapsizeof :4679, dordersizeof :4722)",
 "evidence": "For each of the 13 names: grep in the 7.0.17 .tex shows 'scotchf<name>' documented, and 'nm -D asan/lib/libscotch.so asan/lib/libptscotch.so | grep -i scotchf<name>' returns nothing (loop in this session: sym=0 for all 13, doc=1 for all). Note SCOTCH_archLtleaf is also missing from the C header (see API-10).",
 "upstream_change": "",
 "review_accuracy": "accurate (13/13 confirmed)",
 "fix_options": [
  {
   "label": "Add the wrappers",
   "summary": "One SCOTCH_FORTRAN stanza per routine in the matching library_*_f.c (the sizeof ones: 'ARCHSIZEOF' in library_arch_f.c is the template; free/grow/stat ones copy the pattern 'void routine(args, int * revaptr)').",
   "patch_sketch": "SCOTCH_FORTRAN (STRATSIZEOF, stratsizeof, (int * const sizeptr), (sizeptr)) { *sizeptr = SCOTCH_stratSizeof (); }",
   "tradeoffs": "Delivers what the manual promises, ABI-additive; needs 13 small functions and a Fortran link test per symbol.",
   "preferred": true
  },
  {
   "label": "Remove them from the manuals",
   "summary": "Delete the 13 \\progsyn Fortran entries.",
   "patch_sketch": "-scotchfstratsizeof ( & integer & size )",
   "tradeoffs": "No code, but removes documented functionality (users may rely on the docs); maintainers unlikely.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## BLD-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-20",
 "area": "BLD",
 "our_title": "Fortran mesh-dual partition test never inspects the returned values",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read is conclusive; adding range checks and running the Fortran test would confirm the port.",
 "location": "src/check/test_libmetis_dual_f.f90.in:134-138 (call at ~137)",
 "evidence": "7.0.17: after `call SCOTCHMETISNAMEFU (METIS_PartMeshDual) (ne, nn, eptr, eind, vgwt, vsize, ncommon, nparts, tpwgt, options, objval, epart, npart)` the block ends and the program deallocates epart/npart; no use of objval/epart/npart. The C counterpart src/check/test_libmetis_dual.c:157-175 checks `objval < 0` and that each epart/npart value lies in [baseval, baseval+nparts). Fortran test not executed (gfortran available but not run through CMake templates).",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Mirror the C checks",
   "summary": "After the call, loop and `call exit_c (1)` on out-of-range values or objval < 0 (the file already uses exit_c).",
   "patch_sketch": "+  if (objval < 0) then\n+    print *, \"ERROR: main: invalid objval\"\n+    call exit_c (1)\n+  end if\n+  do i = 1, ne\n+    if ((epart(i) < baseval) .or. (epart(i) >= baseval + nparts)) then ... call exit_c (1)\n+  do i = 1, nn  (npart)",
   "tradeoffs": "Direct port of the C assertions; not compiled here.",
   "preferred": true
  },
  {
   "label": "Use a helper subroutine for range checks",
   "summary": "Add `check_part(arr, n, baseval, nparts)` contained in the program.",
   "patch_sketch": "contains\n  subroutine check_part (...)",
   "tradeoffs": "Cleaner for two arrays; slightly more Fortran.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (parity with test_libmetis_dual.c).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)
