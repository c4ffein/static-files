# G22-bdgraph

Items: DMO-09, DMO-11, DMO-18, DMO-19, DMO-03, DMO-10, PS-DMO-3



===================================================================
## DMO-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-09",
 "area": "DMO",
 "our_title": "Bipartition imbalance strategy variable is never refreshed after sequential, zero and multilevel steps",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/bdgraph_bipart_ml.c:753 ; bdgraph_bipart_sq.c:232-240 (no bbalglbval update) ; bdgraph.c:178-193 (bdgraphZero) ; bdgraph_gather_all.c:249 (no bbalval)",
 "evidence": "grep of bbalglbval/bbalval in 7.0.17: assigned in bdgraphInit2 (bdgraph.c:138), bdgraph_bipart_df.c:389, _ex.c:493, _bd.c:444, bdgraph_store.c:174 and copied in bdgraph_bipart_ml.c:753 ('finegrafptr->bbalglbval = coargrafptr->bbalglbval;'); never in bdgraphBipartSq, bdgraphZero (bdgraph.c:178-193), bdgraphGatherAll (bgraph bbalval left uninitialised).\nReproduced with printf instrumentation in a copy (dbg tree): './drv 4elt.grf m \"\" 8' np=4 prints 'BBALSQ rank r stale=0 recomputed=0.022171' on all 4 ranks right after bdgraphBipartSq, and 'BBALML ... copied=0 recomputed=0.022171' after the ml uncoarsening that copies it, i.e. a strategy test '(bal>0.01)?...' would see 0 although the real imbalance is 2.2%. I did NOT demonstrate divergence between ranks (the copy-from-own-coarse-graph path with duplicated folding) - all ranks held the same stale value in this run.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate on the staleness (verified for Sq and Ml; Zero and GatherAll by reading). The 'different ranks branch differently' consequence is plausible (the Ml copy takes the rank's own coarse graph) but unproven here. Additional inconsistency: bdgraphInit2/bdgraphZero style uses a signed ratio while df/ex/bd/store use |dlt|/avg, and sequential bgraph uses the signed ratio.",
 "fix_options": [
  {
   "label": "A: recompute at the update sites (repo idiom)",
   "summary": "After each place that changes compglbload0dlt without setting bbalglbval (bdgraphBipartSq after the Bcast, bdgraphBipartMlUncoarsen instead of the copy, bdgraphZero) assign bbalglbval from the global data, as bdgraph_bipart_df.c:389 does; add bbalval in bdgraphGatherAll. Tested in the instrumented tree: BBALSQ stale==recomputed, BBALML copied==recomputed.",
   "patch_sketch": "--- bdgraph_bipart_sq.c (after dgrfptr->fronglbnbr = reduloctab[4];)\n+  dgrfptr->bbalglbval      = (dgrfptr->compglbload0avg != 0) ? ((double) ABS (dgrfptr->compglbload0dlt) / (double) dgrfptr->compglbload0avg) : 0.0;\n--- bdgraph_bipart_ml.c:753\n-  finegrafptr->bbalglbval      = coargrafptr->bbalglbval;\n+  finegrafptr->bbalglbval      = (finegrafptr->compglbload0avg != 0) ? ((double) ABS (finegrafptr->compglbload0dlt) / (double) finegrafptr->compglbload0avg) : 0.0;\n--- bdgraph.c (bdgraphZero, after compglbload0dlt)\n+  grafptr->bbalglbval      = (grafptr->compglbload0avg != 0) ? ((double) ABS (grafptr->compglbload0dlt) / (double) grafptr->compglbload0avg) : 0.0;\n--- bdgraph_gather_all.c:249\n+  cgrfptr->bbalval         = (double) cgrfptr->compload0dlt / (double) cgrfptr->compload0avg;",
   "tradeoffs": "Follows exactly the existing per-method convention; every rank derives the value from the already-reduced global loads so it is identical across ranks. Four touch points to keep in sync for future methods. Sign choice (abs vs signed) must be decided once.",
   "preferred": true
  },
  {
   "label": "B: recompute lazily where the strategy tests it",
   "summary": "In bdgraphBipartSt, before stratTestEval in the STRATNODECOND case, refresh grafptr->bbalglbval from compglbload0dlt/compglbload0avg. Single place, covers all methods including future ones. Smoke-tested (default dgpart/dgord runs at np=2,4,5 unchanged).",
   "patch_sketch": "--- a/src/libscotch/bdgraph_bipart_st.c\n+++ b/src/libscotch/bdgraph_bipart_st.c\n@@ -294,6 +294,9 @@\n         o |= bdgraphBipartSt (grafptr, straptr->data.concdat.stratab[1]); /* Then apply second strategy */\n       break;\n     case STRATNODECOND :\n+      grafptr->bbalglbval = (grafptr->compglbload0avg != 0) /* Recompute strategy variable from current (global, hence identical across processes) partition data */\n+                            ? ((double) ABS (grafptr->compglbload0dlt) / (double) grafptr->compglbload0avg)\n+                            : 0.0;\n       o = stratTestEval (straptr->data.conddat.testptr, &testdat, (void *) grafptr); /* Evaluate expression */\n       if (o == 0) {                               /* If evaluation was correct */\n #ifdef SCOTCH_DEBUG_BDGRAPH2\n\n--- a/src/libscotch/bdgraph_gather_all.c\n+++ b/src/libscotch/bdgraph_gather_all.c\n@@ -247,6 +247,7 @@\n \n   cgrfptr->compload0     = dgrfptr->compglbload0; /* Update other fields */\n   cgrfptr->compload0dlt  = dgrfptr->compglbload0dlt;\n+  cgrfptr->bbalval       = (double) cgrfptr->compload0dlt / (double) cgrfptr->compload0avg;\n   cgrfptr->compsize0     = dgrfptr->compglbsize0;\n   cgrfptr->commload      = dgrfptr->commglbload;\n   cgrfptr->commgainextn  = dgrfptr->commglbgainextn;\n",
   "tradeoffs": "One central site, cannot go stale again; but adds a division per condition node and hides the fact that individual methods leave the field stale for other readers (none exist today besides the strategy test). Departs from the per-method convention. Only 'bal' consumers inside bdgraphBipartSt are fixed.",
   "preferred": false
  }
 ],
 "notes": "Preferred A because every existing producer of bbalglbval sets it itself at the end of the method (precedent: bdgraph_bipart_df.c:389, bdgraph_bipart_ex.c:493).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-11",
 "area": "DMO",
 "our_title": "Best-partition MPI reduction breaks ties on signed imbalance instead of magnitude",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read was conclusive; a runtime proof would need two candidates with equal cut and opposite-sign imbalance.",
 "location": "bdgraph_bipart_ml.c:208-211 (OpBest, in[4]/inout[4]; producer :335) ; bdgraph_bipart_sq.c:111-114 (producer :182) ; vdgraph_separate_ml.c:180-183 (producer :422) ; vdgraph_separate_sq.c:104-107 (producer :173)",
 "evidence": "7.0.17 bdgraph_bipart_ml.c:208-211: '(in[3] < inout[3]) || ((in[3] == inout[3]) && ((in[4] < inout[4]) || ((in[4] == inout[4]) && (in[1] < inout[1]))))' with 'reduloctab[4] = coargrafptr->compglbload0dlt;' (signed, :335). Identical pattern in the other three. The sequential selection in the same code base compares absolute values: bdgraph_bipart_st.c:355-362 uses ABS(...) on both sides (after f545452) and bgraph_bipart_st.c:364,370 uses ABS(compload0dlt). Hence among equal communication loads the reduction prefers dlt=-500 over dlt=+3. No dynamic reproducer built (would need two candidates with identical cut and opposite-sign imbalance); source-read only.",
 "upstream_change": "none",
 "review_accuracy": "Accurate. (For the Sq variants the compared quantity is the sequential compload0dlt/comploaddlt, signed.)",
 "fix_options": [
  {
   "label": "A: feed the reduction the absolute imbalance (producer side)",
   "summary": "Store ABS(dlt) in the reduction slot; the operators stay pure '<' comparisons. The slot is not reused afterwards for its signed meaning (checked: ml uses reduglbtab[1]/[3]/[4]-as-commload only, Sq overwrites reduloctab for the Bcast). Compiles and smoke-tested (dgpart/dgord np=2,4,5).",
   "patch_sketch": "-    reduloctab[4] = coargrafptr->compglbload0dlt;\n+    reduloctab[4] = ABS (coargrafptr->compglbload0dlt); /* Compare on absolute imbalance */   (bdgraph_bipart_ml.c:335)\n-    reduloctab[1] = cgrfdat.compload0dlt;\n+    reduloctab[1] = ABS (cgrfdat.compload0dlt);   (bdgraph_bipart_sq.c:182)\n-    reduloctab[4] = coargrafptr->compglbloaddlt;\n+    reduloctab[4] = ABS (coargrafptr->compglbloaddlt);   (vdgraph_separate_ml.c:422)\n-    reduloctab[1] = cgrfdat.comploaddlt;\n+    reduloctab[1] = ABS (cgrfdat.comploaddlt);   (vdgraph_separate_sq.c:173)",
   "tradeoffs": "Four one-line edits, no change to the MPI operator or datatype; consistent total order (ties still broken by rank). GNUMMAX sentinel is unaffected.",
   "preferred": true
  },
  {
   "label": "B: compare absolute values inside the operators",
   "summary": "Change the tie-break in the four OpBest functions to ABS(in[k]) < ABS(inout[k]) (and ==).",
   "patch_sketch": "-       ((in[4] < inout[4]) ||\n-        ((in[4] == inout[4]) && (in[1] < inout[1]))))) {\n+       ((ABS (in[4]) < ABS (inout[4])) ||\n+        ((ABS (in[4]) == ABS (inout[4])) && (in[1] < inout[1]))))) {",
   "tradeoffs": "Keeps the transported value signed (useful if someone later reads reduglbtab[4]) and mirrors bdgraph_bipart_st.c's comparison, but touches the user-defined MPI reduction operator (must stay commutative/associative - it does: lexicographic on (cut, |dlt|, rank)). Untested.",
   "preferred": false
  }
 ],
 "notes": "Effect is quality only (not correctness) and only on exact ties of the primary key.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-18",
 "area": "DMO",
 "our_title": "Debug-only checks use wrong module macros, wrong function name, never-failing sum and && operator",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "source-read",
 "needs": "debug-build",
 "needs_note": "Build with SCOTCH_DEBUG_* enabled and exercise these paths.",
 "location": "hdgraph_fold.c:891-894 (#ifdef SCOTCH_DEBUG_DGRAPH1 and 'dgraphFold2: communication error (18)') ; bdgraph_bipart_ml.c:103-107 (#ifdef SCOTCH_DEBUG_BGRAPH2 ... #endif /* SCOTCH_DEBUG_BDGRAPH2 */) ; vdgraph_separate_ml.c:383,449-451 (BDGRAPH1/BDGRAPH2 macros in the vdgraph module) ; vdgraph_separate_sq.c:181-185 ; hdgraph_order_st.c:189-191",
 "evidence": "7.0.17 quotes: hdgraph_fold.c:894 'errorPrint (\"dgraphFold2: communication error (18)\");' inside hdgraphFold2 under '#ifdef SCOTCH_DEBUG_DGRAPH1'; bdgraph_bipart_ml.c:103 '#ifdef SCOTCH_DEBUG_BGRAPH2 ... default: errorPrint (\"bdgraphBipartMlCoarsen: invalid parameter\")' closed by '#endif /* SCOTCH_DEBUG_BDGRAPH2 */'; vdgraph_separate_ml.c:383 '#ifdef SCOTCH_DEBUG_BDGRAPH1' and :449 '#ifdef SCOTCH_DEBUG_BDGRAPH2' in vdgraph code; vdgraph_separate_sq.c:181-185: 'MPI_Allreduce (&reduglbtab[3], &reduloctab[3], ...MPI_SUM...)' followed by 'if ((reduloctab[3] != 0) && (reduloctab[3] != procglbnbr))' - reduglbtab[3] is already the reduced flag (identical on all ranks, 0 or 1) so the sum is 0 or procglbnbr and the check can never fire; hdgraph_order_st.c:190 '(testdat.testval != STRATTESTVAL) && (testdat.nodeval != STRATPARAMLOG)' where the distributed siblings (bdgraph_bipart_st.c:300, vdgraph_separate_st.c:276, kdgraph_map_st.c:161) use '||'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate, with one correction: the sequential hgraph_order_st.c:284 has the same '&&', so '&&' is not unique to hdgraph_order_st.c, only the distributed siblings use '||'.",
 "fix_options": [
  {
   "label": "A: correct each macro / name / operator",
   "summary": "Use SCOTCH_DEBUG_HDGRAPH1 and 'hdgraphFold2' in hdgraph_fold.c, SCOTCH_DEBUG_BDGRAPH2 for the bdgraphBipartMlCoarsen default case, VDGRAPH1/VDGRAPH2 in vdgraph_separate_ml.c, reduce the LOCAL flag (reduloctab[3]) in vdgraph_separate_sq.c, and '||' in hdgraph_order_st.c (and hgraph_order_st.c).",
   "patch_sketch": "-#ifdef SCOTCH_DEBUG_DGRAPH1\n-      errorPrint (\"dgraphFold2: communication error (18)\");\n+#ifdef SCOTCH_DEBUG_HDGRAPH1\n+      errorPrint (\"hdgraphFold2: communication error (18)\");\n-  if (MPI_Allreduce (&reduglbtab[3], &reduloctab[3], 1, GNUM_MPI, MPI_SUM, ...\n+  if (MPI_Allreduce (&reduloctab[3], &reduglbtab[3], 1, GNUM_MPI, MPI_SUM, ...   /* then compare reduglbtab[3] */\n-        if ((testdat.testval != STRATTESTVAL) &&\n+        if ((testdat.testval != STRATTESTVAL) ||",
   "tradeoffs": "Only affects debug builds (SCOTCH_DEBUG_* defined); zero risk for release but the vdgraph_separate_sq change turns a never-firing check into an active one (verify it does not then fire spuriously: reduloctab[3] semantics must be re-read first). The BGRAPH2/BDGRAPH2 mismatch changes which flag enables the default: branch.",
   "preferred": true
  },
  {
   "label": "B: delete the dead checks",
   "summary": "Remove the checks that can never fire (vdgraph_separate_sq.c:181-185) and the mismatched #ifdef-guarded default: branches, keeping only the macro/name fixes that are certain.",
   "patch_sketch": "-#ifdef SCOTCH_DEBUG_VDGRAPH2\n-  if (MPI_Allreduce (&reduglbtab[3], &reduloctab[3], ...\n-  ...\n-#endif /* SCOTCH_DEBUG_VDGRAPH2 */",
   "tradeoffs": "Less code, no risk of newly firing checks; but loses the intended consistency verification. Untested (not compiled).",
   "preferred": false
  }
 ],
 "notes": "Low value; no runtime proof possible in release builds. I did not build with SCOTCH_DEBUG_* to confirm these compile today.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-19",
 "area": "DMO",
 "our_title": "Unused external-gain code indexes local arrays with global numbers and doubles a commit term",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read was conclusive; the code is unreachable until external gains are implemented.",
 "location": "bdgraph_bipart_ml.c:127-151 (coarsening merge) ; bdgraph_bipart_ex.c:464-465,482,491 ; bdgraph.c:98,107 ('/* TODO: Compute external gains */')",
 "evidence": "veexloctax is assigned only to NULL in bdgraphInit (bdgraph.c:98, 'No external gain (yet)', followed by the literal comment '/* TODO: Compute external gains */' at :107), so the code is unreachable today. In the coarsening merge (bdgraph_bipart_ml.c:147-151): 'finevertnum0 = coarmulttax[coarvertlocnum].vertglbnum[0]; ... coarveexloctax[...] = finegrafptr->veexloctax[finevertnum0] + finegrafptr->veexloctax[finevertnum1]' - vertglbnum are GLOBAL vertex numbers (a multinode can pair with a remote vertex) used to index a LOCAL based array. In bdgraph_bipart_ex.c:482-491 'reduloctab[4] = commlocgainextn * 2;' is later added in full to 'commglbload += reduglbtab[3] / 2 + reduglbtab[4]' while commlocgainextn accumulates '(partval - (partval ^ flagval)) * veexloctax[...]' which is already the full external-load change; so commglbload receives twice that change, while 'commglbgainextn -= reduglbtab[4]' (the 2x) is consistent with bgraph.c:229-230. Not reproducible (needs enabling external gains).",
 "upstream_change": "none",
 "review_accuracy": "Accurate on the indexing bug; the 'adds twice' accounting claim is consistent with my reading of bgraph.c (commload += gain; gain = -gain) but I did not verify it numerically. The suggested 'Convert to local numbers before indexing' is not sufficient: a multinode partner may be remote, so a halo exchange of veex (ghost array) is required.",
 "fix_options": [
  {
   "label": "A: fix in place (ghost array + halve the term)",
   "summary": "Exchange veexloctax into a ghost-sized array with dgraphHaloSync before the coarsening merge and index it with local/ghost numbers; change the exact-method line to 'commglbload += reduglbtab[3] / 2 + reduglbtab[4] / 2'.",
   "patch_sketch": "--- bdgraph_bipart_ex.c:491\n-  grafptr->commglbload     += reduglbtab[3] / 2 + reduglbtab[4];\n+  grafptr->commglbload     += reduglbtab[3] / 2 + reduglbtab[4] / 2;  /* reduglbtab[4] holds twice the external load change */\n--- bdgraph_bipart_ml.c (before the merge loop)\n+  if (dgraphHaloSync (&finegrafptr->s, (byte *) (veexgsttax + baseval), GNUM_MPI) != 0) { ... }  /* ghost copy of veexloctax */\n-    finegrafptr->veexloctax[finevertnum0]\n+    veexgsttax[ghost/local index of finevertnum0]",
   "tradeoffs": "Makes the latent path correct for when external gains are implemented; needs a test harness that actually sets veexloctax (none exists), so correctness cannot be validated today. Untested.",
   "preferred": false
  },
  {
   "label": "B: fail loudly until the feature exists",
   "summary": "Add 'if (finegrafptr->veexloctax != NULL) { errorPrint (\"...external gains not supported\"); return (1); }' guards at the three sites (ml coarsen, ex, df) instead of keeping unverifiable code.",
   "patch_sketch": "+  if (finegrafptr->veexloctax != NULL) {\n+    errorPrint (\"bdgraphBipartMlCoarsen: external gains not yet supported\");\n+    return (1);\n+  }",
   "tradeoffs": "Zero behaviour change today (veexloctax is always NULL) and prevents silent miscomputation when someone wires the TODO; removes the possibility of testing the dead code. Untested.",
   "preferred": true
  }
 ],
 "notes": "Preferred B for a maintainer who has not scheduled the feature; A once external gains are implemented.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-03",
 "area": "DMO",
 "our_title": "Sequential bipartition wrapper tests per-rank failure count and ignores allocation flag, desynchronising collectives",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "Run the Sq method with a forced malloc failure on one rank, as done here, or a real low-memory cluster run.",
 "location": "src/libscotch/bdgraph_bipart_sq.c:174-177 (reduloctab[3]/[4] failure flags), 188-199 (reduloctab[5] allocation flags), 207-210 (reduloctab[4] test, returns before MPI_Op_free at :212), 218-221",
 "evidence": "Source (7.0.17): after the Allreduce, line 207 reads\n  if ((reduloctab[4] != 0) && (reduloctab[4] != dgrfptr->s.procglbnbr)) { errorPrint (\"bdgraphBipartSq: internal error\"); return (1); }\n(reduloctab = LOCAL array; reduglbtab[4] never used) and reduglbtab[5] (OR of allocation failures, set at :188,:193,:199) is never tested anywhere in the function. The 'internal error' return also skips MPI_Op_free/MPI_Type_free and bgraphExit(&cgrfdat).\nReproduced with injected failures (np=3, 4elt, strategy 'r{sep=q{strat=h},seq=r{sep=h}}' so that the q (Sq) method is used, driver drv m):\n(a) FAILFN=_SCOTCHbdgraphBipartSq FAILRANK=1 (memAlloc of partgsttax fails on rank 1): rank 1 prints 'bdgraphBipartSq: out of memory (1)'; the run then dies with 'Caught signal 11 (Segmentation fault: address not mapped to object at address 0x20)' inside opal_convertor_unpack called from the MPI_Scatterv in commScatterv (scatter into NULL partgsttax on rank 1).\n(b) FAILFN=_SCOTCHbgraphBipartGg FAILRANK=1 (bgraphBipartSt fails on rank 1 only): rank 1 prints 'cannot bipartition centralized graph' then 'bdgraphBipartSq: internal error' and returns 1 ('rank 1: Map/Part ret=1'); ranks 0 and 2 never return (blocked in MPI_Bcast, killed by 40 s timeout) - mismatched collectives.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none (bdgraph_bipart_sq.c untouched between 7.0.16 and 7.0.17)",
 "review_accuracy": "Accurate. Extra detail: the wrongly-local test does not just miss errors, it turns a single-rank failure into an immediate 'internal error' on that rank while the others hang; when all ranks fail with procglbnbr>1 the same return leaks cgrfdat and the MPI op/type. Review's suggested fix is right but incomplete: the 'internal error' return must also free cgrfdat/op/type (patched below).",
 "fix_options": [
  {
   "label": "A: test the global values, free before returning (review's fix completed)",
   "summary": "Free the MPI op/type right after the reduction, test reduglbtab[4] (global failure count, collective) instead of reduloctab[4], free cgrfdat on that path, and fold reduglbtab[5] into the final failure test. Tested: injection (a) now returns ret=1 on all three ranks, (b) returns ret=1 on all three ranks (consistent 'internal error'), no hang, no SEGV.",
   "patch_sketch": "--- a/src/libscotch/bdgraph_bipart_sq.c\n+++ b/src/libscotch/bdgraph_bipart_sq.c\n@@ -179,7 +179,7 @@\n     reduloctab[0] = ((cgrfdat.fronnbr != 0) || ((cgrfdat.compsize0 != 0) && ((cgrfdat.s.vertnbr - cgrfdat.compsize0) != 0)))\n                     ? cgrfdat.commload\n                     : GNUMMAX; /* Partitions with empty bipartitions unwanted if they are completely unbalanced */\n-    reduloctab[1] = cgrfdat.compload0dlt;\n+    reduloctab[1] = ABS (cgrfdat.compload0dlt);   /* Compare on absolute imbalance */\n   }\n \n   if (dgrfptr->partgsttax == NULL) {\n@@ -204,18 +204,20 @@\n     errorPrint (\"bdgraphBipartSq: communication error (2)\");\n     return     (1);\n   }\n-  if ((reduloctab[4] != 0) && (reduloctab[4] != dgrfptr->s.procglbnbr)) {\n-    errorPrint (\"bdgraphBipartSq: internal error\");\n-    return     (1);\n-  }\n-\n   if ((MPI_Op_free   (&bestoperdat) != MPI_SUCCESS) ||\n       (MPI_Type_free (&besttypedat) != MPI_SUCCESS)) {\n     errorPrint (\"bdgraphBipartSq: communication error (3)\");\n     return     (1);\n   }\n \n-  if (reduglbtab[3] != 0) {                       /* If none of the sequential methods succeeded */\n+  if ((reduglbtab[4] != 0) && (reduglbtab[4] != dgrfptr->s.procglbnbr)) { /* Global count of failures */\n+    errorPrint (\"bdgraphBipartSq: internal error\");\n+    bgraphExit (&cgrfdat);\n+    return     (1);\n+  }\n+\n+  if ((reduglbtab[3] != 0) ||                     /* If none of the sequential methods succeeded */\n+      (reduglbtab[5] != 0)) {                     /* Or if some process could not allocate data  */\n     bgraphExit (&cgrfdat);\n     return     (1);\n   }\n",
   "tradeoffs": "Collective, local change. Partial failures (some ranks fail sequential bipartitioning, others succeed) are still rejected as 'internal error', which is the evident intent of the original test; behaviour for the all-succeed and all-fail cases is unchanged except the leak fix. Needs injection tests.",
   "preferred": true
  },
  {
   "label": "B: tolerate partial failures, test only the error flags",
   "summary": "Delete the partial-failure test entirely: the OpBest operator already prefers non-erroneous candidates, so a rank whose bgraphBipartSt failed can simply receive the best partition from another rank. Test only reduglbtab[3] (no rank succeeded) and reduglbtab[5] (OOM) and exit on those; free op/type before.",
   "patch_sketch": "-  if ((reduloctab[4] != 0) && (reduloctab[4] != dgrfptr->s.procglbnbr)) {\n-    errorPrint (\"bdgraphBipartSq: internal error\");\n-    return     (1);\n-  }\n   ... (free op/type)\n-  if (reduglbtab[3] != 0) {\n+  if ((reduglbtab[3] != 0) || (reduglbtab[5] != 0)) {\n     bgraphExit (&cgrfdat);\n     return     (1);\n   }",
   "tradeoffs": "More robust (one rank hitting a transient sequential failure no longer kills the bipartition) but changes semantics and hides sequential-method failures; the failing rank must still skip using cgrfdat except for bgraphExit. Untested.",
   "preferred": false
  }
 ],
 "notes": "This method runs at the coarsest levels of the default dgpart/dgmap strategy (q{strat=...}), so any real OOM during the centralised bipartition reaches this code.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-10",
 "area": "DMO",
 "our_title": "Distributed bipartition selection used int-width abs on Gnum; now replaced by ABS macro",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "64bit-build",
 "needs_note": "A 64-bit Gnum build with imbalance above 2^31 to see wrong comparison in 7.0.16.",
 "location": "src/libscotch/bdgraph_bipart_ex.c:130,245 ; bdgraph_bipart_st.c:355,361-362 ; vdgraph_separate_st.c:320 (all now ABS)",
 "evidence": "git diff v7.0.16 v7.0.17 shows every cited abs() replaced by ABS() in exactly these five places, e.g. bdgraph_bipart_ex.c:130 '(ABS (grafptr->compglbload0dlt) < compglbloaddltmax)', bdgraph_bipart_st.c:355 'ABS (savetab[0].compglbload0dlt) > ABS (grafptr->compglbload0dlt)', vdgraph_separate_st.c:320 'ABS (savetab[0].compglbloaddlt) >= ABS (grafptr->compglbloaddlt)'. grep -n '[^a-zA-Z_]abs (' src/libscotch/*.c finds no remaining code use (only comments in hall_order_hf.c). common.h:197 '#define ABS(x) MAX ((x), -(x))'. Not run: needs a 64-bit-Gnum build with >2^31 imbalance.",
 "upstream_change": "f545452 'Bugfix: use size-agnostic macro instead of bounded-size library ABS routine [report R. Perry]' (also touches arch_mesh.c, arch_torus.c, bgraph_bipart_fm.c, ... beyond this review's list)",
 "review_accuracy": "Accurate; the listed line set was complete for the distributed code.",
 "fix_options": [],
 "notes": "ABS evaluates its argument twice (MAX macro); all call sites are side-effect free.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## PS-DMO-3

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DMO-3",
 "our_title": "Left shift of 1 by 31 on signed int in distributed band bipartitioning",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/bdgraph_bipart_bd.c:343,382,388",
 "evidence": "Default './drv 4elt.grf m \"\" 8' under UBSan prints 'bdgraph_bipart_bd.c:343:7: runtime error: left shift of 1 by 31 places cannot be represented in type int' (also 382, 388).",
 "related_review_ids": [],
 "fix_options": [
  {
   "label": "A: unsigned shift",
   "summary": "Use 1U << n (or a Gnum/unsigned mask).",
   "patch_sketch": "-  ... (1 << 31)\n+  ... (1U << 31)",
   "tradeoffs": "Trivial; verify the consumer treats the value as unsigned.",
   "preferred": true
  },
  {
   "label": "B: avoid bit 31",
   "summary": "Limit the bit set to 31 bits.",
   "patch_sketch": "use a 64-bit mask type",
   "tradeoffs": "Changes data layout.",
   "preferred": false
  }
 ],
 "area": "DMO"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)
