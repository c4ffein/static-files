# G01-arch-sub-dist

Items: COR-02, COR-03, COR-04, COR-05, PS-COR-3, COR-27



===================================================================
## COR-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-02",
 "area": "COR",
 "our_title": "Class free hook now guarded; failed loads of hookless classes return cleanly",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch.c:212-219",
 "evidence": "7.0.17 arch.c:212-219: 'if (clasptr->archLoad (&archptr->data, stream) != 0) { errorPrint (...); if (clasptr->archFree != NULL) clasptr->archFree (&archptr->data); memSet (archptr, 0, sizeof (Arch)); return (1); }'. Run: archload on 'cmplt abc' -> 'ERROR: archCmpltArchLoad: bad input / ERROR: archLoad: cannot load architecture data / load ret=1' (no SEGV at pc 0). Same for hcub 31/32 (now rejected), meshXD, etc. Harness (all under work/COR): archload.c = SCOTCH_archLoad() on a one-line .tgt file, linked against the pristine ASan+UBSan libscotch.so (32-bit INT, release, no COMMON_DEBUG/SCOTCH_DEBUG_*); st.c = SCOTCH_stratGraphMap/GraphOrder/MeshOrder + stratSave. Patched tree (fixes tested): work/COR/fix (copy of the ASan build with the patches; diffs in work/COR/diffs/).",
 "upstream_change": "d555f2c 'Do not call nonexistent freeing routines on architecture loading error [report R. Perry]' - adds the 'archFree != NULL' guard (exactly the review's first suggested fix).",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "Note the fix only protects classes whose archFree is NULL; classes with a non-NULL archFree still run it on a partially loaded body (see COR-04/05/07/16).",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-03",
 "area": "COR",
 "our_title": "Sub-architecture terminal numbers used as array indices without release-build range or duplicate checks",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_sub.c:377-379 (range check) / 397-410 (duplicate check) / 417-430 (archDomTerm result ignored), write at ~line 440",
 "evidence": "Command: archload on 'sub 2 0 99 cmplt 4'.\nOutput: 'ERROR: AddressSanitizer: heap-buffer-overflow ... WRITE of size 4 ... #0 _SCOTCHarchSubArchBuild arch_sub.c:472 #1 _SCOTCHarchSubArchLoad arch_sub.c:117 #2 _SCOTCHarchLoad arch.c:213 #3 SCOTCH_archLoad library_arch.c:192'.\nAlso 'sub 2 0 1 cmplt 1' (vnumnbr > orgtermnbr) -> heap-buffer-overflow WRITE at arch_sub.c:474.\nSource (7.0.17): the checks 'if ((vnumnbr < 0) || (vnumnbr > orgtermnbr))', 'invalid vertex number in vertex list', 'duplicate vertex number in vertex list' and the 'archSubArchBuild: internal error (1)' test of archDomTerm's return are all inside '#ifdef SCOTCH_DEBUG_ARCH1/ARCH2' blocks (lines 377-379, 442-459); release code does 'treetab[orgtermnum].domnsiz = 1' with unchecked orgtermnum. Harness (all under work/COR): archload.c = SCOTCH_archLoad() on a one-line .tgt file, linked against the pristine ASan+UBSan libscotch.so (32-bit INT, release, no COMMON_DEBUG/SCOTCH_DEBUG_*); st.c = SCOTCH_stratGraphMap/GraphOrder/MeshOrder + stratSave. Patched tree (fixes tested): work/COR/fix (copy of the ASan build with the patches; diffs in work/COR/diffs/).",
 "upstream_change": "",
 "review_accuracy": "accurate (line numbers shifted by ~0; archDomTerm failure leaves orgdomndat uninitialised as stated)",
 "fix_options": [
  {
   "label": "A. Make the checks unconditional",
   "summary": "Remove the #ifdef SCOTCH_DEBUG_ARCH1/ARCH2 around the three checks and test archDomTerm()'s return value; fold them into one error branch that frees matcdat/treetab/termtab.",
   "patch_sketch": "-#ifdef SCOTCH_DEBUG_ARCH1\n-  if ((vnumnbr < 0) || (vnumnbr > orgtermnbr)) {...return (2);}\n-  messptr = NULL;\n-#endif\n+  if ((vnumnbr < 1) || (vnumnbr > orgtermnbr)) { errorPrint (...); return (2); }\n ...\n-#ifdef SCOTCH_DEBUG_ARCH1\n+    messptr = NULL;\n     if ((orgtermnum < 0) || (orgtermnum >= orgtermnbr)) messptr = \"...invalid vertex number...\";\n     else if (treetab[orgtermnum].domnsiz != 0)          messptr = \"...duplicate vertex number...\";\n+    else if (archDomTerm (orgarchptr, &orgdomndat, orgtermnum) != 0) messptr = \"...invalid terminal number\";\n     if (messptr != NULL) { errorPrint (messptr); matchExit (&matcdat); memFree (treetab - 1); memFree (termtab); return (2); }\n-#endif",
   "tradeoffs": "Tested (see COR-04 patch, same file): 'sub 2 0 99 cmplt 4' -> 'invalid vertex number', 'sub 2 0 1 cmplt 1' -> 'invalid number of terminal domains', no ASan/UBSan output. Cost: O(vnumnbr) compare per terminal, negligible. Only behaviour change: inputs that were silently corrupting memory now fail. vnumnbr==0 is now rejected (was 'domnnbr = -1' garbage).",
   "preferred": true
  },
  {
   "label": "B. Validate in archSubArchLoad (caller) only",
   "summary": "Keep archSubArchBuild trusted/debug-checked for library callers, but validate vnumtab (range via archDomSize of the loaded arch, duplicates via a bitmap) in archSubArchLoad before calling Build.",
   "patch_sketch": "In archSubArchLoad after archLoad(): compute orgtermnbr = archDomSize(...); loop termtab[]: reject <0 or >=orgtermnbr, mark in a calloc'ed flag array, reject repeats; free flags.",
   "tradeoffs": "Does not protect other callers of archSubArchBuild (SCOTCH_archSub in library_arch_build.c passes user data and is also unchecked in release); duplicates the knowledge about terminal numbering in two places. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Precedent for A: upstream already turns debug-only checks into always-on checks for user-supplied sizes (e.g. archHcubArchLoad bound in c5baef9, intLoad). Maintainers keep Build() debug-checked for internal callers in many places, so B is plausible, but A is simpler and also protects SCOTCH_archSub().",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-04",
 "area": "COR",
 "our_title": "Failed sub-architecture load leaves inner Arch freed, NULL or uninitialised when outer cleanup runs",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_sub.c:111-126 (archSubArchLoad), 193-201 (archSubArchFree), 417-427 (Build publishes fields early); arch.c:212-219",
 "evidence": "Commands (archload on one-line files, pristine ASan lib):\n- 'sub 2 0 1 foo' -> 'ERROR: archLoad: invalid architecture type' then 'arch.c:174:24: runtime error: member access within misaligned address 0xbebebebebebebebe for type const struct ArchClass' + SEGV (clasptr of the inner Arch never set).\n- 'sub 2 0 1 cmplt abc' -> two 'cannot load architecture data' then 'arch.c:173:15: runtime error: member access within null pointer of type struct Arch ... #0 archFree arch.c:173 #1 archSubArchFree arch_sub.c:194 #2 archLoad arch.c:216'.\n- 'sub 2 0 0 cmplt 4' (Build fails with 'cannot create sub-architecture (2)') -> 'AddressSanitizer: heap-use-after-free READ of size 8 #0 archFree arch.c:173 #1 archSubArchFree arch_sub.c:194 #2 archLoad arch.c:216'.\n- 'sub 3 0 1 cmplt 4' (bad input (2)) -> NULL deref in archFree via archSubArchFree.\nMechanism confirmed in source: since 7.0.17's d555f2c, archLoad calls clasptr->archFree (archSubArchFree, non-NULL) on a failed load; archSubArchFree dereferences/frees archptr->archptr (either NULL, freed already by archSubArchLoad:122-123, or uninitialised) with no ownership protocol. Harness (all under work/COR): archload.c = SCOTCH_archLoad() on a one-line .tgt file, linked against the pristine ASan+UBSan libscotch.so (32-bit INT, release, no COMMON_DEBUG/SCOTCH_DEBUG_*); st.c = SCOTCH_stratGraphMap/GraphOrder/MeshOrder + stratSave. Patched tree (fixes tested): work/COR/fix (copy of the ASan build with the patches; diffs in work/COR/diffs/).",
 "upstream_change": "d555f2c touched archLoad's failure path but archSubArchFree was already non-NULL, so nothing changed for 'sub'.",
 "review_accuracy": "accurate in substance; the ASan 'double free' is a heap-use-after-free READ of the already freed inner Arch in my runs (same root cause); the 0xbebebebe pointer reproduces exactly",
 "fix_options": [
  {
   "label": "A. Single-owner protocol + tolerant free",
   "summary": "archSubArchLoad zeroes archptr/termtab, archInit()s the inner Arch, frees the inner Arch itself on failure; Build() publishes its fields only on success; archSubArchFree ignores a NULL archptr. Outer archLoad's cleanup then becomes a no-op.",
   "patch_sketch": "archSubArchLoad:\n+  subarchptr->archptr = NULL; subarchptr->termtab = NULL;\n+  archInit (orgarchptr);\n+  if (archLoad (orgarchptr, stream) != 0) { memFree (orgarchptr); memFree (termtab); return (1); } /* archLoad() already cleaned up */\n+  o = archSubArchBuild (...); if (o != 0) { archExit (orgarchptr); memFree (orgarchptr); }\narchSubArchFree:\n-  if ((flagval & ARCHFREE) != 0) {\n+  if (((flagval & ARCHFREE) != 0) && (archptr->archptr != NULL)) {\narchSubArchBuild: move the five 'subarchptr->x = ...' assignments to just before 'return (0)'; free termtab in the two 'cannot create sub-architecture' returns (also leaked).",
   "tradeoffs": "Tested together with COR-03/05: all failing 'sub ...' inputs return 1 with zero ASan/UBSan/LeakSanitizer output; valid 'sub 2 0 1 cmplt 4' and gmap on sub targets unchanged. Small, local to arch_sub.c; no ABI change.",
   "preferred": true
  },
  {
   "label": "B. Have archLoad own the cleanup (caller-side)",
   "summary": "In archSubArchLoad do NOT free the inner Arch on failure and instead leave a fully valid state in subarchptr (archptr set to the inner Arch right after allocation, archInit'ed); let archLoad's call to archSubArchFree release it exactly once.",
   "patch_sketch": "archSubArchLoad: subarchptr->archptr = orgarchptr (after memAlloc+archInit); subarchptr->termtab = NULL; on any failure just 'return (1)'. archSubArchFree: guard termtab/archptr for NULL, and Build() must not memFree(termtab) that it published.",
   "tradeoffs": "Fewer frees in the loader, but Build() is also used standalone (SCOTCH_archSub) with a different ownership rule, so Build() would need two modes. More coupling than A. Not tested.",
   "preferred": false
  },
  {
   "label": "C. Make 'sub' loading all-or-nothing in a temporary",
   "summary": "Load into a local ArchSub temporary, and memcpy it into the caller's body only on success (the body then never holds half-built pointers).",
   "patch_sketch": "ArchSub tmp; ... if (ok) *subarchptr = tmp; else free tmp contents locally; return code only.",
   "tradeoffs": "Cleanest invariant but archLoad's failure path still calls archSubArchFree on the (zeroed) body, so a NULL-tolerant archSubArchFree is still required; hence C subsumes part of A. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A. Precedent: archDecoArchFree already tolerates domverttab==NULL ('if ((archptr->flagval & ARCHDECOFREE) != 0 && archptr->domverttab != NULL)') and archTleafArchFree tolerates permtab==NULL; the repo idiom is tolerant free routines plus archLoad zeroing the body (memSet (archptr, 0, ...)).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-05",
 "area": "COR",
 "our_title": "Dist target loader passes a never-allocated inner Arch pointer to archLoad",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_dist.c:82-100 (archDistArchLoad), arch_dist.h (archDistArchFree defined as NULL)",
 "evidence": "Command: archload on 'dist 2 cmplt 4' -> 'arch.c:209:20: runtime error: member access within null pointer of type struct Arch' then 'AddressSanitizer: SEGV ... WRITE ... #0 _SCOTCHarchLoad arch.c:209 #1 _SCOTCHarchDistArchLoad arch_dist.c:99 #2 archLoad arch.c:213 #3 SCOTCH_archLoad'.\nSource 7.0.17 arch_dist.c:99 'return (archLoad (archptr->archptr, stream));' with archptr->archptr never assigned (archInit zeroes it -> NULL). archDistArchFree is '#define archDistArchFree NULL' so nothing could free an inner Arch anyway. archDistArchBuild() is the only other writer and it just stores a borrowed pointer (and copies orgarchptr->flagval, ARCHFREE included). Harness (all under work/COR): archload.c = SCOTCH_archLoad() on a one-line .tgt file, linked against the pristine ASan+UBSan libscotch.so (32-bit INT, release, no COMMON_DEBUG/SCOTCH_DEBUG_*); st.c = SCOTCH_stratGraphMap/GraphOrder/MeshOrder + stratSave. Patched tree (fixes tested): work/COR/fix (copy of the ASan build with the patches; diffs in work/COR/diffs/).",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Allocate and own the inner Arch",
   "summary": "archDistArchLoad allocates+archInit()s the inner Arch, loads it, frees it on failure; add a real archDistArchFree (same ARCHFREE/NULL-tolerant pattern as archSubArchFree); make archDistArchBuild clear ARCHFREE so borrowed architectures are not freed.",
   "patch_sketch": "arch_dist.c:\n+  if ((archptr->archptr = memAlloc (sizeof (Arch))) == NULL) { errorPrint (\"archDistArchLoad: out of memory\"); return (1); }\n+  archInit (archptr->archptr);\n+  if (archLoad (archptr->archptr, stream) != 0) { memFree (archptr->archptr); archptr->archptr = NULL; return (1); }\n+  return (0);\n+int archDistArchFree (ArchDist * const archptr) { if (((archArch (archptr)->flagval & ARCHFREE) != 0) && (archptr->archptr != NULL)) { archFree (archptr->archptr); memFree (archptr->archptr); } return (0); }\narch_dist.h: -#define archDistArchFree NULL   +int archDistArchFree (ArchDist * const);\narchDistArchBuild: archptr->flagval = orgarchptr->flagval & ~ARCHFREE;",
   "tradeoffs": "Tested: 'dist 2 cmplt 4' loads (size=4), 'dist 2 cmplt abc' fails cleanly, LeakSanitizer clean. Mirrors archSub. Needs a regression test with a dist target file (none exists upstream). The flagval change in Build is needed to avoid double free when a Build()-created dist arch wraps a loaded arch.",
   "preferred": true
  },
  {
   "label": "B. Reject 'dist' in target files",
   "summary": "archDistArchLoad prints 'dist architecture cannot be loaded from a file' and returns 1 (or register the class with a NULL archLoad so archLoad never calls it).",
   "patch_sketch": "int archDistArchLoad (...) { errorPrint (\"archDistArchLoad: loading of dist architectures is not supported\"); return (1); }",
   "tradeoffs": "Zero risk and 2 lines, but removes a documented-looking file format ('dist' has a Save routine, so files written by archSave could not be read back). Not tested (trivial).",
   "preferred": false
  }
 ],
 "notes": "Preferred A as the save routine already exists (a round trip is clearly intended); B is what a maintainer would do if 'dist' is considered internal-only - ask the Scotch team. Idiom: archSubArchLoad allocating its own Arch.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## PS-COR-3

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-COR-3",
 "our_title": "Sub-architecture build leaks its term/domain block on both 'cannot create sub-architecture' returns",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/arch_sub.c:~480-495 (archSubArchBuild error returns)",
 "evidence": "Both error branches do memFree (treetab - 1) and return 2 without freeing termtab (memAllocGroup leader for termtab/domntab) allocated earlier in the function. Not triggered by my inputs, so no LeakSanitizer output.",
 "related_review_ids": [
  "COR-04"
 ],
 "fix_options": [
  {
   "label": "Free termtab on both returns",
   "summary": "Add memFree (termtab) to the two branches.",
   "patch_sketch": "memFree (treetab - 1);\n+ memFree (termtab);\nreturn (2);",
   "tradeoffs": "Included in the patched tree; build and sub-target tests clean, but the leak path itself was not exercised.",
   "preferred": true
  },
  {
   "label": "Single cleanup label",
   "summary": "Route all error exits through one goto label freeing everything allocated.",
   "patch_sketch": "goto fail; ... fail: free in reverse order",
   "tradeoffs": "Cleaner for future paths, larger diff; not tested.",
   "preferred": false
  }
 ],
 "area": "COR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-27

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-27",
 "area": "COR",
 "our_title": "Complete-target matcher stores unchanged pass number and mis-sizes pair loop for the alternate pass",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_cmplt.c:190-241 (archCmpltMatchMate; 'matcptr->passnum = passnum;' at 237)",
 "evidence": "Test mate.c calls the exported _SCOTCHarchCmpltMatchInit/Mate on a 32-bit INT ASan build and prints each coarsening level: ./mate 5 -> 'level 0: coarse=3 passnum=0 singletons: fine#4 covered=5 / level 1: coarse=2 passnum=0 singletons: fine#2 ...'; ./mate 11 -> level 0 singleton fine#10, level 1 (6 vertices) no singleton, level 2 singleton fine#2: passnum stays 0 at every level, so for odd sizes the last coarse vertex is always the unmatched one (7.0.17 line 237 'matcptr->passnum = passnum;' stores the same value it read). Source check of the second claim: with passnum==1 and finevertnbr=5: coarvertmax = 5>>1 = 2; first single at index 0 -> coarvertnum=1; loop 'coarvertnum < coarvertmax' runs once -> only vertices 1,2 paired; vertices 3,4 never emitted, coarse count 2 (should be 3) - so the review is right that fixing only the toggle exposes a second bug.",
 "upstream_change": "",
 "review_accuracy": "accurate (both parts)",
 "fix_options": [
  {
   "label": "A. Toggle and derive coarvertmax from the pass",
   "summary": "matcptr->passnum = passnum ^ 1 for odd sizes, and coarvertmax = (finevertnbr + passnum) >> 1 so that the pair loop covers every vertex when the single multinode is first.",
   "patch_sketch": "-  coarvertmax = finevertnbr >> 1;\n+  passnum     = matcptr->passnum;\n+  coarvertmax = (finevertnbr + passnum) >> 1;\n ...\n-    matcptr->passnum = passnum;\n+    matcptr->passnum = passnum ^ 1;",
   "tradeoffs": "Tested: ./mate_f 5 -> singleton fine#4 then fine#0 (alternates); for n in 2,3,4,5,7,9,11,12,13,16,17,31,100 every level reports 'covered' == number of fine vertices and ends with 1 coarse vertex; no sanitizer output. Changes which vertices are matched in odd levels, hence changes mappings for complete-graph targets with non-power-of-two sizes (results stay valid, are just different) - update any golden-output tests.",
   "preferred": true
  },
  {
   "label": "B. Keep the current deterministic behaviour; delete the dead pass code",
   "summary": "Remove passnum and the unreachable passnum==1 branches; document that the last vertex is the singleton.",
   "patch_sketch": "drop 'Anum passnum', the '& passnum' / '^ 1' branches.",
   "tradeoffs": "Zero behaviour change, no risk, but gives up the balance the original author intended ('Invert pass value if dimension is odd'). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A if the Scotch team wants the evidently intended alternation (arch_tleaf's matcher alternates passes in the same style: 'matcptr->passnum' toggled at the end); B if golden mappings must not move.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)
