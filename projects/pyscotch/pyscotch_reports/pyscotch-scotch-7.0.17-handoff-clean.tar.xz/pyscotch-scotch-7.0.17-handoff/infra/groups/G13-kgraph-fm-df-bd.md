# G13-kgraph-fm-df-bd

Items: GRA-02, GRA-17, GRA-12, GRA-18, GRA-19, GRA-20, GRA-16



===================================================================
## GRA-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-02",
 "area": "GRA",
 "our_title": "k-way FM keeps a stale domain count after its fallback strategy creates more domains, then reads past its arrays",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_fm.c:997 (const domnnbr), 1039-1056 (fallback), 1320 (use), 1831 (writeback)",
 "evidence": "Public API repro (gra02pub.c): 32x32 grid, SCOTCH_archCmplt(4), strategy 'rf{bal=0.00001}' (default 'r' with no sep leaves 1 domain; 'f' is then entered with domnnbr=1, fronnbr=0, and the fallback r{sep=h{pass=10}} builds 4 domains): `./gra02pub 4 'rf{bal=0.00001}'` -> 'AddressSanitizer: heap-buffer-overflow ... READ of size 4 ... #0 kgraphMapFmTablGet kgraph_map_fm.c:129 #1 kgraphMapFm kgraph_map_fm.c:1320 ... 4 bytes after 12-byte region allocated by memReallocGroup kgraph_map_fm.c:1047'. Same crash through a band strategy: `./gra02pub 4 'r' + b{width=3,bnd=f{...},org=f{...}}` (org=f is entered with 1 domain, fronnbr=0) and internal harness gra02.c (kgraphMapFm on a 2-domain, frontier-less, imbalanced mapping of a 16x16 grid onto cmplt(16)): 'heap-buffer-overflow ... kgraphMapFmTablGet kgraph_map_fm.c:129 ... 12 bytes after 24-byte region'. DBG print confirms 'domnnbr(cached)=1 new=4'. Source: `const Gnum domnnbr = grafptr->m.domnnbr;` (line 997) is never refreshed after kgraphMapSt(); the memReallocGroup at 1047 is called with the same size despite its comment. Note: for 32-bit Gnum the memAlloc `|8` slack hides growth of 2->4 parts (24-byte block), growth to >=5 parts overflows. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Additional stale uses of the cached count: savetab sizing (line 1460/1463) and the write-back loop at line 1831 (only the old number of comploaddlt entries is copied to grafptr->comploaddlt).",
 "fix_options": [
  {
   "label": "Refresh domnnbr after the fallback (preferred; also fixes GRA-15)",
   "summary": "Make domnnbr a non-const local, re-read grafptr->m.domnnbr after kgraphMapSt, then (re)allocate and refill comploadmax/comploaddlt; also stratExit the temporary strategy and check results.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_fm.c\n+++ b/src/libscotch/kgraph_map_fm.c\n@@ -957,6 +957,7 @@\n   Gnum                            edxxcdx;        /* Index for extended edge copy                   */\n   Gnum                            edcunbr;        /* Current number of unused extended edge slots   */\n   Gnum                            edxunbr;        /* Number of unused extended edge slots           */\n+  Gnum                            domnnbr;        /* Current number of domains; can change after fallback mapping */\n   Gnum *                          comploadmax;    /* Array of maximum imbalances                    */\n   Gnum *                          comploaddlt;\n   Gnum                            commload;\n@@ -994,12 +995,13 @@\n   const Gnum * restrict const     edgetax = grafptr->s.edgetax;\n   const Gnum * restrict const     edlotax = grafptr->s.edlotax;\n   const Arch * restrict const     archptr = grafptr->m.archptr;\n-  const Gnum                      domnnbr = grafptr->m.domnnbr;\n   const ArchDom * restrict const  domntab = grafptr->m.domntab;\n   Anum * restrict const           parttax = grafptr->m.parttax;\n   Anum * restrict const           parotax = grafptr->r.m.parttax;\n   const Gnum * restrict const     pfixtax = grafptr->pfixtax;\n \n+  domnnbr = grafptr->m.domnnbr;\n+\n #ifdef SCOTCH_DEBUG_KGRAPH3                       /* Allocation of extra memory needed for the check routine */\n   if ((chektab = memAlloc (domnnbr * 3 * sizeof(Gnum))) == NULL) {\n     errorPrint (\"kgraphMapFm: out of memory (1)\");\n@@ -1034,17 +1036,29 @@\n       return  (0);\n     }\n     else {                                        /* Imbalance must be fought */\n-      const Strat *         strat;\n+      Strat *               strat;\n+      int                   o;\n \n-      strat = stratInit (&kgraphmapststratab, \"r{sep=h{pass=10}}\"); /* Use a standard algorithm */\n-      kgraphMapSt (grafptr, strat);               /* Perform mapping */\n+      if ((strat = stratInit (&kgraphmapststratab, \"r{sep=h{pass=10}}\")) == NULL) { /* Use a standard algorithm */\n+        errorPrint (\"kgraphMapFm: cannot create fallback strategy\");\n+        memFree    (comploadmax);\n+        return     (1);\n+      }\n+      o = kgraphMapSt (grafptr, strat);           /* Perform mapping */\n+      stratExit (strat);\n+      if (o != 0) {\n+        errorPrint (\"kgraphMapFm: cannot compute fallback mapping\");\n+        memFree    (comploadmax);\n+        return     (1);\n+      }\n \n       if (grafptr->fronnbr == 0) {                /* If new partition has no frontier */\n         memFree (comploadmax);\n         return  (0);                              /* This algorithm is still useless  */\n       }\n \n-      if (memReallocGroup ((void *) comploadmax,  /* domnnbr has changed after mapping */\n+      domnnbr = grafptr->m.domnnbr;               /* Number of domains has changed after mapping */\n+      if (memReallocGroup ((void *) comploadmax,\n                            &comploadmax, (size_t) (domnnbr * sizeof (Gnum)),\n                            &comploaddlt, (size_t) (domnnbr * sizeof (Gnum)), NULL) == NULL) {\n         errorPrint (\"kgraphMapFm: out of memory (3)\");\n",
   "tradeoffs": "Completes the evident intent of the existing comment (\"domnnbr has changed after mapping\"). Refinement then runs on the new k-way mapping. If the kgraph is a band graph (anchors) a changed part count would still be inconsistent with the original graph; with the GRA-20 fix this is then caught by kgraphMapBd as an error. Tested: no ASan error on both reproducers.",
   "preferred": true
  },
  {
   "label": "Skip refinement when the fallback changed the part count",
   "summary": "After kgraphMapSt, if grafptr->m.domnnbr != domnnbr (or the graph has anchors) free the arrays and return 0 (the fallback result is already a valid, balanced mapping).",
   "patch_sketch": "kgraphMapSt (grafptr, strat);\nstratExit (strat);\nif ((grafptr->m.domnnbr != domnnbr) || (grafptr->fronnbr == 0)) { memFree (comploadmax); return (0); }",
   "tradeoffs": "Minimal and obviously safe; loses the FM refinement in exactly the cases where the fallback created new parts (quality, not correctness). No API/ABI change.",
   "preferred": false
  },
  {
   "label": "Do not run the rb fallback on a k-way graph whose parts were not produced by rb",
   "summary": "Fix at the caller/policy level: drop the fallback entirely (or restrict it to domnnbr==1) because rb restarts from grafptr->domnorg and overwrites the existing mapping.",
   "patch_sketch": "-    else { /* Imbalance must be fought */ ... kgraphMapSt (r{sep=h{pass=10}}) ... }\n+    else { memFree (comploadmax); return (0); /* leave imbalance to a later 'x' (exactifier) step */ }",
   "tradeoffs": "Behaviour change: imbalanced frontier-less mappings are left untouched. Probably not what maintainers want (they added the fallback deliberately).",
   "preferred": false
  }
 ],
 "notes": "Related: SCOTCH_graphMap with the default strategy on cmplt targets does not reach FM (default for archPart is pure recursive bipartitioning); the bug needs an explicit strategy with f after a mapping stage that leaves fewer domains than the architecture.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-17",
 "area": "GRA",
 "our_title": "k-way FM table growth ignores an allocation failure and writes into the array that did not grow",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_fm.c:524-529, callers 572 and 712",
 "evidence": "Source: line 524-525 `edxxsiz *= 2; *edxxsizptr = edxxsiz;` before `memRealloc`; on failure it returns 1 but both callers (kgraphMapFmPartAdd2 line 572, kgraphMapFmPartAdd line 712) ignore the result and store at the next slot of the un-grown array. Fault injection: copy of kgraph_map_fm.c with the realloc forced to fail (env GRA17) built with -DSCOTCH_DEBUG_KGRAPH2 (this forces the resize path; without it resizing was never reached in my tests), explicit k-way strategy m{...asc=b{bnd=d{pass=40}f{...},org=f{...}}} on a 40x40 grid, 64 parts: original -> 'ERROR: kgraphMapFmEdgeResize: out of memory' then 'AddressSanitizer: heap-buffer-overflow ... WRITE of size 4 ... #0 kgraphMapFmPartAdd kgraph_map_fm.c:718 #1 kgraphMapFm kgraph_map_fm.c:1115'. Patched (size published only on success; PartAdd/PartAdd2 propagate; 3 call sites check): clean 'out of memory (5b)' error chain, no sanitizer report from FM (a follow-on UBSan 'load of null pointer' in mapTerm after the failed mapping is a separate error-path weakness in graphMapCompute2). Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. kgraphMapFmPartAdd/PartAdd2 are already `int` functions returning 0, so only the callers need changing.",
 "fix_options": [
  {
   "label": "Publish size after success and propagate errors",
   "summary": "Move *edxxsizptr = edxxsiz after the realloc succeeded; make both PartAdd routines return 1 on resize failure; check the three call sites.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_fm.c\n+++ b/src/libscotch/kgraph_map_fm.c\n@@ -522,12 +522,12 @@\n   edxxsiz = *edxxsizptr;\n \n   edxxsiz *= 2;                                 /* Compute new array size  */\n-  *edxxsizptr = edxxsiz;                        /* Propagate back new size */\n \n   if ((edxxtmp = memRealloc (edxxtab, edxxsiz * sizeof (KgraphMapFmEdge))) == NULL) {\n     errorPrint (\"kgraphMapFmEdgeResize: out of memory\");\n-    return     (1);\n+    return     (1);                             /* Old array and size are left untouched */\n   }\n+  *edxxsizptr = edxxsiz;                        /* Propagate back new size only on success */\n   if (edxxtmp != edxxtab) {                     /* If array has been reallocated, re-link all edges */\n     Gnum                edxxidx;\n \n@@ -568,8 +568,9 @@\n   const Arch * restrict const     archptr = grafptr->m.archptr;\n   const ArchDom * restrict const  domntab = grafptr->m.domntab;\n \n-  if (*edxxnbrptr >= *edxxsizptr)                 /* If new slot would not fit  */\n-    kgraphMapFmEdgeResize (vexxtab, -1, edxxtabptr, edxxsizptr, *edxxnbrptr, tablptr); /* No vexxidx because vertex extended edges will be readd later */\n+  if ((*edxxnbrptr >= *edxxsizptr) &&             /* If new slot would not fit  */\n+      (kgraphMapFmEdgeResize (vexxtab, -1, edxxtabptr, edxxsizptr, *edxxnbrptr, tablptr) != 0)) /* No vexxidx because vertex extended edges will be readd later */\n+    return (1);\n \n   edxxtab = *edxxtabptr;\n   edxxidx = (*edxxnbrptr) ++;                     /* Allocate new slot */\n@@ -708,8 +709,9 @@\n     }\n \n     if (edxxidx == -1) {                          /* If edge slot not found    */\n-      if (*edxxnbrptr >= *edxxsizptr)             /* If new slot would not fit */\n-        kgraphMapFmEdgeResize (vexxtab, vexxidx, edxxtabptr, edxxsizptr, *edxxnbrptr, tablptr);\n+      if ((*edxxnbrptr >= *edxxsizptr) &&         /* If new slot would not fit */\n+          (kgraphMapFmEdgeResize (vexxtab, vexxidx, edxxtabptr, edxxsizptr, *edxxnbrptr, tablptr) != 0))\n+        return (1);\n \n       edxxidx = (*edxxnbrptr) ++;                 /* Allocate new slot */\n       edxxtab = *edxxtabptr;                      /* Update edxxtab    */\n@@ -1125,7 +1127,10 @@\n     if ((pfixtax == NULL) || (pfixtax[vertnum] == -1)) { /* Add only not fixed vertices */\n       for (hashnum = (vertnum * KGRAPHMAPFMHASHPRIME) & hashmsk; vexxtab[hashnum].vertnum != ~0; hashnum = (hashnum + 1) & hashmsk) ;\n \n-      kgraphMapFmPartAdd (grafptr, vertnum, hashnum, vexxtab, &edxxtab, &edxxsiz, &edxxnbr, tablptr);\n+      if (kgraphMapFmPartAdd (grafptr, vertnum, hashnum, vexxtab, &edxxtab, &edxxsiz, &edxxnbr, tablptr) != 0) {\n+        errorPrint (\"kgraphMapFm: out of memory (5b)\");\n+        return     (1);\n+      }\n \n #ifdef SCOTCH_DEBUG_KGRAPH2\n       if (vexxtab[hashnum].edxxidx == -1) {       /* If vertex does not have any neighbor */\n@@ -1496,7 +1501,10 @@\n              (vexxtab[vexxend].vertnum != vertend) && (vexxtab[vexxend].vertnum != ~0); vexxend = (vexxend + 1) & hashmsk) ;\n \n         if (vexxtab[vexxend].vertnum == ~0) {     /* If neighbor vertex not yet inserted, create it */\n-          kgraphMapFmPartAdd (grafptr, vertend, vexxend, vexxtab, &edxxtab, &edxxsiz, &edxxnbr, tablptr);\n+          if (kgraphMapFmPartAdd (grafptr, vertend, vexxend, vexxtab, &edxxtab, &edxxsiz, &edxxnbr, tablptr) != 0) {\n+            errorPrint (\"kgraphMapFm: out of memory (6b)\");\n+            return     (1);\n+          }\n           hashnbr ++;                             /* One more vertex in hash table */\n #ifdef SCOTCH_DEBUG_KGRAPH2\n           if (vexxtab[vexxend].edxxidx == -1) {\n@@ -1633,7 +1641,10 @@\n           Gnum        edxxidx;\n #endif /* SCOTCH_DEBUG_KGRAPH2 */\n \n-          kgraphMapFmPartAdd2 (grafptr, vexxtab, vexxend, &edxxtab, &edxxsiz, &edxxnbr, vexxtab[vexxend].domnnum, domnend, edloval, tablptr); /* Add new extended edge */\n+          if (kgraphMapFmPartAdd2 (grafptr, vexxtab, vexxend, &edxxtab, &edxxsiz, &edxxnbr, vexxtab[vexxend].domnnum, domnend, edloval, tablptr) != 0) { /* Add new extended edge */\n+            errorPrint (\"kgraphMapFm: out of memory (7b)\");\n+            return     (1);\n+          }\n #ifdef SCOTCH_DEBUG_KGRAPH2\n           for (edxxidx = vexxtab[vexxend].edxxidx; (edxxidx != -1) && (edxxtab[edxxidx].domnnum != domnend); edxxidx = edxxtab[edxxidx].edxxidx) ;\n           if (edxxidx == -1) {\n",
   "tradeoffs": "Pure error-path change; tested via injection. Existing OOM paths in kgraphMapFm already `return (1)` with leaks, so the new returns follow the local style.",
   "preferred": true
  },
  {
   "label": "Pre-size the edge array to its bound",
   "summary": "Allocate edxxtab for the worst case (e.g. sum over moved vertices of distinct neighbour domains <= edgenbr + fronnbr*domnnbr) so no resize can happen.",
   "patch_sketch": "edxxsiz = grafptr->s.edgenbr + ...;  (remove kgraphMapFmEdgeResize)",
   "tradeoffs": "Removes the failure mode entirely but costs memory up front (the lazy doubling exists to avoid it).",
   "preferred": false
  }
 ],
 "notes": "In normal builds the resize path is rarely reached (edxxsiz is 16x the frontier size, capped by edgenbr); the DEBUG_KGRAPH2 build forces it.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-12",
 "area": "GRA",
 "our_title": "Diffusion band mapping skips its thread barriers when a domain's anchor is isolated, hanging threads",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_df.c:222-231 (goto fail before the two setup barriers at 257 and 288)",
 "evidence": "Internal harness gra12i.c: grid-pair (14x14 + 7x14 vertices) mapped on cmplt(4) with parts {0,1,1,...}: parts 2 and 3 empty, so their anchors are isolated; kgraphMapBd(width 3, bnd=d{pass=10}) with a thread context of N threads (SCOTCH_contextThreadSpawn). The debug print shows the threads owning domains 2,3 compute velsmsk=0 and jump to `fail:` while the others continue. Results over 12 runs: threads=2: 1 hang of 12 (timeout); threads=3: 3 hangs of 12 (`timeout 20` rc=124); threads=4 once printed 'heap-use-after-free' (barrier mis-pairing lets the master free loopdat while slaves still run). Patched kgraph_map_df.c (flag instead of goto, leave after the barriers): 0 hangs/0 sanitizer reports in 12 runs for each of 2,3,4,8 threads. Why only empty parts: kgraphMapBd (kgraph_map_bd.c:160-174) already bails out to the original-graph strategy when an isolated anchor belongs to a non-empty part, so only anchors of EMPTY parts reach d. The barrier is shared by the end-of-round threadWaitBarrier in threadLaunch, so the mismatch becomes a hang/desync depending on timing. Public-API reproduction (SCOTCH_graphMap with threads and more parts than vertices) did not trigger it in my attempts. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate (including the comparison with bgraph_bipart_df.c). Only the isolated-anchor case is reachable in practice; the sorttab OOM case also skips the barriers.",
 "fix_options": [
  {
   "label": "Set abort flag, keep barrier structure",
   "summary": "Replace the two pre-barrier gotos by setting loopptr->abrtval and not allocating sorttab; all threads then pass both setup barriers and leave at the existing `abrtval == 1` test.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_df.c\n+++ b/src/libscotch/kgraph_map_df.c\n@@ -219,15 +219,11 @@\n       velsmsk &= (velssum != 0);\n     }\n   }\n-  if (velsmsk == 0) {                             /* If graph is too small to have any usable anchors */\n-    loopptr->abrtval = 1;                         /* We will leave during the first iteration         */\n-    goto fail;\n-  }\n-\n-  if ((sorttab = memAlloc (domnnbr * sizeof (KgraphMapDfSort))) == NULL) { /* Allocate here for memory affinity as it is a private array */\n+  if (velsmsk == 0)                               /* If graph is too small to have any usable anchors */\n+    loopptr->abrtval = 1;                         /* We will leave after the barriers, not before     */\n+  else if ((sorttab = memAlloc (domnnbr * sizeof (KgraphMapDfSort))) == NULL) { /* Allocate here for memory affinity as it is a private array */\n     errorPrint (\"kgraphMapDfLoop: out of memory\");\n     loopptr->abrtval = 1;\n-    goto fail;\n   }\n \n   if (velotax == NULL) {\n",
   "tradeoffs": "Same pattern as the existing fail:/barrier handling inside the pass loop and as bgraph_bipart_df.c (\"skip:\" label). Verified on 2/3/4/8 threads. memFree(NULL) at exit is fine.",
   "preferred": true
  },
  {
   "label": "Compute velsmsk globally before the first barrier",
   "summary": "Reduce velsmsk across threads (e.g. threadReduce or a shared atomic AND) so every thread takes the same decision before the first barrier.",
   "patch_sketch": "after velstax is written: loopptr->velsmsk &= local; threadBarrier (descptr); if (loopptr->velsmsk == 0) return;",
   "tradeoffs": "Correct and also avoids the allocation, but needs a new shared field in KgraphMapDfData and one more barrier.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-18",
 "area": "GRA",
 "our_title": "Band-graph diffusion copies from the wrong buffer after the pass swap, so results depend on the pass count",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_df.c:536-540 (copy), 525-528 (swap)",
 "evidence": "Internal harness gra18.c: 24x24 grid, 2 parts with a jagged boundary, kgraphMapBd(width 4, bnd=d{pass=N}), count of vertices changed vs the initial mapping. Original: N=21 changed=1, N=22 changed=1, N=23 changed=2, N=24 changed=7, N=25 changed=8. Patched (copy from difotax): N=21 1, N=22 2, N=23 7, N=24 8, N=25 8 -- i.e. original(N+1) == patched(N): the original is exactly one pass behind (pass=1 never changes any vertex). Source: after each pass the arrays are swapped (difntax <-> difotax, lines 525-527), so the freshest values are in difotax, but line 539 copies `difntax[vertnum].partval`. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Copy from difotax",
   "summary": "Read the last-written array after the swap.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_df.c\n+++ b/src/libscotch/kgraph_map_df.c\n@@ -536,7 +536,7 @@\n \n   if (loopptr->abrtval == 0) {\n     for (vertnum = vertbas; vertnum < vertnnd; vertnum ++) /* Set new part distribution of local vertices */\n-      parttax[vertnum] = difntax[vertnum].partval;\n+      parttax[vertnum] = difotax[vertnum].partval;\n   }\n \n   if (sorttab != NULL)\n",
   "tradeoffs": "Changes mapping results (typically slightly better convergence, one more effective pass); any tests with golden outputs depending on d{pass=..} will change. Same as bgraph_bipart_df.c.",
   "preferred": true
  },
  {
   "label": "Swap only if another pass follows",
   "summary": "Skip the swap after the last pass so difntax stays the freshest.",
   "patch_sketch": "if (passnum > 1) { swap } ",
   "tradeoffs": "Equivalent result but leaves the array roles different from bgraph_bipart_df.c; no advantage.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-19",
 "area": "GRA",
 "our_title": "Mapping cost routine has a loop whose two outcomes both continue, leaving the following block dead",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_cost.c:150-154 (dead loop), 155-172 (dead block), 175-179 (final loop)",
 "evidence": "Source: `for (domnnum = 0; domnnum < domnnbr; domnnum ++) if (verttax-difference != 0) continue;` -- both outcomes of the if continue the loop, so domnnum always ends at domnnbr and the `if (domnnum != domnnbr)` block is dead (kgraph_map_bd.c:158-169 uses `break` for the same test). Applying the review's one-word fix (`== 0 ... break`) is NOT sufficient: the final loop (lines 175-179) then recomputes comploadavg for ALL domains including isolated anchors and subtracts again. Instrumented run (gra12i harness: band graph, 4 domains, 2 empty/isolated): original `comploadavg 74 74 74 74 dlt 25 123 -73 -73`; review's fix only (kgraph_cost_fix.c) -> `comploadavg 148 148 148 148 dlt -49 49 -148 -148` (sum of deltas -296, invalid: isolated anchors double-subtracted); with the final loop also skipping isolated anchors (patched/kgraph_cost.c) -> `comploadavg 148 148 1 1 dlt -49 49 0 0` (consistent). Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Defect real, but the suggested fix is incomplete and, applied alone, makes the load deltas wrong (new bug): the final loop must skip the isolated anchors that the first block processed.",
 "fix_options": [
  {
   "label": "Make the block live and skip isolated anchors in the final loop (preferred if the feature is wanted)",
   "summary": "break on the first isolated anchor, and skip isolated anchors in the last loop.",
   "patch_sketch": "--- a/src/libscotch/kgraph_cost.c\n+++ b/src/libscotch/kgraph_cost.c\n@@ -148,8 +148,8 @@\n     Gnum                        veloval;\n \n     for (domnnum = 0; domnnum < domnnbr; domnnum ++)\n-      if ((grafptr->s.verttax[vertancnnd + domnnum + 1] - grafptr->s.verttax[vertancnnd + domnnum]) != 0)\n-        continue;\n+      if ((grafptr->s.verttax[vertancnnd + domnnum + 1] - grafptr->s.verttax[vertancnnd + domnnum]) == 0)\n+        break;\n \n     if (domnnum != domnnbr) {\n       for (domnnum = 0; domnnum < domnnbr; domnnum ++) {\n@@ -175,6 +175,10 @@\n   domnrat -= fdomwgt;\n   velosum = grafptr->s.velosum - fvelsum;\n   for (domnnum = 0; domnnum < domnnbr; domnnum ++) {\n+    if (((grafptr->s.flagval & KGRAPHHASANCHORS) != 0) && /* Isolated anchors have already been processed above */\n+        ((grafptr->s.verttax[grafptr->s.vertnnd - domnnbr + domnnum + 1] - grafptr->s.verttax[grafptr->s.vertnnd - domnnbr + domnnum]) == 0))\n+      continue;\n+\n     compload[domnnum]            -=\n     grafptr->comploadavg[domnnum] = (Gnum) ((double) velosum * ((double) archDomWght (archptr, &domntab[domnnum]) / domnrat));\n   }\n",
   "tradeoffs": "Behaviour change: balance targets for domains in a band graph with isolated anchors change (empty parts are treated as frozen at the anchor load instead of being given an average share), affecting FM/diffusion balance on band graphs. Needs benchmarks. kgraphMapBd already avoids bands with isolated anchors of non-empty parts, so only empty parts are affected.",
   "preferred": true
  },
  {
   "label": "Delete the dead block",
   "summary": "Remove the never-executed loop and block (and the fdomwgt/fvelsum variables) so the code states what it really does.",
   "patch_sketch": "-    for (...) if (...) continue;\n-    if (domnnum != domnnbr) { ... }\n  (and fdomwgt = 0, fvelsum = 0 become constants)",
   "tradeoffs": "Zero behaviour change, removes misleading code; loses the (untested, possibly wrong) intent.",
   "preferred": false
  }
 ],
 "notes": "Maintainers may prefer deletion if the author intent is unknown; the dead code has been in the file since kgraphCost was split out (eb75701).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-20",
 "area": "GRA",
 "our_title": "Band-graph mapping compares a domain count with its own copy, so a changed part count is never detected",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_bd.c:181 (overwrite) vs 190-195 (compare); 268-271 (leak)",
 "evidence": "Source: line 181 `orggrafptr->m.domnnbr = bndgrafdat.m.domnnbr;` then line 190 `if (bndgrafdat.m.domnnbr != orggrafptr->m.domnnbr) { errorPrint (\"...change in band graph number of parts not supported\") ...}` compares a value with its copy. Repro gra20.c: 24x24 grid, original mapping with 2 parts on cmplt(8), kgraphMapBd with bnd=`r{sep=h{pass=10}}`: original returns 0 with domnnbr silently changed 2->8 ('ret=0 changed=228 domnnbr=8'); patched compares against the saved count and fails: 'ERROR: kgraphMapBd: change in band graph number of parts not supported', ret=1. Leak: line 268-271 `orgflagtab` allocation failure returns without memFree (bndvnumtax + baseval) / kgraphExit (&bndgrafdat); source-read only (needs OOM injection). Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Caveat: after the fix the previously silent change of part count becomes an error, which matters for strategies relying on it (e.g. the GRA-02 fallback inside a band graph).",
 "fix_options": [
  {
   "label": "Compare against the saved domnnbr before copying back; free on failure",
   "summary": "Use the local `domnnbr` captured at function entry; do not overwrite orggrafptr->m.domnnbr; add memFree/kgraphExit on the orgflagtab OOM path.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_bd.c\n+++ b/src/libscotch/kgraph_map_bd.c\n@@ -178,7 +178,6 @@\n   o = kgraphMapSt (&bndgrafdat, paraptr->stratbnd); /* Partition band graph */\n \n   orggrafptr->m.domntab = bndgrafdat.m.domntab;   /* Transfer (potentially updated) mapping domain array back to original graph */\n-  orggrafptr->m.domnnbr = bndgrafdat.m.domnnbr;\n   orggrafptr->m.domnmax = bndgrafdat.m.domnmax;\n   bndgrafdat.m.domntab  = NULL;\n \n@@ -188,7 +187,7 @@\n     kgraphExit  (&bndgrafdat);\n     return (1);\n   }\n-  if (bndgrafdat.m.domnnbr != orggrafptr->m.domnnbr) {\n+  if (bndgrafdat.m.domnnbr != domnnbr) {          /* Compare with number of parts of original graph, which has not been touched yet */\n     errorPrint  (\"kgraphMapBd: change in band graph number of parts not supported\");\n     memFree     (bndvnumtax + bndgrafdat.s.baseval);\n     kgraphExit  (&bndgrafdat);\n@@ -267,6 +266,8 @@\n \n   if ((orgflagtab = memAlloc (kgraphMapBdFlagSize (orggrafptr->s.vertnnd) * sizeof (unsigned int))) == NULL) {\n     errorPrint (\"kgraphMapBd: out of memory (2)\");\n+    memFree    (bndvnumtax + bndgrafdat.s.baseval);\n+    kgraphExit (&bndgrafdat);\n     return (1);\n   }\n \n",
   "tradeoffs": "Behaviour change: strategies that (accidentally) change the number of parts under a band now fail instead of continuing with inconsistent loads. That is the documented intent (\"not supported\").",
   "preferred": true
  },
  {
   "label": "Support a changed part count",
   "summary": "Propagate domnnbr and resize comploadavg/dlt of the original graph instead of erroring.",
   "patch_sketch": "orggrafptr->m.domnnbr = bndgrafdat.m.domnnbr; realloc comploadavg/comploaddlt for the new count; recompute via kgraphCost",
   "tradeoffs": "Real feature work (anchors and the memCpy of comploaddlt assume equal counts); not recommended.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-16",
 "area": "GRA",
 "our_title": "Bit-set shifts in ordering and mapping code were applied to signed integers (fixed in 7.0.17)",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "The 7.0.17 diff shows the fix; there is nothing to run.",
 "location": "hgraph_order_cp.c:102,154-180; hmesh_order_cp.c; kgraph_map_bd.h (kgraphMapBdFlag* macros); library_dgraph_map_stat.c:104,192; mesh_induce_sepa.c:122,139",
 "evidence": "Upstream commit 6a00c51 'Bugfix: apply left shifts to unsigned integers in bit sets [report R. Perry]' changes all five cited places: bit arrays become `unsigned int` and shifts `1U << ...` (e.g. hgraph_order_cp.c:180 `finehasptab[finehsumval] |= (1U << finehsumbit);`, kgraph_map_bd.h macros use `(1U << ...)`, library_dgraph_map_stat.c `nmskloctab[...] |= 1U << ...` with `unsigned int * restrict nmskloctab`, mesh_induce_sepa.c `~(1U << orgvelmbit)`). `git diff v7.0.16 v7.0.17 --stat` lists those six files. UBSan run of gmap/gord on a 40x40 grid with the 7.0.17 ASan+UBSan build shows no shift reports. Residual (not in the review's list): common.h:321 `#define flagSet(a,n) (a)[(n) / (sizeof (int) << 3)] |= (1 << ((n) & ...))` is still a signed shift (used by bdgraph_bipart_ex.c in PT-Scotch); kgraph_map_bd.c still declares `int * restrict orgflagtab` while allocating unsigned int (harmless).",
 "upstream_change": "6a00c51 Bugfix: apply left shifts to unsigned integers in bit sets [report R. Perry]",
 "review_accuracy": "Accurate for 7.0.16; fixed. Missed common.h flagSet/flagVal.",
 "fix_options": [],
 "notes": "flagSet residual not exercised here (needs PT-Scotch bdgraph_bipart_ex with >=32 local vertices flagged).",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)
