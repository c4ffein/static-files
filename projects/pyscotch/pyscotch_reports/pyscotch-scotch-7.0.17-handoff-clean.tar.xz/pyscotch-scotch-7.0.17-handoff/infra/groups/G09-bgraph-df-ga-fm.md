# G09-bgraph-df-ga-fm

Items: SEP-05, SEP-14, SEP-04, SEP-12, SEP-09, SEP-10, PS-SEP-5, GRA-26



===================================================================
## SEP-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-05",
 "area": "SEP",
 "our_title": "Diffusion anchor value now adds the per-thread reduced term instead of itself",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read of 7.0.17 line 380 and the reduction root is conclusive.",
 "location": "src/libscotch/bgraph_bipart_df.c:380",
 "evidence": "7.0.17 line 380: `vancval = loopptr->vanctab[vertnum - vancnnd] + loopptr->thrdtab[thrdnum].vanctab[vertnum - vancnnd]; /* Load variable with anchor value */` (was vanctab[..] + vanctab[..]). The reduced per-thread value written at :367-372 (threadReduce onto the last thread, which owns the anchors) is now the term that is read.",
 "upstream_change": "f37f70d \"Bugfix: add thread reduction value to local anchor [report R. Perry]\" - exactly the review Fix.",
 "review_accuracy": "Accurate; fixed exactly as the review suggested.",
 "fix_options": [],
 "notes": "Not behaviourally re-run (no 7.0.16 binary); source-read only. The reduced value is only valid on the reduction root (last thread), which is also the only thread that executes the anchor legs, so the fix is complete.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-14",
 "area": "SEP",
 "our_title": "Diffusion NaN branch indexes past thread-local range; allocation failure leaves garbage result with success code",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "A naturally failing allocation (and a natural NaN) is needed; I injected both, and the claimed hang was not seen.",
 "location": "src/libscotch/bgraph_bipart_df.c:207-213 (goto skip), 356-366 (NaN), 519-526 (no abrtval check)",
 "evidence": "In 7.0.17 only the vancval line changed (SEP-05). Unchanged: `loopptr->abrtval = 1; goto skip;` after a failed local allocation, `vertnum = vancnnt;` followed by `difntax[vertnum] = diffval * ielstax[vertnum];` in the NaN branch, and bgraphBipartDf() never reads loopdat.abrtval after the launch.\nTest-only fault injections in a copy of the ASan build (ASan+UBSan, 4 threads, work/SEP/t/sep11k.c and sep14.c):\n  (a) forced NaN at vertnum 7, pass 3, strategy r{sep=d{pass=10}}: `INJECT thr=0 vertnum=7 vancnnt=15 vertnnd=15` - i.e. for a non-last thread vancnnt == vertnnd, so the next statement reads ielstax[vertnnd] (one past the thread-local array; hidden by 8-byte group padding so ASan is silent) and writes difntax[vertnnd] (first vertex of the next thread).\n  (b) injected allocation failure in thread 0/1 of a call with veextax != NULL (8-part mapping): `ERROR: bgraphBipartDfLoop: out of memory` then `AddressSanitizer: requested allocation size 0xfffffffdf5f5f5f8` in the caller, because bgraphBipartDf() returned 0 with the thrdtab fields uninitialised.\n  (c) hang: NOT reproduced; see review_accuracy.\nWith the patch (barrier+abort check right after the allocation, NaN branch zeroes diffval instead of jumping, `abrtval > 1` => return 1) (b) gives `rc=1` with 'cannot bipartition job' and no garbage, (a) runs through, normal runs unchanged.",
 "upstream_change": "",
 "review_accuracy": "Partly accurate. Confirmed: the NaN branch indexes ielstax/difntax at vertnnd for non-last threads (OOB read/write), and abrtval is never examined after the launch so an allocation failure returns 0 with uninitialised results. NOT confirmed: 'skips threadReduce while others wait (hang)'. On the NaN path vertnum is set to vancnnt which equals vancnnd in the first leg, so the `if (vertnum == vancnnd)` block (with the reduction) still executes. The reduction is skipped on the other path: the failed-allocation `goto skip` jumps over the veexsum reduction, which unbalances the barrier count when veextax != NULL; in my injected runs that did not hang (the extra generic barrier of the thread launcher absorbed the mismatch) but it is still a barrier-count bug. Also, after a NaN abort the code rolls back to the last valid diffusion array (difotax = difntax), so returning 0 there is deliberate; only the hard-failure abort needs to return 1.",
 "fix_options": [
  {
   "label": "Barrier right after allocation, hard-failure return code, NaN without index jump",
   "summary": "(1) After the local allocation add threadBarrier + `if abrtval != 0 free & return` (GA precedent), removing the `goto skip`; (2) NaN branch: set abrtval = 1 and diffval = 0.0F instead of `vertnum = vancnnt`; (3) hard failures set abrtval = 2 and bgraphBipartDf returns 1 when abrtval > 1 (NaN abort keeps its roll-back semantics and returns 0).",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_df.c\n+++ b/src/libscotch/bgraph_bipart_df.c\n@@ -208,9 +208,18 @@\n                      &ielstax, (size_t) (vertsiz * sizeof (Gnum)), /* Ielstab is group leader as never optional */\n                      &frontab, (size_t) (fronsiz * sizeof (Gnum)), NULL) == NULL) {\n     errorPrint (\"bgraphBipartDfLoop: out of memory\");\n-    loopptr->abrtval = 1;\n-    goto skip;\n+    loopptr->abrtval = 2;      /* Hard failure: results will be invalid */\n   }\n+\n+#ifndef BGRAPHBIPARTDFNOTHREAD\n+  threadBarrier (descptr);                        /* Check that local memory allocation went well, before any reduction takes place */\n+#endif /* BGRAPHBIPARTDFNOTHREAD */\n+  if (loopptr->abrtval != 0) {                    /* If any thread could not allocate its local arrays */\n+    if (ielstax != NULL)                          /* Free local array if necessary; not yet based      */\n+      memFree (ielstax);\n+    return;\n+  }\n+\n   if (thrdnum == 0)                               /* Thread 0 will write directly in frontab */\n     frontab = grafptr->frontab;\n \n@@ -242,7 +251,7 @@\n       if (((veexval >= 0) && (veexval1 != 0)) ||\n           ((veexval <  0) && (veexval1 != veexval))) {\n         errorPrint (\"bgraphBipartDfLoop: internal error\");\n-        loopptr->abrtval = 1;\n+        loopptr->abrtval = 2;\n       }\n #endif /* SCOTCH_DEBUG_BGRAPH2 */\n \n@@ -272,12 +281,11 @@\n     difotax[vertnnd - 1] = loopptr->vanctab[1] * ielstax[vertnnd - 1];\n   }\n \n-skip:\n #ifndef BGRAPHBIPARTDFNOTHREAD\n   threadBarrier (descptr);                        /* Wait until all array values have been computed */\n #endif /* BGRAPHBIPARTDFNOTHREAD */\n \n-  if (loopptr->abrtval == 1) {                    /* If any process decided to quit */\n+  if (loopptr->abrtval != 0) {                    /* If any process decided to quit */\n     if (ielstax != NULL)                          /* Free local array if necessary  */\n       memFree (ielstax + vertbas);\n     return;\n@@ -357,8 +365,8 @@\n #ifdef SCOTCH_DEBUG_BGRAPH2\n           errorPrintW (\"bgraphBipartDfLoop: overflow\");\n #endif /* SCOTCH_DEBUG_BGRAPH2 */\n-          loopptr->abrtval = 1;                   /* Threads need to halt                      */\n-          vertnum = vancnnt;                      /* Skip regular computations but synchronize */\n+          loopptr->abrtval = 1;                   /* Threads need to halt at the end of the pass       */\n+          diffval  = 0.0F;                        /* Keep the vertex loop and reductions in lockstep   */\n         }\n \n         difntax[vertnum] = diffval * ielstax[vertnum];\n@@ -526,6 +534,9 @@\n \n   memFree (loopdat.thrdtab);                      /* Free group leader */\n \n+  if (loopdat.abrtval > 1)                       /* If any thread hit a hard failure (e.g. out of memory), results are not valid; NaN abort (1) keeps last valid state */\n+    return (1);\n+\n #ifdef SCOTCH_DEBUG_BGRAPH2\n   if (bgraphCheck (grafptr) != 0) {\n     errorPrint (\"bgraphBipartDf: inconsistent graph data\");",
   "tradeoffs": "Closes OOB, barrier mismatch and silent-garbage return. One extra barrier per call. Tested with fault injection (alloc failure -> rc=1, NaN -> completes). Uses a new value (2) of abrtval; needs a regression test with injected allocation failure.",
   "preferred": true
  },
  {
   "label": "Minimal: check abrtval after launch and clamp the NaN index",
   "summary": "Leave the synchronisation as is; in bgraphBipartDf after contextThreadLaunch: `if (loopdat.abrtval != 0) { memFree (loopdat.thrdtab); return (1); }`, and in the NaN branch replace `vertnum = vancnnt` by `diffval = 0.0F`.",
   "patch_sketch": "+  if (loopdat.abrtval != 0) {\n+    memFree (loopdat.thrdtab);\n+    return  (1);\n+  }\n...\n-          vertnum = vancnnt;\n+          diffval = 0.0F;",
   "tradeoffs": "Smallest diff, but a NaN abort (which currently degrades gracefully) would then be reported as an error, and the barrier mismatch of the allocation-failure path stays.",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: bgraph_bipart_ga.c does exactly 'allocate; threadBarrier; if abrtval: free and return' (lines 150-160) and bgraph_bipart_gg.c checks for invalid thread partitions after launch.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-04",
 "area": "SEP",
 "our_title": "Genetic crossover draws a random value modulo zero when the graph has two vertices",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/bgraph_bipart_ga.c:239 (guard at :293)",
 "evidence": "7.0.17 changes to bgraph_bipart_ga.c: only abs->ABS. Line 239 still `vecridx = 1 + contextIntRandVal (grafptr->contptr, vertnbr - 2);` and the guard at 293 is still `if (grafptr->s.vertnbr < 2) return (0);`.\nReproducer work/SEP/t/sep04.c: 2-vertex path, 2 parts, SCOTCH_stratGraphMap(\"r{sep=a{pass=5,pop=8}}\"):\n  ./sep04 2\n  AddressSanitizer: FPE on unknown address ... (T4)\n    #0 _SCOTCHintRandVal common_integer.c:471   (UINT64 % 0)\n    #1 bgraphBipartGaLoop bgraph_bipart_ga.c:239\n3- and 4-vertex runs are fine (randVal(1), randVal(2)). With the guard changed to `< 3`, or with `vecridx = (vertnbr > 2) ? ... : 1`, the 2-vertex run returns rc=0.",
 "upstream_change": "",
 "review_accuracy": "Accurate. (Minor: the 'a' method here is reached through the bipartition sub-strategy of the recursive mapping 'r{sep=a...}'.)",
 "fix_options": [
  {
   "label": "Raise the early-return guard to < 3",
   "summary": "The comment of the guard says \"no crossing-over possible\"; with vertnbr == 2 the crossover range (vertnbr - 2) is empty, so return before the loop for vertnbr < 3.",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_ga.c\n+++ b/src/libscotch/bgraph_bipart_ga.c\n@@ -290,7 +290,7 @@\n   const Gnum                demenbr = DEMENBR (paraptr->popunbr, thrdnbr); /* Size of thread local deme */\n   const Gnum                sortnbr = demenbr * thrdnbr; /* Overall number of individuals to sort       */\n \n-  if (grafptr->s.vertnbr < 2)                     /* If less than two vertices, no crossing-over possible and nothing relevant to do */\n+  if (grafptr->s.vertnbr < 3)                     /* If less than three vertices, no crossing-over point (vertnbr - 2 > 0) possible and nothing relevant to do */\n     return (0);\n \n   if (memAllocGroup ((void **) (void *)",
   "tradeoffs": "GA becomes a no-op on 2-vertex graphs (same as for 0/1 vertices today); the following refinement methods in the strategy handle those. Tested.",
   "preferred": true
  },
  {
   "label": "Keep GA on 2 vertices with a fixed crossover point",
   "summary": "Compute the crossover index as 1 when vertnbr == 2.",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_ga.c\n+++ b/src/libscotch/bgraph_bipart_ga.c\n@@ -236,7 +236,7 @@\n       Gnum                vecridx;                /* Crossover point for individuals to be mated          */\n       Gnum                vemuidx;                /* Mutation point for individuals                       */\n \n-      vecridx = 1 + contextIntRandVal (grafptr->contptr, vertnbr - 2); /* Crossing-over preserves at least one vertex in each segment */\n+      vecridx = (vertnbr > 2) ? (1 + contextIntRandVal (grafptr->contptr, vertnbr - 2)) : 1; /* Crossing-over preserves at least one vertex in each segment */\n \n       memCpy (parttab, sorttab[matetab[sortnum]].parttab, vecridx);\n       memCpy (parttab + vecridx, sorttab[matetab[sortnum + 1]].parttab + vecridx, vertnbr - vecridx);",
   "tradeoffs": "GA still explores the 2-vertex case (4 labelings) at negligible cost; slightly more code in the hot loop. Tested no FPE.",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: the existing top-of-function guard idiom (`if (vertnbr < N) return (0)` with a comment) — they would just correct the bound.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-12",
 "area": "SEP",
 "our_title": "Genetic algorithm threads read parents while others overwrite the shared sort table; shared random state",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/bgraph_bipart_ga.c:177, 190-205, 235-249",
 "evidence": "File only changed abs->ABS in 7.0.17. ThreadSanitizer build of pristine 7.0.17 (scratchpad/tsan/pristine), harness work/SEP/t/sep11k_tsan, strategy r{sep=a{pass=8,pop=32}}, 4 threads:\n  WARNING: ThreadSanitizer: data race: Write of size 8 by thread T1 _SCOTCHintRandVal3 common_integer.c:443 <- intRandVal2 <- bgraphBipartGaLoop bgraph_bipart_ga.c:177 ; Previous write ... by thread T2 same place   (shared contptr->randptr state)\n  Write of size 8 at 0x725c00000168 ... bgraph_bipart_ga.c:205 (sorttab[sortnum].parttab) ; Previous read ... bgraph_bipart_ga.c:241 / :242 (parent lookup sorttab[matetab[..]].parttab)   (next-generation cost loop overwrites sorttab while a slower thread still reads parents)\nPatched (barrier after the offspring loop + per-thread generators spawned before launch): the same TSan run reports 0 warnings (run 4 times).",
 "upstream_change": "",
 "review_accuracy": "Accurate on both counts (missing barrier after the offspring loop; shared RNG).",
 "fix_options": [
  {
   "label": "Barrier + pre-spawned per-thread generators",
   "summary": "Add threadBarrier after the offspring loop (before swapping demes), store an IntRandContext per thread in BgraphBipartGaThread, spawn them from the launching thread (intRandSpawn, before contextThreadLaunch) and use a local Context for thread != 0.",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_ga.c\n+++ b/src/libscotch/bgraph_bipart_ga.c\n@@ -132,6 +132,8 @@\n   const int                           thrdnum = 0;\n #endif /* BGRAPHBIPARTGANOTHREAD */\n   Bgraph * restrict const             grafptr = loopptr->grafptr;\n+  Context                             contdat;    /* Local context, only used for its random section */\n+  Context *                           contptr;    /* Pointer to active local context                 */\n   BgraphBipartGaSort * const          sorttab = loopptr->sorttab; /* [norestrict: async] */\n   Gnum * const                        matetab = loopptr->matetab; /* [norestrict: async] */\n   const Gnum                          baseval = grafptr->s.baseval;\n@@ -162,6 +164,13 @@\n     return;\n   }\n \n+  if (thrdnum == 0)\n+    contptr = grafptr->contptr;                   /* Thread 0 uses provided context                          */\n+  else {                                          /* Other threads use their own, pre-spawned, generator     */\n+    contdat.randptr = &loopptr->thrdtab[thrdnum].randdat;\n+    contptr = &contdat;\n+  }\n+\n   demeptr[0] = demetab;                           /* Point to initial and future demes */\n   demeptr[1] = demetab + demesiz;\n \n@@ -174,7 +183,7 @@\n     UINT                randval;                  /* Integer random value to slice into bits       */\n     Gnum                randnbr;                  /* Number of slices to use in a random value     */\n \n-    randval = contextIntRandVal2 (grafptr->contptr); /* Get UINT random value */\n+    randval = contextIntRandVal2 (contptr); /* Get UINT random value */\n     randnbr = MIN (sizeof (UINT), partnum);       /* Compute useable slices   */\n     while (randnbr -- > 0) {\n       demetab[-- partnum] = (GraphPart) (randval & 1); /* Use lowest bit value as part value */\n@@ -236,18 +245,22 @@\n       Gnum                vecridx;                /* Crossover point for individuals to be mated          */\n       Gnum                vemuidx;                /* Mutation point for individuals                       */\n \n-      vecridx = 1 + contextIntRandVal (grafptr->contptr, vertnbr - 2); /* Crossing-over preserves at least one vertex in each segment */\n+      vecridx = 1 + contextIntRandVal (contptr, vertnbr - 2); /* Crossing-over preserves at least one vertex in each segment */\n \n       memCpy (parttab, sorttab[matetab[sortnum]].parttab, vecridx);\n       memCpy (parttab + vecridx, sorttab[matetab[sortnum + 1]].parttab + vecridx, vertnbr - vecridx);\n       parttab += vertnbr;                         /* Move to next offspring */\n       memCpy (parttab, sorttab[matetab[sortnum + 1]].parttab, vecridx);\n       memCpy (parttab + vecridx, sorttab[matetab[sortnum]].parttab + vecridx, vertnbr - vecridx);\n-      vemuidx = contextIntRandVal (grafptr->contptr, vertnbr); /* Perform mutation on every other offspring */\n+      vemuidx = contextIntRandVal (contptr, vertnbr); /* Perform mutation on every other offspring */\n       parttab[vemuidx] ^= 1;\n       parttab += vertnbr;                         /* Move to next offspring */\n     }\n \n+#ifndef BGRAPHBIPARTGANOTHREAD\n+    threadBarrier (descptr);                      /* Make sure nobody still reads parents in sorttab and current deme before they are overwritten */\n+#endif /* BGRAPHBIPARTGANOTHREAD */\n+\n     demetmp    = demeptr[0];                      /* Swap pointers for current and new demes */\n     demeptr[0] = demeptr[1];\n     demeptr[1] = demetmp;\n@@ -307,6 +320,15 @@\n   loopdat.abrtval = 0;                            /* No reason to abort (yet) */\n \n #ifndef BGRAPHBIPARTGANOTHREAD\n+  {\n+    int                 thrdnum;\n+\n+    for (thrdnum = 1; thrdnum < thrdnbr; thrdnum ++) /* Spawn generators while no thread is running; thread 0 keeps the main one */\n+      intRandSpawn (grafptr->contptr->randptr, thrdnum, &loopdat.thrdtab[thrdnum].randdat);\n+  }\n+#endif /* BGRAPHBIPARTGANOTHREAD */\n+\n+#ifndef BGRAPHBIPARTGANOTHREAD\n   contextThreadLaunch (grafptr->contptr, (ThreadFunc) bgraphBipartGaLoop, (void *) &loopdat);\n #else /* BGRAPHBIPARTGANOTHREAD */\n   bgraphBipartGaLoop (NULL, &loopdat);\n--- a/src/libscotch/bgraph_bipart_ga.h\n+++ b/src/libscotch/bgraph_bipart_ga.h\n@@ -71,6 +71,7 @@\n   Gnum                      commgainextn[2];\n   Gnum                      veexsum;              /*+ Area for reducing sums of external gains       +*/\n   Gnum                      veexsum1;\n+  IntRandContext            randdat;              /*+ Private pseudo-random generator, spawned before launch +*/\n } BgraphBipartGaThread;\n \n /*+ The sort structure. +*/",
   "tradeoffs": "Results become independent of thread timing for a given thread count; stream per thread differs from the current (racy) one so GA outputs change (they were not reproducible anyway). One extra barrier per generation. Struct BgraphBipartGaThread grows by sizeof(IntRandContext) (internal). Tested with TSan: 0 reports.",
   "preferred": true
  },
  {
   "label": "Thread 0 pre-draws all random values",
   "summary": "Keep the single generator but let thread 0 fill shared arrays of crossover points, mutation points and the initial-population bits in the already-sequential section (where it builds the mating permutation), then barrier; workers only read them. Plus the same barrier after the offspring loop.",
   "patch_sketch": "/* thread 0, next to intPerm (matetab): */\nfor (i = 0; i < sortnbr / 2; i ++) { vecrtab[i] = 1 + contextIntRandVal (contptr, vertnbr - 2); vemutab[i] = contextIntRandVal (contptr, vertnbr); }\n/* workers: vecridx = vecrtab[sortnum / 2]; ... */",
   "tradeoffs": "Deterministic even across timing and mostly across thread counts, but serialises all RNG draws (population init is O(popunbr * vertnbr) bits) and needs two more shared arrays. Not compiled.",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: bgraph_bipart_gg.c already gives each worker a private random context (intRandSpawn + a local Context), which is option 1; the missing barrier mirrors the barrier already placed after the cost loop.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-09",
 "area": "SEP",
 "our_title": "After failed hash-table growth the FM bipartitioner keeps probing the table it just freed",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "Needs a real memReallocGroup failure; I forced it by fault injection only.",
 "location": "src/libscotch/bgraph_bipart_fm.c:598-606",
 "evidence": "bgraph_bipart_fm.c only changed abs->ABS in 7.0.17. Lines 598-603 still free `hashtab` and the gain table on resize failure but fall through to the `for (hashnum = ... hashtab[hashnum].vertnum != ~0 ...)` probe at :604-606 and later to `memFree (hashtab)` (:849).\nA resize of the FM hash never happens on ordinary inputs (hash is sized 4*(fronnbr+movenbr+degrmax)), so I forced it with a test-only fault injection in a copy of the ASan build (bgraphBipartFmResize returns 1 and hashmax is lowered), strategy r{sep=h{pass=1}f{move=30,pass=-1,bal=0.1}} on a 40x40 grid:\n  ERROR: bgraphBipartFmResize: out of memory (injected)\n  ERROR: bgraphBipartFm: out of memory (2)\n  AddressSanitizer: heap-use-after-free READ of size 4 ... #0 bgraphBipartFm bgraph_bipart_fm.c:606\n  freed by thread T0 here: #1 bgraphBipartFm bgraph_bipart_fm.c:603\nWith `return (1);` added after the cleanup the same run ends with 'cannot bipartition job' and rc=1, no ASan report.",
 "upstream_change": "",
 "review_accuracy": "Accurate (the only caveat: needs an allocation failure in memReallocGroup, which I injected rather than provoked).",
 "fix_options": [
  {
   "label": "Return right after the local cleanup",
   "summary": "Add `return (1);` after memFree (hashtab) / bgraphBipartFmTablExit (tablptr) in the resize-failure branch.",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_fm.c\n+++ b/src/libscotch/bgraph_bipart_fm.c\n@@ -600,6 +600,7 @@\n                 errorPrint (\"bgraphBipartFm: out of memory (2)\");\n                 memFree    (hashtab);             /* Free group leader */\n                 bgraphBipartFmTablExit (tablptr);\n+                return     (1);\n               }\n               for (hashnum = (vertend * BGRAPHBIPARTFMHASHPRIME) & hashmsk; hashtab[hashnum].vertnum != ~0; hashnum = (hashnum + 1) & hashmsk) ; /* Search for new first free slot */\n             }",
   "tradeoffs": "One line. Does not touch the other early `return (1)`s of the function which also skip cleanup (lines ~630, 707, 718, 777; debug-only internal-error paths).",
   "preferred": true
  },
  {
   "label": "Single cleanup label",
   "summary": "Introduce `o = 1; goto fail;` in all error exits of bgraphBipartFm, with one `fail:` label that does memFree (hashtab) + bgraphBipartFmTablExit and returns o (success path falls into the same code with o = 0).",
   "patch_sketch": "-                memFree    (hashtab);\n-                bgraphBipartFmTablExit (tablptr);\n+                o = 1;\n+                goto fail;\n...\n+fail:\n   memFree (hashtab);\n   bgraphBipartFmTablExit (tablptr);\n-  return (0);\n+  return (o);",
   "tradeoffs": "Fixes the debug-path leaks as well, but a bigger diff in a long function and changes the structure the maintainers keep minimal. ",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: wgraph_part_fm.c uses `goto fail` labels with a single cleanup, while bgraph_bipart_fm.c's other error exits are plain returns; both plausible, the one-liner is the least risky.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-10",
 "area": "SEP",
 "our_title": "Zeroing a bipartition graph adds fixed load to part 0 load, unlike init and checker",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/bgraph.c:241-256 (compload0 at :246); bgraph_check.c:182",
 "evidence": "bgraph.c untouched in 7.0.17. bgraphInit2 sets compload0 = velosum, compload0dlt = velosum - compload0avg (compload0avg already subtracts vfixload0), and bgraphCheck requires velosum - cpl1sum == compload0; bgraphZero sets compload0 = velosum + vfixload[0].\nInternal-API harness work/SEP/t/sep10.c (6-vertex path, vfixload = 5,3; Bgraph built with bgraphInit2 then bgraphZero then bgraphCheck):\n  after bgraphInit2: compload0=6 compload0dlt=4 compload0avg=2 bgraphCheck=0\n  ERROR: bgraphCheck: invalid part load\n  after bgraphZero : compload0=11 compload0dlt=9 compload0avg=2 bgraphCheck=1\nWith vfixload = 0,0 both are consistent. After the patch (compload0 = velosum, compload0dlt = velosum - compload0avg) bgraphZero gives 6 / 4 / check=0.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Extra: bgraphSwal (bgraph.c:213-231) has the same convention problem (comploadsum includes both fixed loads; after Init2 + Swal with vfix 5,3 it yields compload0=8 and bgraphCheck fails) but it has no callers in 7.0.17 (grep), so it is latent.",
 "fix_options": [
  {
   "label": "Drop the fixed load from bgraphZero (review Fix)",
   "summary": "compload0 = velosum; compload0dlt = velosum - compload0avg (as bgraphInit2 does).",
   "patch_sketch": "--- a/src/libscotch/bgraph.c\n+++ b/src/libscotch/bgraph.c\n@@ -241,12 +241,9 @@\n bgraphZero (\n Bgraph * restrict const     grafptr)\n {\n-  Gnum                compload0;\n-\n-  compload0 = grafptr->s.velosum + grafptr->vfixload[0];\n   grafptr->fronnbr      = 0;                      /* No frontier vertices */\n-  grafptr->compload0dlt = compload0 - grafptr->compload0avg;\n-  grafptr->compload0    = compload0;\n+  grafptr->compload0dlt = grafptr->s.velosum - grafptr->compload0avg; /* Fixed vertex loads are accounted for in compload0avg, not in compload0 */\n+  grafptr->compload0    = grafptr->s.velosum;\n   grafptr->compsize0    = grafptr->s.vertnbr;\n   grafptr->commload     = grafptr->commloadextn0; /* Initialize communication load */\n   grafptr->commgainextn = grafptr->commgainextn0;",
   "tradeoffs": "Restores consistency with bgraphInit2/bgraphCheck; behaviour change only when vfixload[0] != 0 (fixed-vertex mapping), where refinement starts from the correct imbalance. Tested with the harness.",
   "preferred": true
  },
  {
   "label": "Make bgraphZero call bgraphInit2-style state reset",
   "summary": "Reuse one helper that sets all derived fields from (velosum, compload0avg) for the \"everything in part 0\" state and call it from both bgraphInit2 and bgraphZero (and from bgraphSwal for the mirrored state), so the convention lives in one place.",
   "patch_sketch": "static void bgraphAllZero (Bgraph * grafptr) { grafptr->compload0 = grafptr->s.velosum; grafptr->compload0dlt = grafptr->s.velosum - grafptr->compload0avg; ... }",
   "tradeoffs": "Prevents future drift (and fixes bgraphSwal) at the cost of a slightly larger refactor. Not compiled.",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: bgraphInit2 is the reference; the other state setters should mimic it. Option 1.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## PS-SEP-5

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-SEP-5",
 "our_title": "bgraphSwal recomputes part load including both fixed loads, breaking the checker's convention",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/bgraph.c:213-231",
 "evidence": "Harness work/SEP/t/sep10s.c: bgraphInit2 with fixed loads 5,3 then bgraphSwal gives compload0=8 and bgraphCheck reports 'invalid part load'. No caller in src/libscotch.",
 "related_review_ids": [
  "SEP-10"
 ],
 "fix_options": [
  {
   "label": "Use free-vertex loads only",
   "summary": "compload0 = velosum - compload0; recompute dlt from compload0avg.",
   "patch_sketch": "-  grafptr->compload0 = comploadsum - grafptr->compload0;\n+  grafptr->compload0 = grafptr->s.velosum - grafptr->compload0;",
   "tradeoffs": "Latent; matches bgraphInit2.",
   "preferred": true
  },
  {
   "label": "Remove unused function",
   "summary": "Delete bgraphSwal.",
   "patch_sketch": "delete bgraphSwal and prototype",
   "tradeoffs": "Drops API-shaped helper.",
   "preferred": false
  }
 ],
 "area": "SEP"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## GRA-26

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-26",
 "area": "GRA",
 "our_title": "Multilevel code applies a non-zero offset to a NULL pointer on base-1 graphs (UBSan)",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "kgraph_map_ml.c:239; bgraph_bipart_ml.c:195 (and the pervasive idiom)",
 "evidence": "Base-1 graph grid40b1.grf (converted with gcv): `gpart 8 grid40b1.grf /dev/null` on the UBSan build -> 'kgraph_map_ml.c:239:44: runtime error: applying non-zero offset 18446744073709551608 to null pointer' and 'bgraph_bipart_ml.c:195:35: runtime error: applying non-zero offset ... to null pointer'. With a base-0 graph there are no reports (offset 0). Lines unchanged in 7.0.17. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate; harmless in practice on all current compilers.",
 "fix_options": [
  {
   "label": "Guard the two sites (preferred, minimal)",
   "summary": "Compute coarmulttax only when coarmulttab != NULL.",
   "patch_sketch": "-  const GraphCoarsenMulti * restrict const coarmulttax = coarmulttab - finegrafptr->s.baseval;\n+  const GraphCoarsenMulti * restrict const coarmulttax = (coarmulttab != NULL) ? (coarmulttab - finegrafptr->s.baseval) : NULL;",
   "tradeoffs": "Silences these two reports; the idiom is used everywhere else (hundreds of sites), so UBSan -fsanitize=pointer-overflow noise remains elsewhere.",
   "preferred": true
  },
  {
   "label": "Build with -fno-sanitize=pointer-overflow / document the idiom",
   "summary": "Treat the based-array idiom as intentional (TRICK comments already say so) and disable the check in sanitizer CI.",
   "patch_sketch": "CFLAGS += -fno-sanitize=pointer-overflow (or a UBSan suppressions file)",
   "tradeoffs": "No code change; hides real pointer-overflow bugs too.",
   "preferred": false
  }
 ],
 "notes": "Info-level.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)
