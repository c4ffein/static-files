# G14-graph-loaders

Items: GRA-04, GRA-10, GRA-07, GRA-08, GRA-11, GRA-24, GRA-09, PS-API-5



===================================================================
## GRA-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-04",
 "area": "GRA",
 "our_title": "Graph loader still accepts negative vertex labels and converts labels to indices unchecked (negative edge ends now rejected)",
 "claimed_severity": "high",
 "status": "partially-fixed",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io.c:194-200 (label read, still unchecked), 304/309 (indxtab[vlbltax[v]])",
 "evidence": "Upstream 7.0.17 (febaef7 'Prevent reading negative graph edge values') now rejects edgeval < 0 (graph_io.c:244-246: `(edgeval < 0)) { /* Neither vertex indices nor labels can be negative */`) and edloval < 1, so negative EDGE ENDS are fixed. Negative VERTEX LABELS are not: graph_io.c:194 still only checks `intLoad (stream, &vlblval) != 1`; graphLoad2 then does `indxtab[vlbltax[vertnum]]` with a negative index. Repro: file neglbl.grf = '0\\n2 2\\n1 100\\n-5 1 3\\n3 1 3\\n' ; `gtst neglbl.grf` -> 'AddressSanitizer: heap-buffer-overflow ... READ of size 4 ... #0 graphLoad2 graph_io.c:304 #1 graphLoad graph_io.c:265' (underflow of the indxtab block, 20 bytes before). (Same file with edge end -5 instead gives 'graphLoad: bad input (7)' = fixed part.) Patched graph_io.c (vlblval < 0 rejected): 'graphLoad: bad input (3)'. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "febaef7 Prevent reading negative graph edge values [report R. Perry] (graph_io.c: edloval < 1, edgeval < 0 checks)",
 "review_accuracy": "Accurate for 7.0.16; the edge-end half is now fixed upstream, the label half is not.",
 "fix_options": [
  {
   "label": "Reject negative labels at read time",
   "summary": "Add `(vlblval < 0)` to the label read test next to the new edge checks.",
   "patch_sketch": "--- a/src/libscotch/graph_io.c\n+++ b/src/libscotch/graph_io.c\n@@ -191,7 +191,8 @@\n     if (grafptr->vlbltax != NULL) {               /* If must read label               */\n       Gnum                vlblval;                /* Value where to read vertex label */\n \n-      if (intLoad (stream, &vlblval) != 1) {      /* Read label data */\n+      if ((intLoad (stream, &vlblval) != 1) ||    /* Read label data      */\n+          (vlblval < 0)) {                        /* Labels index arrays */\n         errorPrint (\"graphLoad: bad input (3)\");\n         graphFree  (grafptr);\n         return (1);\n@@ -248,7 +249,14 @@\n         graphFree  (grafptr);\n         return (1);\n       }\n-      grafptr->edgetax[edgenum] = edgeval + baseadj;\n+      edgeval += baseadj;                         /* Adjust to graph base (baseadj is null for labeled graphs, checked in graphLoad2()) */\n+      if ((grafptr->vlbltax == NULL) &&           /* If edge ends are vertex indices, they must be valid  */\n+          ((edgeval < grafptr->baseval) || (edgeval >= grafptr->vertnnd))) {\n+        errorPrint (\"graphLoad: invalid arc end number\");\n+        graphFree  (grafptr);\n+        return (1);\n+      }\n+      grafptr->edgetax[edgenum] = edgeval;\n     }\n   }\n   grafptr->verttax[vertnum] = edgenum;            /* Set end of edge array             */\n",
   "tradeoffs": "One comparison per vertex; rejects only invalid files. Mirrors the style of the edge checks added by febaef7 in the same function.",
   "preferred": true
  },
  {
   "label": "Range-check inside graphLoad2",
   "summary": "In graphLoad2 reject vlbltax[v] < 0 (and edgetax[e] < 0) before using them as indices; protects the other callers of graphLoad2 (Chaco loader graph_io_chac.c, mesh/graph conversion).",
   "patch_sketch": "for (vertnum...) { if (vlbltax[vertnum] < 0 || indxtab[vlbltax[vertnum]] != ~0) { errorPrint (...); memFree (indxtab); return (1); } ...",
   "tradeoffs": "Protects all callers of graphLoad2 (graph_io_chac.c already guarantees labels >= 1) at the cost of a branch in the relabelling loop; does not protect the unlabeled path (see GRA-10).",
   "preferred": false
  }
 ],
 "notes": "Also note vlblmax is initialised to vertnnd-1 and only grows, so labels far above vertnnd allocate a huge indxtab (resource issue, not UB).",
 "history": {
  "reported": "reported",
  "7.0.17": "partially-fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-10",
 "area": "GRA",
 "our_title": "Graph loader has no upper or base-adjusted bound on edge ends (negative values are now rejected)",
 "claimed_severity": "medium",
 "status": "partially-fixed",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io.c:244-251",
 "evidence": "7.0.17 rejects negative edge values at read time (febaef7, graph_io.c:244-246) but still has no upper bound or base-adjusted lower bound: badend.grf (edge end 100000 in a 4-vertex graph): `gpart 2 badend.grf /dev/null` -> 'AddressSanitizer: SEGV ... #0 bgraphBipartGg2 bgraph_bipart_gg.c:239' (graphLoad returns 0; only SCOTCH_graphCheck / gtst reports 'graphCheck: arc data do not match'). Base conversion also slips through the new check: conv.grf (file base 1, edge end 0) loaded with base 0 -> baseadj=-1 -> stored end -1 -> SCOTCH_graphLoad ret=0, SCOTCH_graphCheck ret=1. Patched graph_io.c (check baseval <= end+baseadj < vertnnd when vlbltax == NULL): both files rejected with 'graphLoad: invalid arc end number'; valid base-0/base-1 files still load and check. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "febaef7 (edgeval < 0 only)",
 "review_accuracy": "Accurate for 7.0.16. In 7.0.17 only the negative half is covered (and not after base adjustment).",
 "fix_options": [
  {
   "label": "Range-check each unlabeled edge end in the read loop",
   "summary": "After adding baseadj, require baseval <= end < vertnnd when no vertex labels (labelled ends are already checked in graphLoad2 against vlblmax and the index table).",
   "patch_sketch": "--- a/src/libscotch/graph_io.c\n+++ b/src/libscotch/graph_io.c\n@@ -191,7 +191,8 @@\n     if (grafptr->vlbltax != NULL) {               /* If must read label               */\n       Gnum                vlblval;                /* Value where to read vertex label */\n \n-      if (intLoad (stream, &vlblval) != 1) {      /* Read label data */\n+      if ((intLoad (stream, &vlblval) != 1) ||    /* Read label data      */\n+          (vlblval < 0)) {                        /* Labels index arrays */\n         errorPrint (\"graphLoad: bad input (3)\");\n         graphFree  (grafptr);\n         return (1);\n@@ -248,7 +249,14 @@\n         graphFree  (grafptr);\n         return (1);\n       }\n-      grafptr->edgetax[edgenum] = edgeval + baseadj;\n+      edgeval += baseadj;                         /* Adjust to graph base (baseadj is null for labeled graphs, checked in graphLoad2()) */\n+      if ((grafptr->vlbltax == NULL) &&           /* If edge ends are vertex indices, they must be valid  */\n+          ((edgeval < grafptr->baseval) || (edgeval >= grafptr->vertnnd))) {\n+        errorPrint (\"graphLoad: invalid arc end number\");\n+        graphFree  (grafptr);\n+        return (1);\n+      }\n+      grafptr->edgetax[edgenum] = edgeval;\n     }\n   }\n   grafptr->verttax[vertnum] = edgenum;            /* Set end of edge array             */\n",
   "tradeoffs": "One compare pair per arc (cheap vs the I/O parse); consistent with the new edgeval < 0 test. Does not catch asymmetric adjacency (that remains graphCheck).",
   "preferred": true
  },
  {
   "label": "Run graphCheck in release builds for loaded graphs",
   "summary": "Call graphCheck() unconditionally at the end of graphLoad (today only under SCOTCH_DEBUG_GRAPH2).",
   "patch_sketch": "if (graphCheck (grafptr) != 0) { errorPrint (\"graphLoad: inconsistent graph data\"); graphFree (grafptr); return (1); }",
   "tradeoffs": "Catches asymmetry/duplicates too, but costs a full O(E) check (with hashing) on every load and changes behaviour for slightly malformed but previously usable files.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "partially-fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-07",
 "area": "GRA",
 "our_title": "Matrix Market loader overflows the vertex array on 0-based input",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io_mmkt.c:227-229",
 "evidence": "Repro: `gcv -im0 t0b.mtx /dev/stdout` (5x5 pattern matrix, 0-based indices, base 0) -> 'AddressSanitizer: heap-buffer-overflow ... WRITE of size 4 ... #0 graphGeomLoadMmkt graph_io_mmkt.c:229' (24-byte verttax block: (vertnbr+1)*4 | 8). Base 2: t2c.mtx (6x6, one entry '2 3'): gcv -im2 produces a graph whose end-of-array entry is uninitialised (0xBEBEBEBE = -1094795590 seen in the output; gtst/graphCheck: 'invalid vertex arrays') because `while (vertnum < mrownbr)` compares the based vertnum with the unbased row count so trailing isolated vertices are never filled. Patched (`while (vertnum < (grafptr->vertnnd - 1))`): base 0, 1 and 2 files load and pass SCOTCH_graphCheck. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate, including the fix (loop to vertnnd - 1). graphCheck is only the symptom for base 2; the real defect is the missing fill of trailing vertex entries (uninitialised read).",
 "fix_options": [
  {
   "label": "Compare in based space",
   "summary": "Loop until vertnum reaches vertnnd - 1.",
   "patch_sketch": "--- a/src/libscotch/graph_io_mmkt.c\n+++ b/src/libscotch/graph_io_mmkt.c\n@@ -224,7 +224,7 @@\n   edgetmp = edgenum - edgetmp;                    /* Compute degree and see if it is maximum degree */\n   if (edgetmp > degrmax)\n     degrmax = edgetmp;\n-  while (vertnum < mrownbr)                       /* Fill gaps with isolated vertices and mark beginning of new one */\n+  while (vertnum < (grafptr->vertnnd - 1))        /* Fill gaps with isolated vertices and mark beginning of new one (vertnum is based) */\n     grafptr->verttax[++ vertnum] = edgenum;\n   grafptr->verttax[++ vertnum] = edgenum;         /* Mark end of array */\n \n",
   "tradeoffs": "Two-token change; no effect for base 1.",
   "preferred": true
  },
  {
   "label": "Normalise indices to base 0 while reading",
   "summary": "Store sorttab indices minus baseval and work in unbased space, adding baseval only when writing verttax/edgetax.",
   "patch_sketch": "sorttab[..].vertnum[i] -= baseval at read; compare against mrownbr; verttax[..] = edgenum + ...",
   "tradeoffs": "Cleaner but touches many lines of a rarely used converter; larger regression risk.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-08",
 "area": "GRA",
 "our_title": "Chaco loader's edge-count check is one too permissive and overflows the edge array",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io_chac.c:210-231 (check at 225, stores at 223 and 230)",
 "evidence": "Repro: over.chac = '3 1\\n2 3\\n1 3\\n1 2\\n' (declares 1 edge = 2 arcs, lists 6): `gcv -ic over.chac /dev/stdout` -> 'AddressSanitizer: heap-buffer-overflow ... WRITE of size 4 ... #0 graphGeomLoadChac graph_io_chac.c:230' (8-byte edgetax block). The test at line 225 is `edgenum > (grafptr->edgenbr + 1)`, one too permissive for an array based at 1, and edlotax[edgenum] is stored (line ~222) before any check. Patched (test `edgenum >= edgenbr + 1` hoisted before any store): the same file now fails with 'graphGeomLoadChac: bad input (5)'; valid 3-vertex Chaco file still loads. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate (fix text \"edgenum >= edgenbr + baseval\" is right since Chaco base is 1).",
 "fix_options": [
  {
   "label": "Hoist and tighten the check",
   "summary": "Test edgenum >= edgenbr + 1 before reading/storing edge data.",
   "patch_sketch": "--- a/src/libscotch/graph_io_chac.c\n+++ b/src/libscotch/graph_io_chac.c\n@@ -212,6 +212,12 @@\n \n       ungetc (chabuffcar, filesrcptr);            /* Else put character back to stream */\n \n+      if (edgenum >= (grafptr->edgenbr + 1)) {    /* Test edge array overflow before storing any arc data (edge array is based at 1) */\n+        errorPrint (\"graphGeomLoadChac: bad input (5)\");\n+        graphFree  (grafptr);\n+        return     (1);\n+      }\n+\n       if ((intLoad (filesrcptr, &chavertnum) != 1) ||\n           (chavertnum < 1)                         ||\n           (chavertnum > chavertnbr)                ||\n@@ -222,11 +228,6 @@\n         graphFree  (grafptr);\n         return     (1);\n       }\n-      if (edgenum > (grafptr->edgenbr + 1)) { /* Test edge array overflow */\n-        errorPrint (\"graphGeomLoadChac: bad input (5)\");\n-        graphFree  (grafptr);\n-        return     (1);\n-      }\n       grafptr->edgetax[edgenum ++] = chavertnum;\n     }\n \n",
   "tradeoffs": "Rejects over-long adjacency lists earlier; same error message number kept.",
   "preferred": true
  },
  {
   "label": "Bound the edge loads by the same guard only",
   "summary": "Keep the late check but also guard the edlotax store `if (edgenum <= edgenbr)`.",
   "patch_sketch": "if ((grafptr->edlotax != NULL) && (edgenum <= grafptr->edgenbr)) ... ; if (edgenum >= edgenbr + 1) error",
   "tradeoffs": "Smaller diff, but leaves the order of reads/checks convoluted.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-11",
 "area": "GRA",
 "our_title": "Harwell-Boeing loader indexes the vertex array with unchecked row indices",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io_habo.c:266-282 (row decode and verttax[habnzrval]++), also column pointers 238-247",
 "evidence": "Repro: 4x4 path matrix ok.hb ((10I3) formats). bad99.hb: row index 99 -> `gcv -ib bad99.hb /dev/null` -> 'AddressSanitizer: heap-buffer-overflow ... READ of size 4 ... #0 graphGeomLoadHabo graph_io_habo.c:280' (verttax[habnzrval]++ with habnzrval=99). bad0.hb: blank row field (decoded 0) -> heap-buffer-overflow at verttax[0] (before the based array). Patched graph_io_habo.c rejects both with 'graphGeomLoadHabo: bad input (9)'; ok.hb still loads. Column pointers (habcoltab) are also unvalidated (monotonicity / <= nnz+1) and drive habnzrnum past habnzrtab. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate; the loader additionally trusts the column pointer array.",
 "fix_options": [
  {
   "label": "Reject out-of-range rows right after decoding",
   "summary": "Require 1 <= habnzrval <= habcolnbr (blank fields decode to 0 and are rejected).",
   "patch_sketch": "--- a/src/libscotch/graph_io_habo.c\n+++ b/src/libscotch/graph_io_habo.c\n@@ -274,6 +274,11 @@\n         graphFree  (grafptr);\n         return (1);\n       }\n+      if ((habnzrval < 1) || (habnzrval > habcolnbr)) { /* Row index must be a valid vertex number (also rejects blank or non-digit fields) */\n+        errorPrint (\"graphGeomLoadHabo: bad input (9)\");\n+        graphFree  (grafptr);\n+        return (1);\n+      }\n       habnzrtab[habnzrnum] = habnzrval;\n       if (habnzrval != vertnum) {                 /* If not loop edge      */\n         grafptr->verttax[vertnum] ++;             /* Account for arc       */\n@@ -404,7 +409,7 @@\n     for (charptr ++; *charptr != '\\0'; charptr ++) {\n       if (*charptr == '\\0')                       /* Error if end of string */\n         return (1);\n-      if (! isdigit (*charptr < '0'))\n+      if (! isdigit ((int) (unsigned char) *charptr))\n         break;\n       number = number * 10 + *charptr - '0';\n     }\n",
   "tradeoffs": "One comparison per non-zero; also covers GRA-24 hunk in the same diff. Malformed files fail loudly.",
   "preferred": true
  },
  {
   "label": "Validate the whole pattern in a second pass",
   "summary": "Keep the decoding loop as is but bound verttax updates via a checked helper; additionally validate habcoltab monotonic and habcoltab[n] == nnz+1 (already checked) and entries <= nnz+1.",
   "patch_sketch": "static int graphGeomLoadHaboCheck (habcoltab, habnzrtab, habcolnbr, habnzrnbr)",
   "tradeoffs": "More thorough (also guards the column pointers) but more code; catches non-digit garbage only if decoding is also tightened (isdigit per character).",
   "preferred": false
  }
 ],
 "notes": "Non-digit characters in fixed-width fields are also silently accepted (c - '0' garbage), which the range check turns into an error only if the value falls outside [1, n].",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-24

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-24",
 "area": "GRA",
 "our_title": "Harwell-Boeing loader applies isdigit to the result of a comparison, rejecting valid files",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io_habo.c:407",
 "evidence": "Repro: pre.hb (valid 4x4 path matrix, formats `(1X,10I3)`): `gcv -ib pre.hb /dev/stdout` -> 'gcv: ERROR: graphGeomLoadHabo: bad input (2)'; the same data with `(10I3)` (ok.hb) loads. Source: `if (! isdigit (*charptr < '0')) break;` tests the 0/1 result of a comparison. Patched (`isdigit ((int) (unsigned char) *charptr)`): pre.hb loads and the output graph is byte-identical to ok.hb's. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Cast and test the character",
   "summary": "Same expression as the other isdigit calls in the function.",
   "patch_sketch": "--- a/src/libscotch/graph_io_habo.c\n+++ b/src/libscotch/graph_io_habo.c\n@@ -274,6 +274,11 @@\n         graphFree  (grafptr);\n         return (1);\n       }\n+      if ((habnzrval < 1) || (habnzrval > habcolnbr)) { /* Row index must be a valid vertex number (also rejects blank or non-digit fields) */\n+        errorPrint (\"graphGeomLoadHabo: bad input (9)\");\n+        graphFree  (grafptr);\n+        return (1);\n+      }\n       habnzrtab[habnzrnum] = habnzrval;\n       if (habnzrval != vertnum) {                 /* If not loop edge      */\n         grafptr->verttax[vertnum] ++;             /* Account for arc       */\n@@ -404,7 +409,7 @@\n     for (charptr ++; *charptr != '\\0'; charptr ++) {\n       if (*charptr == '\\0')                       /* Error if end of string */\n         return (1);\n-      if (! isdigit (*charptr < '0'))\n+      if (! isdigit ((int) (unsigned char) *charptr))\n         break;\n       number = number * 10 + *charptr - '0';\n     }\n",
   "tradeoffs": "No downside; enables the documented nX,mIw formats.",
   "preferred": true
  },
  {
   "label": "Reuse a small digit-parsing helper",
   "summary": "Factor the three digit loops of graphGeomLoadHaboFormat into a helper using strtol with end-pointer checks.",
   "patch_sketch": "number = strtol (charptr, &endptr, 10);",
   "tradeoffs": "Removes the class of typos; larger diff in a legacy parser.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-09",
 "area": "GRA",
 "our_title": "Scotch geometry loader keeps the dimension count in a local, so the saved geometry is empty",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_io_scot.c:96-122 (dimnnbr local only), 116-120 (geomtab reuse)",
 "evidence": "Repro gra09.c: SCOTCH_graphGeomLoadScot on a 4-vertex path with a 2-D .xyz file ('2 4\\n0 0.0 0.0\\n...'), then SCOTCH_geomData and SCOTCH_graphGeomSaveScot: orig prints 'dim=0 tab=0x... tab[2]=1.000000' and the saved geometry file starts with '0\\n4' (no coordinates). Source: `Gnum dimnnbr` is a local (line 87), `geomptr->dimnnbr` is never assigned in graphGeomLoadScot (grep dimnnbr in graph_io_scot.c). Patched graph_io_scot.c: dim=2 and the saved geometry file lists all coordinates ('2\\n4\\n0\\t0.000000\\t0.000000 ...'). Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. The reuse of a pre-existing geomtab without size check is also real (a geom previously loaded with a smaller dimension would overflow).",
 "fix_options": [
  {
   "label": "Store dimnnbr and (re)allocate geomtab on dimension change",
   "summary": "Assign geomptr->dimnnbr after validation; realloc geomtab when it differs.",
   "patch_sketch": "--- a/src/libscotch/graph_io_scot.c\n+++ b/src/libscotch/graph_io_scot.c\n@@ -113,11 +113,16 @@\n   if (grafptr->vertnbr == 0)\n     return (0);\n \n-  if ((geomptr->geomtab == NULL) &&               /* Allocate geometry if necessary */\n-      ((geomptr->geomtab = (double *) memAlloc (grafptr->vertnbr * dimnnbr * sizeof (double))) == NULL)) {\n-    errorPrint (\"graphGeomLoadScot: out of memory (1)\");\n-    return     (1);\n+  if (geomptr->dimnnbr != (int) dimnnbr) {       /* (Re)allocate geometry array if absent or if of another dimension */\n+    double *            geomtab;\n+\n+    if ((geomtab = (double *) memRealloc (geomptr->geomtab, grafptr->vertnbr * dimnnbr * sizeof (double))) == NULL) {\n+      errorPrint (\"graphGeomLoadScot: out of memory (1)\");\n+      return     (1);\n+    }\n+    geomptr->geomtab = geomtab;\n   }\n+  geomptr->dimnnbr = (int) dimnnbr;\n \n   if (memAllocGroup ((void **)\n                      &coorfileptr, (size_t) (coornbr * dimnnbr * sizeof (double)),\n",
   "tradeoffs": "Fixes both the missing dimension and the unchecked reuse. Slight ownership assumption: geomtab must have been allocated with memAlloc (true for geomInit/geomExit users; a user-supplied geomtab with dimnnbr==0 would be realloc()ed).",
   "preferred": true
  },
  {
   "label": "Only record the dimension",
   "summary": "Add `geomptr->dimnnbr = dimnnbr;` and keep the allocation logic; reject (error) when geomtab != NULL and dimnnbr differs from the stored one.",
   "patch_sketch": "if ((geomptr->geomtab != NULL) && (geomptr->dimnnbr != dimnnbr)) { errorPrint (...); return (1); }\ngeomptr->dimnnbr = dimnnbr;",
   "tradeoffs": "Smallest change, never reallocates user memory; but refuses to reuse a Geom for a different dimension.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-5

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-5",
 "our_title": "Graph check accepts duplicate vertex labels",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/graph_check.c (SCOTCH_graphCheck)",
 "evidence": "work/API/tl.c builds a 4-vertex graph with vlbltab {0,0,1,2}; SCOTCH_graphCheck returns 0.",
 "related_review_ids": [
  "API-21"
 ],
 "fix_options": [
  {
   "label": "Reject duplicates in graphCheck",
   "summary": "Sort labels and compare neighbours when vlbltax != NULL.",
   "patch_sketch": "intSort1asc1 on a copy; error on equal neighbours",
   "tradeoffs": "O(n log n) memory/time in check only; may reject graphs in the wild.",
   "preferred": true
  },
  {
   "label": "Make consumers robust",
   "summary": "Leave check as is and fix TabLoad-like consumers (API-21 patch).",
   "patch_sketch": "see API-21",
   "tradeoffs": "Does not stop other label consumers misbehaving.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)
