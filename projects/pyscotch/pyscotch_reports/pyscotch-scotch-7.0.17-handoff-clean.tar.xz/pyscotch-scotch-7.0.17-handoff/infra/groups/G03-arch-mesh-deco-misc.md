# G03-arch-mesh-deco-misc

Items: COR-07, COR-14, COR-21, COR-16, PS-COR-1, COR-28, COR-20



===================================================================
## COR-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-07",
 "area": "COR",
 "our_title": "Tree-leaf level count and mesh dimension count lack lower bounds; size product can overflow",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_mesh.c:632-636 (archMeshXArchLoad), arch_tleaf.c:115-137 (archTleafArchLoad), arch_tleaf.c:240-255 (archTleafMatchInit)",
 "evidence": "- 'meshXD 0' loads (ret=0, size=1); 'gmap g44.grf in.tgt out.map' -> 'AddressSanitizer: heap-buffer-overflow READ of size 4 ... #0 _SCOTCHarchMeshXDomNum arch_mesh.c:843 #1 mapTerm mapping.c:495 #2 graphMapCompute2'. 'meshXD -1' same crash.\n- 'sub 1 0 tleaf 0' -> 'heap-buffer-overflow READ of size 4 #0 _SCOTCHarchTleafMatchInit arch_tleaf.c:255 #1 archSubArchBuild arch_sub.c:414 ...' (sizetab[levlnum] with levlnum==0 on an empty table).\n- 'tleaf 0' loads silently (ret=0 size=1); 'tleaf -1 2 1' -> 'AddressSanitizer: requested allocation size 0xfffffffffffffffc ... #1 archTleafArchLoad arch_tleaf.c:120' (levlnbr*2+1 wraps).\n- 'tleaf 2 65536 1 65536 1' -> 'arch_tleaf.c:136:13: runtime error: signed integer overflow: 65536 * 65536 cannot be represented in type int' and loads with size 0.\n- The review's 'sizetab leaks on bad input (2)' does NOT reproduce on 7.0.17: LeakSanitizer is clean for 'tleaf 2 3 1 -1 1' (archLoad now calls archTleafArchFree after a failed load, and the 7.0.17 NULL guard d555f2c keeps that path safe). The '(matching would compute % 0)' claim for meshXD 0 was not exercised separately.",
 "upstream_change": "d555f2c (indirect: sizetab leak no longer observable). No change to the validation itself.",
 "review_accuracy": "accurate for meshXD/levlnbr/overflow; the leak sub-claim is no longer true",
 "fix_options": [
  {
   "label": "A. Validate counts and the size product at load time",
   "summary": "levlnbr >= 1 and <= (ANUMMAX-1)/2; dimnnbr >= 1; per-level/dimension product checked with 'sizeval > ANUMMAX / x' before multiplying.",
   "patch_sketch": "arch_tleaf.c:\n-  if (intLoad (stream, &archptr->levlnbr) != 1) {\n+  if ((intLoad (stream, &archptr->levlnbr) != 1) || (archptr->levlnbr < 1) || (archptr->levlnbr > ((ANUMMAX - 1) / 2))) {\n ...\n+    if (sizeval > (ANUMMAX / archptr->sizetab[levlnum])) { errorPrint (\"archTleafArchLoad: bad input (3)\"); return (1); }\n     sizeval *= archptr->sizetab[levlnum];\narch_mesh.c (archMeshXArchLoad): add '(archptr->dimnnbr < 1)' and a running product 'sizeval > ANUMMAX / c[dimnnum]' check.",
   "tradeoffs": "Tested: meshXD 0/-1, tleaf 0, tleaf -1 2 1, 'sub 1 0 tleaf 0', overflow product all rejected with sanitizers silent; all valid meshes/tleaf in tgt/ unaffected (gmap on cmplt/mesh2D/torus3D/hcub/tleaf/ltleaf/sub targets give the same maps). Behaviour change: 'tleaf 0' (a one-terminal architecture) was accepted before; confirm with the Scotch team that levlnbr==0 is not intended (archTleafArchBuild in library_arch_build.c should be checked for a levlnbr>=1 contract).",
   "preferred": true
  },
  {
   "label": "B. Fix the consumers instead (guard c[-1]/sizetab[-1] users)",
   "summary": "Leave loaders permissive; make archMeshXDomNum, archTleafMatchInit etc. handle dimnnbr==0 / levlnbr==0 as a one-terminal architecture.",
   "patch_sketch": "archMeshXDomNum: 'if (dimnnbr == 0) return (0);'; archTleafMatchInit: 'if (levlnbr == 0) {...single multinode...}'.",
   "tradeoffs": "Many consumers (DomNum, DomSize, DomDist, Bipart, MatchInit, Save...) -> large audit surface; negative counts and overflow still need load-time checks, so B cannot replace A. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A; the repo idiom is the validation chain inside intLoad(...) != 1 || ... at the top of every ArchXxxLoad (archMesh2ArchLoad already rejects c[] < 1).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-14",
 "area": "COR",
 "our_title": "Multi-dimensional mesh distance no longer folds distances like a torus",
 "claimed_severity": "medium",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_mesh.c:905-920 (archMeshXDomDist)",
 "evidence": "7.0.17 archMeshXDomDist: 'disttmp = ((abs (dom0ptr->c[dimnnum][0] + dom0ptr->c[dimnnum][1] - dom1ptr->c[dimnnum][0] - dom1ptr->c[dimnnum][1]) + 1) / 2); distval += disttmp;' (no folding). Run: atst on 'meshXD 2 8 8' -> 'A Distance min=-1 max=14 avg=5.33333 dlt=4.30952', identical to 'mesh2D 8 8'; 'meshXD 3 4 4 4' = 'mesh3D 4 4 4' (max=9); 'torusXD 2 8 8' max=8 as expected for a torus.",
 "upstream_change": "feecf0d 'Bugfix: make archMeshXDomDist() consistent with mesh distances [report R. Perry]'.",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "7.0.17's rounding '(abs(..)+1)/2' differs from the review's suggested 'distval += disttmp' with '>> 1' at the end; both give the same result on the tested cases (max distance 14 for 8x8).",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-21",
 "area": "COR",
 "our_title": "Architecture loaders multiply and sum user-supplied sizes without checking Anum range",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_mesh.c:204 (Mesh2DomSize), 479-480 (Mesh3DomSize), 819-ish/891 (MeshXDomSize), arch_cmpltw.c:259 (velosum)",
 "evidence": "archload on: 'mesh2D 65536 65536' -> 'arch_mesh.c:204:51: runtime error: signed integer overflow: 65536 * 65536 cannot be represented in type int' + 'load ret=0 size=0'; 'torus2D 65536 65536' same; 'mesh3D 2000 2000 2000' -> 'arch_mesh.c:480:51: ... 4000000 * 2000' and size=-589934592; 'meshXD 2 65536 65536' -> 'arch_mesh.c:891:13 ... signed integer overflow'; 'cmpltw 2 2000000000 2000000000' -> 'arch_cmpltw.c:259:13: runtime error: signed integer overflow: 2000000000 + 2000000000 cannot be represented in type int'.",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Validate at load time",
   "summary": "Reject dimension sets whose product (and, for cmpltw, weight sum) does not fit in Anum, using 'a > ANUMMAX / b' before multiplying; the DomSize routines then cannot overflow because domains are sub-boxes.",
   "patch_sketch": "archMesh2ArchLoad: add ' || (archptr->c[0] > (ANUMMAX / archptr->c[1]))'\narchMesh3ArchLoad: add ' || (c[0] > ANUMMAX / c[1]) || ((c[0] * c[1]) > ANUMMAX / c[2])'\narchMeshXArchLoad: running product 'sizeval' with 'sizeval > (ANUMMAX / c[dimnnum])' check\narchCmpltwArchLoad2: 'if (veloval > (ANUMMAX - velosum)) { errorPrint (...); memFree (vecwtab); return (1); }'",
   "tradeoffs": "Tested: all five inputs rejected with 'bad input', sanitizers silent; 'cmplt 2147483647' still loads. Genuinely huge (>2^31 terminal) 32-bit meshes were never representable.",
   "preferred": true
  },
  {
   "label": "B. Widen the arithmetic in the DomSize routines",
   "summary": "Compute in a wider type (int64_t / double) and clamp, leaving the loaders alone.",
   "patch_sketch": "return ((Anum) MIN ((int64_t) (...) * (...), ANUMMAX));",
   "tradeoffs": "Clamping returns a wrong size silently; every consumer (mapping, coarsening) would still see inconsistent architectures. Not recommended. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A (idiom: the 'bad input' chain in each Load function; same approach as the maintainers' c5baef9 bound).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-16",
 "area": "COR",
 "our_title": "Decomposition target loader skips build result and tree consistency validation in release",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_deco.c:297 (return value dropped), 130-200 (all Build2 validation under SCOTCH_DEBUG_ARCH1), 301-338 (type-1 loader)",
 "evidence": "Type 1: target 'deco 1 2 3 / 0 9 2 / 0 9 1 / 1 1 1 / 5 5 5' (domain 1 claims size 9 but has no children inside termdommax=3) loads OK (ret=0 size=9); 'gmap -vm g44.grf bad.tgt out.map' -> 'AddressSanitizer: heap-buffer-overflow READ of size 4 ... #0 _SCOTCHarchDecoDomDist arch_deco.c:511 #1 bgraphInit bgraph.c:110 #2 kgraphMapRbBgraph kgraph_map_rb.c:530'.\nType 0: 'deco 0 2 3 / 0 1 2 / 1 1 2 / 5' (two terminals declared with the same number 2) loads with ret=0, size=1 although termdomnbr=2: archDecoArchBuild2's 'bad terminal count', 'bad maximum terminal' and 'invalid null distance' checks exist only under #ifdef SCOTCH_DEBUG_ARCH1 (lines ~139, ~162, ~197), so in release Build2 only fails on out-of-memory; the dropped return matters for OOM (release) and for every check (debug), where Build2 also frees the architecture and the loader would return 0 on a freed struct.\nAdditional finding while testing the fix: 'deco 0 4 4 / 0 1 1 / 1 1 2 / 2 1 3 / 3 1 4 / 1 1 1 x3' (terminals numbered 1..4 in a 4-node tree, i.e. terminals that are ancestors of other terminals) -> heap-buffer-overflow READ in archDecoArchBuild2 arch_deco.c:193 (distance loop uses 2*i, 2*i+1 beyond termdommax) even on the type-0 path; the review did not mention it.",
 "upstream_change": "",
 "review_accuracy": "accurate; slightly overstated for type 0 in release builds (Build2 can then only fail on OOM, because its checks are debug-only)",
 "fix_options": [
  {
   "label": "A. Propagate Build2's result, make its checks unconditional, validate the type-1 tree",
   "summary": "Check archDecoArchBuild2()'s return in the loader; remove #ifdef SCOTCH_DEBUG_ARCH1 around Build2's checks (and free the architecture on 'bad terminal count'); add a leaf check (terminal domain must have size 1 after accumulation); in the type-1 branch check size>=0, size>1 => both sons inside termdommax with size == size(son0)+size(son1), root size == termdomnbr; bound termdommax so termdommax*(termdommax-1)/2 fits in int.",
   "patch_sketch": "-    archDecoArchBuild2 (archptr, termdomnbr, termdommax, termverttab, termdisttab);\n-    memFree (termverttab);\n+    if (archDecoArchBuild2 (...) != 0) { memFree (termverttab); return (1); }   /* Build2 frees archptr on error */\n+    memFree (termverttab);\n Build2: unconditional: num in [1,termdommax]; 'size(root) == termdomnbr' (+archDecoArchFree); each terminal domverttab[num-1].size == 1; zero terminal distance.\n type-1 after reading: for each i: size<0 -> bad; size>1 -> (2*i+2 < termdommax) && size == size[2i+1]+size[2i+2]; root size == termdomnbr; else 'bad input (7)'.",
   "tradeoffs": "Tested: the type-1 bad file, the duplicate-number file and the non-leaf type-0 file are rejected with clean errors, valid type-0/1 files (and mapping with 'deco 0 4 7 ...') behave as before; no sanitizer output. Behaviour change: malformed deco files that used to load now fail. The termdommax<=46340 cap is a sketch (any bound making the product fit is fine).",
   "preferred": true
  },
  {
   "label": "B. Minimal: only propagate the result and validate type 1",
   "summary": "Leave Build2's debug-only checks as-is (cheap release path); add just the return check and the type-1 tree check in the loader.",
   "patch_sketch": "Loader hunk of A only.",
   "tradeoffs": "Does not catch the type-0 inconsistencies in release (duplicate terminals, non-leaf terminals -> OOB at line 193). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A; the Load routines are where untrusted data enters, and upstream's c5baef9-style fixes are exactly such load-time bounds.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## PS-COR-1

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-COR-1",
 "our_title": "Decomposition target with terminal nodes that are ancestors of other terminals overflows distance table",
 "severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/arch_deco.c:~185-200 (archDecoArchBuild2 distance loop)",
 "evidence": "Target file 'deco 0 4 4 / 0 1 1 / 1 1 2 / 2 1 3 / 3 1 4 / 1 1 1 / 1 1 1 / 1 1 1', run 'atst dd.tgt' on pristine ASan build: AddressSanitizer heap-buffer-overflow READ of size 4 in _SCOTCHarchDecoArchBuild2 arch_deco.c:193 called from archDecoArchLoad arch_deco.c:297. Same crash with patched tree before adding the leaf check; fixed by it.",
 "related_review_ids": [
  "COR-16"
 ],
 "fix_options": [
  {
   "label": "Leaf check after accumulation",
   "summary": "After summing sizes up the tree, require every declared terminal domain to have size 1.",
   "patch_sketch": "for (i = 0; i < termdomnbr; i ++) if (archptr->domverttab[termverttab[i].num - 1].size != 1) { errorPrint (\"archDecoArchBuild2: terminal domain is not a leaf\"); archDecoArchFree (archptr); return (1); }",
   "tradeoffs": "Tested: bad file rejected, valid 'deco 0 4 7 ...' unchanged. Rejects previously accepted nonsensical files.",
   "preferred": true
  },
  {
   "label": "Bound the distance loop",
   "summary": "Skip child lookups whose index exceeds termdommax.",
   "patch_sketch": "guard 2*i+1 <= termdommax in the distance loop",
   "tradeoffs": "Hides the inconsistent tree instead of rejecting it; not tested.",
   "preferred": false
  }
 ],
 "area": "COR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-28

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-28",
 "area": "COR",
 "our_title": "Decrease macro body names caller variables instead of its own parameters",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read is conclusive; the macro has a single caller using matching names.",
 "location": "src/libscotch/fibo.h:149-166",
 "evidence": "7.0.17 fibo.h unchanged: '#define fiboHeapDecreaseMacro(t,n) do { FiboNode * pareptr; pareptr = (n)->pareptr; if ((pareptr != NULL) && (treeptr->cmpfptr (nodeptr, pareptr) < 0)) { ... fiboHeapMoveToRoot (treeptr, nodeptr, pareptr); ...' - the body uses treeptr/nodeptr instead of (t)/(n). Single caller fibo.c:293 'fiboHeapDecreaseMacro (treeptr, nodeptr);' (via fiboHeapDecrease at fibo.h:230), so it compiles and behaves. After the replacement (t)/(n) the library builds (patched tree) and the heap code is unchanged semantically.",
 "upstream_change": "",
 "review_accuracy": "accurate (latent only; no runtime effect today)",
 "fix_options": [
  {
   "label": "A. Use the macro parameters",
   "summary": "Replace treeptr by (t) and nodeptr by (n) in the macro body, including the calls to fiboHeapMoveToRoot.",
   "patch_sketch": "-                                          (treeptr->cmpfptr (nodeptr, pareptr) < 0)) {\n+                                          ((t)->cmpfptr ((n), pareptr) < 0)) {\n-                                        fiboHeapMoveToRoot (treeptr, nodeptr, pareptr);\n+                                        fiboHeapMoveToRoot ((t), (n), pareptr);  (same for the second MoveToRoot)",
   "tradeoffs": "Built into the patched tree; zero behaviour change; removes a trap for future callers. Compile-only check (no test exercises a different caller).",
   "preferred": true
  },
  {
   "label": "B. Turn the macro into a static inline function",
   "summary": "static inline void fiboHeapDecrease (FiboHeap *, FiboNode *); avoids macro hygiene altogether.",
   "patch_sketch": "move the body into fibo.c / fibo.h as static inline.",
   "tradeoffs": "Cleaner, but the maintainers deliberately use macros for hot-path routines (fiboHeapUnlink, LinkAfter...). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: consistent with the neighbouring macros (fiboHeapMoveToRoot(t,n,p) uses its parameters).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-20",
 "area": "COR",
 "our_title": "Header-generation helper dereferences unset file names when run with fewer than two arguments",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dummysizes.c:117-120 (C_fileTab init), 228-231 (open loop), 406-412 (debug block)",
 "evidence": "Command (ASan-built tool in asan/src/libscotch): ./dummysizes   (no arguments; usage says '[<input pattern header file> [<output header file>]]') -> 'dummysizes.c:229:30: runtime error: load of null pointer of type char / AddressSanitizer: SEGV ... READ'. With one argument ('dummysizes library.h') the second slot's nameptr is NULL -> same crash. Source: 'static File C_fileTab[C_FILENBR] = { { FILEMODER }, { FILEMODEW } };' leaves nameptr NULL, then 'if ((C_fileTab[i].nameptr[0] != '-') || ...' for all i. The SCOTCH_DEBUG_MAIN1 block (lines 406-412) references C_fileTab[i].name / .pntr which do not exist in File (nameptr/fileptr): source-read, would not compile with that flag.",
 "upstream_change": "",
 "review_accuracy": "accurate (build-time helper only; not part of the installed library)",
 "fix_options": [
  {
   "label": "A. Default the names to \"-\" (stdin/stdout)",
   "summary": "In the loop that already sets default stream pointers also set nameptr = \"-\".",
   "patch_sketch": "  for (i = 0; i < C_FILENBR; i ++) {\n    C_fileTab[i].fileptr = (... == FILEMODER) ? stdin : stdout;\n+   C_fileTab[i].nameptr = \"-\";\n  }",
   "tradeoffs": "Tested: './dummysizes < /dev/null' and './dummysizes library.h /dev/null' exit 0 (no crash); the Makefile always passes both names so the build is unaffected. Also fix the debug block (nameptr/fileptr) and the CHARMAX line-length test if wanted.",
   "preferred": true
  },
  {
   "label": "B. Require both file names",
   "summary": "After option parsing: if (C_fileNum < 2) print usage and exit(EXIT_FAILURE).",
   "patch_sketch": "if (C_fileNum < C_FILEARGNBR) { fprintf (stderr, \"dummysizes: ERROR: main: missing file names\\n\"); exit (EXIT_FAILURE); }",
   "tradeoffs": "Contradicts the documented usage ('[ ... [ ...]]' optional). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A; every other Scotch command-line tool (e.g. gmap.c's C_fileTab setup) sets '-' as default name - this one forgot.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)
