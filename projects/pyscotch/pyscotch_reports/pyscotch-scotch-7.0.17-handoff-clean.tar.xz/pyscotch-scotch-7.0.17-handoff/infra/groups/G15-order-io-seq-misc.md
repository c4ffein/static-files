# G15-order-io-seq-misc

Items: GRA-03, CLI-23, PS-BLD-1, GRA-25, GRA-22, GRA-14, GRA-27



===================================================================
## GRA-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-03",
 "area": "GRA",
 "our_title": "Ordering-file loader writes past the permutation array when an index is out of range",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/order_io.c:96-120",
 "evidence": "Repro: gotst p4.grf <ord> /dev/stdout (and gra03.c via SCOTCH_graphOrderLoad) on a 4-vertex graph. bad1.ord ('4\\n0 5000\\n1 1\\n2 2\\n3 3'): `gotst p4.grf bad1.ord /dev/stdout` -> 'AddressSanitizer: heap-buffer-overflow ... WRITE of size 4 ... #0 orderPeri order.c:170 #1 orderLoad order_io.c:120 #2 SCOTCH_graphOrderLoad library_graph_order.c:147'. bad2.ord (count 100 on a 4-vertex graph): 'heap-buffer-overflow ... WRITE of size 4 ... #0 intLoad common_integer.c:129 #1 orderLoad order_io.c:107' (permtab was allocated for ordeptr->vnodnbr=4 entries, the file count overwrote ordeptr->vnodnbr at line 96). dup.ord ('4\\n0 2\\n1 2\\n2 3\\n3 1', repeated value) is accepted and leaves peritab holes (later SEGV). Patched order_io.c: ok.ord and a valid permutation load unchanged; bad1/bad2/dup are rejected with 'orderLoad: invalid permutation' / 'bad input (1)'. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Duplicates (non-permutations) are a third failure mode not mentioned.",
 "fix_options": [
  {
   "label": "Validate count and permutation while loading",
   "summary": "Read the count into a local, require it to equal ordeptr->vnodnbr, pre-fill peritab with ~0 and on each entry check range and that the slot is unused, building the inverse on the fly (same marker idiom as graphLoad2 duplicate-label check).",
   "patch_sketch": "--- a/src/libscotch/order_io.c\n+++ b/src/libscotch/order_io.c\n@@ -82,6 +82,7 @@\n {\n   Gnum * restrict     permtab;\n   Gnum                vertnum;\n+  Gnum                vnodnbr;\n \n   if (vlbltax != NULL) {\n     errorPrint (\"orderLoad: vertex labels not yet supported\");\n@@ -93,12 +94,15 @@\n     return     (1);\n   }\n \n-  if (intLoad (stream, &ordeptr->vnodnbr) != 1) {\n+  if ((intLoad (stream, &vnodnbr) != 1) ||\n+      (vnodnbr != ordeptr->vnodnbr)) {            /* Number of items must match that of the ordering (and of the graph) */\n     errorPrint (\"orderLoad: bad input (1)\");\n     memFree    (permtab);\n     return     (1);\n   }\n \n+  memSet (ordeptr->peritab, ~0, ordeptr->vnodnbr * sizeof (Gnum)); /* Mark inverse permutation slots as not yet assigned */\n+\n   if (vlbltax == NULL) {                          /* If ordering does not have label array */\n     for (vertnum = 0; vertnum < ordeptr->vnodnbr; vertnum ++) {\n       Gnum                vertval;\n@@ -114,11 +118,17 @@\n         memFree    (permtab);\n         return     (1);\n       }\n+      if ((permtab[vertnum] <  ordeptr->baseval) ||  /* Permutation value must be a valid, not yet used, index */\n+          (permtab[vertnum] >= (ordeptr->baseval + ordeptr->vnodnbr)) ||\n+          (ordeptr->peritab[permtab[vertnum] - ordeptr->baseval] != ~0)) {\n+        errorPrint (\"orderLoad: invalid permutation\");\n+        memFree    (permtab);\n+        return     (1);\n+      }\n+      ordeptr->peritab[permtab[vertnum] - ordeptr->baseval] = vertnum + ordeptr->baseval; /* Compute inverse permutation on the fly */\n     }\n   }\n \n-  orderPeri (permtab, ordeptr->baseval, ordeptr->vnodnbr, ordeptr->peritab, ordeptr->baseval); /* Compute inverse permutation */\n-\n   memFree (permtab);\n   return  (0);\n }\n",
   "tradeoffs": "Rejects malformed files (behaviour change only for invalid input); one extra memSet and O(n) pass. peritab content is undefined after a failed load (as before). Needs unit test with out-of-range, duplicate and wrong-count files. Idiom: graphLoad2() in graph_io.c marks unused slots with ~0 and errors on \"duplicate vertex label\".",
   "preferred": true
  },
  {
   "label": "Keep orderPeri, add a pre-check pass",
   "summary": "After reading, run a separate validation loop over permtab (range + seen-bitmap) before calling orderPeri; reject count != vnodnbr up front.",
   "patch_sketch": "if (vnodnbr != ordeptr->vnodnbr) { errorPrint (...); memFree (permtab); return (1); }\n/* after the read loop */\nfor (vertnum = 0; vertnum < vnodnbr; vertnum ++) if (permtab[vertnum] < baseval || permtab[vertnum] >= baseval + vnodnbr || flagtab[permtab[vertnum]-baseval]++) { error }",
   "tradeoffs": "Needs a temporary flag array (extra n bytes) but keeps orderPeri untouched; slightly more code.",
   "preferred": false
  },
  {
   "label": "Harden orderPeri itself",
   "summary": "Give orderPeri an error return and range checks so all callers (also library permutation APIs) benefit.",
   "patch_sketch": "void orderPeri (...) -> int orderPeri (...) { ... if ((permtab[permnum] - permbas) < 0 || >= permnbr) return (1); ... }",
   "tradeoffs": "API change of an internal function with several callers (library_graph_order.c, order_io.c, dorder); extra branch in hot paths.",
   "preferred": false
  }
 ],
 "notes": "SCOTCH_graphOrderLoad reaches orderLoad directly, so this is exposed to any application loading ordering files.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## CLI-23

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-23",
 "area": "CLI",
 "our_title": "esMUMPS order loader writes out of bounds on an out-of-range permutation entry; the saver hides write errors",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/esmumps/order_io.c:88-125 (orderLoad), 150-182 (orderSave)",
 "evidence": "Repro t/oio.c linking the internal _ESMUMPSorderLoad/_ESMUMPSorderSave from libesmumps.so:\norderLoad of `0\\n1\\t3\\n0\\t3\\n0 7 1\\n` (perm entry 7 for 3 vertices): `ERROR: AddressSanitizer: heap-buffer-overflow ... #0 _ESMUMPSorderLoad order_io.c:123` (write peritax[permtax[v]] = v out of bounds).\norderSave with an order whose vertnbr == 0 and permtab = malloc(0): `heap-buffer-overflow ... #0 _ESMUMPSorderSave order_io.c:176` (reads permtab[0]); note that real orderings come from memAlloc(0|8) so that read is in-bounds garbage, not a crash.\nLost write error: source-read, order_io.c:169 `o = intSave (stream, ordeptr->rangtab[cblknum]);` after the loop overwrites the loop's status, and :176 does the same after the permutation loop (not reproduced: needs a transient write failure; sustained failures still show up in the final status). Also `cblknbr < 0` / `vertnbr < 0` are not rejected (orderLoad checks only cblknbr > vertnbr).",
 "upstream_change": "",
 "review_accuracy": "Accurate; the vertnbr==0 over-read is milder in practice than the review implies (memAlloc rounds sizes up to >= 8).",
 "fix_options": [
  {
   "label": "Validate on load, accumulate status on save (tested)",
   "summary": "Reject negative counts and permutation values outside [rangtab[0], rangtab[0]+vertnbr); in orderSave only continue while o==1, skip the permtab read for vertnbr==0, and check ferror() at the end.",
   "patch_sketch": "--- a/src/esmumps/order_io.c\n+++ b/src/esmumps/order_io.c\n@@ -88,6 +88,8 @@\n        intLoad (stream, &cblknbr) +\n        intLoad (stream, &vertnbr) != 3) ||\n       (versval != 0)                    ||\n+      (cblknbr < 0)                     ||\n+      (vertnbr < 0)                     ||\n       (cblknbr > vertnbr)) {\n     errorPrint (\"orderLoad: bad input (1)\");\n     return (1);\n@@ -119,8 +121,18 @@\n   permtax = ordeptr->permtab - ordeptr->rangtab[0];\n   peritax = ordeptr->peritab - ordeptr->rangtab[0];\n   for (vertnum = ordeptr->rangtab[0], vertnnd = vertnum + vertnbr; /* Build inverse permutation */\n-       vertnum < vertnnd; vertnum ++)\n-    peritax[permtax[vertnum]] = vertnum;\n+       vertnum < vertnnd; vertnum ++) {\n+    INT                 permval;\n+\n+    permval = permtax[vertnum];\n+    if ((permval < ordeptr->rangtab[0]) || (permval >= vertnnd)) { /* Permutation values must be in the vertex range */\n+      errorPrint (\"orderLoad: bad input (3)\");\n+      orderExit  (ordeptr);\n+      orderInit  (ordeptr);\n+      return (1);\n+    }\n+    peritax[permval] = vertnum;\n+  }\n \n   return (0);\n }\n@@ -166,16 +178,21 @@\n     o = intSave (stream, ordeptr->rangtab[cblknum]);\n     putc (((cblknum & 7) == 7) ? '\\n' : '\\t', stream);\n   }\n-  o = intSave (stream, ordeptr->rangtab[cblknum]);\n+  if (o == 1)                                     /* Do not overwrite a previous error status */\n+    o = intSave (stream, ordeptr->rangtab[cblknum]);\n   putc ('\\n', stream);\n \n   for (vertnum = 0; (o == 1) && (vertnum < (vertnbr - 1)); vertnum ++) { /* Save direct permutation */\n     o = intSave (stream, ordeptr->permtab[vertnum]);\n     putc (((vertnum & 7) == 7) ? '\\n' : '\\t', stream);\n   }\n-  o = intSave (stream, ordeptr->permtab[vertnum]);\n+  if ((o == 1) && (vertnbr > 0))                  /* Do not overwrite error status nor read past empty array */\n+    o = intSave (stream, ordeptr->permtab[vertnum]);\n   putc ('\\n', stream);\n \n+  if (ferror (stream) != 0)                       /* Catch deferred write errors */\n+    o = 0;\n+\n   if (o != 1)\n     errorPrint (\"orderSave: bad output (2)\");\n ",
   "tradeoffs": "Tested: malformed file -> `orderLoad: bad input (3)` returns 1 with no ASan error; vertnbr==0 save returns 0. Duplicate permutation values are still not detected (would need a seen-array or orderCheck()).",
   "preferred": true
  },
  {
   "label": "Run orderCheck() on the loaded ordering",
   "summary": "After reading, call the existing orderCheck (order_check.c) and fail if it returns nonzero; but it must run before building peritab, so first validate range cheaply anyway.",
   "patch_sketch": "if (orderCheck (ordeptr) != 0) { errorPrint (\"orderLoad: invalid ordering\"); orderExit...; return (1); }  /* needs peritab built safely first */",
   "tradeoffs": "Also detects duplicates and bad rangtab ordering; more code and orderCheck itself expects a consistent peritab, so it complements rather than replaces the range check.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## PS-BLD-1

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-BLD-1",
 "our_title": "SCOTCH_graphOrderCheck validates the inverse permutation but not the direct permutation array",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/order_check.c:133-181",
 "evidence": "orderCheck builds a scratch permtab from ordeptr->peritab (lines 152-176) and checks range/uniqueness of peritab only; the user-supplied permtab given to SCOTCH_graphOrderInit is never compared with it. Only read, not exercised (I did not find or test the library_graph_order_check wrapper beyond this routine). This is why test_scotch_graph_order needs its own permtab check.",
 "related_review_ids": [
  "BLD-04"
 ],
 "fix_options": [
  {
   "label": "Check permtab against peritab in the library",
   "summary": "When ordeptr->permtab-like output pointer is set, verify permtab[peritab[i]]==i.",
   "patch_sketch": "in orderCheck loop: if (permtax != NULL && permtax[peritab[vertnum]] != vertnum) error",
   "tradeoffs": "Needs access to the user's permtab from the order structure (may not be retained); small cost; behavior change for callers with inconsistent arrays.",
   "preferred": false
  },
  {
   "label": "Leave library, keep test-side check",
   "summary": "Rely on checkOrder in the test (made to exit).",
   "patch_sketch": "see BLD-04 fix",
   "tradeoffs": "No library change; users of the API get no check.",
   "preferred": true
  }
 ],
 "area": "BLD"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## GRA-25

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-25",
 "area": "GRA",
 "our_title": "Compressed ordering with an invalid block size fails after nested dissection built its tree, and leaks",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/hgraph_order_cp.c:449-454",
 "evidence": "Repro gra25.c: 12x12 grid with each vertex doubled into two twin vertices (compressible), strategy `c{rat=0.9,cpr=n{sep=m{vert=5,low=h{pass=10},asc=f{move=100}},ole=b{cmin=0,strat=s},ose=b{cmin=0,strat=s}},unc=s}` (b with cmin=0 fails after ND created its tree): 'ERROR: hgraphOrderBl: invalid minimum block size' then LeakSanitizer: 'Direct leak of 72 byte(s) ... #1 hgraphOrderNd hgraph_order_nd.c:223 #2 hgraphOrderSt hgraph_order_st.c:310 #3 hgraphOrderCp hgraph_order_cp.c:449'. With `orderExit (&coarordedat)` added on the error path: no leak, ret=1. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "hgraph_order_cp.c was touched in 7.0.17 (6a00c51) only for unsigned bit sets",
 "review_accuracy": "Accurate. The same pattern exists in hmesh_order_cp.c (not checked).",
 "fix_options": [
  {
   "label": "orderExit on the error path",
   "summary": "Release the partially built column-block tree before freeing coarperitab (orderExit does not free the externally provided peritab).",
   "patch_sketch": "--- a/src/libscotch/hgraph_order_cp.c\n+++ b/src/libscotch/hgraph_order_cp.c\n@@ -447,6 +447,7 @@\n   }\n   orderInit (&coarordedat, coargrafdat.s.baseval, coargrafdat.vnohnbr, coarperitab); /* Build ordering of compressed subgraph */\n   if (hgraphOrderSt (&coargrafdat, &coarordedat, 0, &coarordedat.rootdat, paraptr->stratcpr) != 0) {\n+    orderExit  (&coarordedat);                    /* Free (partial) column block tree; peritab is not freed as it was provided */\n     memFree    (coarperitab);\n     hgraphExit (&coargrafdat);\n     memFree    (finecoartax + finegrafptr->s.baseval);\n",
   "tradeoffs": "Matches the success path, which already calls orderExit (&coarordedat) at hgraph_order_cp.c:496 after unlinking the subtree.",
   "preferred": true
  },
  {
   "label": "Free only the tree",
   "summary": "Call a tree-only helper (orderExit2 style) on coarordedat.rootdat.cblktab.",
   "patch_sketch": "if (coarordedat.rootdat.cblktab != NULL) orderExit2 (...)  /* orderExit2 is static in order.c */",
   "tradeoffs": "Would need exposing a helper; orderExit also destroys the mutex created by orderInit, which is the right thing.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-22",
 "area": "GRA",
 "our_title": "Block ordering reads vertex loads directly through the permutation instead of its inverse, skewing the blocks",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/hgraph_order_bl.c:132, 161-164",
 "evidence": "Repro gra22.c: 20x20 grid with vertex weights 1+i, ordering strategy `b{cmin=1200,strat=g}` (Gibbs-Poole-Stockmeyer, a non-identity permutation), then per-block weight computed through peritab: original -> 66 blocks with weights ranging 24 .. 16930 (target ~1215); patched (loads taken through the inverse permutation) -> weights 954 .. 1577. Upstream history: commit a90b1cb (7.0.11, 'Bugfix: do not get vertex loads through inverse permutation') deliberately replaced `velotax[ordeptr->peritab[vnodnum]]` by `velotax[vnodnum]` because the old code ignored ordenum and indexed a local array with original-graph numbers. So the review's suggested fix (go back through peritab) re-introduces that bug for sub-graphs; a correct fix needs a per-call inverse map (vnumtax). ADDITIONAL BUG found while testing (not in the review): hgraphOrderBl calls hgraphOrderSt (line 95) on EVERY entry, including the recursion for 'block already partitioned' (line ~205: `hgraphOrderBl (grafptr, ordeptr, ordenum, cblkptr->cblktab + cblknum, paraptr)`), so `b{...,strat=n{...}}` with a strategy that builds a tree re-runs the whole strategy on each child: `./gra22 400 'b{cmin=400,strat=n{sep=m{vert=50,low=h{pass=10},asc=f{move=100}},ole=s,ose=s}}'` never terminates (timeout 10s rc=124, also with cmin=20000). The recursion also passes the same `ordenum` and the whole-graph vnlosum/vnohnbr for every child. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "a90b1cb (7.0.11) changed the indexing from peritab to vertex order (before 7.0.16)",
 "review_accuracy": "Finding true (blocks are balanced for the wrong vertex order) but the suggested remedy is the code upstream removed; a correct fix must build vertex loads in ordering-vertex space (via vnumtax). The review missed the infinite recursion when strat builds a tree.",
 "fix_options": [
  {
   "label": "Rewrite splitting in ordering space and split run-strategy from recursion",
   "summary": "hgraphOrderBl runs the strategy once, builds lodtab[orig vertex number] from velotax/vnumtax, then a static hgraphOrderBl2 splits each leaf block using loads read through peritab[ordenum + k] and recurses over children with the proper offsets and per-block weights.",
   "patch_sketch": "--- a/src/libscotch/hgraph_order_bl.c\n+++ b/src/libscotch/hgraph_order_bl.c\n@@ -77,91 +77,78 @@\n ** - !0  : on error.\n */\n \n+static\n int\n-hgraphOrderBl (\n-Hgraph * restrict const                   grafptr,\n+hgraphOrderBl2 (\n+const Hgraph * restrict const             grafptr,\n Order * restrict const                    ordeptr,\n-const Gnum                                ordenum, /*+ Zero-based ordering number +*/\n-OrderCblk * restrict const                cblkptr, /*+ Single column-block        +*/\n+const Gnum                                ordenum, /*+ Zero-based ordering number of first column of block +*/\n+OrderCblk * restrict const                cblkptr, /*+ Column block to split                            +*/\n+const Gnum * restrict const               lodtax,  /*+ Vertex loads indexed by ordering vertex number (or NULL) +*/\n const HgraphOrderBlParam * restrict const paraptr)\n {\n   Gnum                cblknbr;                    /* Number of column blocks for splitting */\n   Gnum                cblksiz;                    /* Number of allocated column blocks     */\n \n-  if (paraptr->cblkmin <= 0) {\n-    errorPrint (\"hgraphOrderBl: invalid minimum block size\");\n-    return (1);\n-  }\n+  if (cblkptr->cblktab == NULL) {                 /* If single column block */\n+    Gnum                vnlosum;                  /* Load of the column block */\n \n-  if (hgraphOrderSt (grafptr, ordeptr, ordenum, cblkptr, paraptr->straptr) != 0) /* Perform ordering strategy */\n-    return (1);\n+    if (cblkptr->vnodnbr <= 1)                    /* If block has only one column */\n+      return (0);\n \n-  if (cblkptr->cblktab == NULL) {                 /* If single column block */\n-#ifdef SCOTCH_DEBUG_HGRAPH2\n-    if (cblkptr->vnodnbr != grafptr->vnohnbr) {\n-      errorPrint (\"hgraphOrderBl: invalid column block\");\n-      return (1);\n-    }\n-#endif /* SCOTCH_DEBUG_HGRAPH2 */\n+    if (lodtax == NULL)\n+      vnlosum = cblkptr->vnodnbr;\n+    else {\n+      Gnum                vnodnum;\n \n-    if ((cblkptr->vnodnbr <= 1) ||                /* Il block has only one column    */\n-        (grafptr->vnlosum < (2 * paraptr->cblkmin))) /* Or does not need to be split */\n+      for (vnodnum = 0, vnlosum = 0; vnodnum < cblkptr->vnodnbr; vnodnum ++)\n+        vnlosum += lodtax[ordeptr->peritab[ordenum + vnodnum]]; /* Sum loads in ordering order */\n+    }\n+    if (vnlosum < (2 * paraptr->cblkmin))         /* If block does not need to be split */\n       return (0);\n \n-    cblknbr = grafptr->vnlosum / paraptr->cblkmin; /* Get new (maximum) number of blocks */\n-    cblksiz = MIN (cblknbr, grafptr->vnohnbr);    /* No more column blocks than columns  */\n+    cblknbr = vnlosum / paraptr->cblkmin;         /* Get new (maximum) number of blocks */\n+    cblksiz = MIN (cblknbr, cblkptr->vnodnbr);    /* No more column blocks than columns */\n \n     if ((cblkptr->cblktab = (OrderCblk *) memAlloc (cblksiz * sizeof (OrderCblk))) == NULL) {\n       errorPrint (\"hgraphOrderBl: out of memory\");\n       return (1);\n     }\n \n-    if (grafptr->s.velotax == NULL) {             /* For unweighted graphs, split blocks evenly */\n+    if (lodtax == NULL) {                         /* For unweighted graphs, split blocks evenly */\n       Gnum                cblknum;\n \n       for (cblknum = 0; cblknum < cblksiz; cblknum ++) { /* No more column blocks than those allocated */\n         cblkptr->cblktab[cblknum].typeval = ORDERCBLKLEAF;\n-        cblkptr->cblktab[cblknum].vnodnbr = DATASIZE (grafptr->vnlosum, cblknbr, cblknum);\n+        cblkptr->cblktab[cblknum].vnodnbr = DATASIZE (vnlosum, cblknbr, cblknum);\n         cblkptr->cblktab[cblknum].cblknbr = 0;\n         cblkptr->cblktab[cblknum].cblktab = NULL;\n       }\n     }\n     else {\n       Gnum                vnlomax;                /* Maxumum weight to reach for this subblock      */\n-      Gnum                vnlosum;                /* Current accumulated weight                     */\n+      Gnum                vnlocur;                /* Current accumulated weight                     */\n       Gnum                vnodnum;                /* Current permuted node index                    */\n       Gnum                vnodbas;                /* Starting permuted node index for current block */\n       Gnum                cblknum;                /* Current number of column subblocks             */\n       Gnum                cblkidx;                /* Ghost column block index for even splitting    */\n \n       vnlomax =\n-      vnlosum = 0;\n+      vnlocur = 0;\n       vnodbas =\n-      vnodnum = grafptr->s.baseval;\n+      vnodnum = 0;\n       cblknum =\n       cblkidx = 0;\n       do {                                        /* Go on filling column blocks    */\n-#ifdef SCOTCH_DEBUG_HGRAPH2\n-        if (cblknum >= cblksiz) {                 /* No more column blocks than those allocated */\n-          errorPrint (\"hgraphOrderBl: internal error (1)\");\n-          return (1);\n-        }\n-#endif /* SCOTCH_DEBUG_HGRAPH2 */\n         do {                                      /* Compute bound of next subblock */\n           cblkidx ++;\n-#ifdef SCOTCH_DEBUG_HGRAPH2\n-          if (cblkidx > cblknbr) {                /* No more ghost indices than ghost column blocks */\n-            errorPrint (\"hgraphOrderBl: internal error (2)\");\n-            return (1);\n-          }\n-#endif /* SCOTCH_DEBUG_HGRAPH2 */\n-          vnlomax = DATASCAN (grafptr->vnlosum, cblknbr, cblkidx); /* Bound of next subblock      */\n-        } while (vnlomax <= vnlosum);             /* Next bound must be higher than current state */\n+          vnlomax = DATASCAN (vnlosum, cblknbr, cblkidx); /* Bound of next subblock */\n+        } while (vnlomax <= vnlocur);             /* Next bound must be higher than current state */\n \n         do {                                      /* Accumulate weights until bound is reached */\n-          vnlosum += grafptr->s.velotax[vnodnum];\n+          vnlocur += lodtax[ordeptr->peritab[ordenum + vnodnum]]; /* Get load through position in ordering */\n           vnodnum ++;\n-        } while (vnlosum < vnlomax);\n+        } while ((vnlocur < vnlomax) && (vnodnum < cblkptr->vnodnbr));\n \n         cblkptr->cblktab[cblknum].typeval = ORDERCBLKLEAF; /* Build relevant column block */\n         cblkptr->cblktab[cblknum].vnodnbr = vnodnum - vnodbas;\n@@ -169,7 +156,10 @@\n         cblkptr->cblktab[cblknum].cblktab = NULL;\n         cblknum ++;                               /* One more effective column block */\n         vnodbas = vnodnum;                        /* Reset base for next block       */\n-      } while (vnlosum < grafptr->vnlosum);       /* As long as columns remain       */\n+      } while ((vnodnum < cblkptr->vnodnbr) && (cblknum < cblksiz));\n+\n+      if (vnodnum < cblkptr->vnodnbr)             /* Rounding left some columns over: give them to last block */\n+        cblkptr->cblktab[cblknum - 1].vnodnbr += cblkptr->vnodnbr - vnodnum;\n \n       cblknbr = cblknum;                          /* Use effective number of blocks */\n     }\n@@ -185,14 +175,59 @@\n     pthread_mutex_unlock (&ordeptr->mutedat);\n #endif /* SCOTCH_PTHREAD */\n   }\n-  else {                                          /* Block already partitioned */\n+  else {                                          /* Block already partitioned: recurse WITHOUT re-running the ordering strategy */\n     Gnum                cblknum;\n+    Gnum                ordenum2;\n \n-    for (cblknum = 0; cblknum < cblkptr->cblknbr; cblknum ++) {\n-      if (hgraphOrderBl (grafptr, ordeptr, ordenum, cblkptr->cblktab + cblknum, paraptr) != 0)\n+    for (cblknum = 0, ordenum2 = ordenum; cblknum < cblkptr->cblknbr; cblknum ++) {\n+      if (hgraphOrderBl2 (grafptr, ordeptr, ordenum2, cblkptr->cblktab + cblknum, lodtax, paraptr) != 0)\n         return (1);\n+      ordenum2 += cblkptr->cblktab[cblknum].vnodnbr; /* Children are laid out consecutively in ordering order */\n     }\n   }\n \n   return (0);\n }\n+\n+int\n+hgraphOrderBl (\n+Hgraph * restrict const                   grafptr,\n+Order * restrict const                    ordeptr,\n+const Gnum                                ordenum, /*+ Zero-based ordering number +*/\n+OrderCblk * restrict const                cblkptr, /*+ Single column-block        +*/\n+const HgraphOrderBlParam * restrict const paraptr)\n+{\n+  Gnum * restrict     lodtab;                     /* Vertex loads indexed by ordering vertex number */\n+  Gnum *              lodtax;\n+  int                 o;\n+\n+  if (paraptr->cblkmin <= 0) {\n+    errorPrint (\"hgraphOrderBl: invalid minimum block size\");\n+    return (1);\n+  }\n+\n+  if (hgraphOrderSt (grafptr, ordeptr, ordenum, cblkptr, paraptr->straptr) != 0) /* Perform ordering strategy */\n+    return (1);\n+\n+  lodtab = NULL;\n+  lodtax = NULL;\n+  if (grafptr->s.velotax != NULL) {               /* If vertex loads, build them in ordering vertex number space */\n+    Gnum                vertnum;\n+    const Gnum * restrict const vnumtax = grafptr->s.vnumtax;\n+\n+    if ((lodtab = (Gnum *) memAlloc (ordeptr->vnodnbr * sizeof (Gnum))) == NULL) {\n+      errorPrint (\"hgraphOrderBl: out of memory\");\n+      return (1);\n+    }\n+    lodtax = lodtab - ordeptr->baseval;\n+    for (vertnum = grafptr->s.baseval; vertnum < grafptr->vnohnnd; vertnum ++)\n+      lodtax[(vnumtax != NULL) ? vnumtax[vertnum] : vertnum] = grafptr->s.velotax[vertnum];\n+  }\n+\n+  o = hgraphOrderBl2 (grafptr, ordeptr, ordenum, cblkptr, lodtax, paraptr);\n+\n+  if (lodtab != NULL)\n+    memFree (lodtab);\n+\n+  return (o);\n+}\n",
   "tradeoffs": "Fixes both the imbalance and the recursion. O(vnodnbr) temporary array. Block boundaries change for weighted graphs (intended). Tested with GPS ordering (weights 954..1577 vs 24..16930) and ND-tree strategy (terminates). Note ordeptr->vnodnbr is the top-level graph size (extra memory for sub-graphs).",
   "preferred": true
  },
  {
   "label": "Document/disable weighted splitting in sub-graphs",
   "summary": "Only use peritab-based loads when grafptr->s.vnumtax == NULL && ordenum == 0 (top-level graph), otherwise fall back to even splitting; fix the recursion by moving hgraphOrderSt out of the recursive entry.",
   "patch_sketch": "if (vnumtax == NULL && ordenum == 0) vnlosum += velotax[peritab[vnodnum]]; else even split;",
   "tradeoffs": "Small and safe; leaves sub-graph blocks imbalanced as today.",
   "preferred": false
  }
 ],
 "notes": "NEW-1 (hang) reported here because it was found through this finding; it is independent of vertex weights (also with unit weights if strat builds a tree).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-14",
 "area": "GRA",
 "our_title": "Graph coarsening leaves a dangling vertex array and ignores its error code after an allocation failure",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_coarsen.c:255-258 (verttax freed not reset), 370-371 (thread hash OOM), 553 and 555-566 (returns 0)",
 "evidence": "Source: graph_coarsen.c:255-258 `if (coargrafptr->verttax != NULL) memFree (coargrafptr->verttax); coarptr->retuval = 2;` leaves a dangling verttax; graphCoarsen2 only tests `if (coargrafptr->verttax == NULL) return (coarptr->retuval);` (line 555) and otherwise falls to `return (0);` ignoring retuval (also when a thread-private hash table allocation fails, line 370-371, leaving the coarse arrays unfilled). Fault injection (patched/graph_coarsen_inj.c: edgetax allocation forced to fail via env GRA14_EDGE, harness gra14.c/gra14b.c = SCOTCH_graphPart of a 40x40 grid on 1 and N threads): 'ERROR: graphCoarsen3: out of memory (1)' then 'AddressSanitizer: heap-use-after-free ... READ of size 4 ... #0 graphMatchQueueSort graph_match.c:171 #1 graphMatch graph_match.c:329 #2 graphCoarsen3' -- the caller continued with the freed coarse graph as if coarsening succeeded. With the fix (verttax = NULL after free; graphFree + return retuval when retuval != 0) the injected failure is handled as a normal 'cannot coarsen' (SCOTCH_graphPart returns 0, no sanitizer report). One of 6 multi-threaded injected runs of the FIXED version hung (rc=124); I did not root-cause it (probably an independent thread-coordination issue on the OOM path since the injection fails every call), so treat the multi-thread OOM path as not fully clean. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate; the second case (per-thread hash OOM) not reproduced by injection, source-read only.",
 "fix_options": [
  {
   "label": "NULL verttax after free and honour retuval",
   "summary": "Reset coargrafptr->verttax after the free in graphCoarsen3, and in graphCoarsen2 free the partially built coarse graph and return retuval whenever it is non-zero.",
   "patch_sketch": "--- a/src/libscotch/graph_coarsen.c\n+++ b/src/libscotch/graph_coarsen.c\n@@ -253,8 +253,10 @@\n                         &coarmulttab,          (size_t) (coarmultsiz * sizeof (GraphCoarsenMulti)), NULL) == NULL) ||\n         ((coargrafptr->edgetax = memAlloc (finegrafptr->edgenbr * 2 * sizeof (Gnum))) == NULL)) { /* \"* 2\" for edlotab */\n       errorPrint (\"graphCoarsen3: out of memory (1)\");\n-      if (coargrafptr->verttax != NULL)\n+      if (coargrafptr->verttax != NULL) {\n         memFree (coargrafptr->verttax);\n+        coargrafptr->verttax = NULL;               /* Prevent graphCoarsen2() and callers from using freed graph */\n+      }\n       coarptr->retuval = 2;\n #ifdef GRAPHCOARSENNOTHREAD\n #ifdef SCOTCH_PTHREAD\n@@ -555,6 +557,11 @@\n   if (coargrafptr->verttax == NULL)               /* If graph could not be created */\n     return (coarptr->retuval);\n \n+  if (coarptr->retuval != 0) {                    /* If an error occurred after graph creation (e.g. thread memory allocation) */\n+    graphFree (coargrafptr);                      /* Do not leave a partially built graph behind                              */\n+    return    (coarptr->retuval);\n+  }\n+\n #ifdef SCOTCH_DEBUG_GRAPH2\n   if (graphCheck (coargrafptr) != 0) {            /* Check graph consistency */\n     errorPrint (\"graphCoarsen2: inconsistent graph data\");\n",
   "tradeoffs": "Small, local; callers already handle return value 2. Needs fault-injection tests (memAlloc failure) and a look at the multi-thread unwinding.",
   "preferred": true
  },
  {
   "label": "Make graphCoarsen3 OOM paths symmetric across threads",
   "summary": "Record the error in coarptr->retuval and always run to the end-of-routine barrier in all builds (not only NOTHREAD) before returning; clear coargrafptr entirely (memSet) on failure so callers cannot use it.",
   "patch_sketch": "in each error branch: coarptr->retuval = 2; graphFree-like cleanup under thread 0 after the final barrier; memSet (coargrafptr, 0, sizeof (Graph))",
   "tradeoffs": "More invasive, but also addresses the thread-synchronisation question; needs careful testing.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-27

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-27",
 "area": "GRA",
 "our_title": "Internal graph dump prints one name for the edge-load array and uses another in the generated C",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/graph_dump.c:131",
 "evidence": "Harness gra27.c calling the internal graphDump () on a 3-vertex graph with edge loads prints `Gnum myedlotab_x[] = {` (line 9) but later `grafptr->edlotax = mydelotab_x - 0;` (line 26). Only the internal graphDump/hgraphDump (graph_dump.c / hgraph_dump.c, no non-debug callers) are affected: the public SCOTCH_graphDump (library_graph_dump.c, used by gdump) builds its own text and uses edlotab correctly (verified with gdump on an edge-weighted graph). Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate for graphDump2; but the review's wording 'dumped code ... does not compile' only applies to the internal graphDump(), not to SCOTCH_graphDump/gdump.",
 "fix_options": [
  {
   "label": "Fix the typo",
   "summary": "delotab -> edlotab.",
   "patch_sketch": "-                   \"  %sedlotax = %sdelotab%s - \" GNUMSTRING \";\\n\",\n+                   \"  %sedlotax = %sedlotab%s - \" GNUMSTRING \";\\n\",",
   "tradeoffs": "None.",
   "preferred": true
  },
  {
   "label": "Share one code generator",
   "summary": "Make the internal graphDump delegate to the library SCOTCH_graphDump text generation (single source of truth).",
   "patch_sketch": "graphDump -> reuse library_graph_dump.c emission code",
   "tradeoffs": "Larger refactor for a debug helper.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)
