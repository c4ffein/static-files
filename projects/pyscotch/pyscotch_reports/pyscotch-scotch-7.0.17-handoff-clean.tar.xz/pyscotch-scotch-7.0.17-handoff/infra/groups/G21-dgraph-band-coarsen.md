# G21-dgraph-band-coarsen

Items: DGR-07, DGR-09, DGR-17, API-17, API-20, PS-DGR-5, DGR-13, PS-DGR-1, API-15



===================================================================
## DGR-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-07",
 "area": "DGR",
 "our_title": "Point-to-point band/grow failure frees caller-owned base-shifted array; no NULL guard",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_band_grow.c:389-400 (Ptop error path, free at l.398); callers dgraph_band.c:164-167, library_dgraph_band.c:150-154, library_dgraph_grow.c:131-132",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nPtop is selected when the ghost-exchange graph is sparse (dgraph_ghst.c:299-303; ring/path graph on np=8). Reproducer fiint.c modes band/grow (SCOTCH_dgraphBand / SCOTCH_dgraphGrow on a path graph, 4 vertices/rank, np=8, failure on rank 3):\n`LIBDIR=../fi/lib ./scan2.sh band 8 3 1 4 3 5` (baseval 1): nth=4 -> `(3): ERROR: dgraphBand2Ptop: out of memory (1)` + `ERROR: AddressSanitizer: attempting free on address which was not malloc()-ed: 0x504000048a0c ... #1 _SCOTCHdgraphBand2Ptop dgraph_band_grow.c:398 #2 SCOTCH_dgraphBand library_dgraph_band.c:150`. baseval 0: `attempting double-free ... freed by ... dgraphBand2Ptop dgraph_band_grow.c:398` (second free in SCOTCH_dgraphBand library_dgraph_band.c:153). nth=3 (the caller's own bandvnumgsttax alloc fails and vnumgsttax==NULL is passed down): `SEGV ... dgraphBand2Ptop dgraph_band_grow.c:439` (no NULL guard; Coll has `(vnumgsttax == NULL) ||` at dgraph_band_grow.c:132). `./scan2.sh grow 8 3 0 4 1 3`: `(3): ERROR: dgraphGrow2Ptop: out of memory (1)` + `attempting double-free` (baseval 1: `attempting free on address which was not malloc()-ed`) - the library freed the USER's partgsttab (SCOTCH_dgraphGrow passes `partgsttab - baseval` as vnumgsttax, library_dgraph_grow.c:129) and the harness' own free() then double-frees it. The same bug is reached through the internal dgraphBand (dgraph_band.c:164-167, `./scan2.sh bandint 8 3 0 4 0 7`: double-free at dgraph_band.c:167).",
 "upstream_change": "",
 "review_accuracy": "Accurate (caller double free for band, user array freed for SCOTCH_dgraphGrow, missing NULL guard in Ptop vs Coll). The review does not mention that for baseval != 0 the freed pointer is also not the malloc'ed address (invalid free rather than double free).",
 "fix_options": [
  {
   "label": "Make Ptop mirror Coll: no free of vnumgsttax, NULL guard (tested)",
   "summary": "In dgraphBand2Ptop/dgraphGrow2Ptop initialise procvgbtab=NULL, fold `vnumgsttax == NULL` into the allocation test and free only the group leader on error; vnumgsttax belongs to the caller (Coll already does exactly this, dgraph_band_grow.c:131-132,142,160).",
   "patch_sketch": "--- a/src/libscotch/dgraph_band_grow.c\n+++ b/src/libscotch/dgraph_band_grow.c\n@@ -366,7 +366,9 @@\n \n   vrcvdatsiz = DGRAPHBANDGROWSMUL (grafptr->procsndnbr); /* Senders and receivers inverted because we send local, not halo vertices */\n   vsnddatsiz = DGRAPHBANDGROWSMUL (grafptr->vertgstnbr - grafptr->vertlocnbr);\n-  if (memAllocGroup ((void **) (void *)\n+  procvgbtab = NULL;                              /* In case of error */\n+  if ((vnumgsttax == NULL) ||\n+      (memAllocGroup ((void **) (void *)\n                      &procvgbtab, (size_t) ((procngbnbr + 1) * sizeof (Gnum)),\n                      &nrcvdsptab, (size_t) ((procngbnbr + 1) * sizeof (Gnum)), /* +1 to check against end of array */\n                      &nsnddsptab, (size_t) ((procngbnbr + 1) * sizeof (Gnum)), /* +1 to check against end of array */\n@@ -374,7 +376,7 @@\n                      &nrcvreqtab, (size_t) (procngbnbr       * sizeof (MPI_Request)),\n                      &nsndreqtab, (size_t) (procngbnbr       * sizeof (MPI_Request)),\n                      &vrcvdattab, (size_t) (vrcvdatsiz       * sizeof (Gnum)),\n-                     &vsnddattab, (size_t) (vsnddatsiz       * sizeof (Gnum)), NULL) == NULL) {\n+                     &vsnddattab, (size_t) (vsnddatsiz       * sizeof (Gnum)), NULL) == NULL)) {\n     errorPrint (DGRAPHBANDGROWNSTR \"Ptop: out of memory (1)\");\n     reduglbtab[0] = 1;\n   }\n@@ -392,11 +394,8 @@\n   }\n #endif /* SCOTCH_DEBUG_DGRAPH1 */\n   if (reduglbtab[0] != 0) {\n-    if (vnumgsttax != NULL) {\n-      if (procvgbtab != NULL)\n-        memFree (procvgbtab);                     /* Free group leader */\n-      memFree (vnumgsttax);\n-    }\n+    if (procvgbtab != NULL)\n+      memFree (procvgbtab);                       /* Free group leader; vnumgsttax belongs to the caller */\n     return (1);\n   }\n \n",
   "tradeoffs": "No ABI change (internal routines). Verified (np=8 path graph, baseval 0 and 1): band and grow no longer trigger any ASan error and the failing rank returns 1; other ranks still hang because in non-debug builds the Ptop error is not propagated (reduglbtab is only reduced under SCOTCH_DEBUG_DGRAPH1) - separate DGR-13-class problem.",
   "preferred": true
  },
  {
   "label": "Callee owns the array",
   "summary": "Keep the free in the callee for both variants and remove it from the callers; for SCOTCH_dgraphGrow allocate an internal work array and copy to the user's partgsttab on success.",
   "patch_sketch": "/* Coll+Ptop: free (vnumgsttax + baseval) on error */\n/* dgraphBand, SCOTCH_dgraphBand: drop memFree (bandvnumgsttax + baseval) after a failed call */\n/* SCOTCH_dgraphGrow: allocate gsttax copy */",
   "tradeoffs": "Changes ownership convention for every caller (4 call sites) and costs a copy in Grow; much larger blast radius. Not implemented.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: Coll variant and all callers already follow 'caller frees vnumgsttax' - Ptop is the odd one out. Also note SCOTCH_dgraphGrow returns early on dgraphGhst failure without CONTEXTEXIT (library_dgraph_grow.c:119-122) - out of scope.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-09",
 "area": "DGR",
 "our_title": "Band builder error path: NULL store, uninitialised free, undersized scratch, free after base reset",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_band.c:156 (scratch size), 175-257 (error paths; NULL store l.224, wrong base l.233/256, uninit bandfronloctab l.231); same defects in library_dgraph_band.c:139,201-214,226-232",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nAll four sub-claims reproduced with the internal dgraphBand (fiint.c mode bandint, np=2, path graph, failure on rank 1, `./scan2.sh bandint 2 1 BASE 4 2 6`) and with a 64-bit-Gnum build (-DINTSIZE64, work/DGR/fi64, `mpirun -np 8 ./fiint64 bandint 3 N 0 1`):\n(a) first group allocation fails (nth=2): `dgraph_band.c:224:32: runtime error: store to null pointer of type 'Gnum'` -> SEGV (`bandgrafptr->procdsptab[0] = -1;` with procdsptab NULL).\n(b) later failures, baseval 1 (nth=3..6): `ERROR: AddressSanitizer: attempting free on address which was not malloc()-ed ... #1 _SCOTCHdgraphBand dgraph_band.c:256` = `memFree (bandvnumgsttax + bandgrafptr->baseval)` after dgraphFree() reset baseval to 0 (l.233 has the same pattern).\n(c) uninitialised bandfronloctab: the object compiled with -ftrivial-auto-var-init=pattern (pat/patband.so preloaded) makes `if (bandfronloctab != NULL) memFree (bandfronloctab);` free 0xFEFE...: `ERROR: AddressSanitizer: BUS ... bp 0xfefefefefefefeee ... free asan_malloc_linux.cpp:53` on 'out of memory (3)'. (bandfronloctab is only assigned in the last else branch, l.214.)\n(d) 64-bit overflow (nth=3..6): `ERROR: AddressSanitizer: heap-buffer-overflow ... WRITE of size 32 ... 0 bytes after 40-byte region` raised inside MPI_Allgather unpack: buffer is `MAX (vertgstnbr * sizeof (Gnum), procglbnbr * sizeof (int))` (l.156) = 40 bytes but the dummy Allgather writes procglbnbr * sizeof (Gnum) = 64 bytes. With 32-bit Gnum the two sizes coincide, so this one only exists in INTSIZE64 builds.\nThe public SCOTCH_dgraphBand (library_dgraph_band.c) is a copy-paste of the same code: `./scan2.sh band 8 3 0 4 3 5` nth=5 -> `library_dgraph_band.c:201:32: runtime error: store to null pointer`.",
 "upstream_change": "",
 "review_accuracy": "Accurate on all four. Details: the NULL store is at l.224 in 7.0.17 (review: 138); the review's 'initialise work pointers to NULL' is needed for bandfronloctab only (bandpartgsttax is only freed on a path where it was allocated). The review does not mention that the identical code lives in library_dgraph_band.c (SCOTCH_dgraphBand) and needs the same four fixes; its fix 'free with grafptr->baseval' is right.",
 "fix_options": [
  {
   "label": "Local fixes in both copies (tested)",
   "summary": "(1) bandfronloctab = bandpartgsttax = NULL before the allocations; (2) send a local `Gnum dummval = -1` instead of writing procdsptab[0]; (3) size the scratch buffer as MAX (vertgstnbr, procglbnbr) * sizeof (Gnum); (4) free bandvnumgsttax with grafptr->baseval (bandgrafptr is reset by dgraphFree/dgraphExit). Apply to dgraph_band.c and library_dgraph_band.c.",
   "patch_sketch": "--- a/src/libscotch/dgraph_band.c\n+++ b/src/libscotch/dgraph_band.c\n@@ -153,7 +153,9 @@\n   }\n \n   cheklocval = 0;\n-  bandvnumgstsiz = MAX ((grafptr->vertgstnbr * sizeof (Gnum)), (grafptr->procglbnbr * sizeof (int))); /* TRICK: re-use array for further error collective communications */\n+  bandfronloctab = NULL;                          /* In case of error */\n+  bandpartgsttax = NULL;\n+  bandvnumgstsiz = MAX (grafptr->vertgstnbr, grafptr->procglbnbr) * sizeof (Gnum); /* TRICK: re-use array for further error collective communications, which exchange Gnum's */\n  if ((bandvnumgsttax = memAlloc (bandvnumgstsiz)) == NULL) /* Error will be propagated by dgraphBand2*() */\n     errorPrint (\"dgraphBand: out of memory (1)\");\n  else {\n@@ -221,16 +223,18 @@\n   }\n \n   if (cheklocval != 0) {                          /* In case of memory error */\n-    bandgrafptr->procdsptab[0] = -1;\n-    if (MPI_Allgather (&bandgrafptr->procdsptab[0], 1, GNUM_MPI, /* Send received data to dummy array */\n-                       bandvnumgsttax + bandgrafptr->baseval, 1, GNUM_MPI, grafptr->proccomm) != MPI_SUCCESS) {\n+    Gnum                dummval;                  /* Local error flag; procdsptab may not have been allocated */\n+\n+    dummval = -1;\n+    if (MPI_Allgather (&dummval, 1, GNUM_MPI,     /* Send received data to dummy array */\n+                       bandvnumgsttax + grafptr->baseval, 1, GNUM_MPI, grafptr->proccomm) != MPI_SUCCESS) {\n       errorPrint (\"dgraphBand: communication error (1)\");\n       return (1);\n     }\n     if (bandfronloctab != NULL)\n       memFree (bandfronloctab);\n     dgraphFree (bandgrafptr);\n-    memFree    (bandvnumgsttax + bandgrafptr->baseval);\n+    memFree    (bandvnumgsttax + grafptr->baseval); /* Use original graph base value as band graph structure has just been reset */\n     return (1);\n   }\n   else {\n@@ -253,7 +257,7 @@\n       if (bandfronloctab != NULL)\n         memFree (bandfronloctab);\n       dgraphFree (bandgrafptr);\n-      memFree    (bandvnumgsttax + bandgrafptr->baseval);\n+      memFree    (bandvnumgsttax + grafptr->baseval); /* Use original graph base value as band graph structure has just been reset */\n       return (1);\n     }\n     bandgrafptr->procdsptab[procngbnum]    += bandgrafptr->procdsptab[procngbnum - 1];\n--- a/src/libscotch/library_dgraph_band.c\n+++ b/src/libscotch/library_dgraph_band.c\n@@ -139,7 +139,7 @@\n   }\n \n   cheklocval = 0;\n-  bandvnumgstsiz = MAX ((grafptr->vertgstnbr * sizeof (Gnum)), (grafptr->procglbnbr * sizeof (int))); /* TRICK: re-use array for further error collective communications */\n+  bandvnumgstsiz = MAX (grafptr->vertgstnbr, grafptr->procglbnbr) * sizeof (Gnum); /* TRICK: re-use array for further error collective communications, which exchange Gnum's */\n   if ((bandvnumgsttax = memAlloc (bandvnumgstsiz)) == NULL)\n     errorPrint (STRINGIFY (SCOTCH_dgraphBand) \": out of memory (1)\"); /* Error will be propagated by dgraphBand2*() */\n   else {\n@@ -198,14 +198,16 @@\n   }\n \n   if (cheklocval != 0) {                          /* In case of memory error */\n-    bandgrafptr->procdsptab[0] = -1;\n-    if (MPI_Allgather (&bandgrafptr->procdsptab[0], 1, GNUM_MPI, /* Send received data to dummy array */\n-                       bandvnumgsttax + bandgrafptr->baseval, 1, GNUM_MPI, grafptr->proccomm) != MPI_SUCCESS) {\n+    Gnum                dummval;                  /* Local error flag; procdsptab may not have been allocated */\n+\n+    dummval = -1;\n+    if (MPI_Allgather (&dummval, 1, GNUM_MPI,     /* Send received data to dummy array */\n+                       bandvnumgsttax + grafptr->baseval, 1, GNUM_MPI, grafptr->proccomm) != MPI_SUCCESS) {\n       errorPrint (STRINGIFY (SCOTCH_dgraphBand) \": communication error (2)\");\n       goto fail;\n     }\n     dgraphExit (bandgrafptr);\n-    memFree    (bandvnumgsttax + bandgrafptr->baseval);\n+    memFree    (bandvnumgsttax + grafptr->baseval); /* Use original graph base value as band graph structure has been reset */\n     goto fail;\n   }\n   else {\n@@ -224,7 +226,7 @@\n   for (procngbnum = 1; procngbnum <= grafptr->procglbnbr; procngbnum ++) { /* Process potential error flags from other processes */\n     if (bandgrafptr->procdsptab[procngbnum] < 0) { /* If error notified by another process                                       */\n       dgraphExit (bandgrafptr);\n-      memFree    (bandvnumgsttax + bandgrafptr->baseval);\n+      memFree    (bandvnumgsttax + grafptr->baseval); /* Use original graph base value as band graph structure has been reset */\n       goto fail;\n     }\n     bandgrafptr->procdsptab[procngbnum]    += bandgrafptr->procdsptab[procngbnum - 1];\n",
   "tradeoffs": "No behaviour change on success. Verified 32-bit (np=2, base 0/1, nth=2..6: rc=1 on both ranks, no ASan; pattern-init build shows no bad free) and 64-bit (np=8: no overflow/NULL/double free for nth=0..6). Remaining HANGs for nth=0,1,7 are non-collective error handling inside Band2/HaloSync (DGR-13 family).",
   "preferred": true
  },
  {
   "label": "Remove the duplicated code: make SCOTCH_dgraphBand call dgraphBand",
   "summary": "library_dgraph_band.c re-implements dgraphBand (differences: vlbl/vnum arrays). Factor the shared error handling (and the dummy-Allgather buffer) into one static helper used by both.",
   "patch_sketch": "static int dgraphBandErr (Dgraph * grafptr, Gnum * bandvnumgsttax /* based */, Dgraph * bandgrafptr);  /* sends -1 via a local variable, frees with grafptr->baseval */",
   "tradeoffs": "Prevents the defects from diverging again, but a bigger refactoring of a 300-line routine that upstream keeps separate on purpose (public API variant has vertex labels). Not implemented.",
   "preferred": false
  },
  {
   "label": "Allocate the dummy Allgather buffer from the private group",
   "summary": "Add `procglbnbr * sizeof (Gnum)` to the first memAllocGroup (bandgrafptr->proccnttab already has that size) and gather into it, removing the TRICK of re-using bandvnumgsttax.",
   "patch_sketch": "MPI_Allgather (&dummval, 1, GNUM_MPI, bandgrafptr->proccnttab, 1, GNUM_MPI, comm);  /* only valid if the first group succeeded */",
   "tradeoffs": "Fails when the first group itself failed (needs a fallback buffer anyway); not better than option 1.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: the 'TRICK: re-use array for further error collective communications' comment shows intent to avoid extra allocations, so the minimal sizing/NULL/base fixes (option 1) are in the existing style. Same four patterns also exist in library_dgraph_band.c (reported separately by the public-API review).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-17",
 "area": "DGR",
 "our_title": "Collective grow debug bound omits doubled slot size, falsely failing debug builds",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_band_grow.c:236-239 (SCOTCH_DEBUG_DGRAPH2 block in the Coll variant)",
 "evidence": "Source l.239: `(nsndidxtab[procngbnum] >= (vsnddsptab[grafptr->procngbtab[procngbnum]] + grafptr->procrcvtab[grafptr->procngbtab[procngbnum]]))` but the send area of the grow variant is DGRAPHBANDGROWSMUL (procrcvtab[...]) = 2 * procrcvtab (vsnddsptab is built with the multiplier at l.173-175; the Ptop check at l.499 uses nsnddsptab[procngbnum+1], which includes it).\nReproducer growring.c (mine): ring of 8+8 vertices on np=2 (Coll is selected: dgraph_ghst.c:299-303), seeds at both ends of each rank, SCOTCH_dgraphGrow(distance 3). Release lib: `r0 grow rc=0`, `r1 grow rc=0`. With library_dgraph_grow.c recompiled with -DSCOTCH_DEBUG_DGRAPH2 and preloaded (pat/dbggrow.so): `(0): ERROR: dgraphGrow2Coll: internal error (1)` on both ranks, `grow rc=1`.",
 "upstream_change": "",
 "review_accuracy": "Accurate (debug-only false positive once more than half the ghost slots of a neighbour are used; it needs >= 2 ghost vertices towards one neighbour).",
 "fix_options": [
  {
   "label": "Apply DGRAPHBANDGROWSMUL in the bound (tested)",
   "summary": "Compare against vsnddsptab[...] + DGRAPHBANDGROWSMUL (procrcvtab[...]).",
   "patch_sketch": "--- a/src/libscotch/dgraph_band_grow.c\n+++ b/src/libscotch/dgraph_band_grow.c\n@@ -236,7 +236,7 @@\n #ifdef SCOTCH_DEBUG_DGRAPH2\n           if ((grafptr->procvrttab[grafptr->procngbtab[procngbnum]]     >  vertglbend) ||\n               (grafptr->procvrttab[grafptr->procngbtab[procngbnum] + 1] <= vertglbend) ||\n-              (nsndidxtab[procngbnum] >= (vsnddsptab[grafptr->procngbtab[procngbnum]] + grafptr->procrcvtab[grafptr->procngbtab[procngbnum]]))) {\n+              (nsndidxtab[procngbnum] >= (vsnddsptab[grafptr->procngbtab[procngbnum]] + DGRAPHBANDGROWSMUL (grafptr->procrcvtab[grafptr->procngbtab[procngbnum]])))) {\n             errorPrint (DGRAPHBANDGROWNSTR \"Coll: internal error (1)\");\n             return (1);\n           }\n",
   "tradeoffs": "Debug-build only; verified rc=0 for the same debug-instrumented run.",
   "preferred": true
  },
  {
   "label": "Use the next displacement as bound like the Ptop variant",
   "summary": "`nsndidxtab[procngbnum] >= vsnddsptab[procglbnum + 1]` is not valid for non-contiguous procglbnum; build a per-neighbour end array (nsnddsptab[procngbnum + 1]) as Ptop does.",
   "patch_sketch": "/* in the displacement loop (l.172-180) also record vsndendtab[procngbnum] = vsnddspnum; test nsndidxtab[procngbnum] >= vsndendtab[procngbnum] */",
   "tradeoffs": "Makes the check independent of SMUL (symmetry with Ptop) at the price of one more small array; not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: the Ptop twin of this assertion already accounts for the multiplier.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## API-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-17",
 "area": "API",
 "our_title": "Distributed band extraction writes through NULL array and sizes Gnum gather buffer with int size",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Force memAllocGroup (procdsptab group) to fail on one rank of a multi-rank run and watch for the NULL write under ASan.",
 "location": "src/libscotch/library_dgraph_band.c:142 (bandvnumgstsiz uses sizeof (int)), 200-203 (procdsptab[0] = -1 when memAllocGroup failed), 240-250 (halo-exchange failure returns without freeing)",
 "evidence": "Unchanged vs 7.0.16. Quoted 7.0.17: 'bandvnumgstsiz = MAX ((grafptr->vertgstnbr * sizeof (Gnum)), (grafptr->procglbnbr * sizeof (int)));' ... 'if (cheklocval != 0) { bandgrafptr->procdsptab[0] = -1; if (MPI_Allgather (&bandgrafptr->procdsptab[0], 1, GNUM_MPI, bandvnumgsttax + bandgrafptr->baseval, 1, GNUM_MPI, ...' - procdsptab is the first member of the memAllocGroup that just failed (NULL), and the Allgather receives procglbnbr GNUM values (8 bytes each with INTSIZE64) into a buffer sized for max(vertgstnbr*sizeof(Gnum), procglbnbr*4). Not runtime-reproduced: needs allocation-failure injection plus >2 ranks with tiny local graphs. Compiled the patch against the 64-bit PT build only.",
 "upstream_change": "",
 "review_accuracy": "accurate. Detail: on the error path dgraphExit(bandgrafptr) is also called on a Dgraph whose arrays are partly NULL; and 'goto fail' after the dgraphHaloSync failure leaks bandvnumgsttax and the band arrays.",
 "fix_options": [
  {
   "label": "Local Gnum error flag and Gnum-sized scratch",
   "summary": "Send a stack Gnum (-1) instead of procdsptab[0]; size scratch with sizeof (Gnum).",
   "patch_sketch": "--- library_dgraph_band.c\n+++ library_dgraph_band.c\n@@ -139,7 +139,7 @@\n   }\n \n   cheklocval = 0;\n-  bandvnumgstsiz = MAX ((grafptr->vertgstnbr * sizeof (Gnum)), (grafptr->procglbnbr * sizeof (int))); /* TRICK: re-use array for further error collective communications */\n+  bandvnumgstsiz = MAX ((grafptr->vertgstnbr * sizeof (Gnum)), (grafptr->procglbnbr * sizeof (Gnum))); /* TRICK: re-use array for further error collective communications of Gnum values */\n   if ((bandvnumgsttax = memAlloc (bandvnumgstsiz)) == NULL)\n     errorPrint (STRINGIFY (SCOTCH_dgraphBand) \": out of memory (1)\"); /* Error will be propagated by dgraphBand2*() */\n   else {\n@@ -198,8 +198,10 @@\n   }\n \n   if (cheklocval != 0) {                          /* In case of memory error */\n-    bandgrafptr->procdsptab[0] = -1;\n-    if (MPI_Allgather (&bandgrafptr->procdsptab[0], 1, GNUM_MPI, /* Send received data to dummy array */\n+    Gnum                bandvertlocerr;           /* Error flag; procdsptab may be NULL here */\n+\n+    bandvertlocerr = -1;\n+    if (MPI_Allgather (&bandvertlocerr, 1, GNUM_MPI, /* Send received data to dummy array */\n                        bandvnumgsttax + bandgrafptr->baseval, 1, GNUM_MPI, grafptr->proccomm) != MPI_SUCCESS) {\n       errorPrint (STRINGIFY (SCOTCH_dgraphBand) \": communication error (2)\");\n       goto fail;\n",
   "tradeoffs": "Minimal; fixes NULL write and receive overflow. Not exercised (needs fault injection); compiles in the 64-bit PT build. The halo-sync leak still needs a free on that path.",
   "preferred": true
  },
  {
   "label": "Collective error check with MPI_Allreduce on an int, as dgraphBand2*() do",
   "summary": "Replace the Allgather-based error protocol by cheklocval reduction (MPI_MAX on int) before using procdsptab, then allocate.",
   "patch_sketch": "int chekglbval; MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, grafptr->proccomm);",
   "tradeoffs": "Uses the idiom of the rest of the PT-Scotch code (dgraphBand2Coll error reduction) and drops the 'TRICK: re-use array', but restructures the function and costs one more collective.",
   "preferred": false
  }
 ],
 "notes": "Internal dgraph_band.c has a separate copy of the same pattern (review says so); not checked here.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-20",
 "area": "API",
 "our_title": "Distributed grow returns early on ghost-edge failure, skipping temporary context teardown",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Force the ghost-edge array allocation in dgraphGhst to fail and check the leaked context with LeakSanitizer.",
 "location": "src/libscotch/library_dgraph_grow.c:116 (message says SCOTCH_dgraphBand), 123-127 (return (1) skips CONTEXTEXIT)",
 "evidence": "Unchanged. 7.0.17: 'errorPrint (STRINGIFY (SCOTCH_dgraphBand) \": cannot initialize context\");' and, after 'if (dgraphGhst (&grafdat) != 0) { errorPrint (...); return (1); }', the label 'fail: CONTEXTEXIT (orggrafptr)' is skipped. Needs dgraphGhst failure (alloc/MPI fault injection) to observe; patch compiled in the 64-bit PT build.",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "goto fail + fix label",
   "summary": "'goto fail' in the ghost-edge error branch; use STRINGIFY (SCOTCH_dgraphGrow) in the context message.",
   "patch_sketch": "--- library_dgraph_grow.c\n+++ library_dgraph_grow.c\n@@ -114,7 +114,7 @@\n   o = 1;                                          /* Assume an error */\n \n   if (CONTEXTINIT (orggrafptr)) {\n-    errorPrint (STRINGIFY (SCOTCH_dgraphBand) \": cannot initialize context\");\n+    errorPrint (STRINGIFY (SCOTCH_dgraphGrow) \": cannot initialize context\");\n     goto fail;\n   }\n \n@@ -123,7 +123,7 @@\n \n   if (dgraphGhst (&grafdat) != 0) {               /* Compute ghost edge array if not already present */\n     errorPrint (STRINGIFY (SCOTCH_dgraphGrow) \": cannot compute ghost edge array\");\n-    return (1);\n+    goto fail;\n   }\n \n   bandpartgsttax = (partgsttab != NULL) ? (Gnum *) partgsttab - grafdat.baseval : NULL;\n",
   "tradeoffs": "Minimal; same idiom as the first branch of the function. If dgraphGhst can leave partial arrays in grafdat (shallow clone), also call dgraphExit (&grafdat) before 'goto fail' - I did not verify dgraphGhst's cleanup on failure.",
   "preferred": true
  },
  {
   "label": "Single exit via an 'o' ladder",
   "summary": "Restructure into one exit that always runs 'dgraphExit (&grafdat); CONTEXTEXIT (...)' (like SCOTCH_dgraphBand).",
   "patch_sketch": "fail:\n  dgraphExit (&grafdat); CONTEXTEXIT (orggrafptr); return (o);",
   "tradeoffs": "Safer against partial state but must initialise grafdat before first goto (it is currently assigned after CONTEXTINIT); larger diff.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## PS-DGR-5

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DGR-5",
 "our_title": "SCOTCH_dgraphGrow returns on ghost-array failure without releasing its context",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/library_dgraph_grow.c:~119-123",
 "evidence": "After CONTEXTINIT succeeds, `if (dgraphGhst (&grafdat) != 0) { errorPrint (...); return (1); }` bypasses the fail: label that calls CONTEXTEXIT. Read only.",
 "related_review_ids": [
  "DGR-07"
 ],
 "fix_options": [
  {
   "label": "goto fail",
   "summary": "Use the existing fail label.",
   "patch_sketch": "-    return (1);\n+    goto fail;",
   "tradeoffs": "Trivial; o is already 1.",
   "preferred": true
  },
  {
   "label": "Compute ghost array before CONTEXTINIT",
   "summary": "Reorder so no context exists yet.",
   "patch_sketch": "/* reorder */",
   "tradeoffs": "Alters cloned-graph handling. Not compiled.",
   "preferred": false
  }
 ],
 "area": "DGR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-13",
 "area": "DGR",
 "our_title": "Coarsening/matching allocation failures return before peers' collectives, hanging job",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_coarsen.c:606 (BuildSeq coarhashtab), 727 (BuildThr), 883-886 (thrdtab, \"TODO: cleaner exit\"), 1251-1254 (BuildThr result); dgraph_match_sync_coll.c:121-124",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nSCOTCH_dgraphCoarsen on a ring graph (np=2, 8 vertices/rank, failure on rank 1), `LIBDIR=../fi/lib ./scan2.sh coarsen 2 1 0 8 4 30`:\n- nth=7..11: `(1): ERROR: dgraphMatchSyncColl: out of memory` + `dgraphCoarsen: cannot perform matching`, `r1 rc=2`, rank 0 HANG (inside MPI_Alltoall(v) of the same pass).\n- nth=12: `dgraphCoarsenBuild: out of memory (1)` (the `thrdtab` allocation with the 'TODO: cleaner exit' comment, l.883-886) -> HANG; nth=13 `cannot propagate multinode indices` (dgraphHaloSync2 OOM) -> HANG; nth=14..17 `dgraphCoarsenBuild: out of memory (2)` -> HANG; nth=18..25 `dgraphCoarsenBuild: could not compute adjacency (1)` + `dgraphCoarsenBuildThr: out of memory` (l.727/1251-1254) -> HANG (in some, also `dgraph_coarsen.c:658:23: runtime error: signed integer overflow` on uninitialised data).\nSource confirms the return-before-collective pattern at all four cited sites: dgraph_coarsen.c:604-607 `if ((coarhashtab = memAlloc (coarhashsiz)) == NULL) { errorPrint ('dgraphCoarsenBuildSeq: out of memory'); return (1); }`; l.883-886 `if ((coarptr->thrdtab = memAlloc (thrdnbr * sizeof (DgraphCoarsenThread))) == NULL) { errorPrint ('dgraphCoarsenBuild: out of memory (1)'); return (1); /* TODO: cleaner exit */ }`; l.1251-1254 `if (coarptr->thrdtab[0].retuval != 0) { errorPrint ('dgraphCoarsenBuild: could not compute adjacency (1)'); return (1); }`; dgraph_match_sync_coll.c:121-124 `if ((vsnddsptab = memAlloc (4 * grafptr->procglbnbr * sizeof (int))) == NULL) { errorPrint ('dgraphMatchSyncColl: out of memory'); return (1); }`. Only dgraphCoarsenInit/dgraphMatchInit errors are handled collectively (dgraphCoarsen l.1359-1370: `thrdlocmin = (cheklocval != 0) ? -1 : contextThreadNbr (contptr)` + MPI_Allreduce(MIN)); nth=5 (`dgraphMatchInit: out of memory`) -> both ranks rc=2, no hang.\nAdditional crash found on the way (not in the review): when dgraphCoarsenInit fails, dgraphCoarsen still calls `dgraphMatchInit` (`cheklocval |= dgraphMatchInit (&matedat, 0.5F)`, l.1360) which dereferences the NULL coargsttax: nth=3,4,5 on the original lib -> `ERROR: AddressSanitizer: SEGV ... dgraph_match.c:93:31: runtime error: member access within null pointer`.",
 "upstream_change": "",
 "review_accuracy": "Accurate. The review's proposed fix ('join the next collective with an error marker as dgraphGhst/dgraphFold do') matches the in-repo idiom but note dgraphFold only does so in SCOTCH_DEBUG_DGRAPH1 builds (see DGR-01) and dgraphGhst's Ptop/Coll peers are not joined in release mode either. The review's list is not exhaustive (dgraphMatchSyncPtop, dgraphCoarsenBuildColl/Ptop allocations behave the same; the dgraphMatchInit-after-failed-CoarsenInit crash above).",
 "fix_options": [
  {
   "label": "Hoist the small work allocations into the Init functions, whose errors are already agreed on (tested for MatchSyncColl)",
   "summary": "dgraphCoarsen already makes dgraphCoarsenInit/dgraphMatchInit failures collective via the 'negative thread count' MPI_Allreduce(MIN). Move the 4*P-int scratch of dgraphMatchSyncColl into dgraphMatchInit's memAllocGroup (new DgraphMatchData field syncdsptab) and, likewise, thrdtab/coarhashtab of the build step into dgraphCoarsenInit (thread count is known there via contextThreadNbr).",
   "patch_sketch": "--- a/src/libscotch/dgraph_match.h\n+++ b/src/libscotch/dgraph_match.h\n@@ -64,6 +64,7 @@\n   Gnum *                    queuloctab;           /*+ Queue of unmated local vertex                               +*/\n   Gnum                      queulocnbr;           /*+ Number of enqueued unmated vertices                         +*/\n   Gnum *                    procvgbtab;           /*+ Global vertex number bounds for neighboring processors [+1] +*/\n+  int *                     syncdsptab;           /*+ Work array of dgraphMatchSyncColl() (4 * procglbnbr); allocated here so that errors are handled collectively +*/\n   float                     probval;              /*+ Vertex mating probability (1.0 is certain)                  +*/\n } DgraphMatchData;\n \n--- a/src/libscotch/dgraph_match.c\n+++ b/src/libscotch/dgraph_match.c\n@@ -98,7 +98,8 @@\n \n   if (memAllocGroup ((void **) (void *)\n                      &mateptr->procvgbtab, (size_t) ((grafptr->procngbnbr + 1) * sizeof (Gnum)),\n-                     &mateptr->queuloctab, (size_t) (vertlocnbr * sizeof (Gnum)), NULL) == NULL) {\n+                     &mateptr->queuloctab, (size_t) (vertlocnbr * sizeof (Gnum)),\n+                     &mateptr->syncdsptab, (size_t) (4 * grafptr->procglbnbr * sizeof (int)), NULL) == NULL) {\n     errorPrint (\"dgraphMatchInit: out of memory\");\n     return     (1);\n   }\n--- a/src/libscotch/dgraph_match_sync_coll.c\n+++ b/src/libscotch/dgraph_match_sync_coll.c\n@@ -118,10 +118,7 @@\n   }\n #endif /* SCOTCH_DEBUG_DGRAPH2 */\n \n-  if ((vsnddsptab = memAlloc (4 * grafptr->procglbnbr * sizeof (int))) == NULL) {\n-    errorPrint (\"dgraphMatchSyncColl: out of memory\");\n-    return (1);\n-  }\n+  vsnddsptab = mateptr->syncdsptab;               /* Work array allocated by dgraphMatchInit(), whose errors are agreed upon by all processes */\n   vsndcnttab = vsnddsptab + grafptr->procglbnbr;  /* TRICK: put vsnddsptab, vsndcnttab, vrcvdsptab in order for memSet() */\n   vrcvdsptab = vsndcnttab + grafptr->procglbnbr;\n   vrcvcnttab = vrcvdsptab + grafptr->procglbnbr;\n@@ -429,7 +426,5 @@\n   }\n #endif /* SCOTCH_DEBUG_DGRAPH2 */\n \n-  memFree (vsnddsptab);\n-\n   return (0);\n }\n",
   "tradeoffs": "No new communication; frees are by group leader as today. Verified for MatchSyncColl: coarsen scan nth=5 (the moved allocation) now gives rc=2 on both ranks, the former HANG at nth=7..11 is gone. The CoarsenBuild sites (thrdtab, coarhashtab, BuildThr per-thread tables, HaloSync) are NOT fixed by this patch (sketch only; they still hang at nth>=6). Also the dgraphMatchInit-after-failed-CoarsenInit crash needs `if (cheklocval == 0) cheklocval |= dgraphMatchInit (...)`.",
   "preferred": true
  },
  {
   "label": "Agree on errors before each collective",
   "summary": "Before every MPI_Alltoall/Allreduce of the passes, run a one-int MPI_Allreduce(MAX) of the local error flag and let all processes leave together.",
   "patch_sketch": "if (MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, grafptr->proccomm) != MPI_SUCCESS || chekglbval != 0) { /* cleanup */ return (1); }",
   "tradeoffs": "Simple and robust but adds one collective per matching pass and per build step on the hot path (the SCOTCH_DEBUG_DGRAPH1 'cannot be merged with a useful one' policy shows upstream avoids exactly that); could be restricted to the allocation points that cannot be hoisted.",
   "preferred": false
  },
  {
   "label": "Piggy-back the error flag on an existing collective (dgraphGhst TRICK)",
   "summary": "Where a collective follows anyway (MPI_Alltoall of counts at dgraph_coarsen.c:1407), let the failing process contribute an error marker (e.g. negative count) and join it instead of returning.",
   "patch_sketch": "/* failing rank: set dcntloctab[...] = -1 sentinel, skip work, join MPI_Alltoall; receivers test sentinel */",
   "tradeoffs": "Zero extra communication; needs a sentinel convention per collective and careful cleanup of the remaining work, hence larger and riskier; this is what the 'TODO: cleaner exit' comment alludes to.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: dgraphCoarsen's 'TRICK: negative value on error' reduction and dgraphGhst's 'processes not on error will perform collective communication at end of routine'. Option 1 reuses the former.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## PS-DGR-1

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DGR-1",
 "our_title": "dgraphCoarsen runs matching init after failed coarsening init, dereferencing NULL",
 "severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/dgraph_coarsen.c:1359-1360; dgraph_match.c:93",
 "evidence": "`cheklocval = dgraphCoarsenInit (...); cheklocval |= dgraphMatchInit (&matedat, 0.5F);` calls MatchInit unconditionally. Fault shim on SCOTCH_dgraphCoarsen (np=2, ring, ./scan2.sh coarsen 2 1 0 8 0 6), nth=3,4,5 on unmodified 7.0.17: 'dgraphCoarsenInit: out of memory (n)' then ASan SEGV, 'dgraph_match.c:93:31: runtime error: member access within null pointer of type struct Dgraph'.",
 "related_review_ids": [
  "DGR-13"
 ],
 "fix_options": [
  {
   "label": "Skip MatchInit when CoarsenInit failed",
   "summary": "Call dgraphMatchInit only if cheklocval is 0, keeping the negative-thread-count reduction.",
   "patch_sketch": "cheklocval = dgraphCoarsenInit (...);\nif (cheklocval == 0)\n  cheklocval |= dgraphMatchInit (&matedat, 0.5F);",
   "tradeoffs": "Trivial; error branch must not call dgraphMatchExit on an uninitialised matedat. Not compiled.",
   "preferred": true
  },
  {
   "label": "Make dgraphMatchInit tolerate NULL coargsttax",
   "summary": "Return 1 at top of dgraphMatchInit when mateptr->c.coargsttax is NULL.",
   "patch_sketch": "if (mateptr->c.coargsttax == NULL) return (1);",
   "tradeoffs": "Hides an ordering assumption in the callee; exit path still needs care. Not compiled.",
   "preferred": false
  }
 ],
 "area": "DGR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## API-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-15",
 "area": "API",
 "our_title": "Distributed coarsening copies folded multinode array from NULL pointer on empty or failed processes",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_dgraph_coarsen.c:163-164",
 "evidence": "Unchanged. work/API/dco.c (mpirun --oversubscribe -np 2, 16-vertex distributed path, SCOTCH_dgraphCoarsen with SCOTCH_COARSENFOLD and a user multloctab) on ASan+UBSan PT-Scotch 7.0.17: 'library_dgraph_coarsen.c:163:7: runtime error: null pointer passed as argument 2, which is declared to never be null' on one rank (mode 0, o=0). With coarnbr=1000 so that dgraphCoarsen returns 1 ('cannot coarsen') the same report appears on both ranks: the code then also memCpy's from a NULL multlocptr using vertlocnbr of a coarse graph the caller must treat as invalid.",
 "upstream_change": "",
 "review_accuracy": "accurate on the folding case; review misses that the o!=0 path (return 1/2, coarse graph invalid) also reaches the memCpy, which is worse than a size-0 copy.",
 "fix_options": [
  {
   "label": "Copy only if a folded multinode array exists",
   "summary": "Guard memCpy+memFree with 'if (multlocptr != NULL)' (NULL on failure and on processes that hold no folded vertex).",
   "patch_sketch": "--- library_dgraph_coarsen.c\n+++ library_dgraph_coarsen.c\n@@ -160,8 +160,10 @@\n         o = 2;\n       }                                           /* Go on copying anyway as the user may have reserved more */\n #endif /* SCOTCH_DEBUG_LIBRARY2 */\n-      memCpy  (multloctab, multlocptr, coargrafptr->vertlocnbr * sizeof (DgraphCoarsenMulti)); /* Update array with folded multinode data */\n-      memFree (multlocptr);                       /* Free allocated folded multinode array */\n+      if (multlocptr != NULL) {                   /* If a folded multinode array was created (NULL on failure, or on processes that hold no folded vertex) */\n+        memCpy  (multloctab, multlocptr, coargrafptr->vertlocnbr * sizeof (DgraphCoarsenMulti)); /* Update array with folded multinode data */\n+        memFree (multlocptr);                     /* Free allocated folded multinode array */\n+      }\n     }\n   }\n",
   "tradeoffs": "Fixes both the size-0 and the invalid-graph cases; no behaviour change when the copy is real. Tested: dco.c modes 0 and 1 under mpirun -np 2: no UBSan output, return codes unchanged (0 and 1).",
   "preferred": true
  },
  {
   "label": "Guard on size",
   "summary": "if (coargrafptr->vertlocnbr > 0) memCpy (...); memFree (multlocptr);",
   "patch_sketch": "-      memCpy  (multloctab, multlocptr, coargrafptr->vertlocnbr * sizeof (...));\n+      if (coargrafptr->vertlocnbr > 0)\n+        memCpy (...);",
   "tradeoffs": "Matches the review's suggestion, but still reads vertlocnbr of a possibly invalid coarse graph when o != 0.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: 'if (ptr != NULL) memFree(ptr)' guards appear around the same lines and in dgraph_coarsen.c itself ('Return folded multinode array or NULL').",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)
