# G07-common-misc

Items: COR-08, COR-15, COR-18, PS-SEP-6, COR-17, PS-COR-2



===================================================================
## COR-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-08",
 "area": "COR",
 "our_title": "Forked compression children inherit sibling pipe write ends, so readers never see end-of-file",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/common_file_compress.c:246-262, common_file_decompress.c:224-238 (fork branches, only compiled when COMMON_PTHREAD_FILE is NOT defined; module.h:87-93 aliases it to COMMON_PTHREAD)",
 "evidence": "Needs a build without COMMON_PTHREAD (default shipped Makefile.inc's define it, so the fork path is only used on builds without pthreads, e.g. COMMON_STUB_FORK/windows stubs). I built a copy of the ASan tree with -DCOMMON_PTHREAD/-DCOMMON_PTHREAD_AFFINITY_LINUX/-DSCOTCH_PTHREAD removed (work/COR/nopt):\n- 'gpart 4 g88.grf o1.map.gz' -> OK (one compressed output).\n- 'gpart 4 g88.grf o2.map.gz o2.log.gz' -> hangs (timeout 20 -> rc=124).\n- 'gpart 4 g88.grf.gz o4.map.gz o4.log.gz' (gz input + two gz outputs) -> hangs (rc=124).\nMechanism confirmed in source: child 1 (second compressor) is fork()ed after pipe 0's write end (writptr of file 0) is open in the parent, inherits it, fileBlockClose waits for child 0 (fileCompressExit: waitpid) before closing file 1's write end, but child 0 only sees EOF when every copy of its pipe's write end is closed - child 1 holds one.\nNot reproduced: the duplicated stdout claim (children call exit() -> flush inherited stdout buffer). With stdout redirected, 'gpart -vs 4 g88.grf.gz - > so.txt' produced the same 66 lines before and after changing exit()->_exit(); I could not construct a case with pending stdout data at fork time through the CLI tools. The exit()-vs-_exit() point is still correct per POSIX/atexit semantics (source-read).",
 "upstream_change": "",
 "review_accuracy": "deadlock accurate and reproduced; duplicated-stdout claim plausible from the code but not reproduced",
 "fix_options": [
  {
   "label": "A. Child closes the other children's writer pipe ends; _exit()",
   "summary": "Keep a small list (in common_file_compress.c, fork builds only) of the parent's currently open writer fds; every forked child (compress and decompress) first close()s them. Replace exit() by _exit() in the children (they already fclose() their own stream).",
   "patch_sketch": "common_file_compress.h: FileCompress += 'int wrfdnum; struct FileCompress_ * nextptr;' (fork builds)\ncommon_file_compress.c: static FileCompress * fileCompressForkList; void fileCompressForkClose (void) { for (p = list; p; p = p->nextptr) close (p->wrfdnum); }\n  fileCompress(): child: fileCompressForkClose (); fclose (writptr); fileCompress2 (compptr); _exit (EXIT_SUCCESS);\n                  parent: compptr->wrfdnum = fileno (writptr); push compptr on list.\n  fileCompressExit(): unlink compptr from the list before waitpid.\ncommon_file_decompress.c child: fileCompressForkClose (); ... _exit (EXIT_SUCCESS);",
   "tradeoffs": "Tested in the no-pthread build: the two hanging gpart commands above now finish (rc=0) and produce correct .gz files (zcat OK). Only the fork path changes. The list is process-global (not thread-safe) but the fork path is by definition the non-threaded build.",
   "preferred": true
  },
  {
   "label": "B. Use the thread implementation / refuse fork mode",
   "summary": "Always compile COMMON_PTHREAD_FILE when pthreads exist (already the case in shipped configs) and, for builds without pthreads, fail with an explicit error if more than one compressed file is opened.",
   "patch_sketch": "fileCompress(): '#ifndef COMMON_PTHREAD_FILE if (forkcount ++ > 0) { errorPrint (\"only one compressed stream supported without threads\"); return (1); } #endif'",
   "tradeoffs": "No deadlock, trivial; but turns a hang into a restriction on pthread-less platforms (Windows stubs). Not tested.",
   "preferred": false
  },
  {
   "label": "C. Create pipes so children never inherit earlier write ends",
   "summary": "Open pipes with pipe2(O_CLOEXEC) and have the child exec a tiny helper, or fork all helpers before any pipe is created.",
   "patch_sketch": "pipe2 + exec of a re-entrant helper; or two-phase: allocate all File blocks first, then fork children, then create pipes.",
   "tradeoffs": "Invasive (fileBlockInit/Open are per-file API); pipe2 is not portable to every supported OS. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: no API/ABI change, only the fork-only branches change; the repo already keeps fork-specific state in FileCompress under '#ifndef COMMON_PTHREAD_FILE' (procval).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-15",
 "area": "COR",
 "our_title": "Integer reader overflow check exists only in debug builds and misses some wraparounds",
 "claimed_severity": "medium",
 "status": "partially-fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/common_integer.c:104-130 (checks only under '#ifdef COMMON_DEBUG', lines 109-124)",
 "evidence": "7.0.17 added, inside '#ifdef COMMON_DEBUG', 'tmp = val; val = val * 10 + (car - 48); if (val < tmp) { errorPrint (\"intLoad: overflow\"); return (0); }'. Release builds (COMMON_DEBUG undefined, the shipped configuration) are unchanged: archload on 'cmplt 4294967298' -> 'common_integer.c:121:15: runtime error: signed integer overflow: 429496729 * 10 cannot be represented in type int' and 'load ret=0 size=2' (still wraps to 2 terminals). 64-bit INT build (-DINTSIZE64, work/COR/b64): 'cmplt 4294967298' loads fine as 4294967298 terminals (correct), 'cmplt 9223372036854775810' -> UBSan 'signed integer overflow: 922337203685477581 * 10 cannot be represented in type long int' then 'archCmpltArchLoad: bad input' only because the wrapped value is negative.\nWeakness of the new debug check even when enabled: it relies on signed overflow (UB) and on 'val < tmp', which misses wraps that land above the old value: e.g. 5000000000 with 32-bit INT: tmp=500000000, 500000000*10 wraps to 705032704 > tmp, so it is NOT detected (arithmetic, not run since COMMON_DEBUG is not built).",
 "upstream_change": "6a552f9 'Check overflow in intLoad() in debug mode [report R. Perry]' - debug-only and incomplete (see above).",
 "review_accuracy": "accurate for release; the review's end-to-end reproducer ('cmplt 4294967298' -> 2 terminals) still holds",
 "fix_options": [
  {
   "label": "A. Always check before accumulating",
   "summary": "Test val against INTVALMAX/10 and the last digit against INTVALMAX%10 before multiplying; on overflow errorPrint + return 0 (no UB).",
   "patch_sketch": "    if ((val > (INTVALMAX / 10)) || ((val == (INTVALMAX / 10)) && ((car - '0') > (INTVALMAX % 10)))) {\n      errorPrint (\"intLoad: overflow\");\n      return (0);\n    }\n    val = val * 10 + (car - '0');",
   "tradeoffs": "Tested (32-bit): 'cmplt 4294967298' -> 'intLoad: overflow' then load fails; 'cmplt 2147483647' still loads. Divisions are by constants (strength-reduced), so graph-loading speed is unaffected. Rejects the single value -INTVALMAX-1 (cannot be represented as -val); acceptable, same as before for the positive part. Every loader gets the protection through the existing '!= 1' return checks.",
   "preferred": true
  },
  {
   "label": "B. Use unsigned accumulation with a post-check",
   "summary": "Accumulate in UINT, detect overflow with 'uval < tmp || uval > INTVALMAX+sign', convert at the end.",
   "patch_sketch": "UINT uval; ... uval = uval * 10 + d; if (uval / 10 != tmp) overflow; ...",
   "tradeoffs": "Allows INT_MIN and keeps behaviour defined, but needs a division or a wide type per digit or the multiplication-overflow builtin; the maintainers' own debug check shows they prefer a cheap comparison. Not tested.",
   "preferred": false
  },
  {
   "label": "C. Make the existing debug check unconditional",
   "summary": "Drop the #ifdef COMMON_DEBUG around the 6a552f9 code.",
   "patch_sketch": "remove the three '#ifdef COMMON_DEBUG' wrappers",
   "tradeoffs": "Smallest diff, but the check is itself signed-overflow UB (compiler may delete it) and misses wraps landing above the old value (5000000000 example). Not recommended. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A. Maintainers chose a debug-only cheap check, presumably for speed on huge graph files; A is just as cheap. Idiom: intLoad already returns 0 for syntax errors and callers test '!= 1'.",
 "history": {
  "reported": "reported",
  "7.0.17": "partially-fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-18",
 "area": "COR",
 "our_title": "Per-rank seed now uses odd-odd product, giving distinct states per rank",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source-read of the seed arithmetic was conclusive; an MPI run printing per-rank streams would only confirm it.",
 "location": "src/libscotch/common_integer.c:240-260 (intRandReset), 224-232 (intRandSeed2)",
 "evidence": "7.0.17: 'seedval = ((UINT64) randval) * 2U + 1U;' in intRandSeed2 and 'randval = (((UINT64) randptr->seedval) * 2U + 1U) * (((UINT64) randptr->procval) * 2U + 1U);' in intRandReset. Both factors are odd and, for distinct proc numbers, (2p+1) are distinct odd residues mod 2^64; multiplication by the odd (fixed-seed) factor is a bijection mod 2^64, so distinct ranks always get distinct 64-bit states (old: ((seed|1)*(proc+1))|1 collapsed ranks 1 and 2 with seed 1). I did not run an MPI program; the argument is arithmetic.",
 "upstream_change": "64ec683 'Bugfix: make all pseudo-random generators distinct across MPI processes [report R. Perry]'; 7fae3b0 sets distinct per-process seeds in the distributed test programs.",
 "review_accuracy": "accurate for 7.0.16",
 "fix_options": [],
 "notes": "Distinct seeds do not guarantee statistically independent xorshift streams (states are related by a simple linear map), but the specific collision described is gone.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## PS-SEP-6

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-SEP-6",
 "our_title": "64-bit random-value helper casts its result through 32-bit UINT",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/common_integer.c:~476-480 (intRandVal2)",
 "evidence": "`UINT64 intRandVal2 (...) { return ((UINT) intRandVal3 (&contptr->statdat)); }` truncates the 64-bit generator output to UINT before widening, although 7.0.17 (b41893e) made the API 64-bit wide; callers such as bgraphBipartGaLoop slice it by bits. Not run.",
 "related_review_ids": [],
 "fix_options": [
  {
   "label": "Drop the cast",
   "summary": "Return intRandVal3 directly.",
   "patch_sketch": "-  return ((UINT) intRandVal3 (&contptr->statdat));\n+  return (intRandVal3 (&contptr->statdat));",
   "tradeoffs": "Changes random streams for 32-bit callers using the low bits only slightly (they use low bits, unchanged).",
   "preferred": true
  },
  {
   "label": "Keep truncation, fix the type",
   "summary": "Declare return type UINT if 32 bits intended.",
   "patch_sketch": "UINT intRandVal2 (...)",
   "tradeoffs": "Contradicts the 64-bit API commit.",
   "preferred": false
  }
 ],
 "area": "SEP"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## COR-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-17",
 "area": "COR",
 "our_title": "Large-count MPI wrappers return early on one rank before entering the collective",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/comm.c:125-190 (commGatherv), 192-250 (commScatterv)",
 "evidence": "Needs Gnum != int, i.e. a 64-bit INT build (the 'sizeof (Gnum) == sizeof (int)' fast path forwards straight to MPI otherwise). Test (work/COR/comm/t.c): compile 7.0.17's comm.c with mpicc -DINTSIZE64 -DSCOTCH_PTSCOTCH -DSCOTCH_RENAME, link against the 64-bit sequential lib for memAllocGroup/errorPrint, 2 and 3 ranks, root passes recvcnttab[1] = 1<<33, other ranks pass sendcntnbr = 1<<24 ints:\nmpirun --oversubscribe -np 2 ./t -> 'rank 0 calling / ERROR: commGatherv: communication indices out of range (1) / rank 0 returned 13 (MPI_ERR_ARG)' while 'rank 1 calling' never returns (killed by timeout -> rc=124).\n(With a tiny sendcnt rank 1 returns because the eager MPI_Gatherv send completes locally; the hang appears with a rendezvous-size message, which is the realistic case for counts that overflow int.)\n7.0.17 changed commGatherv (73229e6): added a local check of sendcntnbr ('communication indices out of range (2)') and a common 'goto fail', but that new check is also taken on one rank only before the collective, so it adds a second way to deadlock; the root-only 'out of memory' early return remains; commScatterv is unchanged ('(int) recvcntnbr' unchecked, root-only validation).",
 "upstream_change": "73229e6 'Add overflow check in commGatherv()' - adds checks but keeps the root-only/local-only early exit, so the deadlock design is unchanged.",
 "review_accuracy": "accurate; reproduced with a real 2-rank MPI run",
 "fix_options": [
  {
   "label": "A. Agree on the error with MPI_Allreduce before the collective",
   "summary": "Compute a local error code on every rank (scalar range check on all ranks, array checks and allocation on the root), MPI_Allreduce(MPI_IN_PLACE, &o, 1, MPI_INT, MPI_MAX, comm), and only call MPI_Gatherv/Scatterv when the result is 0; same for commScatterv (check recvcntnbr on all ranks).",
   "patch_sketch": "  o = 0; isndcntnbr = (int) sendcntnbr; if ((Gnum) isndcntnbr != sendcntnbr) { errorPrint (...); o = MPI_ERR_ARG; }\n  if (rootnum == proclocnum) { ... on alloc failure: o = MPI_ERR_OTHER; on range failure: o = MPI_ERR_ARG; break; }\n+ MPI_Allreduce (MPI_IN_PLACE, &o, 1, MPI_INT, MPI_MAX, comm);\n+ if (o == 0) o = MPI_Gatherv (senddattab, isndcntnbr, sendtypval, recvdattab, ircvcnttab, ircvdsptab, recvtypval, rootnum, comm);\n  if (ircvcnttab != NULL) memFree (ircvcnttab); return (o);",
   "tradeoffs": "Tested (comm_fix.c, 3 ranks): all ranks return 13 promptly, no hang. Cost: one extra tiny collective per call, only in 64-bit-INT builds (the 32-bit fast path is untouched). Semantic: every rank now returns the same error.",
   "preferred": true
  },
  {
   "label": "B. Remove the failure mode: chunk or use MPI datatypes",
   "summary": "Avoid int limits altogether by sending big counts as MPI_Type_contiguous blocks (or in several int-sized passes), so that no validation can fail on one rank.",
   "patch_sketch": "build a contiguous datatype of 2^30 elements + remainder per rank; or loop over int-sized slices with MPI_Gatherv per slice.",
   "tradeoffs": "Removes the error case (the real fix for >2^31 elements) but is a rewrite of every call site's displacement logic; displacements are still int in MPI-3 (MPI_Gatherv), so large-count variants (MPI-4 _c routines) would be needed. Not tested.",
   "preferred": false
  },
  {
   "label": "C. Document/assert the precondition and abort",
   "summary": "Replace the error returns by errorPrint + MPI_Abort(comm), turning a latent hang into a clean fatal error.",
   "patch_sketch": "on range failure: errorPrint (...); MPI_Abort (comm, MPI_ERR_ARG);",
   "tradeoffs": "Smallest and deadlock-free, but callers can no longer recover (they never could meaningfully: the other ranks were already lost). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A; precedent: PT-Scotch already uses 'agree with MPI_Allreduce then act' in many dgraph routines (e.g. error codes reduced with MPI_MAX/SUM in dgraph build/redist paths).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## PS-COR-2

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-COR-2",
 "our_title": "Rank-local early exit added to gather wrapper's new send-count check before collective",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/comm.c:~160-175 (commGatherv, 'out of range (2)' goto fail)",
 "evidence": "7.0.17 commGatherv computes isndcntnbr and on mismatch executes 'goto fail' before MPI_Gatherv, on that rank only; peers still enter the collective. Same hang pattern as the root-only check, reproduced for the root-side check in COR-17.",
 "related_review_ids": [
  "COR-17"
 ],
 "fix_options": [
  {
   "label": "Allreduce error code",
   "summary": "Agree on failure across ranks before the collective.",
   "patch_sketch": "MPI_Allreduce (MPI_IN_PLACE, &o, 1, MPI_INT, MPI_MAX, comm); if (o == 0) o = MPI_Gatherv (...);",
   "tradeoffs": "One extra tiny collective in 64-bit INT builds; tested for the root-side case.",
   "preferred": true
  },
  {
   "label": "Abort on overflow",
   "summary": "errorPrint plus MPI_Abort instead of returning.",
   "patch_sketch": "MPI_Abort (comm, MPI_ERR_ARG);",
   "tradeoffs": "Deadlock-free but unrecoverable; not tested.",
   "preferred": false
  }
 ],
 "area": "COR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)
