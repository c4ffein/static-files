# G08-bgraph-gg-gain

Items: SEP-06, SEP-11, SEP-13, SEP-19, SEP-20, PS-SEP-3



===================================================================
## SEP-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-06",
 "area": "SEP",
 "our_title": "Threaded greedy growing now compares each pass against the thread's own best",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read of the 7.0.17 comparison is conclusive.",
 "location": "src/libscotch/bgraph_bipart_gg.c:266-276",
 "evidence": "7.0.17: `if ((passnum == 0) || ((thrdptr->cmloval > cmloval) || ((thrdptr->cmloval == cmloval) && (ABS (thrdptr->cpl0dlt) > ABS (cpl0dlt)))))` then `thrdptr->cmloval = cmloval; thrdptr->cpl0dlt = cpl0dlt;` - the comparison is now against the thread's own best (as in the review Fix), with ABS on the imbalance.",
 "upstream_change": "2d94960 \"Bugfix: select best local partiton with respect to current thread optimum [report R. Perry]\".",
 "review_accuracy": "Accurate; fixed as suggested. Not the known threaded-bgraphBipartGg seeding race (that is SEP-13).",
 "fix_options": [],
 "notes": "Source-read only. Note SEP-11 (reduction across threads still compares signed cpl0dlt) is NOT fixed by this commit.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-11",
 "area": "SEP",
 "our_title": "Across threads, tied communication loads are resolved by signed imbalance, favouring unbalanced results",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/bgraph_bipart_gg.c:373-377",
 "evidence": "7.0.17 line 377 is still `(passdat.thrdtab[thrdnum].cpl0dlt <  cpl0dlt)` (the per-thread test at :270-272 is ABS based since 2d94960, the cross-thread reduction is not).\nTest-only instrumentation of the reduction in a copy of the ASan build + K60 weighted complete graph, 8 threads, strategy r{sep=h{pass=64}} (work/SEP/t/sep11k.c):\n  GGTIE thr=7 best=0 cpl0dlt_new=0 cpl0dlt_cur=-6 signed_prefers_new=0 abs_prefers_new=1\n  GGTIE thr=7 best=0 cpl0dlt_new=-2 cpl0dlt_cur=-6 signed_prefers_new=0 abs_prefers_new=1\n  (on a communication-load tie the balanced partition (0) loses against the one with delta -6)\nEffect on the final bipartition, mean |load0-load1| over 40 seeds: 13.00 (pristine) vs 1.55-1.60 (with ABS in the reduction).",
 "upstream_change": "",
 "review_accuracy": "Accurate. The review Fix (compare ABS of both deltas) is right and gives a large improvement on the tie-heavy test.",
 "fix_options": [
  {
   "label": "ABS in the reduction (review Fix)",
   "summary": "Replace the signed comparison by ABS (..) < ABS (..), mirroring the per-thread test.",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_gg.c\n+++ b/src/libscotch/bgraph_bipart_gg.c\n@@ -374,7 +374,7 @@\n     }\n     if ( (passdat.thrdtab[thrdnum].cmloval <  cmloval) || /* If better partition */\n         ((passdat.thrdtab[thrdnum].cmloval == cmloval) &&\n-         (passdat.thrdtab[thrdnum].cpl0dlt <  cpl0dlt))) {\n+         (ABS (passdat.thrdtab[thrdnum].cpl0dlt) < ABS (cpl0dlt)))) {\n       memFree (passdat.thrdtab[thrdbst].parttab); /* Free preserved former best partition */\n       goto found;                                 /* Record new best partition            */\n     }",
   "tradeoffs": "Behaviour change only on commload ties between threads (more balanced result). Tested. No ABI change.",
   "preferred": true
  },
  {
   "label": "Single comparison macro",
   "summary": "Define one macro/inline (e.g. BGRAPHBIPARTGGBETTER (cmlo, cpl0dlt, bestcmlo, bestcpl0dlt)) used for both the per-pass test and the thread reduction so the two cannot diverge again.",
   "patch_sketch": "#define BGRAPHBIPARTGGBETTER(cm,cd,bcm,bcd) (((cm) < (bcm)) || (((cm) == (bcm)) && (ABS (cd) < ABS (bcd))))",
   "tradeoffs": "Avoids the class of bug; slightly larger diff. Not compiled.",
   "preferred": false
  }
 ],
 "notes": "Same file as the known threaded-bgraphBipartGg issue but a different defect (comparison logic, not RNG seeding): NOT the known issue.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-13",
 "area": "SEP",
 "our_title": "Worker threads seed their generators from state thread 0 is concurrently advancing",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/bgraph_bipart_gg.c:173-179 (spawn at :177), :196 (thread 0 draw)",
 "evidence": "KNOWN ISSUE: this is the threaded bgraphBipartGg seeding race already known and handled elsewhere; reported here for status only. Unchanged in 7.0.17 (gg.c diff = abs->ABS and the SEP-06/SEP-19 fixes).\nTSan on pristine 7.0.17 (scratchpad/tsan/pristine, harness sep11k_tsan, r{sep=h{pass=16}}, 4 threads):\n  WARNING: ThreadSanitizer: data race ... Write by main thread: _SCOTCHintRandVal3 common_integer.c:443 <- bgraphBipartGg2 bgraph_bipart_gg.c:196 ; Previous read by thread T3: _SCOTCHintRandSpawn common_integer.c:296 <- bgraphBipartGg2 bgraph_bipart_gg.c:177\nWith spawning moved before the launch (work/SEP/diffs/sep13.diff) the common_integer.c race disappears (3 TSan runs, no RandVal3 report).\nEXTRA (not in the review, same function): TSan also reports a distinct race on the file-static sentinel `gainLinkDummy` in gain.c: `Write ... bgraph_bipart_gg.c:245 (gainTablAdd -> entrptr->next->prev = linkptr when the slot is empty)` vs `gain.c:311 gainTablAddLog`; all GG threads share the global dummy link. It remains after the RNG fix.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Fix suggestion 'spawn all per-thread generators before launching threads' is right; intRandSpawn's own comment says it does not change the parent state so spawning in the launcher is safe.",
 "fix_options": [
  {
   "label": "Spawn all worker generators before the launch",
   "summary": "In bgraphBipartGg(), before contextThreadLaunch, call intRandSpawn (grafptr->contptr->randptr, thrdnum, &passdat.thrdtab[thrdnum].randdat) for thrdnum 1..thrdnbr-1; workers use &thrdptr->randdat.",
   "patch_sketch": "--- a/src/libscotch/bgraph_bipart_gg.c\n+++ b/src/libscotch/bgraph_bipart_gg.c\n@@ -124,7 +124,6 @@\n {\n   Context                 contdat;                /* Local context, only used for its random section */\n   Context *               contptr;                /* Pointer to active local context                 */\n-  IntRandContext          randdat;                /* Local random context                            */\n   BgraphBipartGgTabl      tabldat;                /* Gain table                                      */\n   BgraphBipartGgVertex *  vexxtax;                /* Extended vertex array [norestrict]              */\n   BgraphBipartGgVertex *  vexxptr;                /* Pointer to current vertex to swap [norestrict]  */\n@@ -174,8 +173,7 @@\n   }\n   else {\n     parttax = thrdptr->parttab - grafptr->s.baseval; /* Use local array                       */\n-    intRandSpawn (grafptr->contptr->randptr, thrdnum, &randdat); /* Create fake local context */\n-    contdat.randptr = &randdat;\n+    contdat.randptr = &thrdptr->randdat;          /* Use generator spawned before threads were launched */\n     contptr = &contdat;\n   }\n \n@@ -327,6 +325,9 @@\n   passdat.grafptr  = grafptr;\n   passdat.passnbr  = (paraptr->passnbr + (thrdnbr - 1)) / thrdnbr; /* Share passes across threads */\n \n+  for (thrdnum = 1; thrdnum < thrdnbr; thrdnum ++) /* Spawn generators while no worker is running; thread 0 keeps the main one */\n+    intRandSpawn (grafptr->contptr->randptr, thrdnum, &passdat.thrdtab[thrdnum].randdat);\n+\n   if (edlotax == NULL) {                          /* If graph has no edge weights */\n     Gnum                vertnum;\n     Gnum * restrict     cmg0tax = passdat.cmg0tax;\n--- a/src/libscotch/bgraph_bipart_gg.h\n+++ b/src/libscotch/bgraph_bipart_gg.h\n@@ -97,6 +97,7 @@\n   Gnum                      cmloval;              /*+ Communication load value +*/\n   Gnum                      cpl0dlt;              /*+ Computation imbalance    +*/\n   GraphPart *               parttab;              /*+ Local part array         +*/\n+  IntRandContext            randdat;              /*+ Private pseudo-random generator, spawned before launch +*/\n } BgraphBipartGgThread;\n \n /*+ The loop routine parameter",
   "tradeoffs": "Deterministic seeds (function of the parent state at call time and thread number). One IntRandContext (32 B) per thread added to the internal BgraphBipartGgThread struct. Tested with TSan.",
   "preferred": true
  },
  {
   "label": "Derive the spawn seed from the stable seed, not the live state",
   "summary": "Change intRandSpawn to seed from roldptr->seedval (+ procnum) instead of statdat.randtab[0], so that spawning is race-free wherever it is called.",
   "patch_sketch": "-  seedval = roldptr->statdat.randtab[0];\n+  seedval = roldptr->seedval;",
   "tradeoffs": "Fixes every present/future caller at once, but two successive spawns from the same parent then give identical streams for the same thread number (passes of a multi-call algorithm would repeat), which changes results; needs a call counter. Not preferred.",
   "preferred": false
  },
  {
   "label": "Barrier inside bgraphBipartGg2",
   "summary": "Workers spawn first, then all threads hit a threadBarrier, then thread 0 starts drawing.",
   "patch_sketch": "/* after local allocation (before first contextIntRandVal): */\nthreadBarrier (descptr);",
   "tradeoffs": "Needs the barrier to be reached on every path (including the allocation-failure path that currently returns early) or it deadlocks. Riskier.",
   "preferred": false
  }
 ],
 "notes": "Handled elsewhere by the parent; options listed for completeness.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-19",
 "area": "SEP",
 "our_title": "Greedy growing's debug consistency result is now kept instead of overwritten",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "debug-build",
 "needs_note": "Build with SCOTCH_DEBUG_BGRAPH2 and force an inconsistent partition to see the failure propagate.",
 "location": "src/libscotch/bgraph_bipart_gg.c:434-444",
 "evidence": "7.0.17 now has `o = 0; /* Everyhting went well */` at :437, BEFORE `#ifdef SCOTCH_DEBUG_BGRAPH2 if (bgraphCheck (grafptr) != 0) { ... o = 1; }`, and the old trailing `o = 0` is removed.",
 "upstream_change": "2a6fd07 \"Bugfix: take graph bipartition check into account [report R. Perry]\".",
 "review_accuracy": "Accurate; fixed as the review suggested.",
 "fix_options": [],
 "notes": "Source-read only (the check is compiled out of the ASan build).",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-20",
 "area": "SEP",
 "our_title": "Load-imbalance comparisons now use size-agnostic ABS instead of int-width abs",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "64bit-build",
 "needs_note": "Build with 64-bit INT and loads above 2^31 to watch balance comparisons.",
 "location": "bgraph_bipart_gg.c, _ga.c, _fm.c, bgraph_bipart_st.c, vgraph_separate_fm.c, vmesh_separate_fm.c, wgraph_part_rb.c",
 "evidence": "grep for libc abs/labs in src/libscotch (excluding comments) finds none; every site of the review is now `ABS (...)` (diffs of bgraph_bipart_fm.c :136,:210,:668,:677,:723,:762; _ga.c :204,:259; _gg.c :221; _st.c :364-367; vgraph_separate_fm.c :132,:196,:295,:336,:594-595; vmesh_separate_fm.c :267,:350,:560,:906-924). wgraph_part_rb.c:293 is now `const Gnum indvertnbr`.",
 "upstream_change": "f545452 \"Bugfix: use size-agnostic macro instead of bounded-size library ABS routine [report R. Perry]\" and 813ef60 \"Bugfix: variable type [report R. Perry]\".",
 "review_accuracy": "Accurate; fixed by the review's own Fix (ABS from common.h and Gnum for indvertnbr).",
 "fix_options": [],
 "notes": "Not run with a 64-bit-Gnum build; source-read. Only the sites listed were checked; other int-typed temporaries holding Gnum deltas were not audited.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## PS-SEP-3

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-SEP-3",
 "our_title": "Greedy-growing threads write the shared static gain-list sentinel concurrently",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/gain.c:76,311; bgraph_bipart_gg.c:245",
 "evidence": "TSan on pristine 7.0.17, r{sep=h{pass=16}}, 4 threads: data race on gainLinkDummy, write at bgraph_bipart_gg.c:245 (gainTablAdd) vs gain.c:311 (gainTablAddLog); persists after the RNG-spawn fix.",
 "related_review_ids": [
  "SEP-13"
 ],
 "fix_options": [
  {
   "label": "Per-table sentinel",
   "summary": "Move the dummy link into each GainTabl so threads never share it.",
   "patch_sketch": "static GainLink gainLinkDummy; -> GainTabl member 'dummy'; compare against &tablptr->dummy",
   "tradeoffs": "Touches all gain.c comparisons and the struct; not compiled.",
   "preferred": true
  },
  {
   "label": "Thread-local sentinel",
   "summary": "Declare the sentinel thread-local.",
   "patch_sketch": "static __thread GainLink gainLinkDummy;",
   "tradeoffs": "Pointer identity then differs per thread; list nodes crossing threads would break; only safe if tables are never shared.",
   "preferred": false
  }
 ],
 "area": "SEP"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)
