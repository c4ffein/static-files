# G12-overlap-kgraph-rb

Items: SEP-01, SEP-17, API-22, GRA-01, GRA-21, GRA-23, GRA-05



===================================================================
## SEP-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-01",
 "area": "SEP",
 "our_title": "Empty bipartition half recurses with part index 0 and no part array, then dereferences NULL",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/wgraph_part_rb.c:355-363 (call at 363), 297-303",
 "evidence": "wgraph_part_rb.c was only touched in 7.0.17 by f545452 (indvertnbr int -> Gnum); the empty-part branch is unchanged: line 363 still reads `wgraphPartRb2 (contptr, partval, &spltdat);`.\nReproducer (work/SEP/t/sep01.c, 6-vertex path, 3 parts, strategy r{sep=z}), built against the pristine ASan+UBSan 7.0.17 lib:\n  ./sep01 6 3 'r{sep=z}'\n  wgraph_part_rb.c:108:5: runtime error: null pointer passed as argument 2, which is declared to never be null   (wgraphPartRb3Fron, called from wgraphPartRb2 :299 <- :363)\n  wgraph_part_rb.c:207:18: runtime error: load of null pointer of type 'const GraphPart'   (wgraphPartRb3One)\n  AddressSanitizer: SEGV on unknown address 0x000000000000 ... SUMMARY: SEGV wgraph_part_rb.c:207 in wgraphPartRb3One\nMechanism confirmed by reading: when compsize[1] <= 0, partval = 0, so the recursion is entered with spltnum = 0 (not the fake part 1 the comment announces) and orgparttax == NULL; since indpartval == 0 it takes the 'small branch' that dereferences orgparttax; splttab[0].vertnbr is also uninitialised. Also reached with sep=b and with the multilevel 'm' strategies, not only 'z'. With the Rb2 call changed to spltnum 1 the same inputs run clean (no crash, ASan/UBSan silent).",
 "upstream_change": "",
 "review_accuracy": "Accurate. Reproducer and diagnosis (spltnum = partval = 0, parttax NULL, uninit splttab[0].vertnbr) match. The suggested one-line Fix (call with 1) works as written; the second half of the Fix (make Rb3* return errors through revaptr) is a robustness extra, not needed for this crash. Release/debug behaviour split in the review was not re-checked (library built without SCOTCH_DEBUG_*).",
 "fix_options": [
  {
   "label": "Always recurse on the fake part 1",
   "summary": "Call wgraphPartRb2 with spltnum 1 in the empty-part branch, as the existing comment (TRICK: use fake part 1 for calling) intends. For partval==1 nothing changes (it already was 1).",
   "patch_sketch": "--- a/src/libscotch/wgraph_part_rb.c\n+++ b/src/libscotch/wgraph_part_rb.c\n@@ -360,7 +360,7 @@\n     spltdat.frontab = NULL;                       /* No separator vertices, even if they were some */\n     spltdat.fronnbr = 0;\n     spltdat.parttax = NULL;\n-    wgraphPartRb2 (contptr, partval, &spltdat);\n+    wgraphPartRb2 (contptr, 1, &spltdat);        /* Always run on fake part 1 */\n     vgraphExit    (&actgrafdat);\n     if (o != 0)\n       goto fail;",
   "tradeoffs": "One-token change, no ABI or behaviour change for the non-crashing case (partval==1). Tested: 6/8/9 vertex paths with 3-5 parts, strategies z, b: no crash. Needs a regression test with an empty-part-1 bipartition (e.g. r{sep=z}).",
   "preferred": true
  },
  {
   "label": "Guard the small-branch test in the callee",
   "summary": "Make the small-branch test depend on a real part array: `if ((indpartval == 0) && (orgparttax != NULL))`, so that a call with spltnum 0 and no part array is treated like the whole-graph call.",
   "patch_sketch": "--- a/src/libscotch/wgraph_part_rb.c\n+++ b/src/libscotch/wgraph_part_rb.c\n@@ -294,7 +294,7 @@\n   const Anum                        inddomnnum = spltptr->splttab[spltnum].domnnum; /* Initial domain number to map        */\n   const Anum                        inddomnsiz = spltptr->splttab[spltnum].domnsiz; /* Number of domains to map            */\n \n-  if (indpartval == 0) {                          /* If in small branch of the recursion; TRICK: never at first call      */\n+  if ((indpartval == 0) && (orgparttax != NULL)) { /* If in small branch of the recursion (a real part, not the fake whole-graph one) */\n     if (inddomnsiz <= 1) {                        /* If target domain is terminal                                         */\n       wgraphPartRb3Fron (dataptr, orggrafptr, orgfrontab, orgfronnbr); /* Copy previous frontier to global frontier array */\n       wgraphPartRb3One  (dataptr, orggrafptr, orgparttax, indpartval, inddomnnum); /* Update mapping and return           */",
   "tradeoffs": "Keeps the call site as is but leaves splttab[0].vertnbr uninitialised (harmless because it is only used when orgparttax != NULL). Slightly more fragile: relies on parttax==NULL meaning \"whole graph\". Tested equivalent on the same inputs.",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: wgraphPartRb() itself starts the recursion with `spltdat.splttab[1]` (the TRICK fake part 1) and the comment in the buggy branch says the same thing, so option 1 is the most likely. Not the known bgraphBipartGg threading issue.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-17",
 "area": "SEP",
 "our_title": "Isolated vertices end up in the overlap frontier and count toward no part",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/wgraph_part_rb.c (wgraphPartRb recursion / vertex separators h,f of vgraph)",
 "evidence": "wgraph_part_rb.c unchanged in substance. Harness work/SEP/t/sep01.c (edgeless graph = all vertices isolated), SCOTCH_graphPartOvl with the DEFAULT strategy on pristine 7.0.17:\n  ./sep01 2 3 - 1   -> ret=0 part: 2 -1\n  ./sep01 3 6 - 1   -> ret=0 part: -1 -1 -1\n  ./sep01 5 2 - 1   -> ret=0 part: 1 -1 1 0 0\nStrategies r{sep=f} and r{sep=h} (vgraph FM / greedy growing) produce the -1 for zero-degree vertices; r{sep=g|f} does not. wgraphCost() gives a separator vertex's load only to its neighbouring parts, so an isolated -1 vertex contributes to no part load.\nPatched (post-pass in wgraphPartRb): {2,0}, {2,0,1}, {1,0,1,0,0}.",
 "upstream_change": "",
 "review_accuracy": "Behaviour accurately described. Whether it is a defect is a design question: wgraphCheck() accepts an isolated frontier vertex and nothing in the docs forbids it; severity Low is appropriate. (The sibling empty-part crash is SEP-01.)",
 "fix_options": [
  {
   "label": "Post-pass in wgraphPartRb",
   "summary": "After the recursion and wgraphCost, scan the frontier; every zero-degree vertex is moved to the currently lightest part, removed from frontab, and compload/compsize/fronload/fronnbr are updated.",
   "patch_sketch": "--- a/src/libscotch/wgraph_part_rb.c\n+++ b/src/libscotch/wgraph_part_rb.c\n@@ -453,6 +453,35 @@\n     return (1);\n   }\n \n+  {                                               /* Isolated vertices cannot belong to a separator: it is not adjacent to any part */\n+    Gnum                fronnum;\n+    Gnum                fronnew;\n+\n+    for (fronnum = fronnew = 0; fronnum < grafptr->fronnbr; fronnum ++) {\n+      Gnum                vertnum;\n+\n+      vertnum = grafptr->frontab[fronnum];\n+      if (grafptr->s.vendtax[vertnum] == grafptr->s.verttax[vertnum]) { /* If frontier vertex has no neighbor */\n+        Gnum                veloval;\n+        Anum                partmin;\n+        Anum                partnum;\n+\n+        veloval = (grafptr->s.velotax != NULL) ? grafptr->s.velotax[vertnum] : 1;\n+        for (partnum = 1, partmin = 0; partnum < grafptr->partnbr; partnum ++) {\n+          if (grafptr->compload[partnum] < grafptr->compload[partmin])\n+            partmin = partnum;                    /* Find lightest part */\n+        }\n+        grafptr->parttax[vertnum] = partmin;      /* Assign vertex to it */\n+        grafptr->compload[partmin] += veloval;\n+        grafptr->compsize[partmin] ++;\n+        grafptr->fronload -= veloval;\n+      }\n+      else\n+        grafptr->frontab[fronnew ++] = vertnum;   /* Keep vertex in frontier */\n+    }\n+    grafptr->fronnbr = fronnew;\n+  }\n+\n #ifdef SCOTCH_DEBUG_WGRAPH2\n   if (wgraphCheck (grafptr) != 0) {\n     errorPrint (\"wgraphPartRb: inconsistent graph data\");",
   "tradeoffs": "Local, O(frontier); vertices end up in a part (balance maintained greedily); changes outputs of graphs with isolated vertices only. Tested on the examples above.",
   "preferred": true
  },
  {
   "label": "Assign them while gluing the recursion",
   "summary": "In wgraphPartRb3Both/Rb3Fron, when copying a separator vertex of a bipartition whose degree is 0, write the current domain number instead of -1 and do not add it to the frontier.",
   "patch_sketch": "if ((orgpartval == 2) && (vendtax[vertnum] == verttax[vertnum])) parttax[orgvnumtax[vertnum]] = inddomnnum + (Anum) 0;  /* instead of -1 */",
   "tradeoffs": "Avoids the extra pass and keeps balance per bipartition, but touches two helpers and must keep frontab in sync. Not compiled.",
   "preferred": false
  },
  {
   "label": "Prevent it in the vertex separators",
   "summary": "In vgraphSeparateFm / vgraphSeparateGg never move a zero-degree vertex into the separator (put it in the lighter part).",
   "patch_sketch": "/* vgraph_separate_gg.c / _fm.c: skip vertices with vendtax[v] == verttax[v] when selecting separator moves */",
   "tradeoffs": "Fixes the cause for all users (nested dissection too, where an isolated vertex in the separator is harmless but wasteful); larger blast radius, changes ordering results. Not compiled.",
   "preferred": false
  }
 ],
 "notes": "Low confidence on what maintainers would prefer; option 1 is local and self-contained.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## API-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-22",
 "area": "API",
 "our_title": "Overlap partition viewer prints out-of-memory error but then continues using NULL arrays",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_map_view.c:713-720",
 "evidence": "Unchanged: errorPrint in the NULL branch then falls through to 'listtab ++; memSet (listtab, ...)'. work/API/po.c on the 64-bit ASan build, partnbr = 1<<36 with ASAN_OPTIONS=allocator_may_return_null=1 and libscotcherr (non-exiting): 'ERROR: SCOTCH_graphPartOvlView: out of memory' then 'AddressSanitizer: unknown-crash ... memset ... SCOTCH_graphPartOvlView library_graph_map_view.c:719'. With the patch: same message and r=1.",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "return (1) in the error branch",
   "summary": "Add the missing return.",
   "patch_sketch": "--- library_graph_map_view.c (SCOTCH_graphPartOvlView)\n@@ -714,6 +718,7 @@\n     errorPrint (STRINGIFY (SCOTCH_graphPartOvlView) \": out of memory\");\n+    return (1);\n   }\n   listtab ++;\n",
   "tradeoffs": "Tested (r=1, no crash). Zero risk.",
   "preferred": true
  },
  {
   "label": "goto fail with common cleanup",
   "summary": "Introduce 'o = 1; ... fail: memFree (compload)' (no cleanup needed now), keep return in one place.",
   "patch_sketch": "o = 1; goto fail;",
   "tradeoffs": "Only worthwhile if more cleanup is added later.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## GRA-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-01",
 "area": "GRA",
 "our_title": "Mapping with zero-weight fixed vertices loops forever in the domain hash probe",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_rb.c:409-412 (hash sizing), 456-473 (probe loop)",
 "evidence": "Harness gra01.c: path graph of 70 vertices, vertices 0..63 fixed to distinct terminals 100..163 (cmplt(1024) target), 6 free vertices, default strategy, SCOTCH_graphMapFixed. `./gra01 64 1` (fixed vertices weight 1) -> 'ret 0'. `timeout 20 ./gra01 64 0` (fixed vertices weight 0) -> killed by timeout (rc=124): infinite loop. Mechanism confirmed in source: kgraph_map_rb.c:291 `if (velomsk == 0) { ... *vflonbrptr = 0; ...}` then kgraph_map_rb.c:409 `hashnbr = mappptr->domnnbr + vflonbr;` (vflonbr==0) so the table has ~8 slots (domnnbr small) while 64 distinct fixed terminals each insert a slot in the `for (hashnum = ...; ; hashnum = (hashnum + 1) & hashmsk)` loop that has no exit when full. With patched/kgraph_map_rb.c (hashnbr = domnnbr + vfixnbr) both runs return 'ret 0'. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Note the hang needs (distinct fixed terminals) > hash capacity, i.e. few free vertices (small mappptr->domnnbr) AND all fixed loads zero; the review's 64-part example works only in that regime. The unused `vfixnbr` parameter of kgraphMapRbVfloMerge (kgraph_map_rb.c:394) is the natural sizing bound.",
 "fix_options": [
  {
   "label": "Size merge table from vfixnbr",
   "summary": "Use the number of fixed vertices (upper bound of distinct fixed terminals, parameter already passed but unused) instead of vflonbr when sizing the hash table.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_rb.c\n+++ b/src/libscotch/kgraph_map_rb.c\n@@ -406,7 +406,7 @@\n   const Arch * restrict const archptr = mappptr->archptr;\n   Anum * restrict const       parttax = mappptr->parttax;\n \n-  hashnbr = mappptr->domnnbr + vflonbr;\n+  hashnbr = mappptr->domnnbr + vfixnbr;           /* Fixed vertices may all belong to distinct parts */\n   for (hashsiz = 0, hashmsk = hashnbr; hashmsk != 0; hashsiz ++, hashmsk >>= 1) ; /* Get upper power of two */\n   hashsiz = 1 << (hashsiz + 2);                   /* Fill hash table at 25% maximum                         */\n   hashmsk = hashsiz - 1;\n",
   "tradeoffs": "No behaviour change except memory: table is sized for min(vfixnbr) entries x4..8; for graphs with huge vfixnbr but few distinct parts it over-allocates (O(vfixnbr) cells, same order as the orgparttax array already allocated by kgraphMapRbVfloBuild). Tested: hang gone. Precedent: kgraphMapRbVfloBuild sizes its table from orgvfixnbr (kgraph_map_rb.c:236-243). Would need a regression test (zero-weight fixed vertices, many distinct terminals).",
   "preferred": true
  },
  {
   "label": "Count distinct fixed terminals in Build and pass that",
   "summary": "Remove the `velomsk == 0` shortcut value `*vflonbrptr = 0` so that vflonbr always equals the number of distinct fixed terminals (slots), and free/NULL vflotab separately when loads are zero.",
   "patch_sketch": "/* kgraphMapRbVfloBuild */\n-  if (velomsk == 0) { memFree (hashtab); *vflonbrptr = 0; *vflotabptr = NULL; return (0); }\n+  (always run the recycle loop; keep vflonbr = #distinct slots)\n+  if (velomsk == 0) { /* loads all zero: keep count, drop table */ *vflonbrptr = vflonbr; memFree (hashtab); *vflotabptr = NULL; return (0); }\n/* then kgraphMapRbVfloSplit() must tolerate vflonbr>0 with vflotab==NULL */",
   "tradeoffs": "Touches the contract of vflonbr/vflotab (vflonbr>0 with NULL vflotab) used by kgraphMapRbVfloSplit and kgraph_map_rb_map.c/part.c; riskier, more code paths to audit.",
   "preferred": false
  },
  {
   "label": "Make the probe loop self-limiting",
   "summary": "Bound the number of probes (hashsiz) and grow/rehash or fail with an error instead of looping forever.",
   "patch_sketch": "for (hashnum = ...; ; hashnum = (hashnum + 1) & hashmsk) {  ->  for (probenbr = 0; probenbr < hashsiz; probenbr ++, hashnum = ...) {  ... }\nif (probenbr == hashsiz) { errorPrint (\"kgraphMapRbVfloMerge: hash table full\"); memFree (hashtab); return (1); }",
   "tradeoffs": "Turns a hang into an error (safe) but does not make the feature work for the failing input; best used in addition to option 1.",
   "preferred": false
  }
 ],
 "notes": "Same function also leaks hashtab on its two error returns (mapResize failure at kgraph_map_rb.c:462 returns without memFree (hashtab)).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-21",
 "area": "GRA",
 "our_title": "Fixed-vertex validation exists only in debug builds; an invalid terminal also leaks the bipartition graph",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_rb.c:547-550, 613-616, 667-670; callers kgraph_map_rb_part.c:255, kgraph_map_rb_map.c:944",
 "evidence": "Repro gra21.c: SCOTCH_graphMapFixed on a 16x16 grid, cmplt(4), fixed vertex with terminal 100 (invalid; the validation in library_graph_map.c:226-232 is only compiled under SCOTCH_DEBUG_LIBRARY1): 'ERROR: kgraphMapRbBgraph: invalid fixed part array' ... LeakSanitizer: 'Direct leak of 1016 byte(s) ... #1 _SCOTCHbgraphInit bgraph.c:120 #2 kgraphMapRbBgraph kgraph_map_rb.c:530 #3 kgraphMapRbPart2 kgraph_map_rb_part.c:255' (same through the Map path with an hcub target: kgraphMapRbMap). With bgraphExit on the error returns (patched) the bgraphInit frames disappear from the leak report. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate; reachable from the release API with an out-of-range fixed part.",
 "fix_options": [
  {
   "label": "bgraphExit in kgraphMapRbBgraph on its error returns",
   "summary": "Call bgraphExit (actgrafptr) before returning 1 once bgraphInit has succeeded.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_rb.c\n+++ b/src/libscotch/kgraph_map_rb.c\n@@ -546,6 +546,7 @@\n \n   if ((veextax = (Gnum *) memAlloc (actgrafptr->s.vertnbr * sizeof (Gnum))) == NULL) {\n     errorPrint (\"kgraphMapRbBgraph: out of memory\");\n+    bgraphExit (actgrafptr);\n     return (1);\n   }\n   veextax -= actgrafptr->s.baseval;\n@@ -667,6 +668,8 @@\n fail:\n   if ((o != 0) || (veexmsk == 0)) {               /* If external gain array is useless */\n     memFree (veextax + actgrafptr->s.baseval);    /* Forget about it                   */\n+    if (o != 0)                                   /* On error, bipartition graph must not be leaked */\n+      bgraphExit (actgrafptr);\n     return  (o);                                  /* Return error code                 */\n   }\n \n",
   "tradeoffs": "Callee cleans up what it created; callers (kgraph_map_rb_map.c:944 comment says the cloned graph is freed via the pool) are unchanged. Verify no double free of the cloned graph tabs: bgraphExit does not free graph data without GRAPHFREETABS, which is only set by the caller after success.",
   "preferred": true
  },
  {
   "label": "Free in the callers",
   "summary": "In kgraphMapRbPart2 / kgraphMapRbMap call bgraphExit (&actgrafdat) when kgraphMapRbBgraph fails.",
   "patch_sketch": "if (kgraphMapRbBgraph (...) != 0) { bgraphExit (&actgrafdat); ... return (1); }",
   "tradeoffs": "Two call sites to maintain; but keeps kgraphMapRbBgraph free of ownership assumptions. Cannot distinguish failure before/after bgraphInit.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-23

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-23",
 "area": "GRA",
 "our_title": "Remapping silently accepts an invalid terminal domain and returns success",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/mapping.c:389; src/libscotch/kgraph_map_rb.c:466",
 "evidence": "Repro (a) gra23.c: SCOTCH_graphRemap on a 16x16 grid, cmplt(4), old partition containing terminal 100: orig returns 0 silently ('ret=0 new[7]=1'); patched mapping.c: 'ERROR: mapBuild3: invalid terminal domain number', 'kgraphInit: cannot initialize remapping (2)', ret=1. (b) gra23b.c: SCOTCH_graphMapFixed with an isolated fixed vertex pinned to terminal 100: orig -> UBSan 'kgraph_cost.c:178:34: runtime error: signed integer overflow: 1 - -2147483648' (uninitialised ArchDom weight consumed by kgraphCost, right after kgraphMapRbVfloMerge ignored archDomTerm); patched kgraphMapRbVfloMerge: 'invalid fixed part array', ret=1. Input validation for these arrays exists only under SCOTCH_DEBUG_LIBRARY1 (library_graph_map.c:201, 240). Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Check archDomTerm in both places",
   "summary": "Fail with an error (goto fail in mapBuild3, free hashtab and return in VfloMerge).",
   "patch_sketch": "--- a/src/libscotch/mapping.c\n+++ b/src/libscotch/mapping.c\n@@ -386,7 +386,10 @@\n             goto fail;\n           domntab = mappptr->domntab;             /* Re-read pointer in case it changed */\n         }\n-        archDomTerm (archptr, &domntab[domnnbr], termnum); /* Create slot with terminal number domain */\n+        if (archDomTerm (archptr, &domntab[domnnbr], termnum) != 0) { /* Create slot with terminal number domain */\n+          errorPrint (\"mapBuild3: invalid terminal domain number\");\n+          goto fail;\n+        }\n         domnnum = domnnbr ++;                     /* Get position of new slot; one more slot created  */\n         break;\n       }\n\n/* kgraph_map_rb.c */\n-        archDomTerm (archptr, &mappptr->domntab[domnnum], pfixval);\n+        if (archDomTerm (archptr, &mappptr->domntab[domnnum], pfixval) != 0) {\n+          errorPrint (\"kgraphMapRbVfloMerge: invalid fixed part array\");\n+          memFree    (hashtab);\n+          mappptr->domnnbr = domnnum;\n+          return (1);\n+        }\n",
   "tradeoffs": "Same pattern as the already-checked call at kgraph_map_rb.c:613. Behaviour change only for invalid input (now an error instead of undefined behaviour).",
   "preferred": true
  },
  {
   "label": "Validate part arrays once at the library boundary",
   "summary": "Make the SCOTCH_DEBUG_LIBRARY1 validation of old/fixed parttabs in graphMapCompute2 unconditional (O(n) archDomTerm calls).",
   "patch_sketch": "move the #ifdef SCOTCH_DEBUG_LIBRARY1 loops in library_graph_map.c:187-203 and 227-234 out of the ifdef",
   "tradeoffs": "Cheap relative to mapping, catches problems before any allocation; but the deeper routines still ignore the return value (defence in depth lost).",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-05",
 "area": "GRA",
 "our_title": "Remapping onto more parts crashes while building the band graph (SEGV in archCmpltDomIncl)",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_band.c:267",
 "evidence": "Repro gra05.c: 32x32 grid, old partition into 2 parts (x*2/32), SCOTCH_graphRemap onto cmplt(8) with strategy 'r{sep=h{pass=10}}b{width=3,bnd=f{move=100,pass=-1,bal=0.05},org=f{move=100,pass=-1,bal=0.05}}': `./gra05 2 8 '<strategy>'` -> 'AddressSanitizer: SEGV on unknown address ... #0 archCmpltDomIncl arch_cmplt.c #1 kgraphMapFmPartAdd kgraph_map_fm.c'. 8->2 and 4->4 do not crash (the overwritten band entries are rewritten at kgraph_band.c:352/450). Source: kgraph_band.c:267 `memSet (bandparotax + bandvertnbr - bandgrafptr->r.m.domnnbr, ~0, bandgrafptr->r.m.domnnbr * sizeof (Gnum));` uses the OLD mapping's domain count (set by mapInit2 at line 222) although the anchors are `domnnbr` (new count) many. Patched kgraph_band.c (memSet over domnnbr entries): 2->8, 8->2, 4->4, 1->16 all return 0 without sanitizer reports. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate, including the suggested fix (bandparotax + bandvertnbr - domnnbr, domnnbr entries), which I verified. The reverse case (more old parts than new) can additionally write before the array start if r.m.domnnbr > bandvertnbr; I could not construct that case through the public API (source-read only).",
 "fix_options": [
  {
   "label": "memSet the anchors, not the old-part count",
   "summary": "Initialise exactly the domnnbr anchor entries.",
   "patch_sketch": "--- a/src/libscotch/kgraph_band.c\n+++ b/src/libscotch/kgraph_band.c\n@@ -264,7 +264,7 @@\n       errorPrint (\"kgraphBand: out of memory (5)\");\n       goto fail;\n     }\n-    memSet (bandparotax + bandvertnbr - bandgrafptr->r.m.domnnbr, ~0, bandgrafptr->r.m.domnnbr * sizeof (Gnum)); /* Old parts of anchors are unspecified */\n+    memSet (bandparotax + bandvertnbr - domnnbr, ~0, domnnbr * sizeof (Gnum)); /* Old parts of anchors are unspecified */\n     bandparotax -= bandgrafptr->s.baseval;\n     bandgrafptr->r.m.flagval |= MAPPINGINCOMPLETE | MAPPINGFREEPART; /* Remapping may be incomplete */\n     bandgrafptr->r.m.parttax  = bandparotax;\n",
   "tradeoffs": "One-line change; no behaviour change when old and new part counts agree. Tested on 4 old/new combinations.",
   "preferred": true
  },
  {
   "label": "Initialise the whole old-part array",
   "summary": "memSet(bandparotax, ~0, bandvertnbr*sizeof) before the copy loops fill band vertices (lines 352/450).",
   "patch_sketch": "memSet (bandparotax, ~0, bandvertnbr * sizeof (Gnum)); /* all entries unspecified until set */",
   "tradeoffs": "Cost O(bandvertnbr) extra stores (negligible vs band construction); more robust against future changes of the anchor layout.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)
