# G10-mesh-separators

Items: SEP-02, SEP-15, SEP-22, SEP-03, SEP-18, PS-SEP-2, PS-SEP-4



===================================================================
## SEP-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-02",
 "area": "SEP",
 "our_title": "Separator-mesh builder indexes element-load array with node numbers, reading far out of bounds",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/mesh_induce_sepa.c:180-186, 227-233, 347 (call from hmesh_order_nd.c:213)",
 "evidence": "7.0.17 diff of mesh_induce_sepa.c is only `1 << ..` -> `1U << ..`. Lines still read: `if (orgmeshptr->velotax != NULL) {... &indmeshptr->velotax ...}` (:180-186), `indvnloval = orgmeshptr->velotax[orgvnodnum];` (:230), `indmeshptr->velotax[orgindxtax[orgvnodnum]] = indvnloval;` (:232), `vnlosum = (indmeshptr->velotax == NULL) ? ... : indvnlosum` (:347).\nPublic API meshes built by SCOTCH_meshBuild have velotax based at velmbas and vnlotax based at vnodbas (library_mesh.c:369-370), so velotax[orgvnodnum] with orgvnodnum in the node range is out of bounds.\nReproducer work/SEP/t/sep02.c: 30x30 quad mesh, element loads given, element array allocated against an mmap guard page, SCOTCH_meshOrder with the default strategy:\n  ./sep02 30\n  AddressSanitizer: SEGV ... READ memory access\n    #0 _SCOTCHmeshInduceSepa asan/src/libscotch/mesh_induce_sepa.c:230\n    #1 _SCOTCHhmeshOrderNd hmesh_order_nd.c:213\nWithout the guard page ASan itself stays silent (the over-read skips the redzone and lands in other live heap blocks) but UBSan reports `mesh_induce_sepa.c:231:18: signed integer overflow: -1094795586 + -1094795586` i.e. summation of 0xBEBEBEBE malloc-fill garbage.\nWith the one-token-family fix (velotax -> vnlotax, 5 sites) the same runs complete (order=0) with and without node loads.",
 "upstream_change": "",
 "review_accuracy": "Mostly accurate. Not reproduced at 8x8: that mesh has 81 nodes (< 120 threshold of the default strategy) so no separator is ever induced; needs >= ~30x30. The ASan 'heap-buffer-overflow' claim is not what plain ASan shows (non-adjacent over-read; needs a guard page or a small mesh). Also note: meshes loaded with meshLoad share ONE array between velotax and vnlotax (mesh_io.c, `vnlotax = velotax`), so for them the current code reads in bounds; the defect is for meshes built through SCOTCH_meshBuild/BuildElem. The review's Fix (read vnlotax, write vnlotax, leave velotax NULL) is right.",
 "fix_options": [
  {
   "label": "Use vnlotax for node loads (review Fix)",
   "summary": "Allocate/read/write the induced node-load array through vnlotax (based at vnodbas, which meshInduceSepa already shifts), keep velotax NULL, test vnlotax for NULL for the vnlosum shortcut.",
   "patch_sketch": "--- a/src/libscotch/mesh_induce_sepa.c\n+++ b/src/libscotch/mesh_induce_sepa.c\n@@ -177,13 +177,13 @@\n   hashmsk = hashmsk * 4 + 3;                      /* Compute size of node hash table */\n \n   indvertnbr = indvelmnbr + orgsepanbr;           /* Upper bound on number of all vertices */\n-  if (orgmeshptr->velotax != NULL) {\n+  if (orgmeshptr->vnlotax != NULL) {\n     p = memAllocGroup ((void **) (void *)\n           &indmeshptr->verttax, (size_t) (indvertnbr * sizeof (Gnum)), /* verttab is not compact */\n           &indmeshptr->vendtax, (size_t) (indvertnbr * sizeof (Gnum)),\n           &indmeshptr->vnumtax, (size_t) (orgsepanbr * sizeof (Gnum)), /* vnumtab is of size indnodenbr                */\n-          &indmeshptr->velotax, (size_t) (orgsepanbr * sizeof (Gnum)), NULL); /* Element vertices assumed not weighted */\n-    indmeshptr->velotax -= indmeshptr->vnodbas;\n+          &indmeshptr->vnlotax, (size_t) (orgsepanbr * sizeof (Gnum)), NULL); /* Element vertices not weighted (velotax left NULL) */\n+    indmeshptr->vnlotax -= indmeshptr->vnodbas;\n   }\n   else\n     p = memAllocGroup ((void **) (void *)\n@@ -224,12 +224,12 @@\n       orgindxtax[orgvnodnum] = indvnodnum ++;     /* One more node vertex created                */\n     indmeshptr->verttax[orgindxtax[orgvnodnum]] = indedgenum; /* Set beginning of edge sub-array */\n     indmeshptr->vnumtax[orgindxtax[orgvnodnum]] = orgvnodnum - (orgmeshptr->vnodbas - orgmeshptr->baseval);\n-    if (indmeshptr->velotax != NULL) {\n+    if (indmeshptr->vnlotax != NULL) {\n       Gnum                indvnloval;\n \n-      indvnloval  = orgmeshptr->velotax[orgvnodnum];\n+      indvnloval  = orgmeshptr->vnlotax[orgvnodnum];\n       indvnlosum += indvnloval;\n-      indmeshptr->velotax[orgindxtax[orgvnodnum]] = indvnloval;\n+      indmeshptr->vnlotax[orgindxtax[orgvnodnum]] = indvnloval;\n     }\n \n     indenodnum  = indedgenum;                     /* Record position of node edge sub-array */\n@@ -344,7 +344,7 @@\n   indmeshptr->edgetax -= indmeshptr->baseval;\n \n   indmeshptr->velosum = indmeshptr->velmnbr;      /* TODO: account for element weights */\n-  indmeshptr->vnlosum = (indmeshptr->velotax == NULL) ? orgsepanbr : indvnlosum;\n+  indmeshptr->vnlosum = (indmeshptr->vnlotax == NULL) ? orgsepanbr : indvnlosum;\n   indmeshptr->degrmax = orgmeshptr->degrmax;      /* Rough estimate */\n \n   if (orgmeshptr->vnumtax != NULL) {              /* If mesh is a submesh */",
   "tradeoffs": "Pure bug fix; changes the induced mesh representation from \"node loads stored in velotax\" to the documented layout. Tested: 30x30 mesh, with and without element/node loads, runs clean. Add a regression test: meshOrder on a mesh built with SCOTCH_meshBuild + velotab != NULL.",
   "preferred": true
  },
  {
   "label": "Drop node weights in the induced separator mesh",
   "summary": "Stop propagating loads at all: always allocate the group without a load array, leave velotax/vnlotax NULL and set vnlosum = orgsepanbr.",
   "patch_sketch": "-  if (orgmeshptr->velotax != NULL) {\n-    p = memAllocGroup (... &indmeshptr->velotax ...);\n-    indmeshptr->velotax -= indmeshptr->vnodbas;\n-  }\n-  else\n+  /* always unweighted */\n     p = memAllocGroup (... verttax, vendtax, vnumtax, NULL);\n...\n-  indmeshptr->vnlosum = (indmeshptr->velotax == NULL) ? orgsepanbr : indvnlosum;\n+  indmeshptr->vnlosum = orgsepanbr;",
   "tradeoffs": "Smallest code; removes the over-read but silently ignores user node weights when ordering separators (quality/behaviour change for weighted meshes). Not recommended unless weights on separators are deemed irrelevant.",
   "preferred": false
  }
 ],
 "notes": "Likely maintainers choice: the first one; the surrounding code (hmesh_order_nd.c) already builds indmeshdat.vnhlsum = indmeshdat.m.vnlosum, i.e. expects node loads in vnlosum/vnlotax.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-15",
 "area": "SEP",
 "our_title": "Error path after separator-mesh induction frees second member of a grouped allocation",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "Needs a genuine allocation failure inside the separator induction; I injected the failure.",
 "location": "src/libscotch/hmesh_order_nd.c:213-216 (also :155-159)",
 "evidence": "File untouched in 7.0.17. Line 215 is still `memFree (nspmeshdat.frontab);` while parttax is the group leader of memAllocGroup (&parttax, &frontab) at :154-156.\nTest-only injection (meshInduceSepa returns 1 when env INDUCE_FAIL is set) in a copy of the ASan build, SCOTCH_meshOrder on a 30x30 quad mesh (work/SEP/t/sep02.c):\n  ERROR: meshInduceSepa: FAULT INJECTION (test only)\n  ERROR: hmeshOrderNd: cannot build induced subgraph (1)\n  AddressSanitizer: attempting free on address which was not malloc()-ed: 0x525000000848 in thread T0\n    #1 _SCOTCHhmeshOrderNd hmesh_order_nd.c:215\nWith `vmeshExit (&nspmeshdat)` in place of the memFree the invalid free is gone. Also by reading: the earlier `return (1)` at :158 (group allocation failure) and the leaf-ordering path do not call meshFree for nspmeshdat.m, so a halo-less vendtax (MESHFREEVEND set by hmeshMesh) leaks.",
 "upstream_change": "",
 "review_accuracy": "Accurate (review Fix 'vmeshExit (&nspmeshdat)' works; the vendtax leak is real for halo meshes and also on the :158 early return).",
 "fix_options": [
  {
   "label": "vmeshExit on the error path (review Fix)",
   "summary": "Replace the interior memFree by vmeshExit (&nspmeshdat) (frees parttax group leader and the mesh data); also meshFree (&nspmeshdat.m) on the allocation-failure return.",
   "patch_sketch": "--- a/src/libscotch/hmesh_order_nd.c\n+++ b/src/libscotch/hmesh_order_nd.c\n@@ -156,6 +156,7 @@\n                       &nspmeshdat.parttax, (size_t) (vertnbr * sizeof (GraphPart)),\n                       &nspmeshdat.frontab, (size_t) (vertnbr * sizeof (Gnum)), NULL) == NULL) {\n     errorPrint (\"hmeshOrderNd: out of memory (1)\");\n+    meshFree   (&nspmeshdat.m);                   /* Free halo-less vendtab, if any */\n     return (1);\n   }\n   memSet (nspmeshdat.parttax, 0, vertnbr * sizeof (GraphPart)); /* Set all vertices to part 0 */\n@@ -212,7 +213,7 @@\n \n     if (meshInduceSepa (&nspmeshdat.m, nspmeshdat.parttax, nspmeshdat.fronnbr, nspmeshdat.frontab, &indmeshdat.m) != 0) {\n       errorPrint (\"hmeshOrderNd: cannot build induced subgraph (1)\");\n-      memFree    (nspmeshdat.frontab);            /* Free remaining space */\n+      vmeshExit  (&nspmeshdat);                   /* Free parttab/frontab group leader and mesh data */\n       return (1);\n     }\n     indmeshdat.vnohnbr = indmeshdat.m.vnodnbr;    /* Fill halo mesh structure of non-halo mesh */",
   "tradeoffs": "Pure error-path change. Tested with injection: invalid free gone.",
   "preferred": true
  },
  {
   "label": "Explicit leader free",
   "summary": "Keep the structure, but free the group through its leader and the mesh separately: `memFree (nspmeshdat.parttax + nspmeshdat.m.baseval); meshFree (&nspmeshdat.m);`",
   "patch_sketch": "-      memFree    (nspmeshdat.frontab);\n+      memFree    (nspmeshdat.parttax + nspmeshdat.m.baseval);\n+      meshFree   (&nspmeshdat.m);",
   "tradeoffs": "Equivalent; duplicates what vmeshExit does, so slightly more fragile if Vmesh gains fields.",
   "preferred": false
  }
 ],
 "notes": "Precedent: the other error exit of the same function (cblktab allocation failure, :171-173) already calls vmeshExit (&nspmeshdat).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-22",
 "area": "SEP",
 "our_title": "Several separator routines return on failure without freeing tables or ignore a callee's error",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Needs forced allocation failures in the FM resize, induced-mesh and ordering allocations.",
 "location": "vgraph_separate_fm.c:202 (ignored result), :587-590 (leak); mesh_induce_sepa.c:205-207; hmesh_order_nd.c:156-159",
 "evidence": "(1) vgraph_separate_fm.c:202 `vgraphSeparateGg (grafptr, &paradat);` still discards an int that can be 1 (vgraphSeparateGg returns int, :90-93); :587-590 `if (vgraphSeparateFmResize (...) != 0) { errorPrint (\"vgraphSeparateFm: out of memory (2)\"); return (1); }` returns without memFree (hashtab) / gainTablExit (tablptr) (compare with bgraph_bipart_fm.c:598-603 which cleans first). The resize is not reached on ordinary inputs (hash sized 16*(fronnbr+movenbr+degrmax)), so not run.\n(2) mesh_induce_sepa.c:205-207: if the first memAllocGroup (verttax/vendtax/vnumtax) succeeded and the second (indedgetax,...) fails, `p == 0 -> return (1)` leaks the first group.\n(3) hmesh_order_nd.c:156-159 returns after a failed memAllocGroup without meshFree (&nspmeshdat.m) (leaks the halo-less vendtax created by hmeshMesh).\nPatches compile and the ordering/partition regression runs (sep02, sep01) are unchanged.",
 "upstream_change": "",
 "review_accuracy": "Accurate on all three sites. (The mesh_induce_sepa and hmeshOrderNd leaks were not triggered at runtime - they need an allocation failure; one related invalid free in hmeshOrderNd is SEP-15.)",
 "fix_options": [
  {
   "label": "Local cleanup + propagate result",
   "summary": "Free hashtab/gain table on the resize failure, test the result of vgraphSeparateGg, free the first induced group when the second allocation fails, meshFree (&nspmeshdat.m) in hmeshOrderNd (see SEP-15 patch).",
   "patch_sketch": "--- a/src/libscotch/vgraph_separate_fm.c\n+++ b/src/libscotch/vgraph_separate_fm.c\n@@ -199,7 +199,8 @@\n       VgraphSeparateGgParam paradat;\n \n       paradat.passnbr = 4;                        /* Use a standard algorithm */\n-      vgraphSeparateGg (grafptr, &paradat);\n+      if (vgraphSeparateGg (grafptr, &paradat) != 0) /* Propagate failure of initial partitioning */\n+        return (1);\n       if (grafptr->fronnbr == 0)                  /* If new partition has no frontier */\n         return (0);                               /* This algorithm is still useless  */\n     }\n@@ -587,6 +588,8 @@\n       if (hashnbr >= hashmax) {\n         if (vgraphSeparateFmResize (&hashtab, &hashmax, &hashmsk, &savetab, savenbr, tablptr, &lockdat) != 0) {\n           errorPrint (\"vgraphSeparateFm: out of memory (2)\");\n+          memFree    (hashtab);                   /* Free group leader */\n+          gainTablExit (tablptr);\n           return (1);\n         }\n       }\n--- a/src/libscotch/mesh_induce_sepa.c\n+++ b/src/libscotch/mesh_induce_sepa.c\n@@ -201,6 +201,8 @@\n           &indvneltax, (size_t) (indvelmnbr    * sizeof (Gnum)),\n           &orgindxtax, (size_t) (orgvertnbr    * sizeof (Gnum)),\n           &hashtab,    (size_t) ((hashmsk + 1) * sizeof (MeshInduceSepaHash)), NULL);\n+    if (p == 0)                                   /* If second group could not be allocated */\n+      memFree (indmeshptr->verttax + indmeshptr->baseval); /* Free first group leader       */\n   }\n   if (p == 0) {\n     errorPrint (\"meshInduceSepa: out of memory (2)\"); /* Allocate induced mesh graph structure */",
   "tradeoffs": "Straightforward; behaviour change only in failure cases (the Gg failure is now reported instead of silently continuing with an unbalanced partition). Compiled and regression-tested; failure paths not executed.",
   "preferred": true
  },
  {
   "label": "Introduce fail labels",
   "summary": "Restructure each function to a single `fail:` exit performing all frees (as done in several other separators) and make every error return go through it.",
   "patch_sketch": "/* vgraphSeparateFm: replace the three `return (1)` after allocation with `o = 1; goto fail;` and free in `fail:` */",
   "tradeoffs": "Covers the debug-only internal-error returns too; bigger diff and more review burden. Not compiled.",
   "preferred": false
  }
 ],
 "notes": "Precedent: graph/ordering code in the repo is full of `memFree (...); return (1)` blocks at the failure site; option 1 is that idiom.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-03",
 "area": "SEP",
 "our_title": "Mesh coarsener never reports failure to shrink, so multilevel recursion overflows the stack",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/vmesh_separate_ml.c:93-98; src/libscotch/mesh_coarsen.c:95-166 (coarnbr/coarrat unused, always return 0 at :346)",
 "evidence": "7.0.17 changes to mesh_coarsen.c: only removal of the debug fprintf (0328b08). meshCoarsen() still never reads `coarnbr` or `coarrat` (grep: only in the prototype) and its only returns are 2 (alloc errors) and 0.\nReproducer work/SEP/t/sep03.c: 300 disjoint triangle elements (900 private nodes), SCOTCH_meshOrder with the DEFAULT strategy against the pristine ASan lib:\n  ./sep03 300\n  AddressSanitizer: stack-overflow ... in _SCOTCHmemAllocGroup common_memory.c:508 <- _SCOTCHmeshCoarsen mesh_coarsen.c:151 <- vmeshSeparateMlCoarsen vmesh_separate_ml.c:96 <- vmeshSeparateMl2 :221 <- vmeshSeparateMl2 :223 ... (245 frames of the recursion)\nSame with an explicit separation-only strategy n{sep=m{vnod=100,low=h{pass=10},asc=f{bal=0.2}},ole=s,ose=s}.\nWith the patch (return 1 when the element count did not drop to <= coarrat*velmnbr) the same run returns order=0 and 30x30 / 70x70 grid meshes give bit-identical orderings to pristine (hash a9fe29d1a6528625 and 8eb4e4eaea8cc125 both ways), i.e. no regression on meshes that coarsen.",
 "upstream_change": "",
 "review_accuracy": "Accurate (stack overflow reproduced; unused coarnbr/coarrat confirmed; uninitialised finemulttax after a matcher hash allocation failure confirmed by reading: meshCoarsenMatchNg sets *coarvelmptr = velmnbr and returns without filling finemulttax). The suggested Fix works; it also covers the alloc-failure case because that path reports 'no element merged'. Side observation: with the default strategy, 30-100 disjoint triangles abort earlier with 'ERROR: hallOrderHdR2Halmd: internal error (2)' (errorexit lib => exit(1)); that is a different defect (halo minimum-degree ordering of an all-isolated-element mesh) and was not analysed.",
 "fix_options": [
  {
   "label": "Ratio check inside meshCoarsen (graphCoarsen idiom)",
   "summary": "After the matching call, if the number of coarse elements is not <= coarrat * velmnbr (or no element merged at all), free the work arrays and return 1 (\"cannot coarsen\"). The ML driver already maps return 1 to \"stop here and run the low strategy\".",
   "patch_sketch": "--- a/src/libscotch/mesh_coarsen.c\n+++ b/src/libscotch/mesh_coarsen.c\n@@ -165,6 +165,13 @@\n \n   meshCoarsenFuncTab[coartype] (finemeshptr, finemulttax, finecoartax, &coarvelmnbr, &coarvnodnbr, &coaredgenbr, contptr); /* Call proper matching function */\n \n+  if ((coarvelmnbr >= finemeshptr->velmnbr) ||    /* If no element could be merged (or matching failed), or if */\n+      ((double) coarvelmnbr > (coarrat * (double) finemeshptr->velmnbr))) { /* coarsening ratio not achieved */\n+    memFree (coarverttax);                        /* Free group leader        */\n+    memFree (finecoartax + finemeshptr->baseval); /* Free multinode array too */\n+    return  (1);                                  /* Mesh cannot be coarsened */\n+  }\n+\n #ifndef DEAD_CODE\n   coarvnodnbr = finemeshptr->vnodnbr;             /* TODO : coarvnodnbr estimator is wrong : too tight */\n   coaredgenbr = finemeshptr->edgenbr;",
   "tradeoffs": "Restores the documented contract (return 1 if the mesh could not be coarsened). Behaviour change: meshes whose matching only reaches a ratio above coarrat (default 0.8, vmesh_separate_st.c:99) now stop one level earlier and run the low strategy there; slight quality shifts possible on such meshes (none seen on 30x30 / 70x70 grids). Tested: identical orderings on grid meshes, overflow gone. Needs a unit test with disjoint elements.",
   "preferred": true
  },
  {
   "label": "Strict no-progress check only",
   "summary": "Same place, but test only `coarvelmnbr >= finemeshptr->velmnbr` (nothing merged), ignoring coarrat.",
   "patch_sketch": "+  if (coarvelmnbr >= finemeshptr->velmnbr) {\n+    memFree (coarverttax);\n+    memFree (finecoartax + finemeshptr->baseval);\n+    return  (1);\n+  }",
   "tradeoffs": "Minimal behaviour change (only stalled levels stop) but still allows many slow levels (each shrinking by 1 element) before the recursion ends, so deep recursion remains possible on pathological meshes.",
   "preferred": false
  },
  {
   "label": "Caller-side check in vmeshSeparateMlCoarsen",
   "summary": "Leave meshCoarsen as is; after it returns 0 compare coarmeshptr->m.velmnbr against finemeshptr->m.velmnbr * paraptr->coarrat and, if not smaller enough, meshExit the coarse mesh, free *finecoarptr and return 1.",
   "patch_sketch": "+  if (coarmeshptr->m.velmnbr > (Gnum) (paraptr->coarrat * (double) finemeshptr->m.velmnbr)) {\n+    meshExit (&coarmeshptr->m);\n+    memFree  (*finecoarptr + finemeshptr->m.baseval);\n+    return   (1);\n+  }",
   "tradeoffs": "Keeps the mesh module untouched but wastes a full coarse-mesh build before rejecting it and leaves the uninitialised-finemulttax hazard inside meshCoarsen. Not preferred.",
   "preferred": false
  }
 ],
 "notes": "Maintainers precedent: graphCoarsen() returns 1 when the ratio coarval cannot be met (graph_coarsen.c:598-603, 659-664), and the Mesh prototype documents `1 : if the mesh could not be coarsened`.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-18",
 "area": "SEP",
 "our_title": "Stray stderr print remains in overlap FM; the mesh coarsening print was removed",
 "claimed_severity": "low",
 "status": "partially-fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read is conclusive for the print; whether the following write can overrun would need fuzzing.",
 "location": "src/libscotch/wgraph_part_fm.c:857-858 (remaining); mesh_coarsen.c:431 (removed); also vmesh_separate_fm.c:155 (not in the review)",
 "evidence": "FIXED part: mesh_coarsen.c no longer contains the `fprintf (stderr, \"++ %ld %ld\\n\", ...) /* TODO REMOVE */` line (grep: no fprintf in mesh_coarsen.c).\nREMAINING: wgraph_part_fm.c:857-858 `if (savedat.savenbr >= savedat.savesiz)\\n fprintf (stderr, \"OUCH\\n\");` immediately before `savedat.savetab[savedat.savenbr].u.loaddat.loadval = frlosum;`. Each move is preceded by wgraphPartFmSaveClaim (line 682) which reserves the slots, so the overrun is probably impossible in practice, but the check only prints.\nNEW (not in the review): vmesh_separate_fm.c:154-156 inside vmeshSeparateFmResize: `/* TODO */ fprintf (stderr, \"hertnum no longer valid !\\n\"); exit (1);` unconditionally after a successful realloc. It is currently shielded by `/* TODO */ hashmax *= 4;` at :362 so resizing is not reached in my 60x60/120x120 mesh orderings, but any path that does resize terminates the host process.",
 "upstream_change": "a mesh_coarsen.c part: 0328b08 \"Clean-up\" (removes the stderr print).",
 "review_accuracy": "Accurate when written; one of the two sites was cleaned up by upstream in 7.0.17. The 'unguarded out-of-bounds savetab write' is not demonstrated: the claim/reservation scheme (wgraphPartFmSaveClaim) appears to make it unreachable; I did not fuzz it.",
 "fix_options": [
  {
   "label": "Delete the print, keep a debug-only check",
   "summary": "Remove the OUCH fprintf; the neighbouring writes already have `#ifdef SCOTCH_DEBUG_WGRAPH2 if (savenbr >= savesiz) { errorPrint (\"wgraphPartFm: internal error (N)\"); goto fail; }`, so add the same block for this write.",
   "patch_sketch": "-          if (savedat.savenbr >= savedat.savesiz)\n-            fprintf (stderr, \"OUCH\\n\");\n+#ifdef SCOTCH_DEBUG_WGRAPH2\n+          if (savedat.savenbr >= savedat.savesiz) {\n+            errorPrint (\"wgraphPartFm: internal error (9)\");\n+            goto fail;\n+          }\n+#endif /* SCOTCH_DEBUG_WGRAPH2 */",
   "tradeoffs": "No release-mode behaviour change; consistent with the other two guards at :826 and :842.",
   "preferred": true
  },
  {
   "label": "Turn it into a real runtime check",
   "summary": "Make the check unconditional: errorPrint + goto fail when savenbr >= savesiz.",
   "patch_sketch": "+          if (savedat.savenbr >= savedat.savesiz) {\n+            errorPrint (\"wgraphPartFm: save table overflow\");\n+            goto fail;\n+          }",
   "tradeoffs": "Protects release builds against a hypothetical overrun at the price of a compare per move. ",
   "preferred": false
  }
 ],
 "notes": "For the extra vmesh FM item a fix is a separate task (implement the hertnum translation or replace exit(1) by errorPrint + return 1); not part of this finding.",
 "history": {
  "reported": "reported",
  "7.0.17": "partially-fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## PS-SEP-2

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-SEP-2",
 "our_title": "Mesh FM hash-resize routine unconditionally prints a message and calls exit(1)",
 "severity": "medium",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/vmesh_separate_fm.c:154-156 (shielded by hashmax *= 4 at :362)",
 "evidence": "`/* TODO */ fprintf (stderr, \"hertnum no longer valid !\\n\"); exit (1);` follows the realloc in vmeshSeparateFmResize, before the address-adjustment code. Resizing was not reached in my 60x60/120x120 mesh orderings.",
 "related_review_ids": [
  "SEP-18"
 ],
 "fix_options": [
  {
   "label": "Finish hertnum translation",
   "summary": "Implement the hash-index to vertex translation back after realloc and delete the exit.",
   "patch_sketch": "/* after rebuilding hash: translate savetab[].hertnum back via new hash lookups; remove fprintf/exit */",
   "tradeoffs": "Real work and tests needed.",
   "preferred": true
  },
  {
   "label": "Fail cleanly",
   "summary": "Replace exit(1) by errorPrint and return 1 so the caller cleans up.",
   "patch_sketch": "-  fprintf (stderr, ...);\n-  exit    (1);\n+  errorPrint (\"vmeshSeparateFmResize: resizing not implemented\");\n+  return (1);",
   "tradeoffs": "Turns a process kill into an error; resize still unusable.",
   "preferred": false
  }
 ],
 "area": "SEP"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## PS-SEP-4

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-SEP-4",
 "our_title": "Default mesh ordering aborts with an internal error on meshes made of disjoint elements",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/hall_order_hd.c (message 'hallOrderHdR2Halmd: internal error (2)')",
 "evidence": "work/SEP/t/sep03.c with 30, 45 and 100 disjoint triangles and the default strategy on pristine 7.0.17 prints 'ERROR: hallOrderHdR2Halmd: internal error (2)' (errorexit lib exits). Cause not analysed.",
 "related_review_ids": [
  "SEP-03"
 ],
 "fix_options": [
  {
   "label": "Investigate halo minimum-degree on isolated elements",
   "summary": "Find which invariant of hallOrderHdR2Halmd the isolated-element mesh violates and handle it.",
   "patch_sketch": "n/a (root cause not analysed)",
   "tradeoffs": "Needs debugging.",
   "preferred": true
  },
  {
   "label": "Pre-filter isolated elements",
   "summary": "Strip isolated elements before the halo ordering.",
   "patch_sketch": "n/a",
   "tradeoffs": "Speculative.",
   "preferred": false
  }
 ],
 "area": "SEP"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)
