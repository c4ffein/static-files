# G29-cmake-sources-config

Items: BLD-01, BLD-02, BLD-12, BLD-13, BLD-24, BLD-25, BLD-06, PS-BLD-2



===================================================================
## BLD-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-01",
 "area": "BLD",
 "our_title": "Five libscotch sources compiled by the Makefile appear in no CMake source list",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "external-dependency",
 "needs_note": "Configure with cmake and run nm on the resulting libscotch for SCOTCH_contextBindMesh and the Fortran wrappers.",
 "location": "src/libscotch/CMakeLists.txt:151 (SCOTCH_C_SOURCES)",
 "evidence": "Loop over src/libscotch/*.c checking whether each name appears in src/libscotch/CMakeLists.txt gave, besides textual-include templates (common_psort.c, common_sort.c, dgraph_band_grow.c, dgraph_halo_fill.c, dgraph_match_scan.c, graph_coarsen_edge.c, graph_match_scan.c, hgraph_induce_edge.c), exactly the five from the review: hgraph_dump.c, library_context_mesh.c, library_context_mesh_f.c, library_graph_induce_f.c, library_memory_f.c. The 7.0.17 Makefile lists them (src/libscotch/Makefile:376 hgraph_dump, 431-432 library_context_mesh[_f], 449 library_graph_induce_f, 470 library_memory_f). Makefile build of 7.0.17 (cp Make.inc/Makefile.inc.x86-64_pc_linux2, CCD=mpicc, make -j8 scotch ptscotch): `nm lib/libscotch.a | grep -i ' T .*contextBindMesh'` -> `T SCOTCH_contextBindMesh`, `T SCOTCHFCONTEXTBINDMESH`, `T scotchfgraphinducelist[_,__]`, `T scotchfmemcur[_,__]` all present; none of these object files can exist in a CMake build since no CMake source list names them (grep of all CMakeLists.txt/*.cmake for the five basenames: only library_dgraph_induce_f.c matches, a different file). scotch.h:235 declares int SCOTCH_contextBindMesh(...). cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; the CMake-side absence is therefore from reading the source list, not from nm on a CMake library.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. Minor: hgraph_dump.c is an internal/debug helper (hgraphDump), not public API; the other four define public symbols (SCOTCH_contextBindMesh, Fortran wrappers).",
 "fix_options": [
  {
   "label": "Add the five files to SCOTCH_C_SOURCES",
   "summary": "List the missing .c (and hgraph_dump.h) in the existing alphabetical block.",
   "patch_sketch": "--- a/src/libscotch/CMakeLists.txt\n+++ b/src/libscotch/CMakeLists.txt\n@@ hgraph_check.h\n+  hgraph_dump.c\n+  hgraph_dump.h\n@@ library_context.c\n+  library_context_mesh.c\n+  library_context_mesh_f.c\n@@ library_graph_induce.c\n+  library_graph_induce_f.c\n@@ library_memory.c\n+  library_memory_f.c",
   "tradeoffs": "Zero risk for existing users; adds 5 objects and 4+ exported symbols to CMake builds, making them match Makefile builds. A test linking SCOTCH_contextBindMesh / scotchfgraphinducelist_ under CMake should be added.",
   "preferred": true
  },
  {
   "label": "CI guard that diffs Makefile object list vs CMake source list",
   "summary": "Add ci/check_sources.sh: extract `xxx$(OBJ)` names from src/libscotch/Makefile (LIBSCOTCHDEPS block) and basenames from SCOTCH_C_SOURCES/PTSCOTCH_C_SOURCES; fail on any asymmetric difference. Run it in the cmake pipeline.",
   "patch_sketch": "comm -3 <(sed -n 's/^[[:space:]]*\\([a-z0-9_]*\\)\\$(OBJ).*/\\1.c/p' src/libscotch/Makefile | sort -u) <(grep -o '[a-z0-9_]*\\.c' src/libscotch/CMakeLists.txt | sort -u) | grep . && exit 1",
   "tradeoffs": "Prevents recurrence but alone does not fix the defect; needs an allow-list for textual-include files and for per-flag files.",
   "preferred": false
  },
  {
   "label": "Single-source list shared by both build systems",
   "summary": "Generate the CMake list from a single file (e.g. src/libscotch/sources.cmake generated from the Makefile) or have the Makefile read it.",
   "patch_sketch": "include(sources.cmake)  # produced by a maintainer script from the Makefile",
   "tradeoffs": "Structural; invasive for a project that hand-maintains both systems; unlikely to be accepted.",
   "preferred": false
  }
 ],
 "notes": "Preferred: add the files. Idiom: CMakeLists already enumerates every .c/.h by hand (including *_f.c), so completing the list is the maintainers' own convention; the CI diff (option 2) can be added on top.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-02",
 "area": "BLD",
 "our_title": "Installed CMake package config unconditionally includes esmumps target files that suffixed builds never install",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Install with SCOTCH_NAME_SUFFIX set under cmake, then run find_package(SCOTCH) from a consumer project.",
 "location": "cmake/SCOTCHConfig.cmake.in:85-92; src/CMakeLists.txt:224",
 "evidence": "7.0.17 src/CMakeLists.txt:224-226: `if(BUILD_LIBESMUMPS AND NOT USE_SUFFIX) add_subdirectory(esmumps) endif()`; CMakeLists.txt:86-88 sets USE_SUFFIX ON when SCOTCH_NAME_SUFFIX non-empty and leaves BUILD_LIBESMUMPS (option default ON, line 99) untouched. src/esmumps/CMakeLists.txt:134 is the only `install(EXPORT esmumpsTargets` (and :174 ptesmumpsTargets), so with a suffix those files are never installed. cmake/SCOTCHConfig.cmake.in:85-92 is configured with @BUILD_LIBESMUMPS@ (still ON) and does `include(\"${CMAKE_CURRENT_LIST_DIR}/esmumpsTargets.cmake\")` (and ptesmumpsTargets.cmake) with no OPTIONAL. include() of a missing file is a hard error in a config file, so find_package(SCOTCH) fails. cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; this is source-read; the control flow is straight-line so confidence is high but it was not executed.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate (line numbers still right). Note the same flaw applies to ptesmumpsTargets.cmake (line 90), which the review mentions only implicitly.",
 "fix_options": [
  {
   "label": "Make the config guard match what is built",
   "summary": "Pass the effective value to configure_package_config_file: compute `set(INSTALL_LIBESMUMPS ON)` only when BUILD_LIBESMUMPS AND NOT USE_SUFFIX and use @INSTALL_LIBESMUMPS@ in SCOTCHConfig.cmake.in.",
   "patch_sketch": "--- a/cmake/SCOTCHConfig.cmake.in\n-if(@BUILD_LIBESMUMPS@)\n+if(@BUILD_ESMUMPS_EFFECTIVE@)\n--- a/src/CMakeLists.txt\n+if(BUILD_LIBESMUMPS AND NOT USE_SUFFIX)\n+  set(BUILD_ESMUMPS_EFFECTIVE ON)\n+else()\n+  set(BUILD_ESMUMPS_EFFECTIVE OFF)\n+endif()",
   "tradeoffs": "Config always matches the installed targets; no behavior change for non-suffixed installs. Needs a CI job with SCOTCH_NAME_SUFFIX (see BLD-14).",
   "preferred": true
  },
  {
   "label": "Use include(... OPTIONAL)",
   "summary": "Make the three esmumps/ptesmumps includes tolerant of missing files.",
   "patch_sketch": "-  include(\"${CMAKE_CURRENT_LIST_DIR}/esmumpsTargets.cmake\")\n+  include(\"${CMAKE_CURRENT_LIST_DIR}/esmumpsTargets.cmake\" OPTIONAL)",
   "tradeoffs": "One-line; but SCOTCH_LIBESMUMPS_FOUND would still be set ON for a suffixed install, which is wrong, and typos in install layout would be silently accepted.",
   "preferred": false
  },
  {
   "label": "Fix at the source: make the suffix not disable esmumps",
   "summary": "Teach src/esmumps to honour SCOTCH_NAME_SUFFIX (it uses the scotch.h rename macros) and drop the `NOT USE_SUFFIX` guard.",
   "patch_sketch": "-if(BUILD_LIBESMUMPS AND NOT USE_SUFFIX)\n+if(BUILD_LIBESMUMPS)",
   "tradeoffs": "Changes what suffixed builds produce; esmumps interface names are fixed by MUMPS so a suffix probably cannot apply -- a maintainers' design decision, high risk.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1: the repo already keeps config in sync via @VAR@ substitution (see @BUILD_PTSCOTCH@ etc.), and the existing guard in src/CMakeLists.txt is deliberate.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-12",
 "area": "BLD",
 "our_title": "metis.h generation rule is attached to two library targets with no dependency on the header target",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Run a parallel cmake build with the Makefile generator many times and look for concurrent writes of metis.h.",
 "location": "src/libscotchmetis/CMakeLists.txt:54-62, 89, 111",
 "evidence": "7.0.17: custom command OUTPUT ${GENERATED_INCLUDE_DIR}/metis.h (line ~54) with target metis_h (line 61). In `foreach(version 3 5)` both add_library(scotchmetisv3/v5 ...) list `${GENERATED_INCLUDE_DIR}/metis.h` as a source (line ~89) and `add_dependencies(scotchmetisv${version} scotch_h metisf_h)` (line 111) -- metis_h is never a dependency of anything (grep metis_h across CMakeLists: only its definition). CMake's own add_custom_command documentation says not to list one OUTPUT in several independent targets for exactly this reason, so with the Makefile generator both libraries carry the rule and can run dummysizes -> metis.h concurrently under make -j. parmetis.h has a single consumer (ptscotchparmetisv3) plus adm2dgr which depends on parmetis_h (line 227), so only metis.h is shared in the problematic way (metisf.h is safe: metisf_h is a dependency). cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; the race itself was not demonstrated; the structure is confirmed.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate for metis.h; the review's mention of parmetis_h is a cleanup (parmetis.h has just one library consumer), not a race.",
 "fix_options": [
  {
   "label": "Depend on the driver target",
   "summary": "add_dependencies(scotchmetisv${version} scotch_h metis_h metisf_h).",
   "patch_sketch": "-  add_dependencies(scotchmetisv${version} scotch_h metisf_h)\n+  add_dependencies(scotchmetisv${version} scotch_h metis_h metisf_h)",
   "tradeoffs": "Standard CMake remedy: header generated once by metis_h before both libs build. No behavior change.",
   "preferred": true
  },
  {
   "label": "Generate both headers from one target and drop them from sources",
   "summary": "Remove metis.h/metisf.h from the add_library() source lists and keep only the dependency, mirroring how scotch.h's consumers behave.",
   "patch_sketch": "    ${GENERATED_INCLUDE_DIR}/scotch.h\n-    ${GENERATED_INCLUDE_DIR}/metis.h\n-    ${GENERATED_INCLUDE_DIR}/metisf.h)",
   "tradeoffs": "Removes the per-target rule attachment entirely; but PUBLIC_HEADER install property still names the files and needs GENERATED set (already set via set_source_files_properties), so verify install.",
   "preferred": false
  },
  {
   "label": "One ALL header target for both headers",
   "summary": "Create add_custom_target(metis_headers ALL DEPENDS metis.h metisf.h) and make both libraries depend on it.",
   "patch_sketch": "add_custom_target(metis_headers ALL DEPENDS ${GENERATED_INCLUDE_DIR}/metis.h ${GENERATED_INCLUDE_DIR}/metisf.h)\nadd_dependencies(scotchmetisv${version} metis_headers)",
   "tradeoffs": "Equivalent to option 1 with one extra target; not run (no cmake).",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (the file already has add_dependencies(... metisf_h); metis_h was simply forgotten).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-13",
 "area": "BLD",
 "our_title": "Declared CMake minimum is older than commands and imported targets the build files use",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Configure with CMake 3.10 through 3.17 and observe the failures.",
 "location": "CMakeLists.txt:44; src/check/CMakeLists.txt:69, 289; README.md:70",
 "evidence": "7.0.17 CMakeLists.txt:44 `cmake_minimum_required(VERSION 3.10)`; src/check/CMakeLists.txt:69 `get_filename_component(file_we ${src} NAME_WLE)` (NAME_WLE: CMake 3.14) and :289 `${CMAKE_COMMAND} -E cat` (cmake -E cat: 3.18); README.md:70 'With CMake, using version 3.10 or higher'. Additional beyond the review (from my knowledge of CMake, not verified here): src/libscotch/CMakeLists.txt:570 links `LibLZMA::LibLZMA` which FindLibLZMA only provides since 3.14; ci/test_cmake.sh uses `ctest --output-junit` (3.21; CI-only). cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; no old-CMake run was possible.",
 "upstream_change": "7.0.17 changed ci/test_cmake.sh (adds --output-on-failure) -- unrelated",
 "review_accuracy": "Accurate. Facts about which CMake release introduced each feature come from CMake docs knowledge, not from running old versions.",
 "fix_options": [
  {
   "label": "Raise the minimum to 3.18 and update docs",
   "summary": "cmake_minimum_required(VERSION 3.18) and README/INSTALL text.",
   "patch_sketch": "-cmake_minimum_required(VERSION 3.10)\n+cmake_minimum_required(VERSION 3.18)\n README.md:70 'version 3.18 or higher'",
   "tradeoffs": "Honest and simple; drops users on RHEL7/Ubuntu 18.04 era CMake. Maintainers decide support floor.",
   "preferred": true
  },
  {
   "label": "Keep 3.10 for the library, require 3.18 only for tests",
   "summary": "Move the high requirement into src/check: `if(CMAKE_VERSION VERSION_LESS 3.18) message(WARNING ...) skip tests`.",
   "patch_sketch": "if(ENABLE_TESTS AND CMAKE_VERSION VERSION_LESS 3.18)\n  message(FATAL_ERROR \"ENABLE_TESTS needs CMake >= 3.18\")\nendif()",
   "tradeoffs": "Preserves the promise for library-only builds; must also guard the LibLZMA::LibLZMA use (3.14).",
   "preferred": false
  },
  {
   "label": "Use 3.10-compatible constructs",
   "summary": "Replace NAME_WLE by `get_filename_component(file_we ${src} NAME)` + `string(REGEX REPLACE \"\\\\.[^.]*$\" \"\" ...)`; replace `-E cat` by a small cmake -P script or `file(READ/WRITE)`.",
   "patch_sketch": "get_filename_component(file_name ${src} NAME)\nstring(REGEX REPLACE \"\\\\.[^.]+$\" \"\" file_we \"${file_name}\")",
   "tradeoffs": "Keeps the stated floor but needs CI on CMake 3.10 to stay true.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1: the project already uses recent features everywhere; raising the declared minimum is the least invasive truth-in-advertising fix.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-24

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-24",
 "area": "BLD",
 "our_title": "Library target exports determinism and FreeBSD compile definitions as public to downstream consumers",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Install with cmake and inspect the exported target's INTERFACE_COMPILE_DEFINITIONS.",
 "location": "src/libscotch/CMakeLists.txt:542, 546-547, 550",
 "evidence": "7.0.17: `target_compile_definitions(scotch PUBLIC cpu_set_t=cpuset_t __BSD_VISIBLE)` (542, FreeBSD), `... PUBLIC COMMON_RANDOM_FIXED_SEED` (546, 550) and `PUBLIC SCOTCH_DETERMINISTIC` (547). All other feature definitions (GZ, BZ2, LZMA, PTHREAD) in the same file are PRIVATE (lines ~560-580). Caveat found by reading consumers: src/check/test_common_random.c:162 tests `COMMON_RANDOM_FIXED_SEED || SCOTCH_DETERMINISTIC`, and in-tree tests include internal headers (common_thread.h uses cpu_set_t at :84 inside struct), so the in-tree tests rely on the PUBLIC visibility. A plain PRIVATE switch would change test behavior; BUILD_INTERFACE-only exposure is needed. Not run (no cmake).",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate for external consumers; the proposed 'make them PRIVATE' fix would break in-tree tests (test_common_random.c, tests that include common_thread.h) unless exposed via $<BUILD_INTERFACE:...>.",
 "fix_options": [
  {
   "label": "PRIVATE + BUILD_INTERFACE for in-tree users",
   "summary": "Define them PRIVATE on scotch and `$<BUILD_INTERFACE:...>` on INTERFACE so only targets in this build tree see them.",
   "patch_sketch": "-  target_compile_definitions(scotch PUBLIC COMMON_RANDOM_FIXED_SEED)\n+  target_compile_definitions(scotch PRIVATE COMMON_RANDOM_FIXED_SEED)\n+  target_compile_definitions(scotch INTERFACE $<BUILD_INTERFACE:COMMON_RANDOM_FIXED_SEED>)",
   "tradeoffs": "Installed package stops leaking; in-tree tests unchanged. Check the generated export for empty INTERFACE entries.",
   "preferred": true
  },
  {
   "label": "Export a separate test-only interface target",
   "summary": "Add `scotch_internal` INTERFACE target carrying the definitions; link tests to it; scotch itself keeps them PRIVATE.",
   "patch_sketch": "add_library(scotch_internal INTERFACE)\ntarget_compile_definitions(scotch_internal INTERFACE ...)\ntarget_link_libraries(test_* PRIVATE scotch_internal)",
   "tradeoffs": "Cleanest separation; touches every add_test_scotch call site.",
   "preferred": false
  },
  {
   "label": "Leave cpu_set_t/__BSD_VISIBLE PUBLIC, privatize only the determinism macros",
   "summary": "FreeBSD rename is only needed by headers that expose cpu_set_t -- verify; the determinism macros are library-internal.",
   "patch_sketch": "split the two blocks",
   "tradeoffs": "Partial; needs FreeBSD to validate.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (BUILD_INTERFACE is already used for include directories in the same file).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-25

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-25",
 "area": "BLD",
 "our_title": "CMake FreeBSD test has a stray brace and the index-size error text names the wrong quantity",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Run cmake on FreeBSD or with a faked host name to observe the condition.",
 "location": "src/CMakeLists.txt:67, 131",
 "evidence": "7.0.17 line 67: `if(${CMAKE_HOST_SYSTEM_NAME}} MATCHES \"^.*FreeBSD.*$\")` -- stray `}` makes the left operand 'FreeBSD}' on FreeBSD, which still matches the regex, so it works by accident; line 131: IDXSIZE branch `message(FATAL_ERROR \"Invalid integer size value\")` (copied from INTSIZE at line 118). Not run (no cmake).",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. (Line 118 is the correct INTSIZE message; only 131 is wrong.)",
 "fix_options": [
  {
   "label": "Fix both",
   "summary": "Remove the brace and fix the message.",
   "patch_sketch": "-if(${CMAKE_HOST_SYSTEM_NAME}} MATCHES ...\n+if(CMAKE_HOST_SYSTEM_NAME MATCHES \"FreeBSD\")\n-    message(FATAL_ERROR \"Invalid integer size value\")   # line 131\n+    message(FATAL_ERROR \"Invalid index size value\")",
   "tradeoffs": "Trivial; the idiom `if(VAR MATCHES ...)` is also what BLD-06 recommends.",
   "preferred": true
  },
  {
   "label": "Use CMAKE_SYSTEM_NAME",
   "summary": "Detect FreeBSD for the target system rather than the host (matters for cross-compiles): `if(CMAKE_SYSTEM_NAME STREQUAL FreeBSD)`.",
   "patch_sketch": "if(CMAKE_SYSTEM_NAME STREQUAL \"FreeBSD\")",
   "tradeoffs": "Behavior change for cross-compilation (arguably correct since the macro affects target code).",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-06",
 "area": "BLD",
 "our_title": "Open MPI version regex requires surrounding spaces the real version string lacks, so oversubscribe flag is never set",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "external-dependency",
 "needs_note": "Run the CMake configure step with Open MPI and read the status messages.",
 "location": "src/CMakeLists.txt:181",
 "evidence": "7.0.17 line 181: `string(REGEX MATCHALL \"\\( Open MPI \\)+\" found_suite ${MPI_C_LIBRARY_VERSION_STRING})` -- in a CMake quoted argument `\\(` is the escape for `(`, so the regex is `( Open MPI )+`, i.e. a group needing a space before AND after 'Open MPI'. Real library version string from this host (MPI_Get_library_version via mpicc): `[Open MPI v5.0.7, package: Debian OpenMPI, ident: 5.0.7, repo rev: v5.0.7, Feb 14, 2025]` -> begins with 'Open MPI' with no leading space. Python emulation with the same regex: `re.search(r'( Open MPI )+', s)` -> None, while `re.search('Open MPI', s)` matches. Consequence checked: `mpirun -np 16 true` on this 8-core host -> 'There are not enough slots available in the system to satisfy the 16 slots' ; `mpirun --oversubscribe -np 16 true` succeeds. cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; cmake -P was not run; the CMake regex dialect is the same for these constructs. Side note: with an empty match the following `if(NOT ${found_suite} STREQUAL \"\")` expands to `if(NOT  STREQUAL \"\")`, fragile but not tested here.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. The Intel pattern `\\(Intel\\)+` on line 186 is fine (no spaces). The review's fix is correct.",
 "fix_options": [
  {
   "label": "Match the vendor name only",
   "summary": "Use a plain MATCHES test.",
   "patch_sketch": "-    string(REGEX MATCHALL \"\\( Open MPI \\)+\" found_suite ${MPI_C_LIBRARY_VERSION_STRING})\n-    if(NOT ${found_suite} STREQUAL \"\")\n+    if(MPI_C_LIBRARY_VERSION_STRING MATCHES \"Open MPI\")",
   "tradeoffs": "Also fixes the fragile unquoted expansion. Should also apply to the Intel block for consistency. Behavior change: tests on OMPI hosts now get --oversubscribe (desired).",
   "preferred": true
  },
  {
   "label": "Ask the MPI launcher instead of parsing the version",
   "summary": "Probe `${MPIEXEC_EXECUTABLE} --oversubscribe -n 1 true` with execute_process and add the flag if it succeeds.",
   "patch_sketch": "execute_process(COMMAND ${MPIEXEC_EXECUTABLE} --oversubscribe ${MPIEXEC_NUMPROC_FLAG} 1 ${CMAKE_COMMAND} -E true RESULT_VARIABLE r OUTPUT_QUIET ERROR_QUIET)\nif(r EQUAL 0) list(APPEND MPIEXEC_PREFLAGS --oversubscribe) endif()",
   "tradeoffs": "Robust to MPICH/vendor builds based on Open MPI (e.g. HPC-X) whose string differs; runs a process at configure time and can mis-detect.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1: same style as existing neighbouring code, smallest diff.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## PS-BLD-2

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-BLD-2",
 "our_title": "Open MPI detection builds an unquoted, possibly empty if() operand after the failing regex",
 "severity": "info",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/CMakeLists.txt:181-185",
 "evidence": "Line 182: `if(NOT ${found_suite} STREQUAL \"\")` expands to `if(NOT  STREQUAL \"\")` when the regex yields no match, which is fragile CMake. Not executed (no cmake).",
 "related_review_ids": [
  "BLD-06"
 ],
 "fix_options": [
  {
   "label": "Use quoted if(VAR MATCHES)",
   "summary": "if(MPI_C_LIBRARY_VERSION_STRING MATCHES \"Open MPI\")",
   "patch_sketch": "see BLD-06",
   "tradeoffs": "Also removes the empty-expansion hazard.",
   "preferred": true
  },
  {
   "label": "Quote the expansion",
   "summary": "if(NOT \"${found_suite}\" STREQUAL \"\")",
   "patch_sketch": "if(NOT \"${found_suite}\" STREQUAL \"\")",
   "tradeoffs": "Keeps regex style but the regex still needs fixing.",
   "preferred": false
  }
 ],
 "area": "BLD"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)
