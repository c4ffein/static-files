# G28-tools-docs-tests

Items: CLI-20, CLI-21, BLD-23, BLD-22, BLD-18, BLD-04, BLD-16, BLD-15



===================================================================
## CLI-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-20",
 "area": "CLI",
 "our_title": "Command-line help states a default imbalance of 0.05 while the code uses 0.01",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gmap.c:105,170,250",
 "evidence": "`gpart -h | grep default` -> `-b<val> : Load imbalance tolerance (default: 0.05)`; code: gmap.c:170 `kbalval = 0.01;` and the sequential library default strategy also uses 0.01 (library_graph_map.c:218 `SCOTCH_stratGraphMapBuild(..., 0.01)`), so the effective default is 0.01. `gpart 2 g.grf /dev/null -cZ` -> `ERROR: main: invalid strategy selection option 'Z' after '-C'` (flag is -c, :250). dgmap/dgpart are consistent (help 0.05 at dgmap.c:82, kbalval = 0.05 at :150).",
 "upstream_change": "",
 "review_accuracy": "Accurate for gmap/gpart only; dgmap.c has the correct 0.05/0.05 pair.",
 "fix_options": [
  {
   "label": "Fix the text",
   "summary": "Help: `(default: 0.01)`; message: `after '-c'`.",
   "patch_sketch": "-  \"  -b<val>    : Load imbalance tolerance (default: 0.05)\",\n+  \"  -b<val>    : Load imbalance tolerance (default: 0.01)\",\n...\n-                errorPrint (\"main: invalid strategy selection option '%c' after '-C'\", argv[i][j]);\n+                errorPrint (\"main: invalid strategy selection option '%c' after '-c'\", argv[i][j]);",
   "tradeoffs": "Documentation-only; also check doc/ and man pages for the same 0.05 claim.",
   "preferred": true
  },
  {
   "label": "Change the code to match the help",
   "summary": "Set kbalval = 0.05 (and pass 0.05 in library_graph_map.c:218).",
   "patch_sketch": "-  kbalval = 0.01;\n+  kbalval = 0.05;",
   "tradeoffs": "Changes default partition quality/behaviour of gmap/gpart and the library default (and golden outputs); not appropriate for a documentation bug.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-21",
 "area": "CLI",
 "our_title": "Distributed tools exit on help or version without finalising MPI",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/dgmap.c:176-178,256,307; dgord.c:154-156,223,255; dgscat.c:121,150,164; dggath.c:123,152,167; dgtst.c:136,164,178; src/libscotch/library_error_exit.c:142",
 "evidence": "Reproduced (OpenMPI 5.0.7): `mpirun --oversubscribe -np 2 asan/bin/dgmap -h` (also dgord -h, dgmap '?', dgmap -V) prints the usage and then `prterun has exited due to process rank N ... exiting improperly ... this process called \"init\", but exited without calling \"finalize\"`, exit status 1 although the tool returned EXIT_SUCCESS. The same is true for all five dg* tools (grep shows `return (EXIT_SUCCESS)` after MPI_Init with the only MPI_Finalize at the end of main).\nSecond half (errors never MPI_Abort): library_error_exit.c:142 is a plain `exit (EXIT_FAILURE);`. Tried `mpirun -np 2 dggath bad.grf` (corrupt graph): `dggath(0): ERROR: dgraphLoadCent: bad input (4)` and prterun terminated the whole job in 0.5 s ('detected that one or more processes exited with non-zero status') - no hang under OpenMPI 5; the hang claim is launcher dependent and I could not reproduce it.",
 "upstream_change": "",
 "review_accuracy": "First half accurate and reproduced. Second half (others can hang in the next collective) is plausible for launchers that do not kill the job on a non-zero rank exit but was not reproduced with OpenMPI/prterun.",
 "fix_options": [
  {
   "label": "Finalize before the early returns",
   "summary": "Call MPI_Finalize() before `return (EXIT_SUCCESS)` in the ?, -h, -V paths (or restructure to one exit at the end).",
   "patch_sketch": "-    usagePrint (stdout, C_usageList);\n-    return     (EXIT_SUCCESS);\n+    usagePrint (stdout, C_usageList);\n+    MPI_Finalize ();\n+    return     (EXIT_SUCCESS);",
   "tradeoffs": "Trivial, local to 5 tools x 3 sites; removes the spurious launcher failure. Not applied/tested beyond the observation. Does not address the error path.",
   "preferred": true
  },
  {
   "label": "MPI_Abort from the PT error-exit library",
   "summary": "In library_error_exit.c, if SCOTCH_PTSCOTCH is defined and MPI is initialised and not finalized, call MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE) instead of exit().",
   "patch_sketch": "#ifdef SCOTCH_PTSCOTCH\n  { int initflag, finaflag; if ((MPI_Initialized (&initflag) == MPI_SUCCESS) && initflag && (MPI_Finalized (&finaflag) == MPI_SUCCESS) && !finaflag) MPI_Abort (MPI_COMM_WORLD, EXIT_FAILURE); }\n#endif\n  exit (EXIT_FAILURE);",
   "tradeoffs": "Guarantees job termination on any launcher; the library already calls MPI_Initialized there (precedent in the same function, line 121). Behaviour change for embedders linking ptscotcherrexit (they get an abort of the whole communicator, which is what 'exit on error' means for a parallel job).",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## BLD-23

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-23",
 "area": "BLD",
 "our_title": "gscat help shows -i bare but the parser rejects it without a number",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gscat.c:73, 121-124",
 "evidence": "7.0.17 usage line 73 `\"  -i  : Create an imbalanced distribution\"`; parser lines 121-124 `vertlocmin = atoll (argv[i]+2)) < 1 -> errorPrint (\"invalid number of vertices in graph parts '%s'\")`. Run: `gscat -h` prints `-i  : Create an imbalanced distribution`; `gscat 3 m4x4.grf out-%r.grf -i` -> `gscat: ERROR: main: invalid number of vertices in graph parts ''` rc=1; `... -i2` -> rc=0.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Fix the usage string",
   "summary": "Show the argument and its meaning.",
   "patch_sketch": "-  \"  -i  : Create an imbalanced distribution\",\n+  \"  -i<num> : Create an imbalanced distribution, each part having at least <num> vertices\",",
   "tradeoffs": "Docs only (man page for gscat, if any, should match).",
   "preferred": true
  },
  {
   "label": "Make the argument optional",
   "summary": "Treat bare -i as a default minimum (e.g. 1).",
   "patch_sketch": "if (argv[i][2] == '\\0') vertlocmin = 1; else ...",
   "tradeoffs": "Behavior change in a CLI tool; contrary to the documented-by-code interface.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (usage strings elsewhere use the `-x<arg>` form).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-22",
 "area": "BLD",
 "our_title": "Man pages lack several options that the programs' usage output lists",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Comparison of man text with usage arrays is conclusive.",
 "location": "man/man1/gmap.1.txt:45-75; gord.1.txt:27-53; dgord.1.txt:32-60",
 "evidence": "7.0.17 option letters in man/man1/gmap.1.txt: -b -c -h -m -q -V -v only; gmap.c usage (src/scotch/gmap.c:105-131) has also -C, -f<file>, -o, -ro/-rr/-rv, -s<obj>. gord.1.txt documents -c -h -m -o -t -V -v, gord.c:86 has -C. dgord.1.txt documents -c -h -m -o -r -t -V -v; dgord.c:79,80 also have -b and -C (a debug-only -d exists under SCOTCH_DEBUG_ALL and is rightly undocumented). Compared by grepping '^\\s*-[A-Za-z]' in the .txt and the usage arrays; man pages are not regenerated by me.",
 "upstream_change": "none (man/ untouched)",
 "review_accuracy": "Accurate (gpart shares gmap.1; there is no gpart.1.txt).",
 "fix_options": [
  {
   "label": "Document the options in the .1.txt and regenerate",
   "summary": "Add entries for the missing options mirroring the C usage strings; regenerate .1 via man/man1/Makefile.",
   "patch_sketch": "+  -Copt     Choose execution context options ... (d|f|r|u)\n+  -ffile    Fixed vertices input file ...",
   "tradeoffs": "Docs only; the .1 files are generated and committed so both must be updated.",
   "preferred": true
  },
  {
   "label": "Generate the options table from the C usage lists",
   "summary": "Script that extracts C_usageList into the .txt skeleton to avoid drift.",
   "patch_sketch": "tools/usage2man.sh",
   "tradeoffs": "Prevents drift but is new tooling; unlikely to be taken.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-18",
 "area": "BLD",
 "our_title": "Makefile check target list omits the mesh-conversion check target that exists",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/check/Makefile:199-241, 702",
 "evidence": "7.0.17 CHECKSCOTCH (lines 199-241) lists check_prog_mmk and check_prog_mord but not check_prog_mcv; the target is defined at line 702 (`check_prog_mcv : check_prog_mmk`) and only appears there (grep). On the 7.0.17 build: `make -n check | grep -c bin/mcv` -> 0; `make -n check_prog_mcv | grep -c bin/mcv` -> 3; running `make check_prog_mcv` succeeds (rc 0, the three diff -q comparisons pass), so the test works and is just not wired in. (CMake does run mcv: CMakeLists.txt:560-566.)",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Add check_prog_mcv to CHECKSCOTCH",
   "summary": "Insert after check_prog_gtst in the list.",
   "patch_sketch": "                    check_prog_gtst\t\t\t\\\n+                    check_prog_mcv\t\t\t\\\n                    check_prog_mmk",
   "tradeoffs": "Verified the target passes today; adds three tiny runs.",
   "preferred": true
  },
  {
   "label": "Make check_prog_mmk's dependants run via mcv",
   "summary": "Chain mcv from check_prog_mmk's recipe.",
   "patch_sketch": "check_prog_mmk: ... ; $(MAKE) check_prog_mcv",
   "tradeoffs": "Obscures the list; against file idiom.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-04",
 "area": "BLD",
 "our_title": "Graph-order test's permutation checker only prints on bad values and then indexes with the bad value",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/check/test_scotch_graph_order.c:79-106, 201",
 "evidence": "7.0.17 lines 94-96: `if ((permval < baseval) || (permval >= vnnd)) SCOTCH_errorPrint (\"checkOrder: invalid permutation value\");` -- no exit; line 104 same for the pair. The header comment (line 74) says `It exits on error.` but errorPrint in libscotcherr only prints (src/libscotch/library_error.c:108-137 has no exit; Makefile links -lscotcherr, CMake `target_link_libraries(... scotch scotcherr)`). Mutation test against the 7.0.17 Makefile build: (1) insert `permtab[5] = permtab[6];` before checkOrder -> `./o2: ERROR: checkOrder: invalid permutation pair`, exit status 0. (2) insert `permtab[5] = baseval - 7;` and compile with -fsanitize=address -> `ERROR: checkOrder: invalid permutation value` then `ERROR: AddressSanitizer: heap-buffer-overflow ... READ of size 4 at 0x506000000004 ... #0 checkOrder o.c:103` ('28 bytes before 64-byte region'). Nuance: SCOTCH_graphOrderCheck (called just before, line ~196, exits) validates peritab (order_check.c:160-176) but not permtab, so the OOB read is only reachable if the library returns an invalid permtab with a valid peritab, i.e. exactly the bug the test is meant to catch.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. The OOB is real but conditional on a library bug (it is a test robustness defect, not a library defect).",
 "fix_options": [
  {
   "label": "Exit after each error (test_libmetis.c idiom)",
   "summary": "Wrap each errorPrint in braces and exit(EXIT_FAILURE); the first failure stops before the OOB index.",
   "patch_sketch": "-      SCOTCH_errorPrint (\"checkOrder: invalid permutation value\");\n+    {\n+      SCOTCH_errorPrint (\"checkOrder: invalid permutation value\");\n+      exit (EXIT_FAILURE);\n+    }\n(same for the 2 other messages)",
   "tradeoffs": "Tested: with the permtab[5]=baseval-7 mutation the patched test now returns 1 under ASan with no OOB; unmutated run on bump.grf returns 0. Zero behavior change on healthy library.",
   "preferred": true
  },
  {
   "label": "Return a status",
   "summary": "Make checkOrder return int and have main OR it into o (the file already uses `o |=` for the Save calls) and exit once.",
   "patch_sketch": "-void checkOrder (...)\n+int checkOrder (...)  /* return 1 on first inconsistency, skip pair check when permval out of range */",
   "tradeoffs": "Slightly more code; keeps single exit path. Equivalent coverage.",
   "preferred": false
  },
  {
   "label": "Fix in a shared helper",
   "summary": "Provide a check-header helper (e.g. in module.h for tests) `#define CHECK(c,msg)` that prints and exits, reuse across tests (BLD-15/16).",
   "patch_sketch": "#define CHECK_FAIL(msg) do { SCOTCH_errorPrint (msg); exit (EXIT_FAILURE); } while (0)",
   "tradeoffs": "Touches many tests; larger diff than maintainers usually take.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1: the in-file comment says 'It exits on error', and neighbouring checkers in the same directory (checkMap in test_scotch_graph_map.c:98-100, test_libmetis*.c) already do errorPrint + exit(EXIT_FAILURE).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-16",
 "area": "BLD",
 "our_title": "Mapping test skips unmapped entries, has no upper bound for variable architectures, and ignores fixed-vertex movement",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/check/test_scotch_graph_map.c:82-108, 279",
 "evidence": "7.0.17 checkMap: line 95 `if (partval == -1) continue;`, upper bound only `if ((flagval == 0) && (partval >= partnbr))`; call at line 279 passes partnbr=archsiz and flagval = (archnum == ARCHNBR-1). Mutations on the 7.0.17 Makefile build with grf m16x16: (a) `memset (parttab, ~0, ...)` before checkMap (every vertex unmapped) -> rc 0, no error; (b) flip fixed vertex (0,0) part (archnum<2) -> rc 0, no error; (c) set parttab[5]=1000000 on the variable-size arch (archnum 3) -> rc 0. Strict variant tested (reject any negative value; bound partval by partnbr or by 2*(vertnbr+2) for variable-size; for typenum 1,5,6 save the preset parttab before compute and require preset entries unchanged): unmutated run rc 0, mutations (a),(b),(c) all rc 1. Imprecision in the review's fix: 'bound partval by the architecture size' does not work for the variable-size arch -- SCOTCH_archSize(Vhcub)=1 and the real labels reach 479 for 256 vertices (instrumented print), so a naive vertnbr+2 bound fails (invalid mapping (2)); a looser bound (2*(vertnbr+2)) is needed.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate on all three gaps; the proposed 'bound by architecture size' is wrong for variable-sized architectures (archSize is 1; labels are domain numbers up to ~2*vertnbr).",
 "fix_options": [
  {
   "label": "Strict checkMap + fixed-vertex comparison",
   "summary": "Reject -1 after any compute; keep saved copy of the preset parttab for the fixed cases and compare; bound labels by partnbr (fixed arch) or 2*(vertnbr+2) (variable arch).",
   "patch_sketch": "-    if (partval == -1)  continue;\n-    if (partval < 0) {\n+    if (partval < 0) {   /* all vertices mapped after computation */\n...\n-    if ((flagval == 0) && (partval >= partnbr)) {\n+    if (partval >= ((flagval == 0) ? partnbr : 2 * (vertnbr + 2))) {\n+ /* in main: memcpy(partsav, parttab, ...) before compute; for typenum 1 or >=5 compare preset entries */",
   "tradeoffs": "Tested against the unmutated test (passes) and three mutations (fail). It only strengthens assertions. Needs maintainers to confirm that -1 is never a legal output of graphMapCompute with an old mapping containing -1 (case 4 sets parotab[0] = -1 but the output was fully mapped in my run).",
   "preferred": true
  },
  {
   "label": "Add a separate fixed-vertex test",
   "summary": "Leave checkMap as is; add checkFixed() invoked only for typenum 1,5,6 and an unmapped-count assertion.",
   "patch_sketch": "static void checkFixed (vertnbr, parttab, partsav) { ... }",
   "tradeoffs": "Smaller blast radius; two functions.",
   "preferred": false
  },
  {
   "label": "Cross-check with an independent metric",
   "summary": "Recompute the edge cut / part loads from parttab via SCOTCH_graphData and require every vertex counted in some part and the cut strictly below edgenbr.",
   "patch_sketch": "compute cut from parttab via SCOTCH_graphData and require 0 < cut < edgenbr",
   "tradeoffs": "Not run here. Catches all-unmapped results but not moved fixed vertices; extra computation.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1: the existing function already is the single consistency routine and its comment says 'It exits on error'.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-15",
 "area": "BLD",
 "our_title": "Mesh-to-graph test prints a graph-check failure but still exits with success",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/check/test_scotch_mesh_graph.c:113-114",
 "evidence": "7.0.17: `if (SCOTCH_graphCheck (&grafdat) != 0)\\n    SCOTCH_errorPrint (\"main: invalid graph converted from mesh\");` then falls through to `exit (EXIT_SUCCESS)`. Mutation on the 7.0.17 Makefile build: after SCOTCH_meshGraph insert `e[0] = 999999` on the edge array (via SCOTCH_graphData) -> `./m: ERROR: graphCheck: invalid edge array` / `./m: ERROR: main: invalid graph converted from mesh`, exit status 0. Fixed variant (braces + exit(EXIT_FAILURE)) on same mutation -> exit status 1.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Exit on failure",
   "summary": "Braces + exit(EXIT_FAILURE).",
   "patch_sketch": "-    SCOTCH_errorPrint (...);\n+  {\n+    SCOTCH_errorPrint (...);\n+    exit (EXIT_FAILURE);\n+  }",
   "tradeoffs": "Tested as above; matches every other check in the file (`cannot create graph from mesh` already exits).",
   "preferred": true
  },
  {
   "label": "Set a status variable",
   "summary": "int o = graphCheck != 0; ... exit (o ? EXIT_FAILURE : EXIT_SUCCESS) after freeing resources.",
   "patch_sketch": "o |= SCOTCH_graphCheck (&grafdat); ... exit (o)",
   "tradeoffs": "Cleans up before exiting; slightly more code than needed for a test.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; same idiom as the lines immediately above in the file.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)
