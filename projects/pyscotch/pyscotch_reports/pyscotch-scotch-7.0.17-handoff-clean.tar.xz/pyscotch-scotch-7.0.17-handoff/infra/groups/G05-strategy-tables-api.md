# G05-strategy-tables-api

Items: GRA-13, PS-DMO-2, GRA-06, GRA-15, API-07, API-23, CLI-01



===================================================================
## GRA-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-13",
 "area": "GRA",
 "our_title": "Ordering-strategy test on maximum degree reads an int parameter as a double (misaligned, out-of-bounds read)",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/hgraph_order_st.c:231-234; parser.c:437",
 "evidence": "Repro gra06.c: `./gra06 '/(mdeg>3)?s;'` -> UBSan 'parser.c:437:38: runtime error: load of misaligned address ... for type double, which requires 8 byte alignment' (stratTestEval reads 8 bytes from the 4-byte degrmax field; with 32-bit Gnum it also reads past the field). Patched hgraph_order_st.c (STRATPARAMINT): no report and mdeg>3 / mdeg>100 evaluate on the real maximum degree. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Declare mdeg as STRATPARAMINT",
   "summary": "Same as vert/edge/load/levl entries of the same table.",
   "patch_sketch": "--- a/src/libscotch/hgraph_order_st.c\n+++ b/src/libscotch/hgraph_order_st.c\n@@ -228,7 +228,7 @@\n                                 (byte *) &hgraphorderstgraphdummy,\n                                 (byte *) &hgraphorderstgraphdummy.vnlosum,\n                                 NULL },\n-                              { STRATNODECOND,        STRATPARAMDOUBLE, \"mdeg\",\n+                              { STRATNODECOND,        STRATPARAMINT,    \"mdeg\",\n                                 (byte *) &hgraphorderstgraphdummy,\n                                 (byte *) &hgraphorderstgraphdummy.s.degrmax,\n                                 NULL },\n@@ -293,6 +293,8 @@\n         else {                                    /* Else if expression is false             */\n           if (straptr->data.conddat.stratab[1] != NULL) /* And if there is an else statement */\n             o = hgraphOrderSt (grafptr, ordeptr, ordenum, cblkptr, straptr->data.conddat.stratab[1]); /* Apply second strategy */\n+          else                                    /* Else no strategy to apply: always maintain a consistent ordering */\n+            hgraphOrderSi (grafptr, ordeptr, ordenum, cblkptr);\n         }\n       }\n       break;\n",
   "tradeoffs": "Changes the declared type of the condition variable to an integer (like vert/edge/load/levl); I did not test comparisons against fractional literals such as mdeg>3.5, whose handling depends on the int/double promotion in stratTestEval.",
   "preferred": true
  },
  {
   "label": "Add a double mirror field",
   "summary": "Keep STRATPARAMDOUBLE and store a double copy of degrmax in Hgraph for the test.",
   "patch_sketch": "hgraphorderstgraphdummy.degrmaxdbl (new double field in Hgraph, set at hgraphInit)",
   "tradeoffs": "Larger structural change for a trivial variable; only justified if fractional thresholds are wanted.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## PS-DMO-2

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DMO-2",
 "our_title": "Strategy with missing sequential-ordering parameter parses with a warning then dereferences NULL strategy",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/hgraph_order_st.c:276 (reached via hdgraphOrderSq2), strategy parser for method n",
 "evidence": "mpirun -np 3 asan/bin/dgord 4elt.grf.gz /dev/null -o'n{sep=d{pass=3},ole=s,ose=s}' printed 'WARNING: stratParserParse: strategy parameter \"osq\" of method \"n\" not set' then 'hgraph_order_st.c:276:18: runtime error: member access within null pointer' and SIGSEGV.",
 "related_review_ids": [],
 "fix_options": [
  {
   "label": "A: reject at parse time",
   "summary": "Make unset STRATPARAMSTRAT parameters of n an error (or default them to the empty strategy).",
   "patch_sketch": "stratParserParse: return error when a STRATPARAMSTRAT default is NULL",
   "tradeoffs": "Behaviour change for users relying on the warning.",
   "preferred": true
  },
  {
   "label": "B: guard at use",
   "summary": "Treat NULL straptr in hgraphOrderSt as the empty strategy.",
   "patch_sketch": "+  if (straptr == NULL) return (hgraphOrderSi (grafptr, ordeptr));",
   "tradeoffs": "Masks bad strategies silently.",
   "preferred": false
  }
 ],
 "area": "DMO"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## GRA-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-06",
 "area": "GRA",
 "our_title": "Ordering strategy with a false condition and no else branch leaves the output unset, then a later write overflows",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/hgraph_order_st.c:285-298",
 "evidence": "Repro gra06.c (8x8 grid, peritab pre-filled with -7): `./gra06 '/(vert>1000)?s;'` -> 'AddressSanitizer: heap-buffer-overflow ... WRITE of size 4 ... #0 orderPeri order.c:170 #1 SCOTCH_graphOrderComputeList'. The branch is selected false, hgraph_order_st.c:294 `if (straptr->data.conddat.stratab[1] != NULL)` has no else, nothing writes peritab, hgraphOrderSt returns 0. Patched hgraph_order_st.c (else -> hgraphOrderSi): peri[0]=0, ret=0, no sanitizer report. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate. (The SCOTCH_DEBUG_HGRAPH2 sanity test at line 273 also uses && instead of || -- cosmetic.)",
 "fix_options": [
  {
   "label": "Fall back to hgraphOrderSi when there is no else strategy",
   "summary": "Mirror the STRATNODEEMPTY case: \"Always maintain a consistent ordering\".",
   "patch_sketch": "--- a/src/libscotch/hgraph_order_st.c\n+++ b/src/libscotch/hgraph_order_st.c\n@@ -228,7 +228,7 @@\n                                 (byte *) &hgraphorderstgraphdummy,\n                                 (byte *) &hgraphorderstgraphdummy.vnlosum,\n                                 NULL },\n-                              { STRATNODECOND,        STRATPARAMDOUBLE, \"mdeg\",\n+                              { STRATNODECOND,        STRATPARAMINT,    \"mdeg\",\n                                 (byte *) &hgraphorderstgraphdummy,\n                                 (byte *) &hgraphorderstgraphdummy.s.degrmax,\n                                 NULL },\n@@ -293,6 +293,8 @@\n         else {                                    /* Else if expression is false             */\n           if (straptr->data.conddat.stratab[1] != NULL) /* And if there is an else statement */\n             o = hgraphOrderSt (grafptr, ordeptr, ordenum, cblkptr, straptr->data.conddat.stratab[1]); /* Apply second strategy */\n+          else                                    /* Else no strategy to apply: always maintain a consistent ordering */\n+            hgraphOrderSi (grafptr, ordeptr, ordenum, cblkptr);\n         }\n       }\n       break;\n",
   "tradeoffs": "Identity (graph-order) ordering for the unmatched case; pure addition. Precedent: same file, case STRATNODEEMPTY.",
   "preferred": true
  },
  {
   "label": "Reject else-less conditions when the strategy is parsed",
   "summary": "Make the ordering strategy parser (or hgraphOrderSt on first use) report an error for COND nodes without else.",
   "patch_sketch": "if (straptr->data.conddat.stratab[1] == NULL) { errorPrint (\"hgraphOrderSt: conditional ordering strategy requires an else branch\"); return (1); }",
   "tradeoffs": "Surfaces strategy mistakes early but breaks existing user strategies that happen to omit else; unlike mapping/separation strategies, where else-less cond is a no-op, ordering needs a result.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## GRA-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "GRA-15",
 "area": "GRA",
 "our_title": "k-way FM fallback ignores a failed strategy parse and leaks the strategy tree",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/kgraph_map_fm.c:1039-1040",
 "evidence": "LeakSanitizer on internal harness gra02 (fallback executed): 'Direct leak of 104 byte(s) ... #1 yyparse parser_yy.y:288 #2 stratParserParse parser_yy.y:819 #3 stratInit parser.c:112 #4 kgraphMapFm kgraph_map_fm.c:1039'. Source: `strat = stratInit (...); kgraphMapSt (grafptr, strat);` no NULL check, no stratExit, return value dropped. With the GRA-02 patch (stratExit + checks) the stratInit frames disappear from the leak report. Build: pristine 7.0.17 ASan+UBSan, 32-bit Gnum (SCOTCH_Num=int); run with LD_LIBRARY_PATH=<asan>/lib, ASAN_OPTIONS=detect_leaks=0 unless noted. Reproducers + patched sources are in work/GRA (gra*.c, patched/*.c); patched sources are linked ahead of libscotch.so (symbol interposition) so no rebuild of the library is needed.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Check NULL, run, stratExit, propagate (preferred; same patch as GRA-02)",
   "summary": "stratInit -> NULL check; kgraphMapSt result checked; stratExit(strat) after use.",
   "patch_sketch": "--- a/src/libscotch/kgraph_map_fm.c\n+++ b/src/libscotch/kgraph_map_fm.c\n@@ -957,6 +957,7 @@\n   Gnum                            edxxcdx;        /* Index for extended edge copy                   */\n   Gnum                            edcunbr;        /* Current number of unused extended edge slots   */\n   Gnum                            edxunbr;        /* Number of unused extended edge slots           */\n+  Gnum                            domnnbr;        /* Current number of domains; can change after fallback mapping */\n   Gnum *                          comploadmax;    /* Array of maximum imbalances                    */\n   Gnum *                          comploaddlt;\n   Gnum                            commload;\n@@ -994,12 +995,13 @@\n   const Gnum * restrict const     edgetax = grafptr->s.edgetax;\n   const Gnum * restrict const     edlotax = grafptr->s.edlotax;\n   const Arch * restrict const     archptr = grafptr->m.archptr;\n-  const Gnum                      domnnbr = grafptr->m.domnnbr;\n   const ArchDom * restrict const  domntab = grafptr->m.domntab;\n   Anum * restrict const           parttax = grafptr->m.parttax;\n   Anum * restrict const           parotax = grafptr->r.m.parttax;\n   const Gnum * restrict const     pfixtax = grafptr->pfixtax;\n \n+  domnnbr = grafptr->m.domnnbr;\n+\n #ifdef SCOTCH_DEBUG_KGRAPH3                       /* Allocation of extra memory needed for the check routine */\n   if ((chektab = memAlloc (domnnbr * 3 * sizeof(Gnum))) == NULL) {\n     errorPrint (\"kgraphMapFm: out of memory (1)\");\n@@ -1034,17 +1036,29 @@\n       return  (0);\n     }\n     else {                                        /* Imbalance must be fought */\n-      const Strat *         strat;\n+      Strat *               strat;\n+      int                   o;\n \n-      strat = stratInit (&kgraphmapststratab, \"r{sep=h{pass=10}}\"); /* Use a standard algorithm */\n-      kgraphMapSt (grafptr, strat);               /* Perform mapping */\n+      if ((strat = stratInit (&kgraphmapststratab, \"r{sep=h{pass=10}}\")) == NULL) { /* Use a standard algorithm */\n+        errorPrint (\"kgraphMapFm: cannot create fallback strategy\");\n+        memFree    (comploadmax);\n+        return     (1);\n+      }\n+      o = kgraphMapSt (grafptr, strat);           /* Perform mapping */\n+      stratExit (strat);\n+      if (o != 0) {\n+        errorPrint (\"kgraphMapFm: cannot compute fallback mapping\");\n+        memFree    (comploadmax);\n+        return     (1);\n+      }\n \n       if (grafptr->fronnbr == 0) {                /* If new partition has no frontier */\n         memFree (comploadmax);\n         return  (0);                              /* This algorithm is still useless  */\n       }\n \n-      if (memReallocGroup ((void *) comploadmax,  /* domnnbr has changed after mapping */\n+      domnnbr = grafptr->m.domnnbr;               /* Number of domains has changed after mapping */\n+      if (memReallocGroup ((void *) comploadmax,\n                            &comploadmax, (size_t) (domnnbr * sizeof (Gnum)),\n                            &comploaddlt, (size_t) (domnnbr * sizeof (Gnum)), NULL) == NULL) {\n         errorPrint (\"kgraphMapFm: out of memory (3)\");\n",
   "tradeoffs": "Parses the small strategy string on every fallback (was already the case).",
   "preferred": true
  },
  {
   "label": "Parse once and cache",
   "summary": "Build the fallback strategy lazily in a static/ module-level Strat guarded by a once-flag or build it in the strategy-parameter structure (KgraphMapFmParam) at method creation.",
   "patch_sketch": "static Strat * kgraphmapfmfallback; (initialise under a pthread_once)",
   "tradeoffs": "Avoids repeated parsing but introduces global state and ownership/teardown questions in a library that currently has none for strategies.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/GRA/diffs/ if any; harness sources alongside)


===================================================================
## API-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-07",
 "area": "API",
 "our_title": "Strategy builders format a double into fixed small stack arrays without a length bound",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_map.c:669-670, 730-731; library_graph_part_ovl.c:169; library_graph_order.c:514; library_mesh_order.c:414; library_dgraph_map.c:307-308, 381-382; library_dgraph_order.c:403",
 "evidence": "Unchanged vs 7.0.16. Reproducer work/API/sb.c: SCOTCH_stratGraphMapBuild(&s,SCOTCH_STRATDEFAULT,4,1e300), SCOTCH_stratGraphOrderBuild(&s,SCOTCH_STRATDEFAULT,0,1e300), SCOTCH_stratGraphPartOvlBuild(&s,SCOTCH_STRATDEFAULT,4,1e300) against the ASan+UBSan 7.0.17 (also 64-bit build): each 'ERROR: AddressSanitizer: stack-buffer-overflow ... WRITE of size 309 ... #0 vsprintf #1 sprintf'. Buffer sizes in 7.0.17: map 64, partovl 64, others 32. SCOTCH_stratGraphClusterBuild (graph_map.c:730-731, bbaltab/denstab[32]) and the Dgraph variants have the same pattern. Any value >= 1e30 overflows a 32-byte buffer.",
 "upstream_change": "",
 "review_accuracy": "accurate on mechanism, sites, and size 309. Suggested fix '%g' changes the textual strategy (6 significant digits, 0.123456789 -> 0.123457) and does not by itself reject NaN/Inf; 'reject non-finite' is a good addition. Review omits that the strategy parser FLOAT token has no sign, so negative ratios already fail later in stratParse.",
 "fix_options": [
  {
   "label": "Bounded snprintf + truncation check (keep %lf)",
   "summary": "Replace each sprintf(buf,\"%lf\",v) by snprintf with sizeof(buf) and return 1 with errorPrint if the result does not fit. Output text for sane values is byte-identical to today.",
   "patch_sketch": "if (snprintf (kbaltab, sizeof (kbaltab), \"%lf\", kbalval) >= (int) sizeof (kbaltab)) {\n  errorPrint (STRINGIFY (SCOTCH_stratGraphMapBuild) \": invalid ratio value\");\n  return (1);\n}\n\n(applied by script to all 6 files x 11 sites; tested sequential ones, see diff for part_ovl:)\n--- library_graph_part_ovl.c\n+++ library_graph_part_ovl.c\n@@ -166,7 +166,10 @@\n   char                bufftab[8192];              /* Should be enough */\n   char                kbaltab[64];\n \n-  sprintf (kbaltab, \"%lf\", balrat);\n+  if (snprintf (kbaltab, sizeof (kbaltab), \"%lf\", balrat) >= (int) sizeof (kbaltab)) { /* Prevent stack overflow with huge values */\n+    errorPrint (STRINGIFY (SCOTCH_stratGraphPartOvlBuild) \": invalid ratio value\");\n+    return (1);\n+  }\n \n   if ((flagval & SCOTCH_STRATRECURSIVE) != 0)\n     strcpy (bufftab, \"<RECU>\");                   /* Use only the recursive bipartitioning framework */\n",
   "tradeoffs": "No change for normal values; values that cannot fit now fail with 1 instead of smashing the stack. Behaviour change only for absurd ratios (e.g. DBL_MAX 'no constraint' sentinel now errors rather than corrupts). Tested: with the patch sb.c now prints 'SCOTCH_stratGraphMapBuild: invalid ratio value' (x3), no ASan error. Needs a unit test with 1e300 and NaN.",
   "preferred": true
  },
  {
   "label": "Format with %g and validate range",
   "summary": "Use snprintf(buf,sizeof buf,\"%.*g\",DBL_DIG,v) (always <= ~25 chars) after rejecting !isfinite(v) or v<0.",
   "patch_sketch": "if (! isfinite (kbalval) || (kbalval < 0.0)) { errorPrint (..., \": invalid imbalance ratio\"); return (1); }\nsnprintf (kbaltab, sizeof (kbaltab), \"%.15g\", kbalval);",
   "tradeoffs": "Cannot overflow even without checking the return value, and also rejects NaN/Inf that today produce unparsable 'nan'/'inf' tokens. But changes the strategy text (e.g. '0.05' instead of '0.050000'), which is visible through SCOTCH_stratSave and might break golden-output tests; exponent form (1e+300) is accepted by the FLOAT lexer but becomes a legal huge ratio rather than an error.",
   "preferred": false
  },
  {
   "label": "Enlarge the buffers",
   "summary": "Make every tab buffer 320 bytes (DBL_MAX '%lf' is 316 chars).",
   "patch_sketch": "char bbaltab[320]; char kbaltab[320]; ...",
   "tradeoffs": "Zero behaviour change, trivially safe, but wastes stack and leaves sprintf in place (and still relies on 8192-byte bufftab surviving ~10 copies of 316-char numbers after stringSubst); not what maintainers do elsewhere.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: library_errcom.c already uses vsnprintf with explicit sizes, and the 'Should be enough' 8192 bufftab is the only other fixed buffer; option 1 matches the existing errorPrint-and-return(1) style. Locale: %lf is locale dependent (decimal comma) while the parser uses atof; not addressed by any option.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-23

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-23",
 "area": "API",
 "our_title": "Several library wrappers ignore Init/stratInit results; coarsen reports wrong code on context failure",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Force memAlloc failure inside SCOTCH_graphMapInit and stratInit and observe the following NULL dereference.",
 "location": "library_graph_map.c:411, 438, 468-469, 501-502; library_graph_order.c:447; library_mesh_order.c:319, 351; library_arch_build.c:131; library_graph_coarsen.c:98-100",
 "evidence": "Unchanged: e.g. 7.0.17 library_graph_map.c:411 'SCOTCH_graphMapInit (grafptr, &mappdat, archptr, parttab);' (returns 1 on OOM when parttab==NULL) followed by SCOTCH_graphMapCompute on a mapping with parttab NULL; library_arch_build.c:131 '*((Strat **) stratptr) = stratInit (&bgraphbipartststratab, \"...\");' then 'bipstratptr->tablptr' dereferenced unconditionally; library_graph_coarsen.c:98-100 'if (CONTEXTINIT (finegrafptr) != 0) {...return (1);}' while the header comment says 2 is the error code (dgraph/mesh variants return 2). Allocation-failure paths only: not runtime-reproduced.",
 "upstream_change": "",
 "review_accuracy": "accurate in substance; most Init functions can only fail on OOM (graphOrderInit/meshOrderInit return 1 only under SCOTCH_DEBUG_LIBRARY1), so severity is low.",
 "fix_options": [
  {
   "label": "Check each Init result and propagate",
   "summary": "'if (SCOTCH_graphMapInit (...) != 0) return (1);' etc.; return 2 from SCOTCH_graphCoarsen/CoarsenMatch on context failure.",
   "patch_sketch": "  if (SCOTCH_graphMapInit (grafptr, &mappdat, archptr, parttab) != 0)\n    return (1);\n  o = SCOTCH_graphMapCompute (...);\n  SCOTCH_graphMapExit (...);",
   "tradeoffs": "Straightforward; changes the documented return of SCOTCH_graphCoarsen on context failure from 1 to 2 (the documented 'error' value), which a caller treating 1 as 'not coarsenable' will notice. Needs fault-injection tests.",
   "preferred": true
  },
  {
   "label": "Make Init infallible",
   "summary": "Allocate nothing in *Init (defer allocation to Compute) so nothing can fail, leaving callers as is.",
   "patch_sketch": "/* SCOTCH_graphMapInit: record parttab==NULL and allocate lazily in graphMapCompute */",
   "tradeoffs": "Removes the ignoring-errors class but changes allocation timing/semantics of the public Init/Exit pair; larger redesign, not recommended.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## CLI-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-01",
 "area": "CLI",
 "our_title": "Distributed mapper rebuilds the default strategy after parsing the user's one, so the strategy option has no effect",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/dgmap.c:388-394 (parse at 257-263)",
 "evidence": "Source (7.0.17): dgmap.c:259-262 `straptr = &argv[i][2]; SCOTCH_stratExit(&stradat); SCOTCH_stratInit(&stradat); SCOTCH_stratDgraphMap(&stradat, straptr);` then, unconditionally at 391-394, `SCOTCH_stratDgraphClusterBuild(&stradat,...)` / `SCOTCH_stratDgraphMapBuild(&stradat,...)`. library_dgraph_map.c:266-270 SCOTCH_stratDgraphMap() does `if (*straptr != NULL) stratExit(*straptr);` before re-parsing, so Build overwrites the -m strategy.\nLibrary repro (t/cli01.c, mpicc, ASan build): SCOTCH_stratDgraphMap(&s,\"r{sep=q{strat=f}}\"); stratSave -> `r{sep=q{strat=f{move=80,pass=-1,bal=0.01,type=b}},seq=,bal=0.05}`; after SCOTCH_stratDgraphMapBuild(&s,0,1,4,0.01): stratSave -> `r{sep=m{asc=b{width=3,bnd=(d{pass=40,dif=1,rem=0,type=b}|)q{strat=f...` (user strategy gone).\nTool repro: `mpirun --oversubscribe -np 1 asan/bin/dgpart 8 asan/grf/bump.grf.gz out.txt -Cd [-m'r{sep=q{strat=f}}']`: md5 of out.txt is a723f6fe071c1e687478f45c9988a734 with AND without -m (identical output; -Cd makes runs deterministic). (Without -Cd runs are not reproducible run-to-run so a comparison is meaningless.) With the fix below, -m with the library default string and with a variant (bal=0.3) give different mappings (040bd7af..., dc215dd1...) and a mapping equal to neither the old output.\nAlso confirmed: the exclusivity check at dgmap.c:388 does fire for `-m... -b0.1` (ERROR: options '-b' / '-c' and '-m' are exclusive), so only the silent-discard half is broken.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Line numbers shifted by 0 (file untouched). The suggested fix is correct and matches gmap.c's idiom (gmap.c:404-413 only builds when -b/-c given, and applies -m later at 443-455). Caveat: with the fix a naive -m string such as 'r{sep=q{strat=f}}' (not a complete mapping strategy) now actually reaches the mapper and crashes in dmapSave (dmapping_io.c:196 null load) - previously masked by the override; that is a separate robustness issue for invalid user strategies, not a regression of the fix.",
 "fix_options": [
  {
   "label": "Guard the default Build calls with straptr == NULL",
   "summary": "Only build the default strategy when the user gave no -m string (the -m string is already parsed into stradat at option time).",
   "patch_sketch": "--- a/src/scotch/dgmap.c\n+++ b/src/scotch/dgmap.c\n@@ -388,10 +388,12 @@\n   if (((straval != 0) || ((flagval & C_FLAGKBALVAL) != 0)) && (straptr != NULL))\n     errorPrint (\"main: options '-b' / '-c' and '-m' are exclusive\");\n \n-  if ((flagval & C_FLAGCLUSTER) != 0)             /* If clustering wanted */\n-    SCOTCH_stratDgraphClusterBuild (&stradat, straval, (SCOTCH_Num) procglbnbr, (SCOTCH_Num) C_partNbr, 1.0, kbalval);\n-  else\n-    SCOTCH_stratDgraphMapBuild (&stradat, straval, (SCOTCH_Num) procglbnbr, (SCOTCH_Num) C_partNbr, kbalval);\n+  if (straptr == NULL) {                          /* If no user strategy provided, build default one */\n+    if ((flagval & C_FLAGCLUSTER) != 0)           /* If clustering wanted */\n+      SCOTCH_stratDgraphClusterBuild (&stradat, straval, (SCOTCH_Num) procglbnbr, (SCOTCH_Num) C_partNbr, 1.0, kbalval);\n+    else\n+      SCOTCH_stratDgraphMapBuild (&stradat, straval, (SCOTCH_Num) procglbnbr, (SCOTCH_Num) C_partNbr, kbalval);\n+  }\n \n   SCOTCH_contextBindDgraph (&contdat, &grafdat, &cogrdat);\n ",
   "tradeoffs": "Smallest change, no new variables; verified: -m now changes the mapping, and -m with -b/-c still errors. Behaviour change: users who passed -m (previously ignored) now get their strategy run - may expose bad user strategies. Matches the `if (straptr != NULL)` idioms in gmap.c/gord.c/dgord.c.",
   "preferred": true
  },
  {
   "label": "Defer parsing of -m to after the exclusivity check (gmap.c structure)",
   "summary": "Do not parse in the option loop; remember `straptr` only, and after the exclusivity check do `if (straptr != NULL) SCOTCH_stratDgraphMap(&stradat, straptr); else { Build... }`.",
   "patch_sketch": "@@ option loop @@\n-          SCOTCH_stratExit (&stradat);\n-          SCOTCH_stratInit (&stradat);\n-          SCOTCH_stratDgraphMap (&stradat, straptr);\n           break;\n@@ before SCOTCH_contextBindDgraph @@\n-  if ((flagval & C_FLAGCLUSTER) != 0)\n-    SCOTCH_stratDgraphClusterBuild (...);\n-  else\n-    SCOTCH_stratDgraphMapBuild (...);\n+  if (straptr != NULL)\n+    SCOTCH_stratDgraphMap (&stradat, straptr);\n+  else if ((flagval & C_FLAGCLUSTER) != 0)\n+    SCOTCH_stratDgraphClusterBuild (...);\n+  else\n+    SCOTCH_stratDgraphMapBuild (...);",
   "tradeoffs": "Also removes the redundant Exit/Init pair and reports a bad -m string after all options are known (error text can mention the exclusive flags); slightly larger diff; mirrors how sequential gmap.c does it. Same user-visible behaviour change as option 1.",
   "preferred": false
  }
 ],
 "notes": "Same pattern exists for dgord? No: dgord.c only calls Build when straval != 0 and errors if -m was also given, so dgord is fine.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)
