# G11-mesh-struct-io

Items: SEP-07, PS-SEP-1, SEP-23, SEP-21, SEP-08, API-08, SEP-16, API-06, API-12



===================================================================
## SEP-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-07",
 "area": "SEP",
 "our_title": "Mesh writer now pairs element loads with elements and node loads with nodes",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/mesh_io.c:351-357",
 "evidence": "7.0.17 mesh_io.c:356 now reads `velotabtab[1] = meshptr->vnlotax;`.\nRun on pristine 7.0.17 (work/SEP/t/sep07.c, 2x2 quad mesh built with element loads 1,2,3,1 and node loads 1..5,1..4, SCOTCH_meshSave to stdout): element lines start 1,2,3,1 then node lines start 1,2,3,4,5 - i.e. element loads and node loads are written correctly, no uninitialised pointer.",
 "upstream_change": "fd6c780 \"Bugfix: assign proper variable [report R. Perry]\".",
 "review_accuracy": "Accurate; fixed as the review suggested (also fixes meshGeomSaveScot).",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## PS-SEP-1

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-SEP-1",
 "our_title": "Mesh flag values for 'vertex arrays grouped' and 'free other arrays' collide, freeing an interior pointer",
 "severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/mesh.h:66,68; mesh.c:130-133; mesh_io.c:~209",
 "evidence": "mesh.h defines MESHFREEOTHR and MESHVERTGROUP both as 0x0010. meshLoad of a labelled mesh sets MESHFREEVERT|MESHVERTGROUP, so meshFree also frees vlbltax, an interior pointer of the already freed group. Pristine ASan: load work/SEP/t/m16.msh then SCOTCH_meshExit -> 'attempting free on address which was not malloc()-ed' at mesh.c:132 via meshExit; same on meshLoad error paths after labels were read.",
 "related_review_ids": [
  "SEP-16"
 ],
 "fix_options": [
  {
   "label": "Give MESHVERTGROUP its own bit",
   "summary": "Change MESHVERTGROUP to 0x0020 (check other uses of the mask).",
   "patch_sketch": "-#define MESHVERTGROUP 0x0010\n+#define MESHVERTGROUP 0x0020",
   "tradeoffs": "One line; flag values are internal. Not compiled.",
   "preferred": true
  },
  {
   "label": "Do not free vlbltax when grouped",
   "summary": "In meshFree test MESHVERTGROUP before freeing vlbltax.",
   "patch_sketch": "-  if ((meshptr->flagval & MESHFREEOTHR) != 0) {\n+  if (((meshptr->flagval & MESHFREEOTHR) != 0) && ((meshptr->flagval & MESHVERTGROUP) == 0)) {",
   "tradeoffs": "Leaves the confusing bit sharing; would break a mesh that wants both.",
   "preferred": false
  }
 ],
 "area": "SEP"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-23

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-23",
 "area": "SEP",
 "our_title": "Mesh and halo-mesh rebasing leave load arrays and halo end array on the old base",
 "claimed_severity": "info",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/mesh.c:148-195; src/libscotch/hmesh.c:92-117",
 "evidence": "Both files untouched. No callers of meshBase/hmeshBase exist in src/libscotch (grep), hence latent.\nInternal-API harness work/SEP/t/sep23.c (3x3 quad mesh built by SCOTCH_meshBuild, then meshBase (m, 0), meshCheck):\n  with element+node loads: `ERROR: meshCheck: invalid element vertex load ; meshCheck=1` (velotax/vnlotax are not shifted)\n  hmeshBase (&h, 0) on a Hmesh with a distinct vehdtax, NO loads: `ERROR: hmeshCheck: invalid non-halo end vertex array ; hmeshCheck=1` (loop over the NEW element range indexes the still old-based vehdtax).\nPatched meshBase/hmeshBase: all three checks return 0.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Two refinements: (1) in meshes made by meshLoad velotax and vnlotax are the SAME array (vnlotax = velotax), so a naive `velotax -= adj; vnlotax -= adj` would shift it twice; the patch shifts once when they alias. (2) vehdtax frequently aliases m.vendtax (e.g. hmesh_order_nd.c), in which case meshBase has already rebased it and hmeshBase must only re-alias, not add baseadj again.",
 "fix_options": [
  {
   "label": "Rebase all arrays consistently",
   "summary": "meshBase: shift velotax/vnlotax (once if they alias); hmeshBase: rebase vehdtax pointer first, add baseadj to its values only if it is a distinct array (else re-alias to m.vendtax).",
   "patch_sketch": "--- a/src/libscotch/mesh.c\n+++ b/src/libscotch/mesh.c\n@@ -176,6 +176,18 @@\n   meshptr->vendtax -= baseadj;\n   meshptr->edgetax -= baseadj;\n \n+  if (meshptr->vnlotax == meshptr->velotax) {     /* If element and node loads share the same array (e.g. meshLoad) */\n+    if (meshptr->velotax != NULL) {\n+      meshptr->velotax -= baseadj;                /* Shift it once only */\n+      meshptr->vnlotax  = meshptr->velotax;\n+    }\n+  }\n+  else {                                          /* Distinct load arrays, based at velmbas and vnodbas respectively */\n+    if (meshptr->velotax != NULL)\n+      meshptr->velotax -= baseadj;\n+    if (meshptr->vnlotax != NULL)\n+      meshptr->vnlotax -= baseadj;\n+  }\n   if (meshptr->vnumtax != NULL)\n     meshptr->vnumtax -= baseadj;\n   if (meshptr->vlbltax != NULL)\n--- a/src/libscotch/hmesh.c\n+++ b/src/libscotch/hmesh.c\n@@ -96,20 +96,26 @@\n   Gnum                baseold;                    /* Old base value  */\n   Gnum                baseadj;                    /* Base adjustment */\n   Gnum                velmnum;\n+  int                 vehdflag;                   /* Flag set if halo end array is the one of the mesh */\n \n   if (meshptr->m.baseval == baseval)              /* If nothing to do */\n     return (baseval);\n \n-  baseold = meshptr->m.baseval;                   /* Record old base value */\n-  baseadj = baseval - baseold;                    /* Compute adjustment    */\n-\n-  meshBase (&meshptr->m, baseval);                /* Change base of mesh */\n-\n-  for (velmnum = meshptr->m.velmbas; velmnum < meshptr->m.velmnnd; velmnum ++)\n-    meshptr->vehdtax[velmnum] += baseadj;         /* Change base of array */\n+  baseold  = meshptr->m.baseval;                  /* Record old base value */\n+  baseadj  = baseval - baseold;                   /* Compute adjustment    */\n+  vehdflag = (meshptr->vehdtax == meshptr->m.vendtax);\n+\n+  meshBase (&meshptr->m, baseval);                /* Change base of mesh, including its vendtab if shared */\n+\n+  if (vehdflag != 0)                              /* If halo end array is the mesh one, it has just been rebased */\n+    meshptr->vehdtax = meshptr->m.vendtax;\n+  else {                                          /* Else vehdtax is a distinct array, still based with old base */\n+    meshptr->vehdtax -= baseadj;                  /* Rebase access before looping on new element range           */\n+    for (velmnum = meshptr->m.velmbas; velmnum < meshptr->m.velmnnd; velmnum ++)\n+      meshptr->vehdtax[velmnum] += baseadj;       /* Change values of array */\n+  }\n \n   meshptr->vnohnnd += baseadj;\n-  meshptr->vehdtax -= baseadj;\n \n   return (baseold);                               /* Return old base value */\n }",
   "tradeoffs": "Latent bug, no callers; tested with the three harness checks. Any future caller gets correct bases.",
   "preferred": true
  },
  {
   "label": "Remove the dead functions",
   "summary": "Delete meshBase/hmeshBase (and their prototypes) since nothing uses them.",
   "patch_sketch": "-Gnum meshBase (Mesh * const, const Gnum);\n-Gnum hmeshBase (Hmesh * const, const Gnum);",
   "tradeoffs": "Zero risk now, but removes API-shaped internal functions the maintainers may want to keep for symmetry with graphBase.",
   "preferred": false
  }
 ],
 "notes": "Both options are plausible; graphBase() is maintained and called, so keeping and fixing mesh counterparts is the more natural choice.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-21",
 "area": "SEP",
 "our_title": "Halo-mesh copy size is now parenthesised so the multiplication applies to the difference",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read of the corrected expression is conclusive; the branch has no caller.",
 "location": "src/libscotch/hmesh_mesh.c:130",
 "evidence": "7.0.17: `memCpy (meshptr->vendtax + hmshptr->vnohnbr, hmshptr->m.verttax + hmshptr->vnohnnd, (hmshptr->m.vnodnbr - hmshptr->vnohnbr) * sizeof (Gnum));`",
 "upstream_change": "f36ab36 \"Bugfix: use parentheses to restore operator precedence [report R. Perry]\".",
 "review_accuracy": "Accurate (and latent, as the review said); fixed exactly as suggested.",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## SEP-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-08",
 "area": "SEP",
 "our_title": "Harwell-Boeing mesh reader indexes arrays with unchecked file values and leaves element load sum zero",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/mesh_io_habo.c:180-186 (velosum missing), 204-207 and 235-242 (checks only under SCOTCH_DEBUG_MESH2), 282",
 "evidence": "File untouched in 7.0.17. Test files built with work/SEP/t (hb_ok.mtx, hb_badvar.mtx, hb_badptr.mtx, hb_badptr2.mtx), harness sep08.c calling SCOTCH_meshGeomLoadHabo then SCOTCH_meshCheck on the pristine ASan lib:\n  ./sep08 hb_ok.mtx      -> ERROR: meshCheck: invalid element vertex load sum ; load=0 meshCheck=1   (velosum stays 0)\n  ./sep08 hb_badvar.mtx  (VARIND entry 9 > NVAR 3) -> AddressSanitizer: heap-buffer-overflow ... #0 meshGeomLoadHabo mesh_io_habo.c:242\n  ./sep08 hb_badptr2.mtx (ELTPTR 1,99,5) -> AddressSanitizer: SEGV ... mesh_io_habo.c:282\n  ./sep08 hb_badptr.mtx (last ELTPTR wrong) -> clean 'bad input (8)' (the only ELTPTR value validated in release builds).\nWith the patch: hb_ok -> load=0 meshCheck=0; the three bad files -> 'bad input (10)', '(7)', '(7)' and load=1, no ASan report.",
 "upstream_change": "",
 "review_accuracy": "Accurate; slightly understated: it is not only VARIND but also intermediate ELTPTR values (not just the last, which is checked at (8)) that are trusted. Review Fix (unconditional checks + velosum = habeltnbr) is right; note the debug-only branches also `return (1)` without freeing, which the patch fixes with meshFree.",
 "fix_options": [
  {
   "label": "Make the range checks unconditional and set velosum",
   "summary": "Drop the #ifdef SCOTCH_DEBUG_MESH2 around the ELTPTR and VARIND range checks, add monotonicity of ELTPTR, free the mesh on error, and set meshptr->velosum = habeltnbr.",
   "patch_sketch": "--- a/src/libscotch/mesh_io_habo.c\n+++ b/src/libscotch/mesh_io_habo.c\n@@ -184,6 +184,7 @@\n   meshptr->vnodbas = 1;\n   meshptr->vnodnnd = meshptr->velmbas;\n   meshptr->vnlosum = habvarnbr;\n+  meshptr->velosum = habeltnbr;                   /* Elements and nodes are not weighted */\n \n   for (velmnum = meshptr->velmbas; velmnum <= meshptr->velmnnd; velmnum ++) { /* Read ELTPTR as second part of vertex array */\n     Gnum              habcolval;                  /* Current column value                                                   */\n@@ -200,12 +201,12 @@\n       meshFree   (meshptr);\n       return (1);\n     }\n-#ifdef SCOTCH_DEBUG_MESH2\n-    if ((habcolval < 1) || (habcolval > (habvixnbr + 1))) {\n+    if ((habcolval < 1) || (habcolval > (habvixnbr + 1)) || /* Always check values read from file */\n+        ((velmnum > meshptr->velmbas) && (habcolval + habvixnbr < meshptr->verttax[velmnum - 1]))) { /* ELTPTR must be non-decreasing */\n       errorPrint (\"meshGeomLoadHabo: bad input (7)\");\n+      meshFree   (meshptr);\n       return (1);\n     }\n-#endif /* SCOTCH_DEBUG_MESH2 */\n \n     meshptr->verttax[velmnum] = habcolval + habvixnbr;\n   }\n@@ -232,12 +233,11 @@\n       meshFree   (meshptr);\n       return (1);\n     }\n-#ifdef SCOTCH_DEBUG_MESH2\n-    if ((habnodval < 1) || (habnodval > habvarnbr)) {\n+    if ((habnodval < 1) || (habnodval > habvarnbr)) { /* Always check values read from file */\n       errorPrint (\"meshGeomLoadHabo: bad input (10)\");\n+      meshFree   (meshptr);\n       return (1);\n     }\n-#endif /* SCOTCH_DEBUG_MESH2 */\n     meshptr->edgetax[edgenum] = habnodval;\n     meshptr->verttax[habnodval] ++;\n   }",
   "tradeoffs": "Tiny runtime cost (two compares per value). Tested on the four files above. A malformed file now fails cleanly.",
   "preferred": true
  },
  {
   "label": "Separate validated reader helper",
   "summary": "Factor the fixed-width integer reader of both loops into a static helper `meshGeomLoadHaboInt (stream, width, min, max, &val)` that returns an error when the value is outside [min,max] or EOF, called with (1, habvixnbr + 1) for ELTPTR and (1, habvarnbr) for VARIND; keep velosum fix.",
   "patch_sketch": "static int meshGeomLoadHaboInt (FILE * stream, int siz, Gnum minval, Gnum maxval, Gnum * valptr);  /* reads siz columns, returns !0 if EOF or out of range */\n...\n  if (meshGeomLoadHaboInt (filesrcptr, habcolsiz, 1, habvixnbr + 1, &habcolval) != 0) { meshFree (meshptr); return (1); }",
   "tradeoffs": "Cleaner and removes the duplicated parsing loops but a larger diff (not compiled here). Same behaviour as option 1.",
   "preferred": false
  }
 ],
 "notes": "Precedent: the graph Harwell-Boeing loader (graph_io_habo.c) reports 'bad input (n)' for malformed data in release builds; option 1 matches that.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## API-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-08",
 "area": "API",
 "our_title": "Fortran Harwell-Boeing mesh loader wrapper hands NULL to a routine that calls atol on it",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_mesh_io_habo_f.c:115 (calls SCOTCH_meshGeomLoadHabo(..., NULL)); mesh_io_habo.c:94 (atol (dataptr))",
 "evidence": "Unchanged. Reproducer work/API/fort.c mode 1 (scotchfmeshgeomloadhabo_(&m,&g,&fd0,&fd1,\"0\",&ierr,1)) on ASan 7.0.17: 'mesh_io_habo.c:94:21: runtime error: null pointer passed as argument 1, which is declared to never be null' then 'AddressSanitizer: SEGV ... #1 atol ... #2 _SCOTCHmeshGeomLoadHabo ... #4 SCOTCHFMESHGEOMLOADHABO library_mesh_io_habo_f.c:115'. The C entry SCOTCH_meshGeomLoadHabo has the same crash for dataptr==NULL.",
 "upstream_change": "",
 "review_accuracy": "accurate. Additionally the doc (s_l.tex:7296-7305) says the Fortran routine takes 'character (*) string' = the matrix rank, so the wrapper ignoring it (comment '/* No use */' copied from the Scot variant) is a functional bug, not only a crash; and simply passing a Fortran string would be unsafe because it is not NUL-terminated.",
 "fix_options": [
  {
   "label": "Copy the Fortran string and pass it (honour the documented parameter)",
   "summary": "Copy datanbr bytes into a NUL-terminated buffer exactly like STRATGRAPHMAP does (library_graph_map_f.c:319-331) and pass it to SCOTCH_meshGeomLoadHabo; free on all exits.",
   "patch_sketch": "--- library_mesh_io_habo_f.c\n+++ library_mesh_io_habo_f.c\n@@ -75,7 +75,7 @@\n SCOTCH_Geom * const         geomptr,              \\\n const int * const           filegrfptr,           \\\n const int * const           filegeoptr,           \\\n-const char * const          dataptr, /* No use */ \\\n+const char * const          dataptr,              \\\n int * const                 revaptr,              \\\n const int                   datanbr),             \\\n (meshptr, geomptr, filegrfptr, filegeoptr, dataptr, revaptr, datanbr))\n@@ -84,16 +84,27 @@\n   FILE *              filegeostream;\n   int                 filegrfnum;                 /* Duplicated handle */\n   int                 filegeonum;\n+  char * restrict     strtab;                     /* Pointer to null-terminated string */\n   int                 o;\n \n+  if ((strtab = (char *) memAlloc (datanbr + 1)) == NULL) { /* Fortran strings are not null-terminated */\n+    errorPrint (STRINGIFY (SCOTCH_NAME_PUBLICFU (MESHGEOMLOADHABO)) \": out of memory\");\n+    *revaptr = 1;\n+    return;\n+  }\n+  memCpy (strtab, dataptr, datanbr);              /* Copy string contents */\n+  strtab[datanbr] = '\\0';                         /* Terminate string     */\n+\n   if ((filegrfnum = dup (*filegrfptr)) < 0) {     /* If cannot duplicate file descriptor */\n     errorPrint (STRINGIFY (SCOTCH_NAME_PUBLICFU (MESHGEOMLOADHABO)) \": cannot duplicate handle (1)\");\n+    memFree    (strtab);\n     *revaptr = 1;                                 /* Indicate error */\n     return;\n   }\n   if ((filegeonum = dup (*filegeoptr)) < 0) {     /* If cannot duplicate file descriptor */\n     errorPrint (STRINGIFY (SCOTCH_NAME_PUBLICFU (MESHGEOMLOADHABO)) \": cannot duplicate handle (2)\");\n     close      (filegrfnum);\n+    memFree    (strtab);\n     *revaptr = 1;                     ...(frees on every return path; full diff in work/API/diffs/library_mesh_io_habo_f.c.diff)",
   "tradeoffs": "Fixes the crash and makes the 'string' argument work as documented. Tested: with stdin=/dev/null the call now returns ierr=1 via 'meshGeomLoadHabo: bad input (2)' (empty file), no crash, no leak. Not tested with a real Harwell-Boeing file. Slight code growth.",
   "preferred": true
  },
  {
   "label": "Treat NULL as matrix 0 in the loader",
   "summary": "In meshGeomLoadHabo: 'habmattag = (dataptr != NULL) ? atol (dataptr) : 0L;' and keep the wrapper passing NULL.",
   "patch_sketch": "-  if (((habmattag = atol (dataptr)) == 0) &&\n-      (dataptr[0] != '0') && (dataptr[0] != '\\0')) {\n+  if (dataptr == NULL)\n+    habmattag = 0;\n+  else if (((habmattag = atol (dataptr)) == 0) && (dataptr[0] != '0') && (dataptr[0] != '\\0')) {",
   "tradeoffs": "Smallest change and also fixes direct C callers passing NULL, but Fortran users still cannot select a matrix other than 0, so the documented argument stays a no-op.",
   "preferred": false
  }
 ],
 "notes": "Maintainers probably prefer option 1 because the Fortran string wrappers all use the memAlloc+memCpy+terminate idiom.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## SEP-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "SEP-16",
 "area": "SEP",
 "our_title": "Geometry loader matches coordinate labels against the first vertices' labels instead of node labels",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/mesh_io_scot.c:169",
 "evidence": "File untouched. Line 169 is still `vnodsorttab[vnodnum].labl = meshptr->vlbltax[vnodnum + meshptr->baseval];`.\nHandcrafted labelled mesh (m16.msh, 2 elements + 4 nodes, elements first, base 0 => stored node labels 2..5) and two geometry files, harness work/SEP/t/sep16b.c, pristine lib:\n  geometry labelled with the node labels 2..5 : ERROR: meshGeomLoadScot: vertex geometry data not found (0) ; load=1\n  geometry labelled 0..3 (the ELEMENT/first-range labels)        : load=0 check=0 (coordinates silently attached to the wrong labels)\nPatched (`vlbltax[vnodnum + meshptr->vnodbas]`): the 2..5 file loads and gives the expected coordinates; the 0..3 file now fails with `not found (4)`. meshGeomSaveScot writes `vlbltax[vnodnum]` for vnodnum in [vnodbas, vnodnnd), i.e. the patched range.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Suggested Fix is right.",
 "fix_options": [
  {
   "label": "Index with vnodbas (review Fix)",
   "summary": "Use meshptr->vlbltax[vnodnum + meshptr->vnodbas].",
   "patch_sketch": "--- a/src/libscotch/mesh_io_scot.c\n+++ b/src/libscotch/mesh_io_scot.c\n@@ -166,7 +166,7 @@\n   if (meshptr->vlbltax != NULL) {                 /* If graph has vertex labels */\n     vnodsortflag = 1;                             /* Assume graph data sorted   */\n     for (vnodnum = 0; vnodnum < meshptr->vnodnbr; vnodnum ++) {\n-      vnodsorttab[vnodnum].labl = meshptr->vlbltax[vnodnum + meshptr->baseval];\n+      vnodsorttab[vnodnum].labl = meshptr->vlbltax[vnodnum + meshptr->vnodbas]; /* Node labels are in [vnodbas, vnodnnd) */\n       vnodsorttab[vnodnum].num  = vnodnum;\n       if ((vnodnum > 0) &&                        /* Check if graph data sorted */\n           (vnodsorttab[vnodnum].labl < vnodsorttab[vnodnum - 1].labl))",
   "tradeoffs": "One-token fix, makes Save/Load coherent for elements-first meshes. Behaviour change: geometry files that (wrongly) relied on the old range stop loading. Needs a Scotch-mesh+geometry round-trip test.",
   "preferred": true
  },
  {
   "label": "Loop on absolute node numbers",
   "summary": "Iterate vnodnum from vnodbas to vnodnnd (like meshGeomSaveScot) and store num = vnodnum - vnodbas, which removes the offset arithmetic altogether.",
   "patch_sketch": "-    for (vnodnum = 0; vnodnum < meshptr->vnodnbr; vnodnum ++) {\n-      vnodsorttab[vnodnum].labl = meshptr->vlbltax[vnodnum + meshptr->baseval];\n+    for (vnodnum = 0; vnodnum < meshptr->vnodnbr; vnodnum ++) {\n+      vnodsorttab[vnodnum].labl = meshptr->vlbltax[meshptr->vnodbas + vnodnum];",
   "tradeoffs": "Same effect; more explicit. ",
   "preferred": false
  }
 ],
 "notes": "EXTRA, found while building the reproducer (not in the review): mesh.h defines MESHFREEOTHR and MESHVERTGROUP both as 0x0010. meshLoad of a LABELLED mesh sets MESHFREEVERT|MESHVERTGROUP, so meshFree() also takes the MESHFREEOTHR branch and frees vlbltax - an interior pointer into the already freed vertex group. Pristine ASan: load m16.msh then SCOTCH_meshExit -> `AddressSanitizer: attempting free on address which was not malloc()-ed ... #1 _SCOTCHmeshFree mesh.c:132 #2 meshExit`; the same happens on every meshLoad error path after labels were read (e.g. 'cannot relabel vertices'). Fix: give MESHVERTGROUP its own bit (0x0020).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/SEP/diffs/ if any; harness sources alongside)


===================================================================
## API-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-06",
 "area": "API",
 "our_title": "Mesh entry points unwrap context containers before touching Mesh fields",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_mesh_order.c:110, 147, 164, 181; library_mesh.c; library_mesh_graph.c:82, 99 (input mesh)",
 "evidence": "7.0.17 uses (Mesh *) CONTEXTOBJECT (meshptr) in SCOTCH_meshOrderInit, OrderSave*, meshLoad/Save/Check/Size/Data/Stat/Build and meshGraph/meshGraphDual (input side). Ran work/API/msh.c on ASan build with a 20-element chain mesh bound via SCOTCH_contextBindMesh: modes 0 (plain) and 1 (bound) both give meshOrder=0 perm0=20, meshCheck=0; mode 3 meshCheck/meshSize/meshGraph on the container also clean. No sanitizer output.",
 "upstream_change": "6a030db Bugfix: guard SCOTCH_mesh*() API routines with Context pass-through macros [report R. Perry]",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "The OUTPUT graph handle of SCOTCH_meshGraph/meshGraphDual is still not unwrapped, tracked in API-12.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-12",
 "area": "API",
 "our_title": "Graph dump and output graph handles of mesh/dmesh builders still skip container unwrapping",
 "claimed_severity": "medium",
 "status": "partially-fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "library_dmesh_dgraph.c:78; library_graph_dump.c:87; library_mesh_graph.c:82, 99 (output graph arg); (library_dgraph_gather.c fixed)",
 "evidence": "Fixed in 7.0.17: SCOTCH_dgraphGather (srccgrfptr = CONTEXTOBJECT) and the INPUT mesh in meshGraph/meshGraphDual. Still present: (a) SCOTCH_graphDump: 'grafptr = (const Graph *) libgrafptr;' - work/API/bnd.c mode 0 (dump a graph bound with SCOTCH_contextBindGraph) prints container bytes ('pverttabs[] = { 0, 0, 4, 4, 934281296, 32600, ...') then 'AddressSanitizer: stack-buffer-overflow READ of size 4 ... graph_dump.c:164 _SCOTCHgraphDumpArray'; mode 1 (plain graph) is correct. (b) meshGraph with a bound OUTPUT graph: bnd.c mode 2 -> r=0 but the original out graph keeps vertnbr=0 and the container itself is overwritten by a Graph (no memory error since sizeof(SCOTCH_Graph) >= sizeof(Graph); review's 'overflow' wording is too strong). (c) SCOTCH_dmeshDgraphDual: 'dmeshDgraphDual ((Dmesh *) meshptr, (Dgraph *) grafptr, noconbr)' - source-read only (no MPI test; there is no SCOTCH_contextBindDmesh so only the Dgraph output can be a container).",
 "upstream_change": "04c85e9 (dgraphGather), 6a030db (mesh input handles)",
 "review_accuracy": "Mostly accurate; dgraphGather part is fixed, 'writes a whole graph over the small container' is wrong for meshGraph (same size) but graphDump over-read is real and ASan-confirmed.",
 "fix_options": [
  {
   "label": "CONTEXTOBJECT on the remaining handles",
   "summary": "graphDump: grafptr = (const Graph *) CONTEXTOBJECT (libgrafptr); meshGraph/meshGraphDual: output (Graph *) CONTEXTOBJECT (grafptr); dmeshDgraphDual: output (Dgraph *) CONTEXTOBJECT (grafptr); add #include \"context.h\".",
   "patch_sketch": "--- library_graph_dump.c\n+++ library_graph_dump.c\n@@ -52,6 +52,7 @@\n \n #include \"module.h\"\n #include \"common.h\"\n+#include \"context.h\"\n #include \"graph.h\"\n #include \"graph_dump.h\"\n #include \"scotch.h\"\n@@ -84,7 +85,7 @@\n \n   prefstr = (prefptr != NULL) ? prefptr : \"\";\n   suffstr = (suffptr != NULL) ? suffptr : \"\";\n-  grafptr = (const Graph *) libgrafptr;\n+  grafptr = (const Graph *) CONTEXTOBJECT (libgrafptr);\n \n   o = graphDumpArrays (grafptr, \"SCOTCH_Num\", prefstr, suffstr, fileptr);\n--- library_mesh_graph.c\n+++ library_mesh_graph.c\n@@ -80,7 +80,7 @@\n const SCOTCH_Mesh * restrict const  meshptr,\n SCOTCH_Graph * restrict const       grafptr)\n {\n-  return (meshGraphNodal ((Mesh *) CONTEXTOBJECT (meshptr), (Graph *) grafptr));\n+  return (meshGraphNodal ((Mesh *) CONTEXTOBJECT (meshptr), (Graph *) CONTEXTOBJECT (grafptr)));\n }\n \n /* This routine builds an opaque dual graph structure\n@@ -97,5 +97,5 @@\n SCOTCH_Graph * restrict const       grafptr,\n const SCOTCH_Num                    noconbr)\n {\n-  return (meshGraphDual ((Mesh *) CONTEXTOBJECT (meshptr), (Graph *) grafptr, noconbr));\n+  return (meshGraphDual ((Mesh *) CONTEXTOBJECT (meshptr), (Graph *) CONTEXTOBJECT (grafptr), noconbr));\n }\n--- library_dmesh_dgraph.c\n+++ library_dmesh_dgraph.c\n@@ -49,6 +49,7 @@\n \n #include \"module.h\"\n #include \"common.h\"\n+#include \"context.h\"\n #include \"dgraph.h\"\n #include \"dmesh.h\"\n #include \"ptscotch.h\"\n@@ -75,5 +76,5 @@\n SCOTCH_Dgraph * restrict const      grafptr,\n const SCOTCH_Num                    noconbr)\n {\n-  return (dmeshDgraphDual ((Dmesh *) meshptr, (Dgraph *) grafptr, noconbr));\n+  return (dmeshDgraphDual ((Dmesh *) meshptr, (Dgraph *) CONTEXTOBJECT (grafptr), noconbr));\n }\n",
   "tradeoffs": "Exactly the idiom upstream used in 6a030db and for dgraphCoarsen's output (library_dgraph_coarsen.c: 'coargrafptr = CONTEXTOBJECT (clibgrafptr)'). Tested: graphDump on a bound graph now dumps the real arrays; meshGraph into a bound output graph fills the underlying graph (vertnbr=21). dmesh variant only compiled.",
   "preferred": true
  },
  {
   "label": "Reject containers where they make no sense",
   "summary": "For output-only handles (meshGraph, dmeshDgraphDual) return 1 with errorPrint if contextContainerTrue(grafptr).",
   "patch_sketch": "if (contextContainerTrue (grafptr)) { errorPrint (STRINGIFY (SCOTCH_meshGraph) \": cannot output to a container\"); return (1); }",
   "tradeoffs": "Safer if the output graph is expected to be uninitialised (bind needs an initialised graph), avoids silently different semantics; but diverges from the CONTEXTOBJECT-everywhere direction upstream just took.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "partially-fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)
