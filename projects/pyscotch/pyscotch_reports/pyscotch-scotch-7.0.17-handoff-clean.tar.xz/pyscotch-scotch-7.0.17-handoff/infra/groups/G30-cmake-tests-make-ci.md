# G30-cmake-tests-make-ci

Items: BLD-05, BLD-08, BLD-09, BLD-10, BLD-11, BLD-03, BLD-07, BLD-14, BLD-21



===================================================================
## BLD-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-05",
 "area": "BLD",
 "our_title": "One CMake overlap-mapping test omits the -o flag that makes gmtst evaluate overlap",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/check/CMakeLists.txt:685-686; src/check/Makefile:776",
 "evidence": "7.0.17 CMakeLists.txt:686 `'$<TARGET_FILE:gmtst>' '${dat}/bump_imbal_32.grf' '${tgt}/k32.tgt' bump_imbal_32_part_ovl_32.map` (no -o) whereas Makefile:776 has `gmtst -o data/bump_imbal_32.grf ...` and CMake gpart_overlap_1 (line ~683) and _4 do pass -o. Ran with the 7.0.17 build: `gpart -o 32 data/bump_imbal_32.grf ovl32.map -vmt`, then `gmtst data/bump_imbal_32.grf tgt/k32.tgt ovl32.map` -> `M Processors 0/32 (0)`, `Target min=0 max=0 ...`, `CommDilat=0.000000`, exit 0; with `gmtst -o ...` -> `P sep=1175`, `P min=388 max=458 avg=419.969`, `P maxavg=1.09056 minavg=0.923878`, exit 0. So without -o the overlap map is read as an ordinary map and nothing meaningful is checked.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. Note neither mode makes gmtst exit non-zero on a bad map; -o merely makes it print the overlap statistics (the test still has no assertion), same as the Makefile.",
 "fix_options": [
  {
   "label": "Add -o (match Makefile)",
   "summary": "Insert -o in the gmtst call of gpart_overlap_2.",
   "patch_sketch": "-  '$<TARGET_FILE:gmtst>' '${dat}/bump_imbal_32.grf' ...\n+  '$<TARGET_FILE:gmtst>' -o '${dat}/bump_imbal_32.grf' ...",
   "tradeoffs": "One token; no risk.",
   "preferred": true
  },
  {
   "label": "Also assert on the output",
   "summary": "In addition to -o, make the test fail unless gmtst's `P sep=` line is present / separator count > 0 (e.g. pipe to grep -q '^P\\s*sep=').",
   "patch_sketch": "... && '$<TARGET_FILE:gmtst>' -o ... | grep -q '^P[[:space:]]*sep='  # pipefail needed",
   "tradeoffs": "Gives the test teeth but diverges from the Makefile test; relies on output format.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (parity with the Makefile, which is the reference for the CMake port).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-08",
 "area": "BLD",
 "our_title": "Scatter/gather CMake tests chain three commands with semicolons so only the file comparison decides the result",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/check/CMakeLists.txt:739-758 (7.0.17 lines ~739-762)",
 "evidence": "7.0.17: test_dgscat, test_dgscat_b100000 and test_dgscat_b1 are `${BASH} -c \"mpiexec dgscat ... ; mpiexec dggath ... ; cmake -E compare_files in out\"` -- three commands joined with `;`, so the test status is that of compare_files only. Demonstration: `cp m16x16.grf out_dggat.grf; bash -c \"false ; false ; cmp m16x16.grf out_dggat.grf\"` -> exit 0 (stale output compares equal). The output file name is fixed (out_dggat.grf) and ctest runs in the build directory, so a file from an earlier successful run persists. (Other tests in this file use `&&`, e.g. gpart_cluster_2.) mpirun not run for the full chain; stale-file mechanism shown with the shell stand-in.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Join with && and remove stale outputs",
   "summary": "Replace `;` by `&&` and prefix `rm -f out_dgscat-*.grf out_dggat.grf &&`.",
   "patch_sketch": "-      -r1 -c '${dat}/m16x16.grf' out_dgscat-%r.grf ; \\\n+      -r1 -c '${dat}/m16x16.grf' out_dgscat-%r.grf && \\\n(and rm -f ... at the start; likewise the dggath line)",
   "tradeoffs": "Matches the style of all neighbouring tests; no behavior change when everything passes.",
   "preferred": true
  },
  {
   "label": "Use CTest fixtures",
   "summary": "Split into three tests (scatter, gather, compare) with FIXTURES_SETUP/REQUIRED and a cleanup fixture that deletes outputs.",
   "patch_sketch": "set_tests_properties(test_dgscat_scatter PROPERTIES FIXTURES_SETUP SCAT)\nset_tests_properties(test_dgscat_gather PROPERTIES FIXTURES_REQUIRED SCAT FIXTURES_SETUP GATH) ...",
   "tradeoffs": "Better reporting (which stage failed); the file already uses FIXTURES_REQUIRED for mmk/mcv; more lines to maintain.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (minimal; the file's own idiom `cmd && cmd` in gpart_* tests).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-09",
 "area": "BLD",
 "our_title": "Fortran header generation rules list the C template header as dependency instead of the Fortran template",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Edit library_f.h after a cmake build and check whether scotchf.h is regenerated.",
 "location": "src/libscotch/CMakeLists.txt:80, 103",
 "evidence": "7.0.17: scotchf.h rule (lines ~75-82) runs dummysizes on `library_f.h` but declares `DEPENDS library.h` (line 80); ptscotchf.h rule runs on `library_pt_f.h` with `DEPENDS library.h` (line 103). By contrast scotch.h correctly lists `DEPENDS library.h` (line 71) for library.h and ptscotch.h lists `library_pt.h scotch_h`. cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; so the stale-build effect was not exercised.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Depend on the real templates",
   "summary": "DEPENDS library_f.h / library_pt_f.h (add dummysizes target is already listed).",
   "patch_sketch": "-  DEPENDS library.h\n+  DEPENDS library_f.h   # scotchf.h\n(and library_pt_f.h for ptscotchf.h)",
   "tradeoffs": "Pure dependency fix; negligible risk.",
   "preferred": true
  },
  {
   "label": "Depend on both",
   "summary": "Keep library.h and add the _f template (the generated Fortran header embeds sizes derived by compiling library.h-related types).",
   "patch_sketch": "DEPENDS library.h library_f.h",
   "tradeoffs": "Over-rebuilds slightly (library.h edits regenerate Fortran header) but safe if dummysizes output depends on more than the template.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; mirrors the scotch.h/ptscotch.h rules right above.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-10",
 "area": "BLD",
 "our_title": "Fortran test-template helper depends on an undefined variable, so template edits do not trigger regeneration",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "source-read",
 "needs": "external-dependency",
 "needs_note": "Edit a .f90.in after a cmake build and see whether the .f90 is regenerated.",
 "location": "src/check/CMakeLists.txt:67-103 (DEPENDS at 78-79; COMMENT at 80)",
 "evidence": "7.0.17 function suffix_fortran_file(src): only `src` and `file_we` are defined; the add_custom_command has `DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/${file}` with ${file} undefined -> the source directory itself, and `COMMENT \"Generate ${file}.f90\"` prints 'Generate .f90'. The command's real input `${CMAKE_CURRENT_SOURCE_DIR}/${file_we}.in` (line ~74) is not listed. Second stage (line ~97-101) uses `DEPENDS ${file_we}_tmp`, a custom-target name, which orders but does not make the output depend on the .tmp file timestamp. cmake is not installed in this environment (no network either), so the CMake configure/generate step could not be run; so the missing rebuild was inferred, not observed.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate, including the second point (the review's fix mentions depending on the .tmp path).",
 "fix_options": [
  {
   "label": "Depend on the real files",
   "summary": "Use the .in path and the .tmp path as DEPENDS.",
   "patch_sketch": "-    ${CMAKE_CURRENT_SOURCE_DIR}/${file}\n+    ${CMAKE_CURRENT_SOURCE_DIR}/${file_we}.in\n ...\n-    DEPENDS\n-      ${file_we}_tmp\n+    DEPENDS\n+      ${CMAKE_CURRENT_BINARY_DIR}/${file_we}.tmp ${file_we}_tmp\n-  COMMENT \"Generate ${file}.f90\"\n+  COMMENT \"Generate ${file_we}.f90\"",
   "tradeoffs": "Pure build-correctness fix; test .f90 now regenerate on edit.",
   "preferred": true
  },
  {
   "label": "Collapse the two-stage generation",
   "summary": "Do the dummysizes call and the regex substitution in one custom command (script step) so only one OUTPUT/DEPENDS pair exists.",
   "patch_sketch": "add_custom_command(OUTPUT ${out} COMMAND dummysizes ... && ${CMAKE_COMMAND} -P cmake_sed.cmake DEPENDS dummysizes ${CMAKE_CURRENT_SOURCE_DIR}/${file_we}.in)",
   "tradeoffs": "Removes two helper targets (`*_tmp`, `*_src`); larger rewrite; the .tmp intermediate is useful for debugging.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; keeps the structure the maintainers wrote.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-11",
 "area": "BLD",
 "our_title": "One ParMETIS Fortran object rule lacks the generated parmetis.h prerequisite its siblings list",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/Makefile:205-208",
 "evidence": "7.0.17 rule `parmetis_dgraph_dual_f_$(V)$(OBJ): parmetis_dgraph_dual_f.c ../libscotch/module.h ../libscotch/common.h $(SCOTCHINCLUDEDIR)/ptscotch.h` has no `parmetis.h`; the five sibling parmetis_* rules (lines 177-203) all list it. parmetis_dgraph_dual_f.c:54 does `#include \"parmetis.h\"`. Reproduced on a 7.0.17 Makefile build: `touch parmetis.h; make -n ptscotch | grep -o -- '-c parmetis[a-z_]*\\.c'` -> parmetis_dgraph_order.c, parmetis_dgraph_dual.c, parmetis_dgraph_order_f.c, parmetis_dgraph_part.c, parmetis_dgraph_part_f.c -- parmetis_dgraph_dual_f.c is missing (not rebuilt). The -j ordering race (compiled before parmetis.h exists) was not provoked; only the stale-rebuild consequence was shown.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate on the missing prerequisite. The 'compile before header exists' part of the claim was not reproduced (generator rule ordering in practice put parmetis.h first).",
 "fix_options": [
  {
   "label": "Add parmetis.h prerequisite",
   "summary": "Append `parmetis.h` to the rule like its siblings.",
   "patch_sketch": "                                        $(SCOTCHINCLUDEDIR)/ptscotch.h\n+                                       parmetis.h",
   "tradeoffs": "Tested on a copy: after the edit, `touch parmetis.h; make -n ptscotch` rebuilds all six parmetis objects. Zero risk.",
   "preferred": true
  },
  {
   "label": "Use a pattern/variable for common headers",
   "summary": "Define PARMETISDEPS = ../libscotch/module.h ../libscotch/common.h $(SCOTCHINCLUDEDIR)/ptscotch.h parmetis.h and use it in all rules.",
   "patch_sketch": "PARMETISDEPS = ...\nparmetis_dgraph_dual_f_$(V)$(OBJ): parmetis_dgraph_dual_f.c $(PARMETISDEPS)",
   "tradeoffs": "Prevents recurrence but diverges from the file's flat explicit style.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; the Makefiles here deliberately spell out every prerequisite per object.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-03",
 "area": "BLD",
 "our_title": "Unquoted heredoc expands the Sonar token into a file the CI job archives for 15 days",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Script and job text are conclusive; confirming scanner log masking would need running the CI job, which is not wanted.",
 "location": "ci/analysis.sh:26-28; .gitlab-ci.yml:127-146 (scotch_sonar)",
 "evidence": "Verified from script text only (no CI secret touched, no network). ci/analysis.sh:26 `cat > sonar-project.properties << EOF` (unquoted delimiter, so variables expand) and :28 `sonar.login=$SONARQUBE_LOGIN`. .gitlab-ci.yml scotch_sonar: script runs `ci/analysis.sh` then `sonar-scanner -X > sonar.log`; artifacts paths include `sonar-project.properties` and `./*.log` (so also sonar.log from the -X debug run), `expire_in: 15 days`. Hence the expanded token is stored in the archived file for 15 days. The -X log may print the effective properties; that part is unverified (scanner not run), the scanner often masks sonar.login/token but this was not checked.",
 "upstream_change": "none (7.0.17 changed ci/test_cmake.sh only in CI)",
 "review_accuracy": "Accurate. Caveat: the job only runs for scheduled pipelines (rules: $CI_PIPELINE_SOURCE == \"schedule\") and has tags ['sonar'], which limits but does not remove exposure. sonar.login is also deprecated in favour of sonar.token / SONAR_TOKEN.",
 "fix_options": [
  {
   "label": "Token via environment, not file",
   "summary": "Remove the line from the heredoc; export SONAR_TOKEN=$SONARQUBE_LOGIN in the job (SonarScanner reads SONAR_TOKEN).",
   "patch_sketch": "--- a/ci/analysis.sh\n-sonar.login=$SONARQUBE_LOGIN\n--- a/.gitlab-ci.yml\n   script:\n+    - export SONAR_TOKEN=\"$SONARQUBE_LOGIN\"\n     - ci/analysis.sh\n-    - sonar-scanner -X > sonar.log",
   "tradeoffs": "Token never hits disk or artifacts. Requires scanner >= 5.x/server supporting SONAR_TOKEN. Existing token must still be rotated since earlier artifacts contain it.",
   "preferred": true
  },
  {
   "label": "Keep the file, stop archiving it",
   "summary": "Leave analysis.sh unchanged; remove sonar-project.properties and sonar.log from artifacts.paths (or add `exclude:`), drop -X.",
   "patch_sketch": "   artifacts:\n     paths:\n       - analyzer_reports\n-      - sonar-project.properties\n-      - ./*.log\n+      - scotch-*.log",
   "tradeoffs": "Minimal and does not depend on scanner version; but `./*.xml`/other globs and other jobs' `untracked: true` artifacts must be re-audited, and the token still sits in the runner workspace.",
   "preferred": false
  },
  {
   "label": "Delete the file in after_script",
   "summary": "`after_script: [rm -f sonar-project.properties sonar.log]` plus quoting the heredoc so the token is passed with -Dsonar.token on the command line.",
   "patch_sketch": "sonar-scanner -Dsonar.token=\"$SONARQUBE_LOGIN\" > sonar.log",
   "tradeoffs": "Token appears on the process command line of the runner; weaker than option 1.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; GitLab masked variables protect logs, and SONAR_TOKEN is the documented non-file channel. Rotate the token regardless (cannot be done from here).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-07",
 "area": "BLD",
 "our_title": "CI Makefile build pipes make into tee under eval without pipefail, so build errors are masked",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "ci/build_makefile.sh:19",
 "evidence": "7.0.17 line 19: `eval '${SCAN}make -j scotch ptscotch esmumps ptesmumps COVERAGE=$COVERAGE 2>&1 | tee ../scotch-build-${JOBNAME}.log' || fatal`; file has `#!/bin/bash` and no `set -o pipefail`. Shell demonstration with the same construct: `bash -c 'eval \"false 2>&1 | tee /dev/null\" || echo FATAL'` prints nothing (status 0); with `set -o pipefail` first it prints FATAL. So the exit status of the build is tee's.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate (the failure would surface only in the test stage, as the review says).",
 "fix_options": [
  {
   "label": "set -o pipefail",
   "summary": "Add `set -o pipefail` after the shebang (script is bash).",
   "patch_sketch": "--- a/ci/build_makefile.sh\n #!/bin/bash\n+set -o pipefail",
   "tradeoffs": "Tested construct returns non-zero. Also affects the `scan-build` prefix path; no other change. Same fix is advisable in ci/test_makefile.sh if it pipes.",
   "preferred": true
  },
  {
   "label": "Check PIPESTATUS",
   "summary": "Capture ${PIPESTATUS[0]} inside the eval and fatal on it.",
   "patch_sketch": "eval '... | tee ...; exit ${PIPESTATUS[0]}' || fatal",
   "tradeoffs": "Works without global option change; slightly obscure.",
   "preferred": false
  },
  {
   "label": "Avoid the pipe",
   "summary": "Redirect with `> log 2>&1; rc=$?; cat log; [ $rc = 0 ] || fatal`.",
   "patch_sketch": "make ... > ../scotch-build-${JOBNAME}.log 2>&1 || { cat ../scotch-build-${JOBNAME}.log; fatal; }",
   "tradeoffs": "Loses live log streaming in the GitLab job.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; ci scripts are already bash (they use `[[ ]]`).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-14",
 "area": "BLD",
 "our_title": "CI integer-size '64' rows add no flags and CMake rows use only default options",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "source-read",
 "needs": "other-platform",
 "needs_note": "Inspect the GitLab runner definitions behind the 32bits/64bits tags and run the pipeline.",
 "location": "ci/env_makefile.sh:7-14; .gitlab-ci.yml:7-46; ci/build_cmake.sh:11",
 "evidence": "7.0.17 ci/env_makefile.sh: `case JOB_INT in 32) flags unchanged;; 32-64) += -DINTSIZE64 -DIDXSIZE64;; 64) flags unchanged;;`. .gitlab-ci.yml: matrix_32 (JOB_INT 32, 32-64) runs with tags ['32bits'], matrix_64 (JOB_INT 64 only) runs with tags ['64bits']. src/libscotch/common.h:216-258 shows the default SCOTCH_Num is `int` unless INTSIZE64 is defined, so '64' jobs build 32-bit integers; -DINTSIZE64 appears only in '32-64' jobs. ci/build_cmake.sh:11 `cmake -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_SHARED_LIBS=ON ..` -- no INTSIZE, IDXSIZE, SCOTCH_NAME_SUFFIX, SCOTCH_DETERMINISTIC. The runner architecture behind tags '32bits'/'64bits' cannot be verified from the repository, so 'only exercised on 32-bit runners' is inferred from the tag names.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate about flags; the 'on 32-bit runners' wording depends on what the runner tags mean (unverifiable here).",
 "fix_options": [
  {
   "label": "Make '64' really 64-bit and widen CMake matrix",
   "summary": "JOB_INT=64 adds -DINTSIZE64 -DIDXSIZE64; add CMake jobs with -DINTSIZE=64 and one with -DSCOTCH_NAME_SUFFIX=_test.",
   "patch_sketch": "--- a/ci/env_makefile.sh\n      64 )\n-       export JOBBUILDFLAGS=\"${JOBBUILDFLAGS}\" ;;\n+       export JOBBUILDFLAGS=\"${JOBBUILDFLAGS} -DINTSIZE64 -DIDXSIZE64\" ;;\n--- a/ci/build_cmake.sh\n+cmake ... ${CMAKE_EXTRA_ARGS} ..",
   "tradeoffs": "Raises CI time; may expose genuine 64-bit failures that were hidden (the point). Maintainers must triage.",
   "preferred": true
  },
  {
   "label": "Add new rows instead of changing '64'",
   "summary": "Introduce JOB_INT=64i (explicit INTSIZE64) leaving '64' as the default-int control.",
   "patch_sketch": "64i ) export JOBBUILDFLAGS=\"... -DINTSIZE64 -DIDXSIZE64\" ;;",
   "tradeoffs": "Keeps old semantics; more jobs, naming noise.",
   "preferred": false
  },
  {
   "label": "Document and test options in a nightly cmake matrix",
   "summary": "Scheduled pipeline with a CMake options matrix (INTSIZE, IDXSIZE, SUFFIX, DETERMINISTIC).",
   "patch_sketch": "parallel: matrix: [{OPT: [-DINTSIZE=64, -DSCOTCH_NAME_SUFFIX=_x, -DSCOTCH_DETERMINISTIC=FULL]}]",
   "tradeoffs": "Cheaper for per-commit CI; delays detection (BLD-02 would be found nightly).",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; the job-name convention (JOB_INT) already promises 64.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-21",
 "area": "BLD",
 "our_title": "MinGW and Haiku Makefile templates define macro names the source never tests",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "other-platform",
 "needs_note": "Build on MinGW and Haiku and confirm the Windows code paths and bzip2 support are off.",
 "location": "src/Make.inc/Makefile.inc.i686_pc_mingw32:29; Makefile.inc.i686_pc_haiku.shlib:13; Makefile.inc.x86-64_pc_haiku.shlib:13",
 "evidence": "7.0.17: mingw32 template has `-DCOMMON_WINDOWS`; the code tests `COMMON_OS_WINDOWS` (src/libscotch/common.h:92,118; common.c:112; parser_ll.l:70). `grep -rn COMMON_WINDOWS src` matches only the template. Both Haiku templates (i686 and x86-64) have `-DCOMMON_FILE_COMPRESS_BZ`; the code tests `COMMON_FILE_COMPRESS_BZ2` (common_file_compress.h:95, common_file_compress.c:62,77,171); no template at all uses COMMON_OS_WINDOWS or ..._BZ2. (the `#endif /* COMMON_FILE_COMPRESS_BZ */` comments in common_file_compress.c:81 are only comments). Not built on Windows/Haiku.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate; the review lists one Haiku file but two Haiku templates (i686 and x86-64) carry the typo.",
 "fix_options": [
  {
   "label": "Rename the macros in the templates",
   "summary": "COMMON_WINDOWS -> COMMON_OS_WINDOWS; COMMON_FILE_COMPRESS_BZ -> COMMON_FILE_COMPRESS_BZ2.",
   "patch_sketch": "-... -DCOMMON_WINDOWS ...\n+... -DCOMMON_OS_WINDOWS ...",
   "tradeoffs": "Switching on the Windows paths for MinGW may expose code that has not been compiled there; BZ2 on Haiku additionally requires -lbz2 in LDFLAGS (check). Untested here.",
   "preferred": true
  },
  {
   "label": "Make the code accept the old spelling",
   "summary": "In common.h: `#if defined COMMON_WINDOWS && !defined COMMON_OS_WINDOWS #define COMMON_OS_WINDOWS`.",
   "patch_sketch": "#ifdef COMMON_WINDOWS\n#define COMMON_OS_WINDOWS\n#endif",
   "tradeoffs": "Keeps third-party Makefile.inc files working but cements two names for one macro.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1; macros are spelt consistently in all other templates (e.g. COMMON_OS_MACOS-style naming).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)
