# G25-metis-graph-part

Items: CLI-02, CLI-03, CLI-06, CLI-07, CLI-08, CLI-19



===================================================================
## CLI-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-02",
 "area": "CLI",
 "our_title": "METIS 5 recursive partitioning dereferences a NULL imbalance vector when the caller passes none",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part.c:583-596 (deref at 290)",
 "evidence": "Repro (t/cm.c mode nullubvec; METIS_SetDefaultOptions(opt); METIS_PartGraphRecursive(&n,&nc,x,a,NULL,NULL,NULL,&np,NULL,NULL /*ubvec*/,opt,&obj,part)) on a 40x40 grid, linked to asan/lib/libscotchmetisv5.so:\nmetis_graph_part.c:290:5: runtime error: load of null pointer of type 'const double'\nAddressSanitizer: SEGV on unknown address 0x000000000000 ... #0 _SCOTCH_METIS_PartGraph2 metis_graph_part.c:290 #1 _SCOTCH_METIS_PartGraph :350 #2 SCOTCH_METIS_V5_PartGraphRecursive :590 #3 METIS_PartGraphRecursive :718\nSame call through METIS_PartGraphKway returns METIS_OK(1) cut=82 (it substitutes &kbalval at 559/562).",
 "upstream_change": "",
 "review_accuracy": "Accurate (lines 587-595 in the review are 583-596 here only because of formatting; same code). Fix suggestion is correct.",
 "fix_options": [
  {
   "label": "NULL fallback in the Recursive wrapper (as Kway does)",
   "summary": "Declare a local `double kbalval = 0.01;` and pass `(ubvec != NULL) ? ubvec : &kbalval` in both branches of V5_PartGraphRecursive.",
   "patch_sketch": "@@ SCOTCH_METIS_V5_PartGraphRecursive @@\n   SCOTCH_Num          baseval;\n+  double              kbalval;\n \n+  kbalval = 0.01;\n   baseval = ...;\n ...\n-                                     SCOTCH_STRATRECURSIVE, ubvec)\n+                                     SCOTCH_STRATRECURSIVE, (ubvec != NULL) ? ubvec : &kbalval)\n ... (same in the _Volume branch)",
   "tradeoffs": "Minimal, exactly the existing Kway idiom. Does not fix CLI-03 (ratio vs deviation) - do that in the same hunk.",
   "preferred": false
  },
  {
   "label": "Make _SCOTCH_METIS_PartGraph2 robust (callee-side)",
   "summary": "Take `kbalval` as a possibly-NULL pointer and default it to 0.01 inside _SCOTCH_METIS_PartGraph2.",
   "patch_sketch": "@@ _SCOTCH_METIS_PartGraph2 @@\n-    SCOTCH_stratGraphMapBuild (&stradat, flagval, *nparts, *kbalval);\n+    SCOTCH_stratGraphMapBuild (&stradat, flagval, *nparts, (kbalval != NULL) ? *kbalval : 0.01);",
   "tradeoffs": "One line and protects every caller, but duplicates the 0.01 default in two places and hides the V5 contract inside the helper. Not tested separately; the combined shared-helper variant in CLI-03 was tested and fixes this crash (nullubvec returns METIS_OK).",
   "preferred": false
  }
 ],
 "notes": "Tested with the combined patch of CLI-02/03/06 (hunks in CLI-03): `./t/cm nullubvec` -> ret=1.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-03",
 "area": "CLI",
 "our_title": "METIS callers' imbalance vector is passed to Scotch unconverted, so a requested 1.05 allows about twofold imbalance",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part.c:553-562, 587-595, 290",
 "evidence": "Repro (t/cm.c mode ubvec; 40x40 grid, random vertex weights 1..10, METIS_PartGraphKway, nparts=4; imbalance = max part weight*4/total):\nubvec=1.001 cut=44 imbalance=2.0002 | ubvec=1.01 cut=40 imbalance=2.0079 | ubvec=1.05 cut=40 imbalance=2.0079 | ubvec=1.3 cut=40 imbalance=2.0079\ni.e. a ubvec of 1.05 (5% asked) yields a 100% imbalanced partition (two parts empty-ish), cut=40; ubvec=0.01 (deviation convention) gives imbalance 1.0046, ubvec=0.05 gives 1.0200.\nSource: kbalval = ubvec (a pointer to 1.05) goes to SCOTCH_stratGraphMapBuild(..., *kbalval) at metis_graph_part.c:290. Note that the default `kbalval = 0.01` is already a deviation, so the wrapper mixes the two conventions.",
 "upstream_change": "",
 "review_accuracy": "Accurate. The proposed conversion kbalval = max(ubvec[0]-1, 0) is right (verified empirically: after the fix imbalance for ubvec=1.001/1.01/1.05/1.3 = 1.0001/1.0046/1.0200/1.0200). Only ubvec[0] is meaningful since multi-constraint is not supported (see CLI-07). ParMETIS_V3_PartKway ignores ubvec entirely (CLI-07).",
 "fix_options": [
  {
   "label": "Convert in the V5 wrappers via a shared helper (tested)",
   "summary": "A static helper _SCOTCH_METIS_V5Params() turns ubvec[0] (ratio) into a deviation (ubvec[0]-1, default 0.01 when NULL or <=1) and, in the same place, normalises options[NUMBERING] (CLI-06). Both V5 wrappers use it. V3 path is untouched (it already passes deviations).",
   "patch_sketch": "--- a/src/libscotchmetis/metis_graph_part.c\n+++ b/src/libscotchmetis/metis_graph_part.c\n@@ -434,6 +439,34 @@\n   return (_SCOTCH_METIS_OutputVol (baseval, *n + baseval, xadj - baseval, adjncy - baseval, vsiztax, *nparts, part - baseval, volume));\n }\n \n+/* This routine extracts the MeTiS 5 numbering and balance parameters.\n+** In MeTiS 5, option value -1 means \"default\" and ubvec[0] is a ratio\n+** (e.g. 1.05), whereas Scotch expects a deviation (e.g. 0.05).\n+*/\n+\n+static\n+int\n+_SCOTCH_METIS_V5Params (\n+const SCOTCH_Num * const    xadj,\n+const SCOTCH_Num * const    options,\n+const double * const        ubvec,\n+SCOTCH_Num * const          basptr,\n+double * const              balptr)\n+{\n+  SCOTCH_Num          baseval;\n+\n+  baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;\n+  if (baseval < 0)                                /* Default value */\n+    baseval = 0;\n+  if (baseval > 1)\n+    return (METIS_ERROR_INPUT);\n+\n+  *basptr = baseval;\n+  *balptr = ((ubvec != NULL) && (ubvec[0] > 1.0)) ? (ubvec[0] - 1.0) : 0.01;\n+\n+  return (METIS_OK);\n+}\n+\n /*\n **\n */\n@@ -550,16 +583,16 @@\n   SCOTCH_Num          baseval;\n   double              kbalval;\n \n-  kbalval = 0.01;\n-  baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;\n+  if (_SCOTCH_METIS_V5Params (xadj, options, ubvec, &baseval, &kbalval) != METIS_OK)\n+    return (METIS_ERROR_INPUT);\n \n   return ((vsize == NULL)\n           ? _SCOTCH_METIS_PartGraph (nvtxs, ncon, xadj, adjncy, vwgt, adjwgt,\n                                      &baseval, nparts, tpwgts, options, objval, part,\n-                                     SCOTCH_STRATDEFAULT, (ubvec != NULL) ? ubvec : &kbalval)\n+                                     SCOTCH_STRATDEFAULT, &kbalval)\n           : _SCOTCH_METIS_PartGraph_Volume (nvtxs, ncon, xadj, adjncy, vwgt, vsize,\n                                             &baseval, nparts, tpwgts, options, objval, part,\n-                                            SCOTCH_STRATDEFAULT, (ubvec != NULL) ? ubvec : &kbalval));\n+                                            SCOTCH_STRATDEFAULT, &kbalval));\n }\n \n /*\n@@ -583,16 +616,18 @@\n SCOTCH_Num * const          part)\n {\n   SCOTCH_Num          baseval;\n+  double              kbalval;\n \n-  baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;\n+  if (_SCOTCH_METIS_V5Params (xadj, options, ubvec, &baseval, &kbalval) != METIS_OK)\n+    return (METIS_ERROR_INPUT);\n \n   return ((vsize == NULL)\n           ? _SCOTCH_METIS_PartGraph (nvtxs, ncon, xadj, adjncy, vwgt, adjwgt,\n                                      &baseval, nparts, tpwgts, options, objval, part,\n-                                     SCOTCH_STRATRECURSIVE, ubvec)\n+                                     SCOTCH_STRATRECURSIVE, &kbalval)\n           : _SCOTCH_METIS_PartGraph_Volume (nvtxs, ncon, xadj, adjncy, vwgt, vsize,\n                                             &baseval, nparts, tpwgts, options, objval, part,\n-                                            SCOTCH_STRATRECURSIVE, ubvec));\n+                                            SCOTCH_STRATRECURSIVE, &kbalval));\n }\n \n /*******************/",
   "tradeoffs": "Fixes CLI-02, -03 and -06 in one place; behaviour change: partitions for callers that set ubvec become tighter and different (that is the point). ubvec[0]<=1.0 treated as 'default' rather than 0 deviation. Tested: ubvec 1.05 -> imbalance 1.02.",
   "preferred": true
  },
  {
   "label": "Convert inside _SCOTCH_METIS_PartGraph2 with an explicit flag",
   "summary": "Keep wrappers as they are but pass a pair (ratio-flag) so PartGraph2 subtracts 1 only for V5 callers (e.g. `kbalval` > 1 means ratio).",
   "patch_sketch": "@@ _SCOTCH_METIS_PartGraph2 @@\n-    SCOTCH_stratGraphMapBuild (&stradat, flagval, *nparts, *kbalval);\n+    SCOTCH_stratGraphMapBuild (&stradat, flagval, *nparts, (*kbalval > 1.0) ? (*kbalval - 1.0) : *kbalval);",
   "tradeoffs": "Smaller diff but heuristic: a V5 ubvec of exactly 1.0 or a (legal) V3 deviation > 1 are mis-handled, and the dual (PartMeshDual) path has its own plumbing. Less principled than option 1.",
   "preferred": false
  }
 ],
 "notes": "The review's own severity (High) is fair: it silently ruins partition quality for every METIS5 caller that sets ubvec (the common case).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-06",
 "area": "CLI",
 "our_title": "METIS wrappers mishandle option arrays filled with -1 and hang or crash during coarsening",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part.c:554,587; metis_graph_part_dual.c:109; metis_graph_order.c:183; metis_options.c:70",
 "evidence": "Repro (t/cm.c numbering_m1: a 40x40 0-based grid, options[0..39] = -1 as METIS 5 callers commonly do): METIS_PartGraphKway never returns (>5 s, killed with SIGSEGV after 5 s the stack was in graphCoarsenEdgeLu graph_coarsen_edge.c:140 reading a wild address 0x03e80000941d) - Scotch built the graph with baseval=-1 so adjacency values 0..n-1 are off by one.\nSource: `baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;` at metis_graph_part.c:554/587 and metis_graph_order.c:183 (not listed in the review), metis_graph_part_dual.c:109. metis_options.c:68-72 memSet(options, 0,...) so SetDefaultOptions masks it (real METIS fills with -1).",
 "upstream_change": "",
 "review_accuracy": "Accurate, and incomplete: metis_graph_order.c:183 (METIS_V5_NodeND) has the identical bug and is not in the review.",
 "fix_options": [
  {
   "label": "Treat negative NUMBERING as 0, reject values other than 0/1 (tested)",
   "summary": "Shared helper normalises baseval (<0 -> 0, >1 -> METIS_ERROR_INPUT), used by both partition wrappers; the same two lines go into metis_graph_order.c:183 and metis_graph_part_dual.c:109.",
   "patch_sketch": "--- a/src/libscotchmetis/metis_graph_part.c\n+++ b/src/libscotchmetis/metis_graph_part.c\n@@ -434,6 +439,34 @@\n   return (_SCOTCH_METIS_OutputVol (baseval, *n + baseval, xadj - baseval, adjncy - baseval, vsiztax, *nparts, part - baseval, volume));\n }\n \n+/* This routine extracts the MeTiS 5 numbering and balance parameters.\n+** In MeTiS 5, option value -1 means \"default\" and ubvec[0] is a ratio\n+** (e.g. 1.05), whereas Scotch expects a deviation (e.g. 0.05).\n+*/\n+\n+static\n+int\n+_SCOTCH_METIS_V5Params (\n+const SCOTCH_Num * const    xadj,\n+const SCOTCH_Num * const    options,\n+const double * const        ubvec,\n+SCOTCH_Num * const          basptr,\n+double * const              balptr)\n+{\n+  SCOTCH_Num          baseval;\n+\n+  baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;\n+  if (baseval < 0)                                /* Default value */\n+    baseval = 0;\n+  if (baseval > 1)\n+    return (METIS_ERROR_INPUT);\n+\n+  *basptr = baseval;\n+  *balptr = ((ubvec != NULL) && (ubvec[0] > 1.0)) ? (ubvec[0] - 1.0) : 0.01;\n+\n+  return (METIS_OK);\n+}\n+\n /*\n **\n */\n@@ -550,16 +583,16 @@\n   SCOTCH_Num          baseval;\n   double              kbalval;\n \n-  kbalval = 0.01;\n-  baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;\n+  if (_SCOTCH_METIS_V5Params (xadj, options, ubvec, &baseval, &kbalval) != METIS_OK)\n+    return (METIS_ERROR_INPUT);\n \n   return ((vsize == NULL)\n           ? _SCOTCH_METIS_PartGraph (nvtxs, ncon, xadj, adjncy, vwgt, adjwgt,\n                                      &baseval, nparts, tpwgts, options, objval, part,\n-                                     SCOTCH_STRATDEFAULT, (ubvec != NULL) ? ubvec : &kbalval)\n+                                     SCOTCH_STRATDEFAULT, &kbalval)\n           : _SCOTCH_METIS_PartGraph_Volume (nvtxs, ncon, xadj, adjncy, vwgt, vsize,\n                                             &baseval, nparts, tpwgts, options, objval, part,\n-                                            SCOTCH_STRATDEFAULT, (ubvec != NULL) ? ubvec : &kbalval));\n+                                            SCOTCH_STRATDEFAULT, &kbalval));\n }\n \n /*\n@@ -583,16 +616,18 @@\n SCOTCH_Num * const          part)\n {\n   SCOTCH_Num          baseval;\n+  double              kbalval;\n \n-  baseval = ((options != NULL) && (options != xadj)) ? options[METIS_OPTION_NUMBERING] : 0;\n+  if (_SCOTCH_METIS_V5Params (xadj, options, ubvec, &baseval, &kbalval) != METIS_OK)\n+    return (METIS_ERROR_INPUT);\n \n   return ((vsize == NULL)\n           ? _SCOTCH_METIS_PartGraph (nvtxs, ncon, xadj, adjncy, vwgt, adjwgt,\n                                      &baseval, nparts, tpwgts, options, objval, part,\n-                                     SCOTCH_STRATRECURSIVE, ubvec)\n+                                     SCOTCH_STRATRECURSIVE, &kbalval)\n           : _SCOTCH_METIS_PartGraph_Volume (nvtxs, ncon, xadj, adjncy, vwgt, vsize,\n                                             &baseval, nparts, tpwgts, options, objval, part,\n-                                            SCOTCH_STRATRECURSIVE, ubvec));\n+                                            SCOTCH_STRATRECURSIVE, &kbalval));\n }\n \n /*******************/\n(+ same 3-line normalisation at metis_graph_order.c:183 and metis_graph_part_dual.c:109)",
   "tradeoffs": "Matches METIS semantics (-1 == default == C numbering). Tested: all-(-1) options now return METIS_OK cut=80 instead of hanging. Behaviour change only for callers that passed -1 (previously broken).",
   "preferred": true
  },
  {
   "label": "Make METIS_SetDefaultOptions faithful (-1 everywhere) and read options through an accessor",
   "summary": "Change SetDefaultOptions to fill options with -1 like real METIS and add `static SCOTCH_Num _SCOTCH_METIS_optGet(options, idx, defval)` returning defval when options[idx] < 0; use it for NUMBERING/OBJTYPE.",
   "patch_sketch": "-  memSet (options, 0, METIS_NOPTIONS * sizeof (SCOTCH_Num));\n+  for (i = 0; i < METIS_NOPTIONS; i ++) options[i] = -1;\n   ... baseval = _SCOTCH_METIS_optGet (options, METIS_OPTION_NUMBERING, 0);",
   "tradeoffs": "Closest to real METIS and fixes CLI-19 (OBJTYPE=-1) the same way, but changes SetDefaultOptions' observable output (tests/users that expect zeros), so more risky.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-07

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-07",
 "area": "CLI",
 "our_title": "Multi-constraint vertex weights (ncon above 1) reach Scotch interleaved and are read as one weight per vertex",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part.c:271-277,396,425; parmetis_dgraph_part.c:156-170",
 "evidence": "Sequential: run with an LD_PRELOAD shim on SCOTCH_graphBuild (t/pre.c) and ncon=2, vwgt[2v]=1, vwgt[2v+1]=1000+v: `[graphBuild] baseval=0 vertnbr=1600 velotab=... [1 1000 1 1001 1 1002 1 1003 ]` - the interleaved array is handed to Scotch as one weight per vertex (vertex 0 gets 1, vertex 1 gets 1000, vertex 2 gets 1, ...). The function ret=1 (no error).\nNote: in 7.0.17 the sequential tpwgts conversion already strides (`twdbtab[i] = tpwgts[i * *ncon]` at metis_graph_part.c:275, comment 'Gather first target constraint; only this one is used') - so the tpwgts half of the finding applies to ParMETIS only, which the review says.\nParMETIS (source-read, parmetis_dgraph_part.c): `_SCOTCH_ParMETIS_floatToInt (*nparts, tpwgts, twintab)` reads tpwgts[0..nparts-1] regardless of *ncon; `veloloctab = vwgt` used as one load per vertex; ncon and ubvec are marked `/* Not used */` at 128/129.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Detail: the sequential half is partially already handled for tpwgts only.",
 "fix_options": [
  {
   "label": "Use only the first constraint, extracted into a temporary array",
   "summary": "When ncon>1, copy vwgt[v*ncon] into a temporary SCOTCH_Num array (and stride tpwgts by ncon in ParMETIS), documenting that only constraint 0 is balanced.",
   "patch_sketch": "if (*ncon > 1 && vwgt != NULL) { velotab = memAlloc(n*sizeof(SCOTCH_Num)); for (v=0; v<n; v++) velotab[v] = vwgt[v * *ncon]; }\n... memFree(velotab) after graphBuild/graphMap\nParMETIS: twdbtab[i] = tpwgts[i * *ncon];",
   "tradeoffs": "Gives correct (if single-constraint) behaviour with no API change; costs one O(n) allocation when ncon>1; needs a test with ncon=2. Closest to what the existing tpwgts handling already does.",
   "preferred": true
  },
  {
   "label": "Reject ncon > 1 explicitly",
   "summary": "Return METIS_ERROR_INPUT (and print one SCOTCH_errorPrint line) when *ncon > 1, in both METIS and ParMETIS wrappers.",
   "patch_sketch": "if ((ncon != NULL) && (*ncon > 1)) { SCOTCH_errorPrint (\"...: multi-constraint partitioning is not supported\"); return (METIS_ERROR_INPUT); }",
   "tradeoffs": "Honest and tiny, but breaks callers that currently 'work' with single-constraint quality on ncon>1 and would now fail; ncon is a non-optional argument in METIS5 so may be a pointer to a 1 in many callers (fine).",
   "preferred": false
  }
 ],
 "notes": "ParMETIS ncon/ubvec half is source-read only (no MPI harness written for ParMETIS_V3_PartKway).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-08",
 "area": "CLI",
 "our_title": "Double-to-integer weight conversion overflows to INT_MIN for normalised weights",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part.c:207-231 (_SCOTCH_METIS_doubleToInt); parmetis_dgraph_part.c:74-111 (float twin)",
 "evidence": "Repro (t/cm.c d2i, the function is exported as _SCOTCH_METIS_doubleToInt): 6 normalised random weights, seeds 1/2/3:\n`0.185404 -> -2147483648  0.140488 -> -2147483648 ...` (all six values come out as INT_MIN, i.e. the (SCOTCH_Num) round(x) conversion of a value >2^31). A 3-weight case (0.4518/0.2673/0.2808) gives 48/28/30, so tidy inputs are fine.\nSource: doubadj = (doubadj*doubtmp)/gcd(round(doubadj), round(doubtmp)) at :222-226 multiplies by reciprocals of fractional residues; (int) round(...) casts at :224 and :229 are UB when out of range. -fsanitize=float-cast-overflow is not part of -fsanitize=undefined so the ASan build does not print it; the INT_MIN results are the observable effect (x86 cvttsd2si).",
 "upstream_change": "",
 "review_accuracy": "Accurate. The review's own suggested fix says 'round(w*1e6), minimum 1': the 'minimum 1' part would turn a legitimate 0 target weight into 1 and 1e6 resolution can overflow 32-bit sums for many parts; a cap near 1e4 is safer. The same algorithm exists in float form in parmetis_dgraph_part.c (floatToInt) and is shared via _SCOTCH_METIS_doubleToInt by PartMeshDual.",
 "fix_options": [
  {
   "label": "Cap the scale factor, fall back to a fixed resolution (tested)",
   "summary": "When doubadj exceeds a cap (1e4) stop searching for a common denominator and round with that fixed scale.",
   "patch_sketch": "--- a/src/libscotchmetis/metis_graph_part.c\n+++ b/src/libscotchmetis/metis_graph_part.c\n@@ -203,6 +203,7 @@\n */\n \n #define EPSILON 1e-6\n+#define DOUBADJMAX 1e4                            /* Largest scale factor, so that weights stay in int range */\n \n void\n _SCOTCH_METIS_doubleToInt (\n@@ -223,10 +224,14 @@\n     if (fabs (doubtmp) >= EPSILON) {            /* If a residual fractional part exists       */\n       doubtmp = doubadj / doubtmp;              /* Incorporate it in renormalization factor   */\n       doubadj = (doubadj * doubtmp) / (double) intGcd ((int) round (doubadj), (int) round (doubtmp));\n+      if (doubadj > DOUBADJMAX) {                 /* If common denominator blows up, settle for a fixed resolution */\n+        doubadj = DOUBADJMAX;\n+        break;\n+      }\n     }\n   }\n   for (i = 0; i < valunbr; i ++)\n-    intetab[i] = (SCOTCH_Num) round (doubtab[i] * doubadj);\n+    intetab[i] = (SCOTCH_Num) round (doubtab[i] * doubadj);\n }\n \n /* This routine is the interface between MeTiS\n(the tested build also clamped to >=1; drop that, zero weights must stay zero)",
   "tradeoffs": "Keeps exact small-integer ratios for 'nice' inputs (0.25/0.75 -> 1/3) and bounded values for arbitrary reals (tested: 0.185404 -> 1854 ...). Tiny relative precision loss (1e-4). Same hunk needed in the float version.",
   "preferred": true
  },
  {
   "label": "Always use a fixed resolution",
   "summary": "intetab[i] = (SCOTCH_Num) round(doubtab[i] * 1e4) with no common-denominator search (drop the loop and intGcd).",
   "patch_sketch": "-  for (i = 0, doubadj = 1.0; i < valunbr; i ++) { ... }\n-  for (i = 0; i < valunbr; i ++)\n-    intetab[i] = (SCOTCH_Num) round (doubtab[i] * doubadj);\n+  for (i = 0; i < valunbr; i ++)\n+    intetab[i] = (SCOTCH_Num) round (doubtab[i] * 10000.0);",
   "tradeoffs": "Simplest and always in range, but changes results for exact ratios (e.g. 0.5/0.5 -> 5000/5000 instead of 1/1) and thus archCmpltw weights; everything downstream only uses ratios, but outputs are no longer bit-identical to 7.0.17 for tidy inputs.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-19",
 "area": "CLI",
 "our_title": "METIS partitioning returns an edge cut when volume was asked for, and the reverse, depending on vsize",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part.c:556-562,589-595 (wrapper), 389-440 (_Volume)",
 "evidence": "t/cm.c objtype on a 40x40 grid, nparts=4: `OBJTYPE=VOL, vsize=NULL: ret=1 objval=82 / true edgecut=82` (a volume was requested, a cut came back); `OBJTYPE=CUT, vsize!=NULL: objval=558, true edgecut=104` (volume returned although CUT was requested). Source: `return ((vsize == NULL) ? _SCOTCH_METIS_PartGraph(...) : _SCOTCH_METIS_PartGraph_Volume(...))` - options[OBJTYPE] is never read; PartMeshDual does honour it (:217-219).",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Select by OBJTYPE, unit sizes when vsize is NULL",
   "summary": "In the wrappers: `volflag = (options != NULL && options != xadj && options[METIS_OPTION_OBJTYPE] == METIS_OBJTYPE_VOL)`; use _Volume when volflag (it already copes with vsize == NULL: unit sizes) else the cut variant ignoring vsize.",
   "patch_sketch": "+  volflag = ((options != NULL) && (options != xadj) && (options[METIS_OPTION_OBJTYPE] == METIS_OBJTYPE_VOL));\n-  return ((vsize == NULL)\n+  return (!volflag\n          ? _SCOTCH_METIS_PartGraph (nvtxs, ncon, xadj, adjncy, vwgt, adjwgt, ...)\n          : _SCOTCH_METIS_PartGraph_Volume (nvtxs, ncon, xadj, adjncy, vwgt, vsize, ...));",
   "tradeoffs": "Real METIS semantics; mirrors PartMeshDual (precedent in the same library). Behaviour change for callers that relied on 'vsize != NULL => volume' (they now need OBJTYPE=VOL, exactly as in METIS 5). Not compiled/tested here.",
   "preferred": true
  },
  {
   "label": "Keep vsize-driven choice but report the requested metric",
   "summary": "Leave partitioning alone and compute the returned objval from options[OBJTYPE] after the fact (call OutputCut or OutputVol accordingly).",
   "patch_sketch": "o = ... existing ...; objval = (OBJTYPE==VOL) ? OutputVol(...unit sizes if vsize==NULL) : OutputCut(...)",
   "tradeoffs": "Does not change the partition (the vsize-weighted edge loads still bias it) but returns the metric the caller asked for; half-fix, partition semantics still differ from METIS.",
   "preferred": false
  }
 ],
 "notes": "The tested CLI-02/03/06 patch does not include this change.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)
