# G27-seq-tools

Items: CLI-11, CLI-12, CLI-16, CLI-17, CLI-13, CLI-14, CLI-18



===================================================================
## CLI-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-11",
 "area": "CLI",
 "our_title": "Architecture builder reads before the start of an array when the graph is labelled and base 1",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/amk_grf.c:208-232; src/libscotch/arch_deco_build.c:301,196 (graphInduceList)",
 "evidence": "Repro with a labelled base-1 path graph (labels 10..40, `printf '0\\n4 6\\n1 100\\n10 1 20\\n20 2 10 30\\n30 2 20 40\\n40 1 30\\n' > lab.grf`; list file `2\\n10 40`), `amk_grf lab.grf lab.tgt -llab.lst`:\n`==ERROR: AddressSanitizer: heap-buffer-overflow ... READ of size 4 ... 4 bytes before 40-byte region #0 _SCOTCHgraphInduceList graph_induce.c:138 #1 _SCOTCHarchDecoArchBuild arch_deco_build.c:196 #2 SCOTCH_archBuild0 library_arch_build.c:146 #3 main amk_grf.c:228`.\nUnlabelled base-1 graph (gmk_m2 4 1 -b1; list `2\\n3 90`): `heap-buffer-overflow WRITE of size 4 ... graph_induce.c:137` (value 90 is never range-checked). Same labelled graph with base 0 works (control). Source: `listtab[listnum] = sorttab[vertnum ++].vertnum;` (amk_grf.c:~218) with sorttab[].vertnum = vertnum (0-based, :205).",
 "upstream_change": "",
 "review_accuracy": "Accurate on both sub-claims.",
 "fix_options": [
  {
   "label": "Store vertnum+baseval and range-check unlabelled lists (tested)",
   "summary": "Convert labels to based vertex numbers and check [baseval, baseval+vertnbr) for the unlabelled case.",
   "patch_sketch": "--- a/src/scotch/amk_grf.c\n+++ b/src/scotch/amk_grf.c\n@@ -196,7 +196,12 @@\n         errorPrint (\"main: duplicate list labels\");\n     }\n \n-    if (vlbltab != NULL) {                        /* If graph has vertex labels */\n+    if (vlbltab == NULL) {                        /* Un-labelled graph: list values are based vertex numbers */\n+      if ((listnbr > 0) &&\n+          ((listtab[0] < baseval) || (listtab[listnbr - 1] >= (baseval + vertnbr))))\n+        errorPrint (\"main: list vertex number out of range\");\n+    }\n+    else {                                        /* If graph has vertex labels */\n       SCOTCH_Num          vertnum;\n \n       if ((sorttab = (C_VertSort *) memAlloc (vertnbr * sizeof (C_VertSort))) == NULL)\n@@ -215,7 +220,7 @@\n             (sorttab[vertnum].vlblnum > listtab[listnum]))\n           errorPrint (\"main: list label '\" SCOTCH_NUMSTRING \"' not in graph\", (SCOTCH_Num) listtab[listnum]);\n \n-        listtab[listnum] = sorttab[vertnum ++].vertnum; /* Replace label by number */\n+        listtab[listnum] = sorttab[vertnum ++].vertnum + baseval; /* Replace label by based vertex number, as expected by library */\n       }\n       memFree (sorttab);                          /* Free sort area */\n     }",
   "tradeoffs": "Two-line change in the tool; tested: labelled base-1 now builds an arch, out-of-range list gives `ERROR: main: list vertex number out of range`. Behaviour change only for base-1 graphs (previously UB).",
   "preferred": true
  },
  {
   "label": "Validate and re-base in the library (archDecoArchBuild / SCOTCH_archBuild0)",
   "summary": "Have SCOTCH_archBuild0/2 (library_arch_build.c) accept un-based or reject out-of-range lists: check each list entry against [baseval, baseval+vertnbr) and return 1.",
   "patch_sketch": "in library_arch_build.c before calling archDecoArchBuild: for (i = 0; i < listnbr; i ++) if ((listptr[i] < baseval) || (listptr[i] >= baseval + vertnbr)) { errorPrint (\"SCOTCH_archBuild0: vertex list out of range\"); return (1); }",
   "tradeoffs": "Protects every API user (not only the CLI), but SCOTCH_archBuild0's documented contract is based numbers so it only adds validation, not re-basing; does not fix the tool's off-by-one for labelled graphs, so it needs option 1 as well.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-12",
 "area": "CLI",
 "our_title": "Drawing output (Inventor, VTK) writes vertex indices off by the graph base",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gout_o.c:405 (Inventor), 1167-1176 (VTK CELLS)",
 "evidence": "3x3 grid made with `gmk_m2 3 3 -b0|-b1 gX.grf -ggX.xyz`, `gout gX.grf gX.xyz /dev/null out.<ext> -mn -Ov|-Oi`:\nVTK base0: `CELLS 4 20 / 5 0 1 2 5 8 / 4 0 3 4 5 ...` ; base1: `CELLS 4 20 / 5 1 2 3 6 9 / 4 1 4 5 6 ...` while `POINTS 9` has indices 0..8 (index 9 out of range).\nInventor base0: `coordIndex [ 0, 1, 2, 5, 8, -1, 0, 3, ...  -1 ]`; base1: `0, 1, 2, 5, 8, -2, 0, 3, 4, 5, -2, 1, 4, 7, 8, -2, 3, 6, 7, -1 ]` (terminators -1-1 = -2, except the last one which is printed literally).",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Un-base only real vertex indices (tested)",
   "summary": "Inventor: write -1 for the terminator, indxtab[i]-baseval otherwise. VTK: print the point count as is and un-base the point indices.",
   "patch_sketch": "--- a/src/scotch/gout_o.c\n+++ b/src/scotch/gout_o.c\n@@ -402,7 +402,7 @@\n   for (indxnum = 0; indxnum < indxnbr - 1; indxnum ++) {\n     if ((indxnum % 8) == 0)\n       fprintf (fileptr, \"\\n\");\n-    fprintf (fileptr, \"\\t\" SCOTCH_NUMSTRING \",\", indxtab[indxnum] - baseval); /* Un-base vertex indices in paths */\n+    fprintf (fileptr, \"\\t\" SCOTCH_NUMSTRING \",\", (indxtab[indxnum] == -1) ? (SCOTCH_Num) -1 : (indxtab[indxnum] - baseval)); /* Un-base vertex indices in paths, not path terminators */\n   }\n   if (((indxnbr - 1) % 8) == 0)\n     fprintf (fileptr, \"\\n\");\n@@ -1171,9 +1171,10 @@\n     SCOTCH_Num          indxtmp;\n \n     pontnbr = indxtab[indxnum];\n-    for (indxtmp = indxnum + pontnbr; indxnum < indxtmp; )\n-      fprintf (fileptr, SCOTCH_NUMSTRING \"\\t\", indxtab[indxnum ++]);\n-    fprintf (fileptr, SCOTCH_NUMSTRING \"\\n\", indxtab[indxnum ++]);\n+    fprintf (fileptr, SCOTCH_NUMSTRING \"\\t\", pontnbr); /* Number of points is not a vertex index */\n+    for (indxtmp = ++ indxnum + pontnbr - 1; indxnum < indxtmp; )\n+      fprintf (fileptr, SCOTCH_NUMSTRING \"\\t\", indxtab[indxnum ++] - baseval); /* POINTS are un-based */\n+    fprintf (fileptr, SCOTCH_NUMSTRING \"\\n\", indxtab[indxnum ++] - baseval);\n   }\n \n   fprintf (fileptr, \"\\nCELL_TYPES \" SCOTCH_NUMSTRING \"\\n\", /* All cells ate poly-line paths */",
   "tradeoffs": "Both outputs verified identical between base-0 and base-1 inputs after the patch. No behaviour change for base-0 graphs.",
   "preferred": true
  },
  {
   "label": "Normalise at the source: build indxtab with un-based vertex numbers",
   "summary": "In both path builders, store `verttmp - baseval` into indxtab (and keep -1 / counts unchanged), so the printers need no change.",
   "patch_sketch": "-    indxtab[indxnbr ++] = verttmp;\n+    indxtab[indxnbr ++] = verttmp - baseval;   /* also at the loop's end-vertex insertion */",
   "tradeoffs": "Fixes both writers in one idiom but the Inventor colour loop reads parttax[indxtab[...]] (needs re-basing back) - riskier; the per-printer change is safer.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-16",
 "area": "CLI",
 "our_title": "Drawing a base-1 graph to a Tulip file applies an offset to a NULL geometry pointer and crashes",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gout_o.c:921-924",
 "evidence": "`gout g1.grf /dev/null /dev/null o.tlp -mn -gn -Ot` with a base-1 graph: `gout_o.c:921:37: runtime error: applying non-zero offset 18446744073709551592 to null pointer`, `gout_o.c:978:40: member access within null pointer of type 'const struct C_GeoVert'`, `AddressSanitizer: SEGV on unknown address 0x000000000010`. With a base-0 graph the same command correctly prints `gout: ERROR: outDrawTulMesh: geometry not provided`. Other three drawers (:284, :573, :1071) correctly test geomptr->coortab.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Test geomptr->coortab == NULL (tested)",
   "summary": "Same test the other three drawing routines use.",
   "patch_sketch": "--- a/src/scotch/gout_o.c\n+++ b/src/scotch/gout_o.c\n@@ -921,7 +921,7 @@\n   const C_GeoVert * restrict const  coortax = geomptr->coortab - baseval;\n   const SCOTCH_Num * restrict const parttax = mappptr->labltab - baseval;\n \n-  if (coortax == NULL) {\n+  if (geomptr->coortab == NULL) {\n     errorPrint (\"outDrawTulMesh: geometry not provided\");\n     return (1);\n   }",
   "tradeoffs": "One-line; precedent in the same file (lines 284, 573, 1071). Tested: ERROR + rc=1.",
   "preferred": true
  },
  {
   "label": "Compute coortax after the check",
   "summary": "Declare `coortax` without initialiser and assign after validating geomptr->coortab.",
   "patch_sketch": "const C_GeoVert * restrict coortax;  ... if (geomptr->coortab == NULL) {...}  coortax = geomptr->coortab - baseval;",
   "tradeoffs": "Avoids forming a pointer before the null test (also removes the UBSan 'offset to null pointer' report on this line) but is a larger edit than option 1.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-17",
 "area": "CLI",
 "our_title": "Draw-option parser reads past the end of an unterminated brace argument",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gout_c.c:708-710",
 "evidence": "`gout g0.grf g0.xyz /dev/null o.iv -mn '-Oi{c'` -> `gout_c.c:709:11: runtime error: load of null pointer of type 'char'`, `AddressSanitizer: SEGV ... #0 C_parse gout_c.c:709 #1 outDrawParse gout_o.c:218`. `-Oi{c}` works. Source: `argeptr = strpbrk (argbptr, \",}\\0\"); if (*argeptr == '\\0') return (3);` (the \"\\0\" in the literal ends the set; strpbrk returns NULL when no delimiter).",
 "upstream_change": "",
 "review_accuracy": "Accurate. Note the code obviously intended to catch exactly this case ('If there is no end delimiter').",
 "fix_options": [
  {
   "label": "Check argeptr == NULL (tested)",
   "summary": "Drop the useless \\0 and test the pointer.",
   "patch_sketch": "--- a/src/scotch/gout_c.c\n+++ b/src/scotch/gout_c.c\n@@ -705,8 +705,8 @@\n       int                 argunum;\n       int                 flagval;\n \n-      argeptr = strpbrk (argbptr, \",}\\0\");        /* Search for the argument end  */\n-      if (*argeptr == '\\0')                       /* If there is no end delimiter */\n+      argeptr = strpbrk (argbptr, \",}\");          /* Search for the argument end  */\n+      if (argeptr == NULL)                        /* If there is no end delimiter */\n         return (3);                               /* Return syntax error value    */\n \n       argusiz = ((argeptr - argbptr) < 127)       /* Get argument bounded length */",
   "tradeoffs": "Tested: `ERROR: main: error in output option string (3)`, rc=1.",
   "preferred": true
  },
  {
   "label": "Use strcspn",
   "summary": "`len = strcspn (argbptr, \",}\"); if (argbptr[len] == '\\0') return (3); argeptr = argbptr + len;`",
   "patch_sketch": "size_t argulen = strcspn (argbptr, \",}\");\nif (argbptr[argulen] == '\\0') return (3);\nargeptr = argbptr + argulen;",
   "tradeoffs": "Never produces a NULL pointer at all; equivalent behaviour, slightly different style from the rest of the file (which uses strpbrk).",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-13",
 "area": "CLI",
 "our_title": "Architecture statistics tool seeds its minimum distance with an unsigned shift that gives -1 for 32-bit integers",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/atst.c:161",
 "evidence": "`echo 'cmplt 8' > c8.tgt; atst c8.tgt` -> `A\tDistance\tmin=-1\tmax=1\tavg=1\tdlt=0`; `amk_m2 4 4 | atst` -> `min=-1 max=6 avg=2.66667`; cmplt 1 -> `min=-1 max=0`. Source: `distmin = (SCOTCH_Num) (((unsigned long) ((SCOTCH_Num) -1)) >> 1);` - on LP64 with 32-bit SCOTCH_Num the unsigned long is 0x7FFF...FFFF whose truncation to int is -1.",
 "upstream_change": "",
 "review_accuracy": "Accurate. The proposed `(SCOTCH_Num)(((unsigned SCOTCH_Num) ~0) >> 1)` does not compile as written (`unsigned SCOTCH_Num` is not valid C when SCOTCH_Num is a typedef); use SCOTCH_NUMMAX.",
 "fix_options": [
  {
   "label": "Use SCOTCH_NUMMAX (tested)",
   "summary": "SCOTCH_NUMMAX is a public macro in scotch.h and already used in gotst.c:235 and in the check tests.",
   "patch_sketch": "--- a/src/scotch/atst.c\n+++ b/src/scotch/atst.c\n@@ -158,7 +158,7 @@\n       (termnum != termnbr))\n     errorPrint (\"main: cannot enumerate terminal domains\");\n \n-  distmin = (SCOTCH_Num) (((unsigned long) ((SCOTCH_Num) -1)) >> 1); /* Set to maximum number in Anum */\n+  distmin = SCOTCH_NUMMAX;                        /* Set to maximum number in Anum */\n   distmax = 0;\n   distsum = 0;\n ",
   "tradeoffs": "One line, precedent in the same directory (gotst.c). Tested: min=1 for cmplt 8. The single-terminal case then prints min=SCOTCH_NUMMAX rather than -1 (no pairs), arguably should print 0.",
   "preferred": true
  },
  {
   "label": "Initialise from the first pair",
   "summary": "Set distmin on the first iteration (flag) or to 0 when termnbr<2 so no sentinel is ever printed.",
   "patch_sketch": "SCOTCH_Num distmin = -1;  ... if ((distmin < 0) || (distmin > distval)) distmin = distval;  ... after loops: if (distmin < 0) distmin = 0;",
   "tradeoffs": "Avoids a sentinel altogether and gives 0 for single-terminal targets; slightly more code than option 1.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-14",
 "area": "CLI",
 "our_title": "Graph converter silently accepts an unknown input format code because its table bound is wrong",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gcv.c:187",
 "evidence": "`gcv -iS -oZ g44.grf /dev/null; echo $?` -> rc=0 (no message); `gcv -iS -iZ ...` correctly gives `ERROR: main: unprocessed option '-iZ'`. Source: loop at :180 scans C_outFormatTab (6 entries) but :187 tests `C_inpFormatTab[j].code == '\\0'` (8 entries); for an unknown code j==6 and C_inpFormatTab[6].code=='S' != 0.",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Test C_outFormatTab[j].code (tested)",
   "summary": "Replace the table in the check.",
   "patch_sketch": "--- a/src/scotch/gcv.c\n+++ b/src/scotch/gcv.c\n@@ -184,7 +184,7 @@\n               break;\n             }\n           }\n-          if (C_inpFormatTab[j].code == '\\0')\n+          if (C_outFormatTab[j].code == '\\0')\n             errorPrint (\"main: unprocessed option '%s'\", argv[i]);\n           break;\n         case 'V' :",
   "tradeoffs": "One-token fix; tested: `-oZ` -> ERROR rc=1.",
   "preferred": true
  },
  {
   "label": "Factor the lookup",
   "summary": "Write a small `C_formatFind(tab, stride, code)` helper used for both -i and -o so the two blocks cannot diverge again.",
   "patch_sketch": "static int C_outFormatFind (char c) { int j; for (j = 0; C_outFormatTab[j].code != '\\0'; j ++) if (C_outFormatTab[j].code == c) return (j); return (-1); }",
   "tradeoffs": "Slightly bigger; removes the copy-paste root cause, but the two tables have different element types (C_FormatInp/C_FormatOut) so two helpers are needed.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-18",
 "area": "CLI",
 "our_title": "2-D mesh generator writes a wrong arc count in the header for some sizes with the -e -t options",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/gmk_m2.c:198-200",
 "evidence": "`gmk_m2 2 2 -e -t -` : header arcs=8, 12 arcs written -> `gtst: ERROR: graphLoad: invalid arc count (1)`; `1 2 -e -t`: header -2, 2 written; `1 1 -e -t`: -4 vs 0; `2 1`: -2 vs 2; all fail to load. Other sizes correct (1x3, 1x4, 1x5, 2x3, 2x5, 3x3, 5x2: header == written). Plain `-t` (4-neighbour) is correct for 2x2/1x2/1x1/2x1/1x5.",
 "upstream_change": "",
 "review_accuracy": "Accurate, and precisely limited to the case where BOTH dimensions are <= 2 (the two independent corrections `-6*d1` and `-6*d0` overlap there).",
 "fix_options": [
  {
   "label": "Closed form from distinct neighbour positions (tested)",
   "summary": "Per axis the number of distinct positions is n_i = min(d_i,3); each vertex has n0*n1-1 (8-neighbour) or n0+n1-2 (4-neighbour) distinct neighbours.",
   "patch_sketch": "--- a/src/scotch/gmk_m2.c\n+++ b/src/scotch/gmk_m2.c\n@@ -195,9 +195,16 @@\n   fileBlockOpen (C_fileTab, C_FILENBR);           /* Open all files */\n \n   if ((flagval & C_FLAGTORUS) != 0) {             /* Build a torus           */\n-    edgenbr = ((flagval & C_FLAGELEM) != 0)       /* Compute number of edges */\n-              ? (8 * (d[0] * d[1]) - ((d[0] < 3) ? (6 * d[1]) : 0) - ((d[1] < 3) ? (6 * d[0]) : 0))\n-              : (4 * (d[0] * d[1]) - ((d[0] < 3) ? (2 * d[1]) : 0) - ((d[1] < 3) ? (2 * d[0]) : 0));\n+    {\n+      SCOTCH_Num          n0;                     /* Number of distinct positions along each dimension, self included */\n+      SCOTCH_Num          n1;\n+\n+      n0 = (d[0] < 3) ? d[0] : 3;\n+      n1 = (d[1] < 3) ? d[1] : 3;\n+      edgenbr = ((flagval & C_FLAGELEM) != 0)     /* Compute number of edges */\n+                ? ((d[0] * d[1]) * (n0 * n1 - 1))\n+                : ((d[0] * d[1]) * (n0 + n1 - 2));\n+    }\n \n     fprintf (C_filepntrsrcout, \"0\\n\" SCOTCH_NUMSTRING \"\\t\" SCOTCH_NUMSTRING \"\\n\" SCOTCH_NUMSTRING \"\\t000\\n\",\n              (SCOTCH_Num) (d[0] * d[1]),          /* Print number of vertices */",
   "tradeoffs": "Matches the generator's own duplicate-removal logic; tested for 2x2,1x2,1x1,2x1,3x3,2x5,1x4 (-e -t) and 2x2, 1x5 (-t): gtst loads all. Keeps the existing structure.",
   "preferred": true
  },
  {
   "label": "Count the arcs actually written",
   "summary": "Run C_edgeOutput to a counting pass (or accumulate its return value) and write the header afterwards / seek back.",
   "patch_sketch": "make C_edgeOutput return the number of arcs; write the header after the body (or compute in a dry-run pass into /dev/null).",
   "tradeoffs": "Cannot drift from the writer again, but needs a two-pass or seekable output (stdout/pipe use is common), so it costs time and complexity.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)
