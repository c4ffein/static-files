# G19-dgraph-build-induce

Items: DGR-05, DGR-12, DGR-06, PS-DGR-3, DGR-11, DGR-08, DGR-18, DGR-21



===================================================================
## DGR-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-05",
 "area": "DGR",
 "our_title": "Interleaved failure markers scanned with single index, hiding upper-rank failures",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_build.c:186-198, 209-217 (check at l.213)",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nReproducer fbuild.c (mine): SCOTCH_dgraphBuild of a ring (4 vertices/rank) with the first allocation of dgraphBuild2 (the private-data group, l.173-179) failing on rank FAILRANK. `LD_LIBRARY_PATH=../fi/lib timeout 30 mpirun --oversubscribe -np 2 ./fbuild 1 0`: `(1): ERROR: dgraphBuild2: out of memory`, `r1 build rc=1`, rank 0 never returns (HANG; it proceeds into dgraphBuild3's dgraphAllreduceMaxSum with procdsptab computed from -1 counts). np=4 with failing rank 3: same HANG. np=2 failing rank 0 is detected (both rc=1). Source l.213: `if (grafptr->procngbtab[procnum] < 0)` while the Allgather at l.204 stores (vertlocnbr, vertlocmax) pairs, so the failure marker of rank r sits at procngbtab[2r], [2r+1] and only r < P/2 is ever inspected (l.219 correctly reads [2*procnum]).",
 "upstream_change": "",
 "review_accuracy": "Accurate. Both lines match (186-198/212-217 -> 179-217 in 7.0.17).",
 "fix_options": [
  {
   "label": "Test procngbtab[2 * procnum] (tested)",
   "summary": "Read the same slot the loop below uses.",
   "patch_sketch": "--- a/src/libscotch/dgraph_build.c\n+++ b/src/libscotch/dgraph_build.c\n@@ -210,7 +210,7 @@\n   grafptr->procdsptab[0] =                        /* Build vertex-to-process array */\n   grafptr->procvrttab[0] = baseval;\n   for (procnum = 0; procnum < grafptr->procglbnbr; procnum ++) {\n-    if (grafptr->procngbtab[procnum] < 0) {       /* If error notified by another process during memory allocation */\n+    if (grafptr->procngbtab[2 * procnum] < 0) {   /* If error notified by another process during memory allocation */\n       memFree (grafptr->procdsptab);\n       grafptr->procdsptab = NULL;                 /* Free memory that has just been allocated */\n       return (1);\n",
   "tradeoffs": "One-token fix. Verified: np=2 (fail r1) and np=4 (fail r3) give rc=1 on all ranks, no hang.",
   "preferred": true
  },
  {
   "label": "Receive into a typed pair array / scan before use",
   "summary": "Declare the receive buffer as `int (* procngbpair)[2]` (view of procngbtab+procrcvtab) so that index confusion cannot recur, and test both fields in a dedicated pre-loop before any procdsptab is written.",
   "patch_sketch": "int (* restrict const procpairtab)[2] = (int (*)[2]) grafptr->procngbtab;\nfor (procnum = 0; procnum < procglbnbr; procnum ++)\n  if ((procpairtab[procnum][0] < 0) || (procpairtab[procnum][1] < 0)) { memFree (grafptr->procdsptab); grafptr->procdsptab = NULL; return (1); }",
   "tradeoffs": "More readable, same cost; relies on the existing 'TRICK' of reusing procngbtab+procrcvtab as one int[2P] array (alignment fine). Not compiled.",
   "preferred": false
  },
  {
   "label": "Let dgraphBuild3 agree on the error",
   "summary": "Failing process skips its dummy Allgather and calls dgraphBuild3 with procdsptab==NULL; the healthy ones are then stopped by dgraphBuild3's own reduction (reduloctab[16], 'no private data').",
   "patch_sketch": "/* in the alloc-failure branch: drop the dummy Allgather, fall through to dgraphBuild3 */",
   "tradeoffs": "Needs the Allgather of the healthy ranks to be matched somehow; larger restructuring for no gain. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: the loop body two lines below already indexes [2 * procnum], so the one-token fix is the obvious one.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-12",
 "area": "DGR",
 "our_title": "Label translation scans first edgelocnbr slots instead of real edge ranges; unknown labels unreported",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_build.c:401-409 (edsoloctab fill), 424-440 (translation), 468-479",
 "evidence": "Reproducer lab.c (mine), np=1: 2 vertices with labels 10/20, vertloctab=[0,2], vendloctab=[1,3], edgeloctab=[20,77,10,88], edgelocnbr=2, edgelocsiz=4 (slots 1 and 3 are gaps), SCOTCH_dgraphBuild(&g,0,2,2,vert,vend,NULL,lbl,2,4,edge,NULL,NULL) then SCOTCH_dgraphCheck. `./lab 0` -> `build rc=0`, `edge array after build: [1 77 10 88]` (expected [1 . 0 .]): slot 0 translated, gap slot 1 scanned (left as 77), the REAL edge in slot 2 (beyond slots baseval..baseval+edgelocnbr-1) keeps its raw label 10; `dgraphCheck: arc data do not match`. `./lab 1` (compact graph, edge label 555 that exists on no process): `build rc=0`, edge array `[1 555]` - untranslated label accepted without error (l.405 loop never verifies edsolocptr->edgelocnum == -1 for all entries).",
 "upstream_change": "",
 "review_accuracy": "Accurate on both points (gap slots translated/real edges untranslated; unknown labels not diagnosed). Whether non-compact edge arrays are 'allowed by the docs' is true for SCOTCH_dgraphBuild (vendloctab != vertloctab+1, edgelocsiz > edgelocnbr).",
 "fix_options": [
  {
   "label": "Iterate over [vertloctax[v], vendloctax[v]) and diagnose untranslated labels (tested)",
   "summary": "Fill edsoloctab vertex by vertex from the real edge ranges, sort exactly edsoloctnd - edsoloctab entries, and after the neighbour rounds scan edsoloctab for entries whose edgelocnum is not -1 (label found on no process) and raise the existing collective error path.",
   "patch_sketch": "--- a/src/libscotch/dgraph_build.c\n+++ b/src/libscotch/dgraph_build.c\n@@ -400,12 +400,15 @@\n       return (1);\n     }\n \n-    for (edsolocptr = edsoloctab, edsoloctnd = edsoloctab + edgelocnbr, edgelocnum = baseval;\n-         edsolocptr < edsoloctnd; edsolocptr ++, edgelocnum ++) {\n-      edsolocptr->vlblglbnum = edgeloctax[edgelocnum];\n-      edsolocptr->edgelocnum = edgelocnum;\n+    for (edsolocptr = edsoloctab, vertlocnum = baseval;   /* Edges are taken vertex by vertex as edge array may be non-compact */\n+         vertlocnum < (vertlocnbr + baseval); vertlocnum ++) {\n+      for (edgelocnum = vertloctax[vertlocnum]; edgelocnum < vendloctax[vertlocnum]; edgelocnum ++, edsolocptr ++) {\n+        edsolocptr->vlblglbnum = edgeloctax[edgelocnum];\n+        edsolocptr->edgelocnum = edgelocnum;\n+      }\n     }\n-    intSort2asc2 (edsoloctab, grafptr->edgelocnbr);\n+    edsoloctnd = edsolocptr;                      /* Number of real edges is edgelocnbr */\n+    intSort2asc2 (edsoloctab, edsoloctnd - edsoloctab);\n \n     procrcvnum = (grafptr->proclocnum + 1) % procglbnbr; /* Compute indices of neighbors */\n     procsndnum = (grafptr->proclocnum - 1 + procglbnbr) % procglbnbr;\n@@ -455,6 +458,14 @@\n       }\n     }\n \n+    for (edsolocptr = edsoloctab; edsolocptr < edsoloctnd; edsolocptr ++) { /* Edges whose label was not found on any process remain untranslated */\n+      if (edsolocptr->edgelocnum != -1) {\n+        errorPrint (\"dgraphBuild3: unknown vertex label in edge array\");\n+        cheklocval = 1;\n+        break;\n+      }\n+    }\n+\n     memFree (vesongbtab[0]);\n \n #ifdef SCOTCH_DEBUG_DGRAPH1                       /* Communication cannot be merged with a useful one */\n@@ -463,7 +474,7 @@\n     chekglbval = cheklocval;\n #endif /* SCOTCH_DEBUG_DGRAPH1 */\n     if (chekglbval != 0) {\n-      errorPrint (\"dgraphBuild3: duplicate vertex label (2)\");\n+      errorPrint (\"dgraphBuild3: duplicate or unknown vertex label (2)\");\n       return (1);\n     }\n   }\n",
   "tradeoffs": "Same complexity; a graph that previously (wrongly) passed with unknown labels now fails with a clear message. Verified: lab 0 gives edges [1 77 0 88] and check rc=0; lab 1 gives build rc=1 with 'unknown vertex label in edge array'.",
   "preferred": true
  },
  {
   "label": "Compact the edge array before translating",
   "summary": "If DGRAPHHASVENDLOC would apply, copy real edges into a compact temporary array, translate, copy back (or build the graph compact), keeping the simple [baseval, baseval+edgelocnbr) loop.",
   "patch_sketch": "/* allocate edgecpttab[edgelocnbr]; fill via vertloctax/vendloctax; translate; scatter back */",
   "tradeoffs": "Extra O(E) memory and copies; unnecessary since edsoloctab already stores the edge index.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: edsoloctab entries already carry edgelocnum, i.e. the sorting structure is index-based and does not require compactness - only the fill loop does.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-06",
 "area": "DGR",
 "our_title": "Induce tests running prefix sums for failure sentinel instead of per-rank counts",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_induce.c:156-182 (Allgather l.167-168, check l.177)",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nUpstream rewrote dgraphInduce2 in 3c9b3ab ('Rework error handling and structure of dgraphInduce()') but the faulty test survived: l.177 `if (indgrafptr->procdsptab[procnum] < 0)` inspects the running prefix sum (procdsptab[procnum+1] = procdsptab[procnum] + proccnttab[procnum], l.179), whereas the failing process contributes -1 to proccnttab (Allgather l.167-168 into proccnttab; the failing side Allgathers dummval=-1 at l.136-139).\nReproducer: SCOTCH_dgraphInducePart (np=2, ring of 4+4 vertices, baseval 1, keep even vertices), fault on rank 1 for the n-th allocation: `LIBDIR=../fi/lib ./scan2.sh induce 2 1 1 4 0 3`: nth=0,1,2 -> `(1): ERROR: dgraphInduce2: out of memory (1)/(2)/(3)`, `r1 rc=1`, rank 0 HANG (it carries on to the dgraphHaloSync collective). Same with the failure on rank 0 and baseval 1 (`./scan2.sh induce 2 0 1 4 0 1`: HANG): procdsptab[1] = 1 + (-1) = 0 is not negative. With baseval 0 and a failure on rank 0 the bug is masked (0 + -1 < 0), which is why rank-0-only tests pass.",
 "upstream_change": "3c9b3ab (restructured dgraphInduce2 error handling; did not touch the faulty comparison)",
 "review_accuracy": "Accurate about the mechanism. Line numbers (181-186) shifted to 156-182 because of 3c9b3ab, which the review predates; the claim that the code 'tests procdsptab' is still literally true in 7.0.17.",
 "fix_options": [
  {
   "label": "Test proccnttab[procnum] (tested)",
   "summary": "Inspect the array that actually carries the -1 markers.",
   "patch_sketch": "--- a/src/libscotch/dgraph_induce.c\n+++ b/src/libscotch/dgraph_induce.c\n@@ -174,7 +174,7 @@\n \n   indgrafptr->procdsptab[0] = baseval;            /* Build vertex-to-process array */\n   for (procnum = 0; procnum < indgrafptr->procglbnbr; procnum ++) {\n-    if (indgrafptr->procdsptab[procnum] < 0)      /* If error notified by another process */\n+    if (indgrafptr->proccnttab[procnum] < 0)      /* If error notified by another process */\n       goto fail2;\n     indgrafptr->procdsptab[procnum + 1] = indgrafptr->procdsptab[procnum] + indgrafptr->proccnttab[procnum];\n   }\n",
   "tradeoffs": "One-token fix. Verified: nth=0..2 now give rc=1 on both ranks, base 0/1, failure on either rank; nth=3 still HANGs because the failure is inside dgraphHaloSync2 (separate non-collective error path).",
   "preferred": true
  },
  {
   "label": "Separate MAX-reduced error flag",
   "summary": "Gather two Gnums per process (count, flag) or run a tiny MPI_Allreduce(MAX) on cheklocval instead of overloading the count array with a sentinel.",
   "patch_sketch": "Gnum redu[2] = { indvertlocnbr, 0 }; /* failing side: redu[1] = 1 */\nMPI_Allgather (redu, 2, GNUM_MPI, tab, 2, GNUM_MPI, comm); for (p...) if (tab[2*p+1] != 0) goto fail2;",
   "tradeoffs": "Robust against future sentinel confusion (also negative prefix sums with unusual bases); doubles the message and needs a 2P work array instead of reusing proccnttab. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Same idiom as DGR-05/09 (negative sentinel in an Allgather'd array); the check was most likely meant to read proccnttab as in dgraph_band.c where procdsptab[1..P] holds the counts before accumulation.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## PS-DGR-3

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DGR-3",
 "our_title": "dgraphInduce2 rebases edge array without checking shrinking memRealloc result",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/dgraph_induce.c:~237-245",
 "evidence": "Fault shim on SCOTCH_dgraphInducePart (np=2, baseval 1, last allocation): UBSan 'dgraph_induce.c:245:28: runtime error: applying non-zero offset 18446744073709551612 to null pointer'; call returns 0. `indgrafptr->edgeloctax = memRealloc (...); indgrafptr->edgeloctax -= baseval;` never tests NULL. Shrink failure is rare.",
 "related_review_ids": [],
 "fix_options": [
  {
   "label": "Keep old block when shrink fails",
   "summary": "Use the old pointer if memRealloc returns NULL.",
   "patch_sketch": "tmp = memRealloc (edgeloctax + baseval, n); if (tmp != NULL) edgeloctax = tmp - baseval;",
   "tradeoffs": "No behaviour change otherwise. Not compiled.",
   "preferred": true
  },
  {
   "label": "Treat as error",
   "summary": "goto fail2 on NULL.",
   "patch_sketch": "if (tmp == NULL) goto fail2;",
   "tradeoffs": "Fails an operation that could succeed. Not compiled.",
   "preferred": false
  }
 ],
 "area": "DGR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-11",
 "area": "DGR",
 "our_title": "Graph checker accepts out-of-range edge ends, reads past holes, skips load check",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_check.c:295-323 (local checks; edge loads inside the HASEDGEGST block l.303-321), 458-468 (matching loop)",
 "evidence": "Reproducer chk.c (mine): SCOTCH_dgraphBuild with 2 vertices/rank, vertlocmax 2 or 4, then SCOTCH_dgraphCheck. `LD_LIBRARY_PATH=../fi/lib ASAN_OPTIONS=detect_leaks=0 mpirun --oversubscribe -np N ./chk VARIANT`:\n- far (an edge end 1000, far beyond every process range): `check rc=0` for np=1 and np=2 -> accepted silently (no process range matches, l.460-461 skip it).\n- hole (vertlocmax 4, edge end 2 = a numbering-hole slot of its own process): `ERROR: AddressSanitizer: stack-buffer-overflow ... READ of size 4 ... #0 _SCOTCHdgraphCheck dgraph_check.c:467 #1 SCOTCH_dgraphCheck` (`vendngbptr[vertglbend - vertngbmin]` indexes past the vertlocnbr+... received/local vertex arrays).\n- negall (all edge loads -5, symmetric): `check rc=0` (the `edloloctax[edgelocnum] <= 0` test at l.316 is inside `if ((grafptr->flagval & DGRAPHHASEDGEGST) != 0)`, which is false for freshly built graphs); the asymmetric case is only caught by 'arc load data do not match'.",
 "upstream_change": "",
 "review_accuracy": "Accurate on all three points. Precision: the hole case reads vertloctax/vendloctax entries beyond vertlocnbr (heap or caller memory) and then edgengbptr[garbage]; the 'far' case only matters for graphs built by hand - dgraphLoad/Build3 paths translate labels first.",
 "fix_options": [
  {
   "label": "Range check on every edge + bound lookups by neighbour vertex count + unconditional edge-load check (tested)",
   "summary": "In the local pass test baseval <= end < procvrttab[procglbnbr] and edloloctax > 0 for every edge (independent of DGRAPHHASEDGEGST), and in the matching loop skip/flag ends with (end - vertngbmin) >= vertngbnbr[procngbsel] (holes).",
   "patch_sketch": "--- a/src/libscotch/dgraph_check.c\n+++ b/src/libscotch/dgraph_check.c\n@@ -303,21 +303,27 @@\n     }\n     edgelocnbr += vendloctax[vertlocnum] - vertloctax[vertlocnum];\n \n-    if ((grafptr->flagval & DGRAPHHASEDGEGST) != 0) { /* If ghost edge array is valid */\n-      for (edgelocnum = vertloctax[vertlocnum]; edgelocnum < vendloctax[vertlocnum]; edgelocnum ++) {\n-        if ((edgegsttax[edgelocnum] < grafptr->baseval) ||\n-            (edgegsttax[edgelocnum] >= grafptr->vertgstnnd)) {\n-          errorPrint (\"dgraphCheck: inconsistent ghost edge array\");\n-          cheklocval = 1;\n-          goto fail;\n-        }\n-\n-        if ((edloloctax != NULL) &&\n-            (edloloctax[edgelocnum] <= 0)) {\n-          errorPrint (\"dgraphCheck: invalid edge load\");\n-          cheklocval = 1;\n-          goto fail;\n-        }\n+    for (edgelocnum = vertloctax[vertlocnum]; edgelocnum < vendloctax[vertlocnum]; edgelocnum ++) {\n+      if ((edgeloctax[edgelocnum] < grafptr->baseval) || /* Edge ends must belong to some process range */\n+          (edgeloctax[edgelocnum] >= grafptr->procvrttab[procglbnbr])) {\n+        errorPrint (\"dgraphCheck: invalid edge end\");\n+        cheklocval = 1;\n+        goto fail;\n+      }\n+\n+      if ((edloloctax != NULL) &&                 /* Check edge loads whether or not ghost edge array exists */\n+          (edloloctax[edgelocnum] <= 0)) {\n+        errorPrint (\"dgraphCheck: invalid edge load\");\n+        cheklocval = 1;\n+        goto fail;\n+      }\n+\n+      if (((grafptr->flagval & DGRAPHHASEDGEGST) != 0) && /* If ghost edge array is valid */\n+          ((edgegsttax[edgelocnum] < grafptr->baseval) ||\n+           (edgegsttax[edgelocnum] >= grafptr->vertgstnnd))) {\n+        errorPrint (\"dgraphCheck: inconsistent ghost edge array\");\n+        cheklocval = 1;\n+        goto fail;\n       }\n     }\n   }\n@@ -463,6 +469,11 @@\n           Gnum                edgengbnnd;\n           Gnum                edgengbsum;\n \n+          if ((vertglbend - vertngbmin) >= vertngbnbr[procngbsel]) { /* If end vertex falls in a hole of the neighbor numbering range */\n+            cheklocval = 1;                       /* Do not access neighbor data beyond the received vertices                        */\n+            continue;\n+          }\n+\n           for (edgengbnum = vertngbptr[vertglbend - vertngbmin],\n                edgengbnnd = vendngbptr[vertglbend - vertngbmin], edgengbsum = 0;\n                edgengbnum < edgengbnnd; edgengbnum ++) {\n",
   "tradeoffs": "Stricter checker: graphs previously accepted with dangling or non-positive-load edges now fail (that is the point; but externally generated test graphs with zero loads would now be rejected - check vs the rest of the suite). Verified on chk.c: far/hole/negall now rc=1 (no ASan), ok graph rc=0 for np=1,2.",
   "preferred": true
  },
  {
   "label": "Report unmatched ends instead of silently skipping them",
   "summary": "In the matching loop count, per edge, whether some process range claimed it (vertglbend inside [procvrttab[0], procvrttab[P])) and add a final 'edge end not in any range' error; leave hole detection to the vertex-count bound.",
   "patch_sketch": "/* before the 'for (procnum ...)' round loop */\nfor (...edges...) if ((vertglbend < procvrttab[0]) || (vertglbend >= procvrttab[procglbnbr])) cheklocval = 1;",
   "tradeoffs": "Same effect for out-of-range ends without touching edge-load semantics; does not fix the hole read by itself.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: dgraphCheck already uses cheklocval/goto fail with a collective Allreduce at the end (l.328-335). Edge-load positivity is a documented graph invariant ('invalid edge load' message exists) so enforcing it unconditionally is consistent.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-08

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-08",
 "area": "DGR",
 "our_title": "Ghost-edge builder reports allocation failure but continues with NULL work arrays",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_ghst.c:129-165 (error block l.150-157, memSet l.162)",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\n`LIBDIR=../fi/lib ./scan2.sh ghst 2 1 0 4 0 2` (SCOTCH_dgraphGhst on a freshly built 2x4-vertex graph, failure on rank 1): nth=0 `(1): ERROR: dgraphGhst: out of memory (1)` and nth=1 `(1): ERROR: dgraphGhst: out of memory (2)` both followed by `ERROR: AddressSanitizer: SEGV on unknown address ...` and `dgraph_ghst.c:164:3: runtime error: null pointer passed as argument 1, which is declared to never be null` (memSet (vertsidtab, ...) with vertsidtab NULL/uninitialised after memAllocGroup failure; 7.0.17 numbering l.162-164). Source: the `if (cheklocval != 0)` block (l.150-156) performs the dgraphAllreduceMaxSum that healthy ranks perform at l.290, but never returns, so the failing rank executes the whole routine and then a second reduction.",
 "upstream_change": "dgraph_ghst.c only whitespace/comment re-alignment between 7.0.16 and 7.0.17 (no functional change).",
 "review_accuracy": "Accurate. The 'unmatched collective' consequence is the lesser problem: the first thing that happens is the memSet on NULL/uninitialised pointers.",
 "fix_options": [
  {
   "label": "return (1) right after the early reduction (tested)",
   "summary": "The failing process joins the healthy ones' final reduction (that is what the existing 'TRICK' comment says) and then returns; edgegsttax, if allocated and flagged DGRAPHFREEEDGEGST, is freed later by dgraphFree/dgraphExit.",
   "patch_sketch": "--- a/src/libscotch/dgraph_ghst.c\n+++ b/src/libscotch/dgraph_ghst.c\n@@ -150,10 +150,9 @@\n   reduloctab[1] =\n   reduloctab[2] = 0;\n   if (cheklocval != 0) {                          /* TRICK: Processes not on error will perform collective communication at end of routine */\n-    if (dgraphAllreduceMaxSum (reduloctab, reduglbtab, 2, 1, grafptr->proccomm) != 0) {\n+    if (dgraphAllreduceMaxSum (reduloctab, reduglbtab, 2, 1, grafptr->proccomm) != 0)\n       errorPrint (\"dgraphGhst: communication error (1)\");\n-      return (1);\n-    }\n+    return (1);                                   /* Failing process must not go any further; edgegsttax, if any, is freed by dgraphFree() */\n   }\n \n   vertlocmin = procvrttab[grafptr->proclocnum];\n",
   "tradeoffs": "Behaviour: failing rank now returns 1 instead of crashing; healthy ranks already return 1 via reduglbtab[0]. Verified for nth=0,1: rc=1 on both ranks, no ASan. If the early reduction itself fails we still return 1.",
   "preferred": true
  },
  {
   "label": "Jump to the common final reduction",
   "summary": "Instead of duplicating the reduction, `goto` a label placed at the final reduction (l.286-292) with reduloctab[0]=1 and skip the sort/ghost computation; mirrors dgraphFold2's fail labels.",
   "patch_sketch": "if (cheklocval != 0) { reduloctab[0] = 1; reduloctab[1] = reduloctab[2] = 0; goto done; }\n...\ndone:\n  if (dgraphAllreduceMaxSum (reduloctab, reduglbtab, 2, 1, comm) != 0) ...",
   "tradeoffs": "Single collective call site (cleaner) but needs care with declarations between the goto and the label; touches more lines. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: 'TRICK: Processes not on error will perform collective communication at end of routine' (l.150) clearly intends early return.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-18",
 "area": "DGR",
 "our_title": "Grid builder marks arrays freeable before build succeeds; late failure double-frees",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_build_grid3d.c:476-483",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nfiint mode grid3d: SCOTCH_dgraphBuildGrid3D (4x4x2, incrval 3 => vertex labels present) on np=1, failure injected on the n-th allocation, followed by the customary SCOTCH_dgraphExit. `LIBDIR=../fi/lib ./scan2.sh grid3d 1 0 0 4 0 4`: nth=0,1,2 (groups / Build2 allocation, before pointers are stored) -> rc=1, clean. nth=3 (dgraphBuild3's label group `out of memory`, after dgraphBuild3 stored vertloctax/edgeloctax in the graph): `(0): ERROR: dgraphBuild3: out of memory` then `ERROR: AddressSanitizer: attempting double-free on 0x5120000253c0 ... #1 dgraphFree2 dgraph.c:128 #2 _SCOTCHdgraphExit dgraph.c:204 #3 SCOTCH_dgraphExit library_dgraph.c:138`; the first free is the routine's own `memFree (datadat.edgeloctax + baseval)`/`memFree (vertloctax + baseval)` at l.481-482. Source l.476: `grafptr->flagval = (DGRAPHFREETABS | ...)` is set before the call (and with `=`, discarding other flags).",
 "upstream_change": "",
 "review_accuracy": "Accurate. Only reachable when dgraphBuild3 fails after storing the pointers, i.e. with vertex labels (incrval != 1) or via its collective consistency checks; plain Build2 failures leave NULL pointers in the structure and are harmless.",
 "fix_options": [
  {
   "label": "Set the flags with |= only after a successful build (tested)",
   "summary": "Move the flagval assignment after dgraphBuild2 and use |=, exactly like dgraphBuildHcub (dgraph_build_hcub.c:215).",
   "patch_sketch": "--- a/src/libscotch/dgraph_build_grid3d.c\n+++ b/src/libscotch/dgraph_build_grid3d.c\n@@ -473,8 +473,6 @@\n   }\n   vertloctax[vertlocnum] = edgelocnum;            /* Mark end of local vertex array */\n \n-  grafptr->flagval = (DGRAPHFREETABS | DGRAPHVERTGROUP | DGRAPHEDGEGROUP); /* All arrays will be freed on exit */\n-\n   if (dgraphBuild2 (grafptr, baseval,             /* Build distributed graph */\n                     vertlocnbr, vertlocnbr, vertloctax, vertloctax + 1, veloloctax, velolocsum, NULL, vlblloctax,\n                     edgelocnum - baseval, edgelocsiz, datadat.edgeloctax, NULL, datadat.edloloctax, degrglbmax) != 0) {\n@@ -483,5 +481,7 @@\n     return  (1);\n   }\n \n+  grafptr->flagval |= (DGRAPHFREETABS | DGRAPHVERTGROUP | DGRAPHEDGEGROUP); /* All arrays will be freed on exit, but only once the graph has been built (see dgraphBuildHcub()) */\n+\n   return (0);\n }\n",
   "tradeoffs": "Verified: nth=3 now returns 1 and SCOTCH_dgraphExit is clean. The graph structure keeps dangling pointers after a failed build but without FREETABS they are not freed again (same as hcub).",
   "preferred": true
  },
  {
   "label": "Don't free in the routine; let dgraphExit do it",
   "summary": "Set the flags before the call, and on failure only clear the pointers the routine owns if Build2/3 did not store them.",
   "patch_sketch": "if (dgraphBuild2 (...) != 0) { if (grafptr->vertloctax == NULL) { memFree (...); memFree (...); } return (1); }",
   "tradeoffs": "Needs to know whether the callee stored the pointers (dgraphLoadCent sets flags after the build regardless of o, see dgraph_io_load.c:630). Fragile; not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: dgraph_build_hcub.c:204-217 (free leaders on failure, set flags after success).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-21",
 "area": "DGR",
 "our_title": "Matching check loop bound is a count against based indices, skipping last vertex",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_match_check.c:113-120",
 "evidence": "Source l.113-114: `vertlocnbr = grafptr->vertlocnbr; for (vertlocnum = baseval; vertlocnum < vertlocnbr; vertlocnum ++) { if (mategsttax[vertlocnum] < 0) ...` - the end bound is a count, the index is based. Reproducer mchk.c (mine): np=1 path graph of 3 vertices, matching built by hand: vertices b and b+1 mated (one multinode), last vertex b+2 left at mategsttax = -1 and absent from the multinode array; dgraphMatchCheck (compiled with the internal headers) -> baseval 0: `ERROR: dgraphMatchCheck: unmatched local vertex`, rc=1; baseval 1: rc=0 (unmatched last vertex not seen).",
 "upstream_change": "",
 "review_accuracy": "Accurate (debug-only; dgraphMatchCheck is only called under SCOTCH_DEBUG_DGRAPH2, dgraph_coarsen.c:1386-1393). Note: graphs coarsened inside the library always have baseval 0 only when the user's graph has baseval 0 - PT-Scotch keeps the user's base.",
 "fix_options": [
  {
   "label": "Loop to vertlocnbr + baseval (tested)",
   "summary": "Use the based end bound (grafptr->vertlocnnd).",
   "patch_sketch": "--- a/src/libscotch/dgraph_match_check.c\n+++ b/src/libscotch/dgraph_match_check.c\n@@ -111,7 +111,7 @@\n   }\n \n   vertlocnbr = grafptr->vertlocnbr;\n-  for (vertlocnum = baseval; vertlocnum < vertlocnbr; vertlocnum ++) {\n+  for (vertlocnum = baseval; vertlocnum < (vertlocnbr + baseval); vertlocnum ++) {\n     if (mategsttax[vertlocnum] < 0) {\n       errorPrint (\"dgraphMatchCheck: unmatched local vertex\");\n       cheklocval = 1;\n",
   "tradeoffs": "Debug-only; verified: baseval 1 now reports 'unmatched local vertex'.",
   "preferred": true
  },
  {
   "label": "Check coverage via flaggsttax after the multinode scan",
   "summary": "Drop the separate pass and, once all multinodes have set flaggsttax[], verify that every local vertex has a flag != -1 (stronger: every vertex belongs to exactly one multinode).",
   "patch_sketch": "for (vertlocnum = baseval; vertlocnum < vertlocnnd; vertlocnum ++)\n  if (flaggsttax[vertlocnum] == -1) { errorPrint (\"dgraphMatchCheck: vertex without multinode\"); goto fail; }",
   "tradeoffs": "Catches more inconsistencies (mate array fine but multinode missing); must run after the multinode loop, so errors are reported later; not tested.",
   "preferred": false
  }
 ],
 "notes": "Same pattern as other debug-only checks (bound counts vs based index).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)
