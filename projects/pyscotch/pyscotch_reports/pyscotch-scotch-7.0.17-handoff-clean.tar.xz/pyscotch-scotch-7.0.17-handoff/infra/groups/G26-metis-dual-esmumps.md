# G26-metis-dual-esmumps

Items: CLI-05, CLI-15, CLI-09, CLI-10, CLI-22, BLD-19, BLD-17



===================================================================
## CLI-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-05",
 "area": "CLI",
 "our_title": "METIS mesh-dual partitioning applies the Fortran null-pointer convention to some arguments but not the vertex weights, overflowing the stack",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/metis_graph_part_dual.c:198-226 (graphBuild at 206, OutputVol at 217-219)",
 "evidence": "Repro t/pm.c (6x6 quad mesh, ASan build, libscotchmetisv5):\n(a) vwgt == &ne (Fortran 'null' convention that the same function applies to options/tpwgts/vsize): `==ERROR: AddressSanitizer: stack-buffer-overflow ... #0 SCOTCH_graphBuild library_graph.c:262 #1 SCOTCH_METIS_PartMeshDual metis_graph_part_dual.c:206` (both base 0 and base 1).\n(b) options[OBJTYPE]=VOL, options[NUMBERING]=1, vsize=NULL: `metis_graph_part_dual.c:219:11: runtime error: applying non-zero offset 18446744073709551612 to null pointer ... metis_graph_part.c:171:15: load of null pointer ... SEGV in _SCOTCH_METIS_OutputVol` (with base 0 it happens to work because NULL-0 == NULL is handled by OutputVol).\n(c) source: `SCOTCH_graphBuild (&graftmp, ...)` at :206 has its return value discarded (still true).",
 "upstream_change": "",
 "review_accuracy": "Accurate on all three sub-points (vwgt not normalised, vsize-baseval with NULL/ne, graphBuild unchecked); verified (a) and (b) by running.",
 "fix_options": [
  {
   "label": "Normalise 'null' pointers once at the top and use them everywhere (tested)",
   "summary": "Introduce vwgtptr/vsizptr = NULL when the pointer is NULL or equals ne; use them in the vsize edge-load loop, graphBuild and the OutputVol call (pass NULL, not NULL-baseval); check graphBuild and clean up.",
   "patch_sketch": "--- a/src/libscotchmetis/metis_graph_part_dual.c\n+++ b/src/libscotchmetis/metis_graph_part_dual.c\n@@ -90,6 +90,8 @@\n   SCOTCH_Graph        graftmp;\n   SCOTCH_Arch         archdat;\n   SCOTCH_Strat        stradat;\n+  const SCOTCH_Num *  vwgtptr;\n+  const SCOTCH_Num *  vsizptr;\n   SCOTCH_Num          baseval;                    /* Global base value                   */\n   SCOTCH_Num          velmbas;                    /* Base value of mesh element vertices */\n   SCOTCH_Num          vnodbas;                    /* Base value of mesh node vertices    */\n@@ -103,6 +105,9 @@\n   SCOTCH_Mesh         meshdat;\n   int                 o;\n \n+  vwgtptr = ((vwgt  != NULL) && (vwgt  != ne)) ? vwgt  : NULL; /* Fortran null arrays are those equal to ne */\n+  vsizptr = ((vsize != NULL) && (vsize != ne)) ? vsize : NULL;\n+\n   baseval = 0;                                    /* Assume base value is 0 */\n \n   if ((options != NULL) && (options != ne))       /* For the Fortran interface, null arrays are those equal to ne */\n@@ -166,7 +171,7 @@\n \n   SCOTCH_graphData (&grafdat, NULL, &vertnbr, &verttab, &vendtab, NULL, NULL, &edgenbr, &edgetab, NULL); /* Get graph topology arrays */\n \n-  if ((vsize != NULL) && (vsize != ne)) {\n+  if (vsizptr != NULL) {\n     const SCOTCH_Num * restrict vsiztax;\n     Gnum                        vertnum;\n     Gnum                        edgenum;\n@@ -183,14 +188,14 @@\n     }\n     edlotax = edlotab - baseval;                  /* Base access to edlotax */\n     edgetax = edgetab - baseval;\n-    vsiztax = vsize   - baseval;\n+    vsiztax = vsizptr - baseval;\n \n     for (vertnum = 0, edgenum = baseval;          /* Un-based scan of vertex array verttab */\n          vertnum < vertnbr; vertnum ++) {\n       SCOTCH_Num          vsizval;                /* Communication size of current vertex */\n       SCOTCH_Num          edgennd;\n \n-      vsizval = vsize[vertnum];\n+      vsizval = vsizptr[vertnum];\n       for (edgennd = vendtab[vertnum]; edgenum < edgennd; edgenum ++) { /* Based traversal of compact edge array */\n         SCOTCH_Num          vertend;              /* Based end vertex number                                     */\n \n@@ -203,7 +208,16 @@\n     edlotab = NULL;\n \n   SCOTCH_graphInit  (&graftmp);\n-  SCOTCH_graphBuild (&graftmp, baseval, vertnbr, verttab, vendtab, vwgt, NULL, edgenbr, edgetab, edlotab);\n+  if (SCOTCH_graphBuild (&graftmp, baseval, vertnbr, verttab, vendtab, vwgtptr, NULL, edgenbr, edgetab, edlotab) != 0) {\n+    SCOTCH_errorPrint (\"SCOTCH_METIS_PartMeshDual: cannot build graph\");\n+    if (edlotab != NULL)\n+      memFree (edlotab);\n+    SCOTCH_meshExit  (&meshdat);\n+    SCOTCH_graphExit (&grafdat);\n+    SCOTCH_archExit  (&archdat);\n+    *objval = METIS_ERROR;\n+    return (METIS_ERROR);\n+  }\n   SCOTCH_stratInit  (&stradat);\n \n   if (SCOTCH_graphMap (&graftmp, &archdat, &stradat, epart) == 0) {\n@@ -214,9 +228,9 @@\n         epart[vertnum] += baseval;\n     }\n \n-    if (((vsize != NULL) && (vsize != ne)) ||     /* If computation of communication volume wanted */\n+    if ((vsizptr != NULL) ||                      /* If computation of communication volume wanted */\n         ((options != NULL) && (options != ne) && (options[METIS_OPTION_OBJTYPE] == METIS_OBJTYPE_VOL)))\n-      o = _SCOTCH_METIS_OutputVol (baseval, vertnbr + baseval, verttab - baseval, edgetab - baseval, vsize - baseval, *nparts, epart - baseval, objval);\n+      o = _SCOTCH_METIS_OutputVol (baseval, vertnbr + baseval, verttab - baseval, edgetab - baseval, (vsizptr != NULL) ? (vsizptr - baseval) : NULL, *nparts, epart - baseval, objval);\n     else\n       o = _SCOTCH_METIS_OutputCut (baseval, vertnbr + baseval, verttab - baseval, edgetab - baseval,\n                                    (edlotab != NULL) ? (edlotab - baseval) : NULL, epart - baseval, objval);",
   "tradeoffs": "Local to the one function, follows the file's own `!= ne` idiom; tested: both ASan crashes gone (no sanitizer report from the shim, remaining 'null pointer offset' UBSan notes come from libscotch internals). No ABI change.",
   "preferred": true
  },
  {
   "label": "Resolve all optional arguments through one helper",
   "summary": "Add `static const SCOTCH_Num * _SCOTCH_METIS_optArray(const SCOTCH_Num * p, const SCOTCH_Num * nullref)` (returns NULL if p==nullref) in metis_graph_part.h and use it for vwgt, vsize, options, tpwgts in PartMeshDual (and the Fortran wrappers).",
   "patch_sketch": "static inline const SCOTCH_Num * _SCOTCH_METIS_optArray (const SCOTCH_Num * p, const SCOTCH_Num * nullref) { return ((p == nullref) ? NULL : p); }",
   "tradeoffs": "Cleaner when more functions need it (METIS_PartGraph* wrappers use `options != xadj`), but touches more lines and a shared header; both options need the same graphBuild/OutputVol hunks.",
   "preferred": false
  }
 ],
 "notes": "Fortran-wrapper path (metis_graph_part_dual_f.c) was not exercised separately.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-15",
 "area": "CLI",
 "our_title": "METIS dual-graph builder leaves the output adjacency pointer dangling after a failed allocation",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Needs a forced malloc failure inside the dual-graph builder.",
 "location": "src/libscotchmetis/metis_graph_dual.c:106-118; parmetis_dgraph_dual.c:150-171,175 (SCOTCH_DEBUG_ALL return)",
 "evidence": "Source (7.0.17) metis_graph_dual.c:109-116: `if (((*xadj = malloc (...)) == NULL) || ((*adjncy = malloc (...)) == NULL)) { SCOTCH_errorPrint (...); if (*xadj != NULL) free (*xadj); SCOTCH_graphExit (&grafdat); return (METIS_ERROR_MEMORY); }` - *xadj is left dangling after free() (and *adjncy is untouched/uninitialised if xadj allocation fails).\nparmetis_dgraph_dual.c: arrays come from malloc() (comments 'Use plain malloc()') but the OOM branch frees them with `memFree` (lines ~165-168) - a mismatch under COMMON_MEMORY_TRACE/CHECK; with SCOTCH_DEBUG_ALL the `MPI_Allreduce` failure path `return (METIS_ERROR)` skips dgraphExit/dmeshExit and the two arrays. Not run: needs allocation-failure injection (ASAN max_allocation_size_mb trick does not work here because the graph arrays have the same size as the arrays being copied).",
 "upstream_change": "",
 "review_accuracy": "Partly imprecise: the review says METIS_MeshToDual 'skips graphExit' - it does NOT; `SCOTCH_graphExit (&grafdat)` is present in the OOM branch (line 114). The dangling *xadj, the malloc/memFree mismatch and the DEBUG_ALL leaks are accurate. (METIS_MeshToDual also returns without meshExit when meshBuildElem fails - not in the review, but meshBuildElem failure leaves the mesh uninitialised so this is benign.)",
 "fix_options": [
  {
   "label": "Null the caller's pointers, pair malloc/free, free on every return",
   "summary": "After free(*xadj) set *xadj = NULL; in ParMETIS use free() for vertloctab/edgeloctab; in the DEBUG_ALL branch jump to the abort labels instead of returning.",
   "patch_sketch": "-    if (*xadj != NULL)\n-      free (*xadj);\n+    if (*xadj != NULL) { free (*xadj); *xadj = NULL; }\n...\n-    if (edgeloctab != NULL) memFree (edgeloctab);\n-    if (vertloctab != NULL) memFree (vertloctab);\n+    if (edgeloctab != NULL) free (edgeloctab);\n+    if (vertloctab != NULL) free (vertloctab);\n...\n-    return (METIS_ERROR);   /* DEBUG_ALL allreduce */\n+    o = METIS_ERROR; goto abort1;",
   "tradeoffs": "Minimal, local, no ABI change; matches the 'user-managed array => plain malloc/free' comment already in the file.",
   "preferred": true
  },
  {
   "label": "Allocate both arrays in one memAlloc'd group and hand out with a documented free()",
   "summary": "Not possible: METIS requires two independent user-freed arrays, so the alternative is to build the dual graph directly into malloc'd arrays (skip the copy) by calling SCOTCH_graphBuild-less library routine - far larger change.",
   "patch_sketch": "(no short sketch; would need a meshGraphDual variant writing into caller-provided buffers)",
   "tradeoffs": "Avoids the double copy and OOM window but is a big refactor for a Low finding; not recommended.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-09",
 "area": "CLI",
 "our_title": "ParMETIS node-ordering wrapper reports an error although the ordering it produced is valid and complete",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/parmetis_dgraph_order.c:131-224 (o set at ~190; Compute/Perm unchecked at ~150)",
 "evidence": "Repro t/pn.c (16x16 grid, block-distributed, ParMETIS_V3_NodeND with a sizes buffer): np=1 ret=1(OK), np=2 ret=1, np=3 ret=-4 (METIS_ERROR) although order is valid and complete (rank0 order range [0,244]), np=4 ret=1. With sizes==NULL and np=2 the call returns -4 although the ordering was computed (`rank 0/2 sizes=NULL: ret=-4`).\nSource: `o = METIS_ERROR;` then `SCOTCH_dgraphOrderCompute (&grafdat, &ordedat, &stradat); SCOTCH_dgraphOrderPerm (&grafdat, &ordedat, order);` - both return values dropped; `o = METIS_OK;` only inside the `if ((rootnum >= 0) && (sizes != NULL))` branch reached for power-of-two process counts. The 'METIS_OK on failed runs' half is source-read only (I could not force Compute/Perm to fail).",
 "upstream_change": "",
 "review_accuracy": "Accurate (first half reproduced, second half follows from the unchecked calls).",
 "fix_options": [
  {
   "label": "Derive the status from Compute/Perm; make sizes best effort",
   "summary": "Initialise o = METIS_OK once the graph is built; set o = METIS_ERROR if dgraphOrderCompute/OrderPerm fail; keep the separator-tree/sizes code best effort (on its failure leave sizes at ~0 as already memSet).",
   "patch_sketch": "-        SCOTCH_dgraphOrderCompute (&grafdat, &ordedat, &stradat);\n-        SCOTCH_dgraphOrderPerm    (&grafdat, &ordedat, order);\n+        if ((SCOTCH_dgraphOrderCompute (&grafdat, &ordedat, &stradat) == 0) &&\n+            (SCOTCH_dgraphOrderPerm    (&grafdat, &ordedat, order) == 0))\n+          o = METIS_OK;\n ...\n                   _SCOTCH_ParMETIS_V3_NodeNDTree (...);\n-                  o = METIS_OK;\n                 }",
   "tradeoffs": "Matches the ParMETIS contract (sizes is auxiliary); behaviour change: np not a power of two now succeeds (was error). Callers that tested for error to detect 'no sizes' lose that signal (sizes stays ~0 as the code already documents).",
   "preferred": true
  },
  {
   "label": "Keep error for 'sizes unavailable' but report real failures too",
   "summary": "Return METIS_ERROR if Compute/Perm fail, otherwise METIS_OK, and set sizes to all zeros when the tree cannot be built (never return OK with garbage sizes).",
   "patch_sketch": "same Compute/Perm check as above; plus `else if (sizes != NULL) memSet (sizes, 0, ...);` and no error for non-power-of-two",
   "tradeoffs": "Slightly more conservative on documentation; essentially the same behaviour change, but makes the 'sizes invalid' state explicit. Needs a multi-rank test (np = 1,2,3,4).",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-10",
 "area": "CLI",
 "our_title": "esMUMPS discards the results of its ordering and symbolic-factorisation steps and always returns success",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/esmumps/esmumps.c:140,143,171,235",
 "evidence": "Source (7.0.17): `graphBuildGraph2 (...)`; `orderGraph (&ordedat, &grafdat);`; `symbolFaxGraph (&symbdat, &grafdat, &ordedat);` results discarded (lines 140/143/171); function ends `return (0);` (235).\nRepro t/es.c (path graph of n=262143 vertices, inputs mmap'ed; run with ASAN_OPTIONS=allocator_may_return_null=1:max_allocation_size_mb=1 so orderGraphListStrat's rangtab (n+1)*4 allocation fails):\n`WARNING: AddressSanitizer failed to allocate 0x100008 bytes` / `ERROR: orderGraphListStrat: out of memory` / `symbol_fax.c:178:11: runtime error: applying non-zero offset 18446744073709551612 to null pointer` ... `esmumps.c:191:11: runtime error: ... null pointer` / `esmumps returned 0; nv entries written: 0 of 262143` - success reported, nv/pe never written.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Detail: the failing order leaves ordedat reinitialised (cblknbr=0, NULL tabs), so symbolFaxGraph runs on an empty ordering instead of crashing - it silently yields cblknbr=0 and the final loop does nothing.",
 "fix_options": [
  {
   "label": "Check each step, clean up, return 1 (tested)",
   "summary": "Test the three return values, free what was built and return 1 (same value esmumps2 already returns on vendtab OOM).",
   "patch_sketch": "--- a/src/esmumps/esmumps.c\n+++ b/src/esmumps/esmumps.c\n@@ -136,11 +136,20 @@\n   for (vertnum = 0; vertnum < n; vertnum ++)\n     vendtab[vertnum] = petab[vertnum] + lentab[vertnum];\n \n-  graphInit        (&grafdat);\n-  graphBuildGraph2 (&grafdat, 1, n, pfree - 1, petab, vendtab, velotab, NULL, iwtab, NULL); /* Assume Fortran-based indexing */\n+  graphInit (&grafdat);\n+  if (graphBuildGraph2 (&grafdat, 1, n, pfree - 1, petab, vendtab, velotab, NULL, iwtab, NULL) != 0) { /* Assume Fortran-based indexing */\n+    errorPrint (\"esmumps2: cannot build graph\");\n+    memFree    (vendtab);\n+    return     (1);\n+  }\n \n-  orderInit  (&ordedat);\n-  orderGraph (&ordedat, &grafdat);                /* Compute ordering with Scotch */\n+  orderInit (&ordedat);\n+  if (orderGraph (&ordedat, &grafdat) != 0) {     /* Compute ordering with Scotch */\n+    errorPrint (\"esmumps2: cannot compute ordering\");\n+    graphExit  (&grafdat);\n+    memFree    (vendtab);\n+    return     (1);\n+  }\n \n #ifdef ESMUMPS_ORDER_DUMP\n   {\n@@ -167,8 +176,15 @@\n   memCpy (lasttab, ordedat.peritab, n * sizeof (INT));\n #endif /* ESMUMPS_DEBUG */\n \n-  symbolInit     (&symbdat);\n-  symbolFaxGraph (&symbdat, &grafdat, &ordedat);  /* Compute block symbolic factorizaion */\n+  symbolInit (&symbdat);\n+  if (symbolFaxGraph (&symbdat, &grafdat, &ordedat) != 0) { /* Compute block symbolic factorizaion */\n+    errorPrint (\"esmumps2: cannot compute symbolic factorization\");\n+    symbolExit (&symbdat);\n+    orderExit  (&ordedat);\n+    graphExit  (&grafdat);\n+    memFree    (vendtab);\n+    return     (1);\n+  }\n \n #ifdef ESMUMPS_DEBUG_OUTPUT\n   {",
   "tradeoffs": "Minimal; same 'nonzero = error' as the first allocation in the function. Tested with the OOM repro: `ERROR: esmumps2: cannot compute ordering`, returns 1, no UB. Fortran callers get ncmpa=1 (see CLI-22 for sign convention).",
   "preferred": true
  },
  {
   "label": "Single-exit cleanup with a negative MUMPS-style code",
   "summary": "Restructure with `o = -1; ... goto cleanup` and return a negative value (ESMUMPS convention for MUMPS: ncmpa<0 is error), so test_esmumps's `ncmpa < 0` check works as-is.",
   "patch_sketch": "int o = -1; if (graphBuildGraph2(...) != 0) goto end0; ... o = 0; end2: symbolExit; end1: orderExit; end0: graphExit; memFree (vendtab); return (o);",
   "tradeoffs": "Resolves CLI-10 and CLI-22 together and matches how MUMPS reads ncmpa, but changes the (undocumented) positive error code the function returns today (+1 on OOM) - ABI-visible for Fortran callers.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## CLI-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-22",
 "area": "CLI",
 "our_title": "esMUMPS test driver and its Fortran wrapper disagree on the sign of the error return",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "alloc-injection",
 "needs_note": "Needs a forced out-of-memory return through the Fortran wrapper.",
 "location": "src/esmumps/test_esmumps.c:138,146-147; esmumps.c:134 (return (1)); library_esmumps_f.c:81",
 "evidence": "Source (7.0.17): esmumps2 returns 1 on error (esmumps.c:121-134 `errorPrint (\"esmumps2: out of memory\"); return (1);`), ESMUMPSF stores it (`*ncmpa = esmumps (...)`, library_esmumps_f.c:81), test_esmumps.c:146 `if (ncmpa < 0) { errorPrint (\"test_esmumps: error in ESMUMPSF (%d)\", ncmpa); exit (EXIT_FAILURE); }` - a +1 never fails the test; `ncmpa` is an INT (64-bit in -DINTSIZE64 builds) printed with %d. With the CLI-10 fix applied the same limitation shows (`./t/es` returns 1 and a test_esmumps-style `ncmpa < 0` check would pass).",
 "upstream_change": "",
 "review_accuracy": "Accurate.",
 "fix_options": [
  {
   "label": "Make the test strict (ncmpa != 0 is not right either: ncmpa is a compression count on success)",
   "summary": "Define the error convention first: tests should fail on ncmpa < 0, so change esmumps2 to return -1 on errors (see CLI-10 option 2) and print with INTSTRING cast: `errorPrint (\"...(\" INTSTRING \")\", ncmpa)`.",
   "patch_sketch": "-    errorPrint (\"test_esmumps: error in ESMUMPSF (%d)\", ncmpa);\n+    errorPrint (\"test_esmumps: error in ESMUMPSF (\" INTSTRING \")\", (INT) ncmpa);   /* and esmumps2 -> return (-1) on error */",
   "tradeoffs": "Keeps the MUMPS convention (<0 error). ABI-visible change of the error code (+1 -> -1) for Fortran callers.",
   "preferred": true
  },
  {
   "label": "Keep +1 and let the test fail on ncmpa > 0 only when the graph is known to need no compression",
   "summary": "Not general: ncmpa legitimately counts compressions on success, so a positive value is ambiguous.",
   "patch_sketch": "(no patch recommended)",
   "tradeoffs": "Shows why option 1 (a negative error code) is the only clean fix.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## BLD-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-19",
 "area": "BLD",
 "our_title": "esmumpsv test branch is guarded by a macro nothing defines",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/check/test_libesmumps.c:181-196",
 "evidence": "ESMUMPS_HAS_ESMUMPSV occurs only at test_libesmumps.c:181 and :196 (grep over the whole 7.0.17 tree), defined nowhere, while esmumpsv() is declared in src/esmumps/library.h:59 and defined in library_esmumps.c:90. Compiled test_libesmumps.c with -DESMUMPS_HAS_ESMUMPSV against the 7.0.17 Makefile libesmumps.a: `bump.grf`, `bump_imbal_32.grf`, `m16x16_b100000_v.grf` all rc 0, so the path works. Note the branch is guarded by `velotab != NULL`; of the two graphs the test runs (Makefile:330-331) only bump_imbal_32.grf (flags `001`, vertex weights) executes it -- bump.grf has no weights.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. Enabling the macro is sufficient for bump_imbal_32.grf; it passes.",
 "fix_options": [
  {
   "label": "Remove the guard",
   "summary": "esmumpsv is part of the public library; delete the #ifdef/#endif.",
   "patch_sketch": "-#ifdef ESMUMPS_HAS_ESMUMPSV\n ...\n-#endif /* ESMUMPS_HAS_ESMUMPSV */",
   "tradeoffs": "Tested equivalent (macro defined) passes on the shipped weighted graph.",
   "preferred": true
  },
  {
   "label": "Define the macro in both build systems",
   "summary": "Add -DESMUMPS_HAS_ESMUMPSV to check's CFLAGS and target_compile_definitions.",
   "patch_sketch": "target_compile_definitions(test_libesmumps PRIVATE ESMUMPS_HAS_ESMUMPSV)",
   "tradeoffs": "Keeps an opt-out for builds against an older esmumps, but no such build exists inside this tree.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1: the function is unconditional in the shipped header, so the guard has no meaning.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)


===================================================================
## BLD-17

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "BLD-17",
 "area": "BLD",
 "our_title": "Concurrent esmumps and ptesmumps goals both rebuild the same esmumps directory under make -j",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/Makefile:122-129; src/esmumps/Makefile:55, 61, 68",
 "evidence": "7.0.17 src/Makefile: `esmumps: scotch` -> `(cd esmumps ; $(MAKE) scotch && $(MAKE) install)`; `ptesmumps: scotch ptscotch` -> `(cd esmumps ; $(MAKE) ptscotch && $(MAKE) ptinstall)`; src/esmumps/Makefile: `ptscotch: scotch` so the ptesmumps goal re-runs the `scotch` goal (same objects, same libesmumps.a) in the same directory. Reproduction on a fresh 7.0.17 Makefile build: after building scotch/ptscotch, repeat 8 times {make clean in esmumps; rm lib/*esmumps*; `make -j16 esmumps ptesmumps`}: src/esmumps entered 8 times per run; `grep -c 'gcc.* -c dof.c'` = 2 in 5 of 8 runs (e1:1, e2:2, e5:2, ...), i.e. two concurrent compilers writing dof.o in the same directory, and two `ar` runs on libesmumps.a. No hard failure occurred in 8 runs (races are timing dependent), so impact is shown as duplicate concurrent compilation/archiving of the same targets, not as a corrupted archive.",
 "upstream_change": "none (file untouched between v7.0.16 and v7.0.17)",
 "review_accuracy": "Accurate. Failure not observed, only the duplicate concurrent work that makes corruption possible.",
 "fix_options": [
  {
   "label": "ptesmumps depends on esmumps and only runs ptinstall",
   "summary": "src/Makefile: `ptesmumps : esmumps ptscotch` / `(cd esmumps ; $(MAKE) ptinstall)`.",
   "patch_sketch": "-ptesmumps\t\t\t:\tscotch\tptscotch\n-\t\t\t\t\t(cd esmumps ; $(MAKE) ptscotch && $(MAKE) ptinstall)\n+ptesmumps\t\t\t:\tesmumps\tptscotch\n+\t\t\t\t\t(cd esmumps ; $(MAKE) ptinstall)",
   "tradeoffs": "Tested: 8 runs of `make -j16 esmumps ptesmumps` -> dof.c compiled exactly once each time, both libesmumps.a and libptesmumps.a installed; `make -j8 ptesmumps` alone also builds both. Behavior change: `make ptesmumps` now also installs the sequential esmumps (harmless: same archive). esmumps/Makefile ptinstall still lists `scotch` as prerequisite but it is up to date by then.",
   "preferred": true
  },
  {
   "label": "Make esmumps/Makefile ptscotch independent",
   "summary": "Drop `ptscotch: scotch` and make ptinstall copy the already-built library (or build with a distinct object directory).",
   "patch_sketch": "-ptscotch\t\t\t:\tscotch\n+ptscotch\t\t\t:\n+\t\t\t\t\t@:",
   "tradeoffs": "Fixes at the lowest level but ptscotch would not build anything on its own; needs ptinstall to depend on libesmumps.a.",
   "preferred": false
  },
  {
   "label": "Serialize at CI level",
   "summary": "ci/build_makefile.sh: `make -j scotch ptscotch esmumps && make ptesmumps`.",
   "patch_sketch": "eval '${SCAN}make -j scotch ptscotch esmumps COVERAGE=$COVERAGE ...' && make ptesmumps",
   "tradeoffs": "Hides the problem for CI only; users running `make -j esmumps ptesmumps` still race.",
   "preferred": false
  }
 ],
 "notes": "Preferred option 1 (src/Makefile already expresses inter-target ordering by prerequisites, e.g. `escheck : esmumps`).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/BLD/diffs/ if any; harness sources alongside)
