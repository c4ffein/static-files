# G20-dgraph-io-dmesh

Items: DGR-03, DGR-19, DGR-15, DGR-16, DGR-20, CLI-04, PS-DGR-2



===================================================================
## DGR-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-03",
 "area": "DGR",
 "our_title": "Centralized loader never broadcasts header error; property digits overflow char[4]",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_io_load.c:218-235 (header), 249 (sprintf), 201 (proptab[4])",
 "evidence": "Reproducer (mine): load.c = SCOTCH_dgraphInit + SCOTCH_dgraphLoad(&g, rank==0 ? fopen(argv[1]) : NULL, -1, 0). File bad1.grf = `0\\n4 8\\n0 1000000\\n2 1 3\\n2 0 2\\n2 1 3\\n2 0 2` (property field out of 0..111). Command: `LD_LIBRARY_PATH=../fi/lib ASAN_OPTIONS=detect_leaks=0 mpirun --oversubscribe -np 2 ./load bad1.grf`.\nOutput: `(0): ERROR: dgraphLoadCent: bad input (1)` then on BOTH ranks `ERROR: AddressSanitizer: stack-buffer-overflow ... WRITE of size 8 ... #0 vsprintf ... #1 sprintf ... #2 dgraphLoadCent dgraph_io_load.c:249 ... #3 _SCOTCHdgraphLoad dgraph_io_load.c:152 ... 'proptab' (line 201) <== Memory access at offset 52 overflows this variable`. Rank 1 gets the garbage header through MPI_Bcast because reduglbtab[0] (the only error flag that is broadcast, l.231-237) is still 0. Source l.222-228 sets `cheklocval = 1` instead (a variable that is overwritten with 0 at l.262 before use).",
 "upstream_change": "",
 "review_accuracy": "Accurate on all counts (flag never propagated, garbage header on all ranks, 12-byte write into char[4], dgraphLoadDist propagates via reduloctab[0]=2 + dgraphAllreduceMaxSum). The 12-byte worst case (INT_MIN) is right; the overflow needs a value outside -99..999 (\"%3.3d\" already fits 0..999 in char[4]).",
 "fix_options": [
  {
   "label": "Set reduglbtab[0] = 1 on header error (tested)",
   "summary": "The broadcast already carries reduglbtab[0] as the error flag (every process returns 1 if it is non-zero); the reader simply forgot to set it. Replace the dead `cheklocval = 1`.",
   "patch_sketch": "--- a/src/libscotch/dgraph_io_load.c\n+++ b/src/libscotch/dgraph_io_load.c\n@@ -224,7 +224,7 @@\n         (reduglbtab[4] < 0)                     ||\n         (reduglbtab[4] > 111)) {\n       errorPrint (\"dgraphLoadCent: bad input (1)\");\n-      cheklocval = 1;\n+      reduglbtab[0] = 1;                          /* Propagate error to all processes through broadcast */\n     }\n   }\n \n",
   "tradeoffs": "Zero cost, no ABI change. Verified: both ranks now return rc=1 with only the reader's error message and no ASan error.",
   "preferred": true
  },
  {
   "label": "Defensive validation on every process after the broadcast + snprintf",
   "summary": "Independently of the flag, each process re-checks 0 <= reduglbtab[1..4] and reduglbtab[4] <= 111 after MPI_Bcast and uses snprintf (proptab, sizeof (proptab), ...).",
   "patch_sketch": "if ((reduglbtab[0] != 0) || (reduglbtab[1] < 0) || (reduglbtab[3] < 0) || (reduglbtab[4] < 0) || (reduglbtab[4] > 111)) {\n  errorPrint (\"dgraphLoadCent: invalid header\");\n  return (1);\n}\n...\nsnprintf (proptab, sizeof (proptab), \"%3.3d\", (int) reduglbtab[4]);",
   "tradeoffs": "Belt and braces (protects against any future path that forgets the flag), duplicates the reader's check; snprintf is C99 (Scotch already uses it in a few tools but the library code base prefers sprintf with bounded input).",
   "preferred": false
  },
  {
   "label": "Restructure like dgraphLoadDist: reduction instead of broadcast flag",
   "summary": "Read the header on the root, then use dgraphAllreduceMaxSum with reduloctab[0]=2 on error as dgraphLoadDist (dgraph_io_load.c:~700-716) does, then broadcast.",
   "patch_sketch": "/* root: on error reduloctab[0] = 2; all: dgraphAllreduceMaxSum (...); if (reduglbtab[0] >= 2) return (1); */",
   "tradeoffs": "Largest diff, one extra reduction; consistent with LoadDist. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: the 'reduglbtab[0] != 0 -> return (1)' check after the Bcast is already there (l.237-238), so setting the flag is the intended design; LoadDist is the reference implementation. dgraphLoadMulti not examined.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-19",
 "area": "DGR",
 "our_title": "Loader abort messages the refusing rank and never waits on pending sends",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_io_load.c:411-448 (root loop, TAGBAD handling l.445-447), 520-534 (abort loop, starts at current procnum l.522)",
 "evidence": "Reproducer fload.c (mine): np=2, rank 0 reads ring4.grf (4-vertex ring) and distributes; rank 1 gets its dgraphLoadCent edge-array allocation (message 'out of memory (6)', l.591) failed via the fault shim, then after the load each rank does MPI_Iprobe(ANY_SOURCE, ANY_TAG) on the communicator. `LD_LIBRARY_PATH=../fi/lib mpirun --oversubscribe -np 2 ./fload ring4.grf 1 1`: `(1): ERROR: dgraphLoadCent: out of memory (6)`, `r1 load rc=1 ... stray-message-pending=1`, `r1   stray: src=0 tag=1` (tag 1 = TAGVERTLOCTAB): the root sent the zero-byte abortion message (l.522-526 starts at the current `procnum`, which is the very rank that answered TAGBAD) although that rank had already received its vertex array and is not waiting for another one. Source also shows: after `stattab[0].MPI_TAG != TAGOK` (l.446) the root only sets cheklocval and `break`s out through l.521-528 without MPI_Waitall on the Isends of l.425-438 (vertex array, load array, label array, held in the block-local requtab[]), then frees vertredtax/edgeredtax (l.530-534) - source-read; not observable under ASan because MPI writes/reads are invisible.",
 "upstream_change": "",
 "review_accuracy": "Accurate on both claims (the pending-send part is by source only; the stray-message part is demonstrated).",
 "fix_options": [
  {
   "label": "Waitall on TAGBAD and start the abort loop at procnum + 1 for that case (tested for the stray message)",
   "summary": "Remember the first process that still needs an abortion message (procabrnum = procnum by default, procnum + 1 after a TAGBAD answer) and MPI_Waitall the posted Isends in the TAGBAD branch.",
   "patch_sketch": "--- a/src/libscotch/dgraph_io_load.c\n+++ b/src/libscotch/dgraph_io_load.c\n@@ -316,6 +316,7 @@\n \n   if (fileptr != NULL) {\n     Gnum                procnum;\n+    Gnum                procabrnum;               /* First process to send an abortion message to */\n \n     for (procnum = 0; procnum < grafptr->procglbnbr; procnum ++) {\n       Gnum                vertrednnd;\n@@ -323,6 +324,8 @@\n       Gnum                edgerednum;\n       Gnum                veloredsum;\n \n+      procabrnum = procnum;                       /* By default, the process being served still waits for data and needs an abortion message */\n+\n       for (vertrednum = edgerednum = baseval, veloredsum = 0,\n            vertrednnd = DATASIZE (vertglbnbr, grafptr->procglbnbr, procnum) + baseval;\n            vertrednum < vertrednnd; vertrednum ++) {\n@@ -443,8 +446,11 @@\n             errorPrint (\"dgraphLoadCent: communication error (8)\");\n             return (1);\n           }\n-          if (stattab[0].MPI_TAG != TAGOK)        /* If receiver could not allocate memory for edge arrays */\n+          if (stattab[0].MPI_TAG != TAGOK) {      /* If receiver could not allocate memory for edge arrays */\n             cheklocval = 1;\n+            procabrnum = procnum + 1;             /* This receiver already knows about the failure; do not send it an abortion message */\n+            MPI_Waitall (requnbr, &requtab[0], &stattab[0]); /* Complete vertex, load and label sends before send buffers are freed or reused */\n+          }\n           else {\n             if (MPI_Isend (edgeredtax + baseval, edgerednum - baseval, GNUM_MPI,\n                            procnum, TAGEDGELOCTAB, grafptr->proccomm, &requtab[requnbr ++]) != MPI_SUCCESS) {\n@@ -519,7 +525,7 @@\n       }\n \n       if (cheklocval != 0) {                      /* If error encountered                           */\n-        for ( ; procnum < grafptr->procglbnbr; procnum ++) { /* Send abortion messages              */\n+        for (procnum = procabrnum; procnum < grafptr->procglbnbr; procnum ++) { /* Send abortion messages */\n           if (procnum != grafptr->proclocnum) {   /* Abortion messages complete vertloctab receives */\n             if (MPI_Send (vertredtax + baseval, 0, GNUM_MPI, procnum, TAGVERTLOCTAB, grafptr->proccomm) != MPI_SUCCESS)\n               errorPrint (\"dgraphLoadCent: communication error (11)\");\n",
   "tradeoffs": "Local to the reader process; protocol unchanged for receivers. Verified: `./fload ring4.grf 1 1` now ends with stray-message-pending=0 on both ranks (rc=1 on both). The Waitall part compiles and runs but its necessity is not observable here.",
   "preferred": true
  },
  {
   "label": "Let the failed receiver consume the abortion message",
   "summary": "Keep the root loop as is and make the receiver that sent TAGBAD post a matching zero-byte MPI_Recv(TAGVERTLOCTAB) before its final MPI_Allreduce.",
   "patch_sketch": "/* receiver, in 'out of memory (6)' branch after MPI_Send (TAGBAD) */\nMPI_Recv (NULL, 0, GNUM_MPI, protnum, TAGVERTLOCTAB, grafptr->proccomm, MPI_STATUS_IGNORE);",
   "tradeoffs": "Smaller on the receiver, but couples correctness to a message the root may not send (e.g. when the root's own error occurs before it reaches that receiver); pending sends on the root still have to be waited for. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: the abortion-by-empty-message protocol is documented in the receiver ('Empty message means abortion wanted', l.574).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-15",
 "area": "DGR",
 "our_title": "Mesh loader stores element-range array without marking it private, leaking it",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dmesh_io_load.c:271 (alloc), 370 (flags), 381 (store); dmesh.c:106-113 (dmeshFree2)",
 "evidence": "Reproducer dmload.c (mine): np=1, SCOTCH_dmeshInit; SCOTCH_dmeshLoad(&m, fopen(\"good.adm\"), -1, 0) with good.adm = `3\\n1 0 2 3 2 4 1 0\\n2 1 2\\n2 2 3\\n` (valid 1-process 'version 3' distributed mesh); SCOTCH_dmeshExit(&m). `ASAN_OPTIONS=detect_leaks=1 mpirun -np 1 ./dmload good.adm`: `dmeshLoad rc=0` and a LeakSanitizer record `Direct leak of 8 byte(s) in 1 object(s) allocated from: #1 fi_malloc #2 dmeshLoadAdm dmesh_io_load.c:271 #3 _SCOTCHdmeshLoad dmesh_io_load.c:141 #4 SCOTCH_dmeshLoad library_dmesh_io_load.c:99`. Source: l.370 sets only DMESHFREETABS; dmeshFree2 frees prelvrttab only under DMESHFREEPRIV (dmesh.c:106-109), the only other writer dmeshBuildAdm sets DMESHFREEPRIV (dmesh_build_adm.c:101-106).",
 "upstream_change": "",
 "review_accuracy": "Accurate for the leak. The 'an older prelvrttab is overwritten' part is true only for a dmesh that already had one (not tested).",
 "fix_options": [
  {
   "label": "Set DMESHFREEPRIV together with DMESHFREETABS (tested)",
   "summary": "prelvrttab is private data in this codebase's terminology (dmeshBuildAdm sets DMESHFREEPRIV when it allocates it).",
   "patch_sketch": "--- a/src/libscotch/dmesh_io_load.c\n+++ b/src/libscotch/dmesh_io_load.c\n@@ -367,7 +367,7 @@\n     return (1);\n   }\n \n-  meshptr->flagval   |= DMESHFREETABS;\n+  meshptr->flagval   |= DMESHFREETABS | DMESHFREEPRIV; /* prelvrttab is private data, freed under DMESHFREEPRIV (see dmeshBuildAdm()) */\n   meshptr->baseval    = baseval;\n   meshptr->velmglbnbr = reduglbtab[3];\n   meshptr->velmglbmax = reduglbtab[10];\n",
   "tradeoffs": "One-token change, no ABI effect. Verified: the leak record at dmesh_io_load.c:271 disappears (count 0).",
   "preferred": true
  },
  {
   "label": "Also release a pre-existing prelvrttab",
   "summary": "Before `meshptr->prelvrttab = prelvrttab;` free the old array when DMESHFREEPRIV is set, or refuse to load into a non-empty mesh.",
   "patch_sketch": "if (((meshptr->flagval & DMESHFREEPRIV) != 0) && (meshptr->prelvrttab != NULL))\n  memFree (meshptr->prelvrttab);\nmeshptr->prelvrttab = prelvrttab;\nmeshptr->flagval |= DMESHFREETABS | DMESHFREEPRIV;",
   "tradeoffs": "Covers re-load into a used mesh; but dmeshLoad also would have to release velmloctab/eelmloctab of the old content (not done today either), so it is better handled by requiring an empty/freed mesh.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: dmesh_build_adm.c:101-106.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-16",
 "area": "DGR",
 "our_title": "Mesh loader failure label frees unrebased array, but guarding check makes branch unreachable",
 "claimed_severity": "low",
 "status": "not-a-bug",
 "method": "both",
 "needs": "none-found",
 "needs_note": "Source read plus a rejected-malformed-file run were conclusive; no input reaches the branch.",
 "location": "src/libscotch/dmesh_io_load.c:318-325 (goto fail l.321, rebase l.325), 361-367 (free of eelmloctax + baseval l.364)",
 "evidence": "The structure is as described: `goto fail` at l.321 precedes `eelmloctax -= baseval;` (l.325) while the fail block frees `eelmloctax + baseval` (l.364), which for baseval=1 is 8 bytes into the block. But the path is unreachable: preldspadj (l.317-319) is baseval + the sum over ranks of velmlocnbr, which dmeshLoadAdm has already forced to equal velmglbnbr + baseval by the earlier header check `reduglbtab[12] != reduloctab[3]` (l.~232: sum of local element counts vs the global count, with velmglbnbr min/max-checked identical on all ranks), after which `preldspadj != (velmglbnbr + baseval)` (l.320) can never be true. Tested: a malformed file whose header gives velmglbnbr=5 but velmlocnbr=2 (badsum.adm: `3\\n1 0 5 3 2 4 1 0\\n2 1 2\\n2 2 3`) is rejected earlier: `(0): ERROR: dmeshLoadAdm: inconsistent distributed mesh headers`, rc=1, never reaching 'bad input (2)'.",
 "upstream_change": "",
 "review_accuracy": "The code defect is real as written (latent) but the review's consequence ('corrupting the heap on a malformed .adm file') cannot occur: 'bad input (2)' is dead code behind the header-consistency check. Severity should be 'info' (hygiene).",
 "fix_options": [],
 "notes": "If upstream wants to harden it anyway: move `eelmloctax -= baseval;` above the check, or `goto fail` only after rebasing. No option list given because there is no reachable defect; no test possible to demonstrate otherwise.",
 "history": {
  "reported": "reported",
  "7.0.17": "not-a-bug"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-20

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-20",
 "area": "DGR",
 "our_title": "Dual-graph hash resize result ignored; allocation failure spins forever",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dmesh_dgraph.c:592-596 (resize call), 266-272, 316-323, 431-436, 507-510 (other returns)",
 "evidence": "Reproducer dmual.c (mine): np=1, 100 elements all sharing node 0 (SCOTCH_dmeshBuildAdm with velmloctab=[0..100], eelmloctab all 0, vnodglbnbr 1) -> one dual vertex has 99 neighbours > helmmax (64), forcing a hash resize; SCOTCH_dmeshDgraphDual(&m,&g,1). Normal run: rc=0. With reallfail.so preloaded (overrides the shim's fi_realloc: every realloc returns NULL) and a 10 s timeout: `[reallfail] realloc(6152) -> NULL (call #1)` ... `(call #1000000)`, `(call #2000000)`, `(call #3000000)` ... then timeout: the loop `if (helmnbr >= helmmax) { dmeshDgraphDualHashEdgeResize (...); goto redo; }` (l.592-596) ignores the return value of the resize, helmnbr stays >= helmmax, so it spins re-calling memRealloc forever. The other `return (1)` after errorPrint at l.266-272, 316-323, 431-436, 507-510 leak the arrays allocated so far (eeneloctax, prfrloctab, ercvcnttab, ...) and, in a multi-process run, do not join the MPI_Alltoall(v)/dgraphBuild2 that the other ranks are entering (source-read).",
 "upstream_change": "",
 "review_accuracy": "Accurate. The function is documented to return non-zero on out-of-memory (dmesh_dgraph.c:~60) but the only caller discards it.",
 "fix_options": [
  {
   "label": "Check the resize result and bail out with cleanup (tested)",
   "summary": "Test the return value, free helmtab/hnodtab/nrcvdattab/edgeloctax/vertloctax and return 1.",
   "patch_sketch": "--- a/src/libscotch/dmesh_dgraph.c\n+++ b/src/libscotch/dmesh_dgraph.c\n@@ -591,7 +591,15 @@\n \n           if (helmtab[helmend].vertnum != velmlocnum) { /* If edge not yet created      */\n             if (helmnbr >= helmmax) {             /* If edge hash table full, resize it */\n-              dmeshDgraphDualHashEdgeResize (&helmtab, &helmsiz, &helmmax, &helmmsk, velmlocnum);\n+              if (dmeshDgraphDualHashEdgeResize (&helmtab, &helmsiz, &helmmax, &helmmsk, velmlocnum) != 0) {\n+                errorPrint (\"dmeshDgraphDual: out of memory (7)\");\n+                memFree    (helmtab);\n+                memFree    (hnodtab);\n+                memFree    (nrcvdattab);\n+                memFree    (edgeloctax + baseval);\n+                memFree    (vertloctax + velmlocbas);\n+                return     (1);\n+              }\n               goto redo;                          /* Recompute helmend with new mask */\n             }\n \n",
   "tradeoffs": "Verified: same preload run now prints `dmeshDgraphDual: out of memory (7)` and `DgraphDual rc=1` immediately. Multi-process runs still need the failing process to be joined by its peers (they are blocked at dgraphBuild2), see option 2.",
   "preferred": true
  },
  {
   "label": "Collective failure: record the error, finish the loop idly, join dgraphBuild2 with an error marker",
   "summary": "Set cheklocval, stop adding edges (jump to the end of the element loop), and let all processes agree before dgraphBuild2 (dgraphCoarsen-style 'negative on error' reduction).",
   "patch_sketch": "/* on resize failure: cheklocval = 1; goto done; ... done: MPI_Allreduce (&cheklocval, &chekglbval, ...); if (chekglbval != 0) { cleanup; return (1); } */",
   "tradeoffs": "Fixes the hang as well as the spin; one extra Allreduce; larger diff.",
   "preferred": false
  },
  {
   "label": "Size the edge hash table once for the worst case",
   "summary": "Compute the maximum per-element neighbour count bound (sum of node degrees of the element, <= nrcvdatsiz) up front and allocate the table in the existing out-of-memory (5) allocation, removing the resize function.",
   "patch_sketch": "helmmax = MAX (64, 2 * maxelmdeg); helmsiz = 4 * helmmax; /* no dmeshDgraphDualHashEdgeResize */",
   "tradeoffs": "Removes the failure point but can over-allocate for skewed meshes (the resize exists to avoid that).",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: dgraphLoadCent and dmeshDgraphDual's own edge-array growth (l.612-621) already test memRealloc results and return; the resize call was simply left unchecked.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## CLI-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-04",
 "area": "CLI",
 "our_title": "Mesh-to-distributed-graph converter assumes an error handler that exits but links one that returns",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotchmetis/adm2dgr.c:179-225 (errorPrint/dgraphInit/free), src/libscotchmetis/CMakeLists.txt:228",
 "evidence": "Source (7.0.17): CMakeLists.txt:228 `target_link_libraries(adm2dgr PRIVATE ptscotchparmetisv${version} ptscotch scotch ptscotcherr)`; src/libscotch/CMakeLists.txt:859 `add_library(ptscotcherr library_error.c)` (non-exiting) whereas libscotchmetis/Makefile:243 links -lscotcherrexit (exits). adm2dgr.c: `prelvrttab = memAlloc(...)` ... `free (prelvrttab);` (memAlloc/free mismatch under COMMON_MEMORY_TRACE/CHECK), vertloctab/edgeloctab returned by SCOTCH_ParMETIS_V3_Mesh2Dual are never freed, message `\"dmeshBuildAdm: communication error\"` is wrong, `SCOTCH_dgraphInit(&grafdat, MPI_COMM_WORLD)` (harmless: proccomm == MPI_COMM_WORLD, so the 'instead of proccomm' remark is cosmetic).\nTool run: `mpirun -np 1 asan/bin/adm2dgr t/m44.msh t/m44.dgr` (mesh made by mmk_m2): `adm2dgr: ERROR: dmeshLoadCent: not implemented` (src/libscotch/dmesh_io_load.c:172; :402 for multi-file). So in 7.0.17 adm2dgr cannot load any mesh and dies before reaching the cited code (Makefile build), i.e. the tool is effectively dead; in a CMake build SCOTCH_errorPrint returns and execution would continue with an unloaded mesh. Not run for that reason.",
 "upstream_change": "",
 "review_accuracy": "Accurate on every point except 'dgraphInit is given MPI_COMM_WORLD instead of proccomm' (equal values here). Important context the review lacks: adm2dgr is unusable anyway because SCOTCH_dmeshLoad is not implemented.",
 "fix_options": [
  {
   "label": "Link the exit variant in CMake and tidy up the code",
   "summary": "CMake: link ptscotcherrexit (mirroring the Makefile). Code: memAlloc->memFree, free the dual arrays (`free(vertloctab); free(edgeloctab);` - they are plain malloc'd), fix the message, use proccomm.",
   "patch_sketch": "--- a/src/libscotchmetis/CMakeLists.txt\n-    target_link_libraries(adm2dgr PRIVATE ptscotchparmetisv${version} ptscotch scotch ptscotcherr)\n+    target_link_libraries(adm2dgr PRIVATE ptscotchparmetisv${version} ptscotch scotch ptscotcherrexit)\n--- a/src/libscotchmetis/adm2dgr.c\n-    errorPrint (\"dmeshBuildAdm: communication error\");\n-    return (1);\n+    errorPrint (\"main: communication error\");   /* errorPrint exits */\n...\n-  free (prelvrttab);\n+  memFree (prelvrttab);\n+  free (vertloctab);   /* allocated by plain malloc() in Mesh2Dual */\n+  free (edgeloctab);",
   "tradeoffs": "Smallest, consistent with all other CLI tools (they use the exit library); no behaviour change in the working Makefile build. Nothing to test until dmeshLoad exists.",
   "preferred": true
  },
  {
   "label": "Make every error path return explicitly",
   "summary": "Keep the non-exiting error library and turn each `SCOTCH_errorPrint(...)` into `{ SCOTCH_errorPrint(...); MPI_Abort(proccomm,1); return 1; }` with a single cleanup label.",
   "patch_sketch": "goto-based cleanup: `abort1: free dual arrays; abort2: SCOTCH_dmeshExit; abort3: memFree(prelvrttab); MPI_Finalize/Abort`",
   "tradeoffs": "Robust against whichever error library is linked, but a bigger rewrite for a tool that cannot currently load a mesh; unlike the other CLI tools, it deviates from the repo idiom of exit-on-error.",
   "preferred": false
  }
 ],
 "notes": "Leaks at process exit are harmless in a CLI; the real defect is the build-system inconsistency.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)


===================================================================
## PS-DGR-2

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DGR-2",
 "our_title": "dgraphHaloSync2 allocation failure is local only; peers continue and hang",
 "severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/dgraph_halo.c (dgraphHaloSync2, message \"dgraphHaloSync2: out of memory\")",
 "evidence": "Fault shim: induce np=2 nth=3, band np=8 nth=8, coarsen nth=13 each print '(1): ERROR: dgraphHaloSync2: out of memory' then the caller's 'cannot perform halo exchange'; failing rank returns 1, other ranks HANG. Still true with my other fixes applied.",
 "related_review_ids": [
  "DGR-06",
  "DGR-09",
  "DGR-13"
 ],
 "fix_options": [
  {
   "label": "Agree on allocation status inside HaloSync2",
   "summary": "Failing rank joins a one-int allreduce that peers also call.",
   "patch_sketch": "MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, comm); if (chekglbval) return (1);",
   "tradeoffs": "Extra collective on a hot routine. Not compiled.",
   "preferred": false
  },
  {
   "label": "Pre-allocate halo scratch in dgraphGhst",
   "summary": "Allocate the scratch with the ghost arrays, whose failures are already agreed on.",
   "patch_sketch": "/* add scratch to dgraphGhst2 memAllocGroup */",
   "tradeoffs": "Holds memory for graph lifetime; larger change. Not compiled.",
   "preferred": true
  }
 ],
 "area": "DGR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)
