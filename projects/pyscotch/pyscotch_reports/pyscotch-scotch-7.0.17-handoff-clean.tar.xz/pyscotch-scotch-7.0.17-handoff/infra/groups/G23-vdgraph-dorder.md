# G23-vdgraph-dorder

Items: DMO-05, DMO-12, PS-DMO-1, DMO-04, DMO-14, DMO-15, DMO-02, DMO-13



===================================================================
## DMO-05

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-05",
 "area": "DMO",
 "our_title": "Uncoarsening returns on all-invalid coarse separators without freeing its exchange buffer group",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/vdgraph_separate_ml.c:399-406 (memAllocGroup), 449-453 (return (1) without memFree)",
 "evidence": "Source (7.0.17): memAllocGroup(&vsndcnttab,...) at :399; after the reduction, 'if (reduglbtab[0] == 1) { ... return (1); }' at :449-453 has no memFree(vsndcnttab) (the reduglbtab[5] path just above does free it).\nReproduced with LeakSanitizer using a strategy whose coarsest separation is empty (low=z) so that every coarse separator is invalid: LEAK=1 mpirun --oversubscribe -np 3 ./drv 4elt.grf o 'n{sep=m{vert=120,low=z,asc=b{width=3,strat=q{strat=f}}},ole=q{strat=<leaf>},ose=s,osq=<leaf>}' (strategy in st_z.txt):\n  'Direct leak of 44616 byte(s) in 1 object(s) allocated from: ... memAllocGroup_ ... vdgraphSeparateMlUncoarsen vdgraph_separate_ml.c:399' (and 24360 B on another rank; 5 such leak records over the 3 ranks).\nAfter the one-line fix below the same run reports 0 leak records from vdgraph_separate_ml.c:399.",
 "upstream_change": "none",
 "review_accuracy": "Accurate. (The 'bdgraphBipartMlUncoarsen allocates after the check' comparison is right: bdgraph_bipart_ml.c:354 allocates after the validity test.)",
 "fix_options": [
  {
   "label": "A: free the group leader before the early return",
   "summary": "Insert memFree(vsndcnttab) in the 'all invalid' branch; vsndcnttab is non-NULL there because reduglbtab[5]==0 means every rank's allocation succeeded. Tested: LSan record disappears.",
   "patch_sketch": "--- a/src/libscotch/vdgraph_separate_ml.c\n+++ b/src/libscotch/vdgraph_separate_ml.c\n@@ -419,7 +419,7 @@\n     reduloctab[1] = (Gnum) finegrafptr->s.proclocnum; /* Set rank according to global order on both sub-communicators */\n     reduloctab[2] = (Gnum) coargrafptr->s.pkeyglbval; /* Set color key according to coarse graph sub-communicator     */\n     reduloctab[3] = coargrafptr->compglbsize[2];\n-    reduloctab[4] = coargrafptr->compglbloaddlt;\n+    reduloctab[4] = ABS (coargrafptr->compglbloaddlt); /* Compare on absolute imbalance */\n   }\n \n   if ((MPI_Type_contiguous (6, GNUM_MPI, &besttypedat)                                != MPI_SUCCESS) ||\n@@ -450,6 +450,7 @@\n #ifdef SCOTCH_DEBUG_BDGRAPH2\n     errorPrintW (\"vdgraphSeparateMlUncoarsen: no valid partition\");\n #endif /* SCOTCH_DEBUG_BDGRAPH2 */\n+    memFree (vsndcnttab);                         /* Free group leader; allocation succeeded everywhere as reduglbtab[5] is zero */\n     return (1);                                   /* All invalid partitions will lead to low method be applied at upper level */\n   }\n \n",
   "tradeoffs": "One line, no behaviour change except the leak; the merged reduction (allocation flag piggybacked on the best-partition reduction) is preserved.",
   "preferred": true
  },
  {
   "label": "B: allocate after the validity check (bdgraphBipartMlUncoarsen structure)",
   "summary": "Move the memAllocGroup below the 'reduglbtab[0] == 1' return and add a second error reduction after it (as bdgraph_bipart_ml.c:353-370 does).",
   "patch_sketch": "-  if (memAllocGroup (...vsndcnttab...) == NULL) { ...; reduloctab[5] = 1; }\n   ... reduction ...\n   if (reduglbtab[0] == 1) return (1);\n+  if (memAllocGroup (...vsndcnttab...) == NULL) { ...; reduloctab[5] = 1; }\n+  reduglbtab[5] = reduloctab[5];  /* collective only if SCOTCH_DEBUG_VDGRAPH1 as in the bdgraph version */\n+  if (reduglbtab[5] != 0) { ... return (1); }",
   "tradeoffs": "Never allocates on the fallback path (saves a transient allocation of ~ local graph size) but, as in the bdgraph twin, the second error check is only collective in debug builds (otherwise a failing rank returns while the others proceed), so it trades a leak for a potential hang. Untested.",
   "preferred": false
  }
 ],
 "notes": "Fires on every level where all coarse separators have an empty part; z-strategy forces it, in normal runs it is a rare fallback.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-12

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-12",
 "area": "DMO",
 "our_title": "Separator store omits per-rank part loads, so restored partitions feed stale loads to band extraction",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/vdgraph_store.c:114-155 ; vdgraph.h:74-82 (VdgraphStore) ; vdgraph_separate_bd.c:109-110 (consumer) ; vdgraph_check.c:226-250",
 "evidence": "Source: VdgraphStore (vdgraph.h:74) has no complocload[]; vdgraphStoreSave/Updt copy compglbload[], compglbsize0, complocsize0, fronlocnbr but never complocload[]; vdgraph_check.c computes complocload[] locally (:194-206) but only reduces/compares the GLOBAL sums.\nReproduced with a check inserted at the entry of vdgraphSeparateBd (dbg tree) that recomputes the true local loads from partgsttax: with strategy sep=(q{strat=h}|z)b{width=3,strat=q{strat=f}} (np=3, 4elt, drv o) it prints\n  DMO12 STALE rank 0: complocload=(476,4679,47) true=(5202,0,0)\n  DMO12 STALE rank 1: complocload=(3824,1344,34) true=(5202,0,0)\n  DMO12 STALE rank 2: complocload=(3436,1713,53) true=(5202,0,0)\n(same with sep=(m{...}|z)b{...}). Mechanism in this run: '|' restores the initial separation via vdgraphStoreUpdt (global fields restored, complocload left from the first strategy), then vdgraphSeparateZr sees compglbsize[0]==vertglbnbr and skips vdgraphZero, so the stale complocload reaches vdgraphSeparateBd -> dgraphBand(... complocload[0]+complocload[2], complocload[1] ...). With the patch (store/restore + vdgraphCheck test) the same run prints no STALE line.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate. The instrumented reproduction shows the stale loads reach Bd; I did not observe 'negative' anchor loads nor a changed final separator (the effect on quality/validity of the band graph was not measured).",
 "fix_options": [
  {
   "label": "A: store and restore complocload[3] (and check it)",
   "summary": "Add complocload[3] to VdgraphStore, copy in Save, restore in Updt; add the local-load comparison to vdgraphCheck so debug builds catch it. Tested via the instrumented tree (no STALE lines).",
   "patch_sketch": "--- a/src/libscotch/vdgraph.h\n+++ b/src/libscotch/vdgraph.h\n@@ -77,6 +77,7 @@\n   Gnum                      compglbload[2];       /*+ Load in both parts                +*/\n   Gnum                      compglbsize0;         /*+ Number of vertices in part 0      +*/\n   Gnum                      complocsize0;         /*+ Number of vertices in parts       +*/\n+  Gnum                      complocload[3];       /*+ Local loads of both parts and of separator +*/\n   Gnum                      fronlocnbr;           /*+ Number of local frontier vertices +*/\n   byte *                    datatab;              /*+ Variable-sized data array         +*/\n } VdgraphStore;\n\n--- a/src/libscotch/vdgraph_store.c\n+++ b/src/libscotch/vdgraph_store.c\n@@ -120,6 +120,9 @@\n   storptr->compglbload[1] = grafptr->compglbload[1];\n   storptr->compglbsize0   = grafptr->compglbsize[0];\n   storptr->complocsize0   = grafptr->complocsize[0];\n+  storptr->complocload[0] = grafptr->complocload[0];\n+  storptr->complocload[1] = grafptr->complocload[1];\n+  storptr->complocload[2] = grafptr->complocload[2];\n   storptr->fronlocnbr     = grafptr->complocsize[2];\n \n   fronloctab = storptr->datatab;                  /* Compute data offsets within save structure */\n@@ -150,6 +153,9 @@\n   grafptr->compglbsize[0] = storptr->compglbsize0;\n   grafptr->compglbsize[1] = grafptr->s.vertglbnbr - (storptr->compglbsize0 + storptr->fronglbnbr);\n   grafptr->compglbsize[2] = storptr->fronglbnbr;\n+  grafptr->complocload[0] = storptr->complocload[0];\n+  grafptr->complocload[1] = storptr->complocload[1];\n+  grafptr->complocload[2] = storptr->complocload[2];\n   grafptr->complocsize[0] = storptr->complocsize0;\n   grafptr->complocsize[1] = grafptr->s.vertlocnbr - (storptr->complocsize0 + storptr->fronlocnbr);\n   grafptr->complocsize[2] = storptr->fronlocnbr;\n\n--- a/src/libscotch/vdgraph_check.c\n+++ b/src/libscotch/vdgraph_check.c\n@@ -235,6 +235,14 @@\n     cheklocval = 1;\n   }\n \n+  if ((cheklocval == 0) &&\n+      ((complocload[0] != grafptr->complocload[0]) ||\n+       (complocload[1] != grafptr->complocload[1]) ||\n+       (complocload[2] != grafptr->complocload[2]))) {\n+    errorPrint (\"vdgraphCheck: invalid local part loads\");\n+    cheklocval = 1;\n+  }\n+\n   reduloctab[0] = complocload[0];\n   reduloctab[1] = complocload[1];\n   reduloctab[2] = complocload[2];\n",
   "tradeoffs": "Matches what the store already does for the other local data (complocsize0); +24 bytes per store; ABI-internal only. Must also be added if 'z'-like shortcuts rely on compglbsize only.",
   "preferred": true
  },
  {
   "label": "B: recompute local loads where they are consumed",
   "summary": "In vdgraphSeparateBd (and vdgraphZero's shortcut in vdgraphSeparateZr) recompute complocload[] from partgsttax/veloloctax (one O(local n) pass) instead of trusting the field.",
   "patch_sketch": "--- vdgraph_separate_bd.c (before dgraphBand)\n+  complocload[0] = complocload[1] = complocload[2] = 0;\n+  for (vertlocnum = baseval; vertlocnum < vertlocnnd; vertlocnum ++)\n+    grafptr->complocload[grafptr->partgsttax[vertlocnum]] += (veloloctax == NULL) ? 1 : veloloctax[vertlocnum];",
   "tradeoffs": "No struct change, fixes the only consumer, but costs an extra pass per band extraction and leaves the field stale for any future reader. Untested.",
   "preferred": false
  }
 ],
 "notes": "Related latent bug found on the way: vdgraphSeparateZr's shortcut '(compglbsize[0] != vertglbnbr)' skips vdgraphZero (which also resets complocload/complocsize) whenever the global sizes already say 'all in part 0', so any stale local field survives it.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## PS-DMO-1

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DMO-1",
 "our_title": "Zero separator method skips resetting local loads when global sizes already say all-in-part-0",
 "severity": "low",
 "status": "still-present",
 "method": "both",
 "location_7_0_17": "src/libscotch/vdgraph_separate_zr.c (vdgraphSeparateZr) calling vdgraphZero in vdgraph.c:119-141",
 "evidence": "vdgraphSeparateZr only calls vdgraphZero when compglbsize[0] != vertglbnbr. After a '|' strategy restores the initial separation via vdgraphStoreUpdt (global fields only), the local complocload/complocsize stay from the first strategy. Instrumented run (np=3, 4elt, sep=(q{strat=h}|z)b{...}) printed complocload=(476,4679,47) vs true (5202,0,0) at vdgraphSeparateBd entry.",
 "related_review_ids": [
  "DMO-12"
 ],
 "fix_options": [
  {
   "label": "A: always call vdgraphZero",
   "summary": "Drop the shortcut test in vdgraphSeparateZr.",
   "patch_sketch": "-  if (grafptr->compglbsize[0] != grafptr->s.vertglbnbr)\n     vdgraphZero (grafptr);",
   "tradeoffs": "Costs one memset of the part array; removes the stale state independent of the store fix.",
   "preferred": true
  },
  {
   "label": "B: fix only the store",
   "summary": "Save/restore complocload in VdgraphStore (DMO-12 option A).",
   "patch_sketch": "see DMO-12",
   "tradeoffs": "Fixes the cause but leaves the shortcut relying on global sizes only.",
   "preferred": false
  }
 ],
 "area": "DMO"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-04",
 "area": "DMO",
 "our_title": "Diffusion methods encode allocation failure as -1 inside summed degrees, so other ranks mask it",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "alloc-injection",
 "needs_note": "Forced allocation failure on one rank, which was injected here; stock runs cannot hit it.",
 "location": "src/libscotch/vdgraph_separate_df.c:121-152 (flag at :128, reduction :132, error branch :141-144, unconditional use after); src/libscotch/bdgraph_bipart_df.c:124-150 (flag :131, reduction :138, check :143)",
 "evidence": "Source (7.0.17) vdgraph_separate_df.c:128 'reduloctab[0] = -1;' then MPI_SUM reduction over {degrees,loads}; :141-144 'if (reduglbtab[0] < 0) { if (ielsloctax != NULL) memFree (ielsloctax + baseval); }' falls through (no return) into 'if ((reduglbtab[0] == 0) || (reduglbtab[1] == 0)) { memFree (ielsloctax + baseval); ...' and then the diffusion loops. bdgraph_bipart_df.c additionally does 'ielsloctax -= baseval' on the NULL result.\nReproduced with injected allocation failure on rank 1 (np=3):\nvdgraphSeparateDf: FAILFN=_SCOTCHvdgraphSeparateDf FAILRANK=1, './drv 4elt.grf o <strategy with b{width=3,strat=d{pass=3}}>' -> '(1): ERROR: vdgraphSeparateDf: out of memory' then 'vdgraph_separate_df.c:177:28: runtime error: store to null pointer of type float' + SEGV (backtrace SeparateDf <- SeparateSt <- SeparateBd <- SeparateMl <- hdgraphOrderNd).\nbdgraphBipartDf: FAILFN=_SCOTCHbdgraphBipartDf FAILRANK=1, './drv 4elt.grf m \"\" 8' (default strategy) -> 'bdgraph_bipart_df.c:198:30: runtime error: store to null pointer of type float' + SEGV.\nIn both cases the -1 of the failing rank was swallowed by the positive degrees of the other ranks, exactly as the review says.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate for both files. Nuance: bdgraphBipartDf does 'return (1)' on a detected error (no fall-through), the use-after-free/fall-through is specific to vdgraphSeparateDf; both suffer from the masking.",
 "fix_options": [
  {
   "label": "A: dedicated error slot in the same reduction, return on error",
   "summary": "Add a fifth entry to reduloctab/reduglbtab holding the allocation-failure flag (summed), leave the degree/load entries untouched, test it right after the Allreduce in both files and return(1) (freeing the group leader first). Shift the 'minus baseval' bookkeeping into the success branch. Tested: injected failures on rank 1 now give a clean 'out of memory' and OrderCompute/Map returns on all ranks, no SEGV (for the order run the failing band separation is then handled by the strategy fallback: 'vdgraphSeparateBd: cannot separate band graph').",
   "patch_sketch": "--- a/src/libscotch/vdgraph_separate_df.c\n+++ b/src/libscotch/vdgraph_separate_df.c\n@@ -97,8 +97,8 @@\n   float                           valolocval[2];  /* Fraction of load to remove from anchor vertices at each step */\n   Gnum                            vanclocnnd;\n   Gnum                            vertlocnum;\n-  Gnum                            reduloctab[4];  /* Local degree of both anchor vertices, minus edges to other anchors, and their loads */\n-  Gnum                            reduglbtab[4];\n+  Gnum                            reduloctab[5];  /* Local degree of both anchor vertices, minus edges to other anchors, their loads, and error flag */\n+  Gnum                            reduglbtab[5];\n   Gnum                            passnum;\n   float                           cdifval;\n   float                           cremval;\n@@ -112,6 +112,7 @@\n \n   reduloctab[0] = grafptr->s.vendloctax[grafptr->s.vertlocnnd - 2] - grafptr->s.vertloctax[grafptr->s.vertlocnnd - 2] - (grafptr->s.procglbnbr - 1);\n   reduloctab[1] = grafptr->s.vendloctax[grafptr->s.vertlocnnd - 1] - grafptr->s.vertloctax[grafptr->s.vertlocnnd - 1] - (grafptr->s.procglbnbr - 1);\n+  reduloctab[4] = 0;                              /* Assume no memory error */\n   if (grafptr->s.veloloctax == NULL)\n     reduloctab[2] =\n     reduloctab[3] = 1;\n@@ -125,7 +126,7 @@\n                      &difogsttax, (size_t) (grafptr->s.vertgstnbr * sizeof (float)),\n                      &difngsttax, (size_t) (grafptr->s.vertgstnbr * sizeof (float)), NULL) == NULL) {\n     errorPrint (\"vdgraphSeparateDf: out of memory\");\n-    reduloctab[0] = -1;\n+    reduloctab[4] = 1;\n   }\n   else {\n     ielsloctax -= grafptr->s.baseval;\n@@ -133,14 +134,15 @@\n     difngsttax -= grafptr->s.baseval;\n   }\n \n-  if (MPI_Allreduce (reduloctab, reduglbtab, 4, GNUM_MPI, MPI_SUM, grafptr->s.proccomm) != MPI_SUCCESS) {\n+  if (MPI_Allreduce (reduloctab, reduglbtab, 5, GNUM_MPI, MPI_SUM, grafptr->s.proccomm) != MPI_SUCCESS) {\n     errorPrint (\"vdgraphSeparateDf: communication error (1)\");\n     return     (1);\n   }\n \n-  if (reduglbtab[0] < 0) {                        /* If memory error */\n+  if (reduglbtab[4] != 0) {                       /* If memory error on any process */\n     if (ielsloctax != NULL)\n       memFree (ielsloctax + grafptr->s.baseval);  /* Free group leader */\n+    return (1);\n   }\n   if ((reduglbtab[0] == 0) ||                     /* If graph is too small to have any usable anchors, leave partition as is */\n       (reduglbtab[1] == 0)) {\n\n--- a/src/libscotch/bdgraph_bipart_df.c\n+++ b/src/libscotch/bdgraph_bipart_df.c\n@@ -121,6 +121,7 @@\n     reduloctab[3] = grafptr->s.veloloctax[grafptr->s.vertlocnnd - 1];\n   }\n \n+  reduloctab[4] = 0;                              /* Assume no memory error */\n   veexlocnbr = (grafptr->veexloctax != NULL) ? grafptr->s.vertlocnbr : 0;\n   if (memAllocGroup ((void **) (void *)\n                      &ielsloctax, (size_t) (grafptr->s.vertlocnbr * sizeof (float)),\n@@ -128,19 +129,21 @@\n                      &difogsttax, (size_t) (grafptr->s.vertgstnbr * sizeof (float)),\n                      &difngsttax, (size_t) (grafptr->s.vertgstnbr * sizeof (float)), NULL) == NULL) {\n     errorPrint (\"bdgraphBipartDf: out of memory\");\n-    reduloctab[0] = -1;\n+    reduloctab[4] = 1;\n+  }\n+  else {\n+    ielsloctax -= grafptr->s.baseval;\n+    difogsttax -= grafptr->s.baseval;\n+    difngsttax -= grafptr->s.baseval;\n+    veexloctax  = (grafptr->veexloctax != NULL) ? (veexloctax - grafptr->s.baseval) : NULL;\n   }\n-  ielsloctax -= grafptr->s.baseval;\n-  difogsttax -= grafptr->s.baseval;\n-  difngsttax -= grafptr->s.baseval;\n-  veexloctax  = (grafptr->veexloctax != NULL) ? (veexloctax - grafptr->s.baseval) : NULL;\n \n-  if (MPI_Allreduce (reduloctab, reduglbtab, 4, GNUM_MPI, MPI_SUM, grafptr->s.proccomm) != MPI_SUCCESS) {\n+  if (MPI_Allreduce (reduloctab, reduglbtab, 5, GNUM_MPI, MPI_SUM, grafptr->s.proccomm) != MPI_SUCCESS) {\n     errorPrint (\"bdgraphBipartDf: communication error (1)\");\n     return     (1);\n   }\n \n-  if (reduglbtab[0] < 0) {\n+  if (reduglbtab[4] != 0) {                       /* If memory error on any process */\n     if (ielsloctax != NULL)\n       memFree (ielsloctax + grafptr->s.baseval);  /* Free group leader */\n     return (1);\n",
   "tradeoffs": "No extra communication; mirrors reduloctab[5] error slots used in bdgraphBipartMl/Sq. Slightly larger reduction message (+8 bytes). Needs injection tests; Df is used inside every band graph of the default strategies.",
   "preferred": true
  },
  {
   "label": "B: separate MPI_MAX allreduce of the error flag before the data reduction",
   "summary": "Allocate, then do a first MPI_Allreduce(&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX) and bail out collectively before computing the anchor degrees; keep the degree reduction unchanged.",
   "patch_sketch": "   if (memAllocGroup (...) == NULL) { errorPrint (\"...out of memory\"); cheklocval = 1; }\n+  if (MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, grafptr->s.proccomm) != MPI_SUCCESS) { ...return (1); }\n+  if (chekglbval != 0) { if (ielsloctax != NULL) memFree (...); return (1); }\n   ... (existing degree reduction unchanged)",
   "tradeoffs": "Smallest semantic change to the data reduction, but one extra collective per call (latency) on a hot path; Scotch avoids extra collectives (see the '#ifdef SCOTCH_DEBUG_*1' idiom). Untested.",
   "preferred": false
  }
 ],
 "notes": "Also note in the review 'even when detected, the error branch frees the arrays and falls through' is confirmed by reading; I could not trigger the detected path because I could not make the sum negative with the 3-rank test (all other ranks had positive degrees).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-14",
 "area": "DMO",
 "our_title": "Distributed column-block count function returns 1 on failure, indistinguishable from a valid count",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "mpi-fault",
 "needs_note": "An MPI_Allreduce failure (or debug-build internal error) is needed to reach the error return.",
 "location": "src/libscotch/dorder_tree_dist.c:113-123 (dorderCblkDist, 'return (1)' at :120) ; src/libscotch/library_dgraph_order_tree_dist.c:84",
 "evidence": "7.0.17: 'Gnum dorderCblkDist (...) { ... if (dorderCblkDist2 (ordeptr, &dblklocnbr, &dblkglbnbr) != 0) return (1); return (dblkglbnbr); }' and the public wrapper 'return (dorderCblkDist ((Dorder *) ordeptr));' whose comment says '>=0 on success, <0 on error'. The error is only reachable when MPI_Allreduce fails (dorder_tree_dist.c:99-103) or in SCOTCH_DEBUG_DORDER2 builds, so I could not trigger it in a run.",
 "upstream_change": "none",
 "review_accuracy": "Accurate (line numbers moved: the wrapper is now at library_dgraph_order_tree_dist.c:84; the 'callers sizing arrays overflow in SCOTCH_dgraphOrderTreeDist' consequence is the caller's responsibility, not verified).",
 "fix_options": [
  {
   "label": "A: return -1",
   "summary": "'return (-1);' in dorderCblkDist (Gnum is signed). Compiles.",
   "patch_sketch": "--- a/src/libscotch/dorder_tree_dist.c\n+++ b/src/libscotch/dorder_tree_dist.c\n@@ -117,7 +117,7 @@\n   Gnum                dblkglbnbr;\n \n   if (dorderCblkDist2 (ordeptr, &dblklocnbr, &dblkglbnbr) != 0)\n-    return (1);\n+    return (-1);\n \n   return (dblkglbnbr);\n }\n",
   "tradeoffs": "One character; only the public wrapper calls dorderCblkDist (grep), so no internal caller depends on '1'. Matches the documented contract.",
   "preferred": true
  },
  {
   "label": "B: status-code internal API",
   "summary": "Change dorderCblkDist to 'int dorderCblkDist (const Dorder *, Gnum * cblkptr)' and let SCOTCH_dgraphOrderCblkDist translate failure to a negative SCOTCH_Num, keeping internals on the usual 0/!0 convention.",
   "patch_sketch": "-Gnum dorderCblkDist (const Dorder * restrict const ordeptr)\n+int  dorderCblkDist (const Dorder * restrict const ordeptr, Gnum * restrict const dblkglbptr)\n ...\n--- library_dgraph_order_tree_dist.c\n+  SCOTCH_Num dblkglbnbr;\n+  return (dorderCblkDist ((Dorder *) ordeptr, &dblkglbnbr) != 0 ? -1 : dblkglbnbr);",
   "tradeoffs": "Cleaner API (no in-band error value), but changes an internal prototype (dorder.h) and is more code for the same effect. Untested.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-15

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-15",
 "area": "DMO",
 "our_title": "Mapping save validity test uses contradictory && conditions and wrong bound, so it never triggers",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source read was conclusive; triggering needs a corrupted distributed mapping.",
 "location": "src/libscotch/dmapping_io.c:123-126",
 "evidence": "7.0.17: 'if ((reduglbtab[1] < 0) && (reduglbtab[1] > grafptr->procglbnbr)) { errorPrint (\"dmapSave: invalid mapping (1)\"); return (1); }' - a value cannot be both <0 and >procglbnbr (compilers flag this as always false), and reduglbtab[1] is the summed number of mapped vertices (reduloctab[1] = dmapptr->vertlocnbr), which should be compared with the number of graph vertices, not the process count. Not triggerable without a corrupted dmapping.",
 "upstream_change": "none (dmapping_io.c last touched by 4290e22 before 7.0.16)",
 "review_accuracy": "Accurate. Proposed fix 'compare with vertglbnbr' is right; the field is grafptr->vertglbnbr.",
 "fix_options": [
  {
   "label": "A: make it an out-of-range test (|| and vertglbnbr)",
   "summary": "(reduglbtab[1] < 0) || (reduglbtab[1] > grafptr->vertglbnbr).",
   "patch_sketch": "--- a/src/libscotch/dmapping_io.c\n+++ b/src/libscotch/dmapping_io.c\n@@ -120,7 +120,7 @@\n     errorPrint (\"dmapSave: inconsistent parameters\");\n     return (1);\n   }\n-  if ((reduglbtab[1] < 0) && (reduglbtab[1] > grafptr->procglbnbr)) {\n+  if ((reduglbtab[1] < 0) || (reduglbtab[1] > grafptr->vertglbnbr)) {\n     errorPrint (\"dmapSave: invalid mapping (1)\");\n     return (1);\n   }\n",
   "tradeoffs": "Catches over-count and negative sums but tolerates partial mappings (sum < vertglbnbr), which may exist for mappings with unmapped vertices. Compiles.",
   "preferred": true
  },
  {
   "label": "B: require an exact match",
   "summary": "'reduglbtab[1] != grafptr->vertglbnbr' - the saved file header (vertglbnbr written at :146) then always equals the graph size.",
   "patch_sketch": "-  if ((reduglbtab[1] < 0) && (reduglbtab[1] > grafptr->procglbnbr)) {\n+  if (reduglbtab[1] != grafptr->vertglbnbr) {",
   "tradeoffs": "Stronger validation, but could reject a legitimate partial mapping that PT-Scotch can produce; verify against the fragment semantics in dmapping.c before adopting. Untested.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-02",
 "area": "DMO",
 "our_title": "Order file writer gathers labels into an unbased buffer using based displacements, shifting output",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dorder_io.c:123,145,203-208 ; src/libscotch/dorder_io_tree.c:118,131,151,157",
 "evidence": "Reproduced for dorderSave with a 12-vertex path graph, baseval 1, vertex labels 101..112 (lbl.grf, flags '100'): 'mpirun --oversubscribe -np 3 asan/bin/dgord lbl.grf ord.out' produced\n  12\n  -1094795586\t106\n  101\t107\n  102\t108 ... 109\t-1094795586\ni.e. first column shifted by one vertex (label of the previous vertex) and the first entry uninitialised; second column (label of permuted index) shifted too. Source (7.0.17): receive buffer 'vlbltax' is a plain memAllocGroup block (dorder_io.c:123), gathered into with the based grafptr->procdsptab at :145, and only rebased afterwards at :203 ('vlbltax -= ordeptr->baseval;').\ndorder_io_tree.c (dorderSaveTree2, used by dgord -T / SaveTree / SaveMap / SaveBlock): same unbased vlbltab (memAlloc of vnodglbnbr entries, :118) gathered with based displacements (:131). Output of dgord -T is nevertheless correct (101..112 with right fathers) because orderSaveTree() indexes the array with based vertex numbers, so reads match the shifted writes; the defect there is a pure heap overflow of baseval Gnum past the end of the buffer by the MPI write (and read). I could not show it with ASan since the write happens inside libmpi (uninstrumented): source-read.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "Only dmapping_io.c was fixed upstream (4290e22, Oct 2025, pre-7.0.16). Nothing for dorder_io*.c in 7.0.17.",
 "review_accuracy": "Accurate for dorderSave (wrong output + overflow). Imprecise for dorder_io_tree.c: the saved tree/map/block output is correct there; only the out-of-bounds write/read remains. Review also says 'prints the previous vertex's label on every line' - confirmed (both columns).",
 "fix_options": [
  {
   "label": "A: base the receive buffer before the gather (dmapSave idiom)",
   "summary": "Shift the label buffer pointer by baseval before commGatherv (only where it is non-NULL), drop the later shift in dorderSave, and hand the based pointer to funcptr()/free the group leader at +baseval in dorderSaveTree2. Tested: dgord on lbl.grf now prints 101..112 in the right columns.",
   "patch_sketch": "--- a/src/libscotch/dorder_io.c\n+++ b/src/libscotch/dorder_io.c\n@@ -81,7 +81,7 @@\n {\n   Gnum * restrict       peritab;\n   Gnum * restrict       permtab;\n-  Gnum * restrict       vlbltax;\n+  Gnum * restrict       vlbltax = NULL;\n   int                   procglbnbr;\n   int                   reduloctab[3];\n   int                   reduglbtab[3];\n@@ -141,6 +141,9 @@\n #endif /* SCOTCH_DEBUG_DORDER1 */\n \n   if (grafptr->vlblloctax != NULL) {\n+    if (vlbltax != NULL)\n+      vlbltax -= ordeptr->baseval;                /* Base label array since displacement array is based */\n+\n     if (commGatherv (grafptr->vlblloctax + grafptr->baseval, grafptr->vertlocnbr, GNUM_MPI,\n                      vlbltax, grafptr->proccnttab, grafptr->procdsptab, GNUM_MPI, protnum, grafptr->proccomm) != MPI_SUCCESS) {\n       errorPrint (\"dorderSave: communication error (3)\");\n@@ -200,7 +203,6 @@\n     orderPeri (peritab, ordeptr->baseval, ordeptr->vnodglbnbr, permtab, ordeptr->baseval); /* Compute direct permutation */\n \n     if (grafptr->vlblloctax != NULL) {            /* If ordering has label array */\n-      vlbltax -= ordeptr->baseval;                /* Base label array            */\n \n       for (vertnum = 0; vertnum < ordeptr->vnodglbnbr; vertnum ++) {\n         if (fprintf (stream, GNUMSTRING \"\\t\" GNUMSTRING \"\\n\",\n\n--- a/src/libscotch/dorder_io_tree.c\n+++ b/src/libscotch/dorder_io_tree.c\n@@ -127,6 +127,8 @@\n #endif /* SCOTCH_DEBUG_DORDER1 */\n     if (cheklocval != 0)\n       return (1);\n+    if (vlbltab != NULL)\n+      vlbltab -= ordeptr->baseval;                /* Base label array since displacement array is based */\n     if (commGatherv (grafptr->vlblloctax + grafptr->baseval, grafptr->vertlocnbr, GNUM_MPI,\n                      vlbltab, grafptr->proccnttab, grafptr->procdsptab, GNUM_MPI, protnum, grafptr->proccomm) != MPI_SUCCESS) {\n       errorPrint (\"dorderSaveTree2: communication error (3)\");\n@@ -155,7 +157,7 @@\n     cheklocval = dorderGather (ordeptr, NULL);\n \n   if (vlbltab != NULL)\n-    memFree (vlbltab);\n+    memFree (vlbltab + ordeptr->baseval);\n \n #ifdef SCOTCH_DEBUG_DORDER1                       /* Communication cannot be merged with a useful one */\n   if (MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, ordeptr->proccomm) != MPI_SUCCESS) {\n",
   "tradeoffs": "Tiny, local, no ABI change. Relies on pointer arithmetic below the allocation start (same as dmapSave since 4290e22), so non-root ranks (vlbltax NULL) must be guarded or initialised to NULL (UBSan flags 'applying non-zero offset to null pointer' otherwise - observed in my first attempt; the shown diff contains the guard for dorderSave but the tree variant needs no guard since vlbltab is NULL-tested). Needs a test with baseval=1 + labels in the PT-Scotch test-suite.",
   "preferred": true
  },
  {
   "label": "B: over-allocate by baseval, no pointer rebasing",
   "summary": "Allocate vnodglbnbr+baseval entries; gather into the buffer with the based displacements unchanged; in dorderSave use unbased indexing 'vlbltax[vertnum+baseval]' / 'vlbltax[permtab[vertnum]]' (delete the 'vlbltax -= baseval'); in dorderSaveTree2 only the allocation size changes since orderSaveTree() already indexes with based numbers.",
   "patch_sketch": "--- dorder_io.c\n-    vlblnbr = (grafptr->vlblloctax != NULL) ? ordeptr->vnodglbnbr : 0;\n+    vlblnbr = (grafptr->vlblloctax != NULL) ? ordeptr->vnodglbnbr + ordeptr->baseval : 0;\n...\n-      vlbltax -= ordeptr->baseval;                /* Base label array            */\n(delete)\n--- dorder_io_tree.c\n-      if ((vlbltab = memAlloc (ordeptr->vnodglbnbr * sizeof (Gnum))) == NULL) {\n+      if ((vlbltab = memAlloc ((ordeptr->vnodglbnbr + ordeptr->baseval) * sizeof (Gnum))) == NULL) {",
   "tradeoffs": "Avoids any out-of-range pointer arithmetic, one-line in the tree file; but leaves a baseval-sized hole at the start of the buffer and the unbased-vs-based convention of the two files stays inconsistent (dorderSave would index unbased while orderSaveTree indexes based). Not the idiom used by dmapSave. Untested.",
   "preferred": false
  }
 ],
 "notes": "Only reproduces with baseval != 0 and vertex labels. dgord/dgpart tests with baseval 0 would never see it.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)


===================================================================
## DMO-13

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DMO-13",
 "area": "DMO",
 "our_title": "Block ordering writer never frees range array and overwrites loop error with trailing writes",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dorder_io_block.c:84-125 (rangtab :88; leaks on :93-98, :123; trailing intSave :107-108,:117-118)",
 "evidence": "Source: rangtab = memAlloc(...) at :88 is never freed on any path (including the early 'bad output (1)' return); after each guarded loop the code runs an unconditional 'o = intSave (stream, rangtab[...]); putc (...)' which overwrites a failure status from the loop.\nReproduced with SCOTCH_dgraphOrderSaveBlock through drv2: (1) leak: 'LEAK=1 mpirun --oversubscribe -np 2 ./drv2 4elt.grf b blk.out' -> LSan 'Direct leak ... allocated from ... dorderSaveBlock2 dorder_io_block.c:88 <- dorderSaveTree2 dorder_io_tree.c:151 <- dorderSaveBlock <- SCOTCH_dgraphOrderSaveBlock'. (2) hidden write error: './drv2 4elt.grf b /dev/full' (np=2) prints 'rank 0 save(b) ret=0' - the ~100 KB output cannot be written (/dev/full) yet SCOTCH_dgraphOrderSaveBlock returns 0. With the patch below: '(0): ERROR: dorderSaveBlock2: bad output (2)', rank 0 ret=1, and the LSan record is gone.\nTooling (all in work/DMO): fault-injection copy of the ASan+UBSan 7.0.17 build (memAlloc/memAllocGroup hook selected by env FAILFN=<function> FAILRANK FAILSKIP, injected-failure runs are labelled as such), C drivers drv.c/drv2.c/drv3.c linked against libptscotcherr (non-exiting errorPrint), run via 'mpirun --oversubscribe -np N'.",
 "upstream_change": "none",
 "review_accuracy": "Accurate on both points. (Non-root ranks still return 0 for a root-only I/O failure; that is the existing contract of dorderSaveTree2.)",
 "fix_options": [
  {
   "label": "A: free on every return, guard the trailing writes",
   "summary": "memFree(rangtab) on the early-error return and at the end; wrap the two trailing intSave/putc in 'if (o == 1)'. Tested (above).",
   "patch_sketch": "--- a/src/libscotch/dorder_io_block.c\n+++ b/src/libscotch/dorder_io_block.c\n@@ -95,6 +95,7 @@\n                (Gnum) cordptr->cblknbr,\n                (Gnum) cordptr->vnodnbr) < 0) {\n     errorPrint (\"dorderSaveBlock2: bad output (1)\");\n+    memFree    (rangtab);\n     return     (1);\n   }\n \n@@ -102,8 +103,10 @@\n     o = intSave (stream, rangtab[cblknum]);\n     putc (((cblknum & 7) == 7) ? '\\n' : '\\t', stream);\n   }\n-  o = intSave (stream, rangtab[cblknum]);\n-  putc ('\\n', stream);\n+  if (o == 1) {                                   /* Do not hide a previous error */\n+    o = intSave (stream, rangtab[cblknum]);\n+    putc ('\\n', stream);\n+  }\n \n   orderPeri (cordptr->peritab, cordptr->baseval, cordptr->vnodnbr, rangtab, cordptr->baseval); /* TRICK: re-use rangtab as permtab */\n \n@@ -111,12 +114,16 @@\n     o = intSave (stream, rangtab[vertnum]);\n     putc (((vertnum & 7) == 7) ? '\\n' : '\\t', stream);\n   }\n-  o = intSave (stream, rangtab[vertnum]);\n-  putc ('\\n', stream);\n+  if (o == 1) {                                   /* Do not hide a previous error */\n+    o = intSave (stream, rangtab[vertnum]);\n+    putc ('\\n', stream);\n+  }\n \n   if (o != 1)\n     errorPrint (\"dorderSaveBlock2: bad output (2)\");\n \n+  memFree (rangtab);\n+\n   return (1 - o);\n }\n \n",
   "tradeoffs": "Minimal; error text/return codes unchanged except that write errors are now reported.",
   "preferred": true
  },
  {
   "label": "B: single-exit rewrite",
   "summary": "Restructure into an 'o = 1; ... goto end;' flow with one 'end: memFree (rangtab); return (o);' so that future edits cannot reintroduce a leak.",
   "patch_sketch": "   if (... < 0) { errorPrint (...); o = 1; goto end; }\n   ...\nend:\n   memFree (rangtab);\n   return (o);",
   "tradeoffs": "Slightly bigger diff, cleaner invariants (free in one place); same behaviour as A. Untested.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DMO/diffs/ if any; harness sources alongside)
