# G02-arch-tleaf-hcub-build

Items: COR-06, COR-19, PS-API-3, API-10, PS-API-2, PS-API-4, CLI-24



===================================================================
## COR-06

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-06",
 "area": "COR",
 "our_title": "Labelled tree-leaf permutation size and uniqueness unchecked in release, yielding out-of-range terminals",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_tleaf.c:690-735 (SCOTCH_DEBUG_ARCH2 blocks at ~690-705 and ~712-720), uses at 799-801 (archLtleafDomNum/DomTerm) and DomDist (~497)",
 "evidence": "Size-mismatch case (the dangerous one): target file 'ltleaf 1 4 1 3 2 1 0' (levlnbr 1, size 4, link 1, permnbr 3, perm 2 1 0 - 3 does not divide 4), then 'gmap -vm g44.grf in.tgt out.map' -> 'AddressSanitizer: heap-buffer-overflow ... READ of size 4 ... #0 _SCOTCHarchTleafDomDist arch_tleaf.c:497 #1 graphMapView2 library_graph_map_view.c:470 #2 SCOTCH_graphMapView' (terminal 3 maps to domnnum - permnum + permtab[permnum] = 5 >= termnbr 4).\nDuplicate case: 'ltleaf 1 4 1 4 0 0 1 2' loads fine (ret=0) and gmap -vm gives 'Processors 3/4' (a terminal is lost; peritab[3] stays uninitialised heap content, 0xbebebebe under ASan). I did NOT get an ASan heap-buffer-overflow at line 801 for the review's exact string in 4 gmap variants; the defect there is an uninitialised-read (MSan/valgrind class), index OOB needs the size-mismatch variant above.\nThe debug-only check itself (SCOTCH_DEBUG_ARCH2): 'for (levlnum = levlnbr-1, sizeval = sizetab[levlnum]; sizeval != permnbr; levlnum --, sizeval *= archptr->sizetab[levlnum]) { if (levlnum < 0) ...' - the comma expression evaluates sizetab[levlnum] with levlnum==-1 (reads linktab[-1]'s neighbour sizetab[-1]) before the 'levlnum < 0' test: source-read, confirmed. Harness (all under work/COR): archload.c = SCOTCH_archLoad() on a one-line .tgt file, linked against the pristine ASan+UBSan libscotch.so (32-bit INT, release, no COMMON_DEBUG/SCOTCH_DEBUG_*); st.c = SCOTCH_stratGraphMap/GraphOrder/MeshOrder + stratSave. Patched tree (fixes tested): work/COR/fix (copy of the ASan build with the patches; diffs in work/COR/diffs/).",
 "upstream_change": "",
 "review_accuracy": "mostly accurate; the review's reproducer string for the OOB read does not by itself produce an ASan-visible OOB in 7.0.17 (it yields an uninitialised peritab slot); a size-mismatch permutation does",
 "fix_options": [
  {
   "label": "A. Unconditional checks with O(n) duplicate detection",
   "summary": "Always run the level-boundary check (test levlnum before indexing) and detect duplicates by marking peritab[] (initialised to -1) while reading, instead of the O(n^2) debug loop.",
   "patch_sketch": "-#ifdef SCOTCH_DEBUG_ARCH2\n-  if (archptr->permnbr != 1) { ... for (...; sizeval != permnbr; levlnum --, sizeval *= sizetab[levlnum]) { if (levlnum < 0) ...\n+  if (archptr->permnbr != 1) {\n+    for (levlnum = levlnbr - 1, sizeval = sizetab[levlnum]; sizeval != permnbr; ) {\n+      if ((levlnum <= 0) || (sizeval > permnbr)) { errorPrint (\"...permutation size does not match level boundaries\"); return (1); }\n+      levlnum --; sizeval *= sizetab[levlnum];\n+    }\n+  }\n ... allocate permtab (2*permnbr); peritab = permtab + permnbr; for all: peritab[i] = -1;\n for (permnum...) { read permtab[permnum] + range check;\n+  if (peritab[permtab[permnum]] >= 0) { errorPrint (\"...duplicate permutation index\"); return (1); }\n+  peritab[permtab[permnum]] = permnum; }\n-  (remove the separate inverse-permutation loop)",
   "tradeoffs": "Tested: 'ltleaf 1 4 1 4 0 0 1 2' -> 'duplicate permutation index'; 'ltleaf 1 4 1 3 2 1 0' -> 'permutation size does not match level boundaries'; valid 'ltleaf 2 2 1 2 1 4 3 2 1 0' and mapping on ltleaf unchanged; no sanitizer output. O(n) instead of O(n^2) so it is fine to leave enabled for large permutations. Behaviour change: previously accepted malformed files are now rejected.",
   "preferred": true
  },
  {
   "label": "B. Only promote the cheap size check, keep duplicate check debug-only",
   "summary": "Make the level-boundary check unconditional (this is what causes OOB), leave the O(n^2) duplicate loop under SCOTCH_DEBUG_ARCH2 and fix its levlnum<0 ordering.",
   "patch_sketch": "As A for the first hunk; keep '#ifdef SCOTCH_DEBUG_ARCH2' around the permtmp loop.",
   "tradeoffs": "Leaves the uninitialised peritab slot (wrong mapping, UB read) in release for duplicate files. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: the Load routine already builds peritab in the same pass; marking is free.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-19",
 "area": "COR",
 "our_title": "Hypercube dimension bound fixed, but int-typed shifts remain undefined for 31-62 bits on 64-bit INT",
 "claimed_severity": "low",
 "status": "partially-fixed",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/arch_hcub.c:104-107 (bound), 158, 242, 261, 380 ('1 << ...' int shifts)",
 "evidence": "7.0.17 bound: 'archptr->dimnnbr > (Anum) ((sizeof (Anum) << 3) - 2)' (c5baef9): 32-bit INT: 'hcub 31' and 'hcub 32' are rejected ('archHcubArchLoad: bad input'), 'hcub 30' loads with size 1073741824 - fixed for the review's 32-bit cases.\n64-bit INT build (work/COR/b64): 'hcub 40' -> 'arch_hcub.c:261:13: runtime error: shift exponent 40 is too large for 32-bit type int' and size=256 (garbage); 'hcub 31' -> 'left shift of 1 by 31 places cannot be represented in type int', size=-2147483648; the bound is now 62 but the shifts at lines 158/242/261/380 are still 'int' shifts ('1 << ...'), so any dimnnbr in 31..62 is UB/garbage on INTSIZE64 builds.",
 "upstream_change": "c5baef9 'Set tighter boundary on hypercube dimension in archHcubArchLoad()' - fixes the bound only; the review's second half ('shift (Anum) 1') was not applied.",
 "review_accuracy": "accurate; 7.0.17 fixes it only on 32-bit INT builds",
 "fix_options": [
  {
   "label": "A. Shift an Anum",
   "summary": "Use '(Anum) 1 << n' at the four sites (the bound from c5baef9 is then correct).",
   "patch_sketch": "arch_hcub.c: 158: vertnbr = (Anum) 1 << archptr->dimnnbr;  242: (domnnum < ((Anum) 1 << archptr->dimnnbr))  261: return ((Anum) 1 << domnptr->dimncur);  380: bitsset | ((Anum) 1 << dom1ptr->dimncur)",
   "tradeoffs": "Tested on the 64-bit build: 'hcub 40' size=1099511627776, 'hcub 62' size=4611686018427387904 (2^62), 'hcub 63' rejected, no UBSan output; 32-bit unchanged. Zero cost.",
   "preferred": true
  },
  {
   "label": "B. Tighten the bound to what int can hold",
   "summary": "Keep the 'int' shifts and cap dimnnbr at 30 for every INT size.",
   "patch_sketch": "dimnnbr > 30",
   "tradeoffs": "Silently forbids hypercubes above 2^30 on 64-bit builds (unrealistic sizes anyway), but contradicts the evident intent of the comment ('enough bits in ArchHcubDom bitsset field'). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: c5baef9 already reasons in Anum bits; and 6a00c51 ('apply left shifts to unsigned integers in bit sets') shows the maintainers fixing the same class of shift bug elsewhere.",
 "history": {
  "reported": "reported",
  "7.0.17": "partially-fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-3

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-3",
 "our_title": "Hypercube architecture uses int shift for dimensions up to 62, which the loader permits",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/arch_hcub.c:158, 242, 261 (1 << dimnnbr); loader limit at 104-106",
 "evidence": "work/API/arch.c mode 5, archHcub(40): UBSan 'arch_hcub.c:261:13: runtime error: shift exponent 40 is too large for 32-bit type int', size reported 256. Loader accepts dimnnbr <= sizeof(Anum)*8-2.",
 "related_review_ids": [
  "API-10"
 ],
 "fix_options": [
  {
   "label": "Shift an Anum",
   "summary": "Use ((Anum) 1) << dimnnbr at the three sites.",
   "patch_sketch": "-  vertnbr = 1 << archptr->dimnnbr;\n+  vertnbr = ((Anum) 1) << archptr->dimnnbr;",
   "tradeoffs": "Fixes 31..62 on 64-bit Anum; 32-bit Anum still needs the limit lowered.",
   "preferred": true
  },
  {
   "label": "Lower the limit",
   "summary": "Cap dimnnbr at sizeof(int)*8-2 in loader and builder.",
   "patch_sketch": "(archptr->dimnnbr > 30)",
   "tradeoffs": "Rejects large cubes that 64-bit builds could address.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-10",
 "area": "API",
 "our_title": "Tleaf, Ltleaf and Hcub builders accept values the file loaders reject, enabling heap write",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_arch.c:339-358 (SCOTCH_archHcub), 496-540 (SCOTCH_archTleaf), 551-575 (SCOTCH_archLtleaf)",
 "evidence": "Unchanged. work/API/arch.c on ASan 7.0.17 (SCOTCH_archLtleaf is not even declared in scotch.h/library.h: only SCOTCH_archTleaf is; I declared it manually): mode 0 archLtleaf(levl=1,size {2},link {1},permnbr=2,permtab {5,0}) -> 'heap-buffer-overflow ... WRITE of size 4 ... SCOTCH_archLtleaf library_arch.c:562'; mode 1 archHcub(70) -> 'arch_hcub.c:261:13: runtime error: shift exponent 70 is too large for 32-bit type int' and size=64; mode 2 archTleaf sizes {0,-3} -> r=0 size=0; mode 3 archTleaf(levlnbr=-1) -> ASan 'requested allocation size 0xfffffffffffffffc ... exceeds maximum' (memAlloc((levlnbr*2+1)*sizeof)). archHcub(0) accepted (loader rejects <1).",
 "upstream_change": "",
 "review_accuracy": "accurate. Extra points the review missed: (1) SCOTCH_archLtleaf is exported but undeclared in the public header; (2) archHcub even with a loader-valid dimension 31..62 hits 'int 1 << dimnnbr' UB (arch_hcub.c:158,242,261), so the loader limit (sizeof(Anum)*8-2) is itself too loose; (3) on failure the builders leave clasptr set to tleaf/ltleaf with dangling sizetab (SCOTCH_archExit would free garbage); (4) duplicate permutation indices leave holes in peritab (the loader only checks them under SCOTCH_DEBUG_ARCH2).",
 "fix_options": [
  {
   "label": "Validate in the library builders (mirror loader checks), free on failure",
   "summary": "Hcub: dimnnbr in [1, 62]; Tleaf: levlnbr>=0, size>=2, link>=1 checked before touching archptr; Ltleaf: permnbr>0, 0<=permtab<permnbr, duplicates detected via peritab=~0 sentinel, clasptr reset to NULL and arrays freed on failure.",
   "patch_sketch": "--- library_arch.c\n+++ library_arch.c\n@@ -348,6 +348,12 @@\n     return (1);\n   }\n \n+  if ((dimnnbr < 1) ||                            /* Same checks as in archHcubArchLoad() */\n+      (dimnnbr > (SCOTCH_Num) ((sizeof (Anum) << 3) - 2))) {\n+    errorPrint (STRINGIFY (SCOTCH_archHcub) \": invalid number of dimensions\");\n+    return (1);\n+  }\n+\n   tgtarchptr    = (Arch *) archptr;\n   tgtarchdatptr = (ArchHcub *) (void *) (&tgtarchptr->data);\n \n@@ -502,6 +508,18 @@\n     return (1);\n   }\n \n+  if (levlnbr < 0) {                              /* Same checks as in archTleafArchLoad() */\n+    errorPrint (STRINGIFY (SCOTCH_archTleaf) \": invalid number of levels\");\n+    return (1);\n+  }\n+  for (levlnum = 0; levlnum < (Anum) levlnbr; levlnum ++) {\n+    if ((sizetab[levlnum] < 2) ||\n+        (linktab[levlnum] < 1)) {\n+      errorPrint (STRINGIFY (SCOTCH_archTleaf) \": invalid level size or link cost\");\n+      return (1);\n+    }\n+  }\n+\n   tgtarchptr          = (Arch *) archptr;\n   tgtarchdatptr       = (ArchTleaf *) (void *) (&tgtarchptr->data);\n   tgtarchptr->clasptr = archClass (\"tleaf\");\n@@ -543,23 +561,46 @@\n   Arch *              tgtarchptr;\n   ArchTleaf *         tgtarchdatptr;\n \n+  if (permnbr <= 0) {                             /* Same checks as in archLtleafArchLoad() */\n+    errorPrint (STRINGIFY (SCOTCH_archLtleaf) \": invalid permutation size\");\n+    return (1);\n+  }\n+  for (permnum = 0; permnum < (Anum) permnbr; permnum ++) {\n+    if ((permtab[permnum] < 0) ||\n+        (permtab[permnum] >= permnbr)) {\n+      errorPrint (STRINGIFY (SCOTCH_archLtleaf) \": invalid permutation index\");\n+      return (1);\n+    }\n+  }\n+\n   if (SCOTCH_archTleaf (archptr, levlnbr, sizetab, linktab) != 0) /* Build tree part */\n     return (1);\n   tgtarchptr          = (Arch *) archptr;\n   tgtarchdatptr       = (ArchTleaf *) (void *) (&tgtarchptr->data);\n-  tgtarchptr->clasptr = archClass (\"ltleaf\");     /* Override class */\n \n   if ((tgtarchdatptr->permtab = memAlloc (permnbr * 2 * sizeof (Anum))) == NULL) { /* TRICK: space for peritab too */\n     errorPrint (STRINGIFY (SCOTCH_archLtleaf) \": out of memory\");\n+    memFree    (tgtarchdatptr->sizetab);          /* Undo tree part construction */\n+    tgtarchptr->clasptr = NULL;\n     return (1);\n   }\n+  tgtarchptr->clasptr    = archClass (\"ltleaf\");  /* Override class */\n   tgtarchdatptr->permnbr = (Anum) permnbr;\n   tgtarchdatptr->peritab = tgtarchdatptr->permtab + permnbr;\n \n   for (permnum = 0; permnum < tgtarchdatptr->permnbr; permnum ++)\n+    tgtarchdatptr->peritab[permnum] = ~0;         /* Detect duplicate indices */\n+  for (permnum = 0; permnum < tgtarchdatptr->permnbr; permnum ++) {\n     tgtarchdatptr->permtab[permnum] = permtab[permnum];\n-  for (permnum = 0; permnum < tgtarchdatptr->permnbr; permnum ++) /* Build inverse permutation */\n-    tgtarchdatptr->peritab[tgtarchdatptr->permtab[permnum]] = permnum;\n+    if (tgtarchdatptr->peritab[permtab[permnum]] != ~0) { /* If index already used */\n+      errorPrint (STRINGIFY (SCOTCH_archLtleaf) \": duplicate permutation index\");\n+      memFree    (tgtarchdatptr->permtab);\n+      memFree    (tgtarchdatptr->sizetab);\n+      tgtarchptr->clasptr = NULL;\n+      return (1);\n+    }\n+    tgtarchdatptr->peritab[permtab[permnum]] = permnum; /* Build inverse permutation */\n+  }\n \n   return (0);\n }\n",
   "tradeoffs": "Smallest and local; behaviour change: values the loaders already refuse are now refused by builders too (archHcub(0) now fails). Tested with ASan (64-bit build): archLtleaf{5,0} -> r=1 'invalid permutation index'; duplicate -> r=1; valid Ltleaf/Tleaf/Hcub(3) still build with correct sizes; no leaks reported. Leaves the int-shift UB for Hcub dims 31..62 to be fixed in arch_hcub.c (use (Anum) 1 << ...).",
   "preferred": true
  },
  {
   "label": "Shared ArchXxxArchBuild routines in arch_*.c",
   "summary": "Move validation+allocation into new archTleafArchBuild/archLtleafArchBuild/archHcubArchBuild (precedent: archCmpltwArchBuild, archMeshXArchBuild, archDecoArchBuild called from library_arch.c) and have BOTH the loaders and SCOTCH_arch* call them.",
   "patch_sketch": "int archTleafArchBuild (ArchTleaf * const, const Anum levlnbr, const Anum * const sizetab, const Anum * const linktab); /* does the checks + memAlloc + fills */\n/* library_arch.c: return (archTleafArchBuild ((ArchTleaf *) ..., levlnbr, sizetab, linktab)); */",
   "tradeoffs": "Single source of truth, no future drift between loader and builder, matches repo precedent; but larger diff, touches arch_tleaf.c/h and the loaders (risk of regressions in .tgt loading), and needs new tests.",
   "preferred": false
  },
  {
   "label": "Document-only plus assertions under SCOTCH_DEBUG_ARCH1",
   "summary": "Leave builders trusting callers and add checks only under SCOTCH_DEBUG_ARCH1.",
   "patch_sketch": "#ifdef SCOTCH_DEBUG_ARCH1\n  if (permtab[permnum] < 0 || permtab[permnum] >= permnbr) {...}\n#endif",
   "tradeoffs": "No release-mode protection (the heap write stays reachable from Fortran/Python callers); not recommended.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: library_arch.c routines are thin wrappers over archXxxArchBuild in arch_*.c (see SCOTCH_archCmpltw, SCOTCH_archMesh*, SCOTCH_archDeco); option 2 is the architecture-conformant one, option 1 is the quick patch. I tested option 1 only.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-2

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-2",
 "our_title": "SCOTCH_archLtleaf is exported but has no declaration in the public header",
 "severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/library.h:204 (only archTleaf declared); library_arch.c:551",
 "evidence": "Compiling a caller of SCOTCH_archLtleaf against 7.0.17 scotch.h gives 'implicit declaration of function SCOTCH_archLtleaf'; nm shows the symbol exported.",
 "related_review_ids": [
  "API-10",
  "API-24"
 ],
 "fix_options": [
  {
   "label": "Declare it in library.h",
   "summary": "Add the prototype next to SCOTCH_archTleaf.",
   "patch_sketch": "int SCOTCH_archLtleaf (SCOTCH_Arch * const, const SCOTCH_Num, const SCOTCH_Num * const, const SCOTCH_Num * const, const SCOTCH_Num, const SCOTCH_Num * const);",
   "tradeoffs": "ABI-neutral; header also feeds scotchf.h/ptscotch.h generation.",
   "preferred": true
  },
  {
   "label": "Make it static/internal",
   "summary": "Remove from the exported set if it is not meant to be public.",
   "patch_sketch": "/* drop SCOTCH_ prefix */",
   "tradeoffs": "Breaks any user already calling it with their own prototype.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-4

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-4",
 "our_title": "Tleaf/Ltleaf builders leave class pointer set with dangling arrays after a failed allocation",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/library_arch.c:496-540, 551-575",
 "evidence": "SCOTCH_archTleaf sets tgtarchptr->clasptr = archClass(\"tleaf\") before memAlloc of sizetab and returns 1 on failure without resetting it; SCOTCH_archLtleaf overrides clasptr to ltleaf before allocating permtab, and on failure leaves sizetab allocated. A later SCOTCH_archExit then calls archTleafArchFree on indeterminate pointers.",
 "related_review_ids": [
  "API-10"
 ],
 "fix_options": [
  {
   "label": "Set class after success, free on failure",
   "summary": "Assign clasptr only when all allocations succeeded; free sizetab when permtab fails (done in my API-10 patch).",
   "patch_sketch": "see API-10 patch",
   "tradeoffs": "Small.",
   "preferred": true
  },
  {
   "label": "Zero the arch on failure",
   "summary": "memSet the data area and clasptr to NULL before returning 1.",
   "patch_sketch": "memSet (tgtarchdatptr, 0, sizeof (*tgtarchdatptr)); tgtarchptr->clasptr = NULL;",
   "tradeoffs": "Leaks if sizetab was already allocated unless freed first.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## CLI-24

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "CLI-24",
 "area": "CLI",
 "our_title": "Hypercube, FFT and similar generators shift an int by the dimension, undefined from 31 up",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/scotch/amk_hy.c:149-150; gmk_hy.c:146-147; gmk_ub2.c:164-165; amk_fft2.c:154-155; amk_ccc.c:157-159,170",
 "evidence": "`timeout 5 amk_hy 31 /dev/null` -> `amk_hy.c:149:13: runtime error: left shift of 1 by 31 places cannot be represented in type 'int'`; dims 32/40: `shift exponent 40 is too large for 32-bit type 'int'`. Same for gmk_hy (:146), gmk_ub2 (:164), amk_fft2 (:154-157), amk_ccc (:157-159) at dims 31/32/40, plus `signed integer overflow: 31 * -2147483648` in gmk_hy:151 and `-2147483648 * 4` in gmk_ub2:169. (A dimension >= 31 means >= 2^31 vertices and terabytes of output; practical exposure is nil, it is a UB hygiene issue.)",
 "upstream_change": "",
 "review_accuracy": "Accurate. Not merely a 32-bit SCOTCH_Num problem: the shifts are on plain int, so it applies to 64-bit builds too.",
 "fix_options": [
  {
   "label": "Bound the dimension at parse time",
   "summary": "Reject dimensions that do not fit (e.g. > 30, or > bit width of SCOTCH_Num - 2) right after atoi, with an errorPrint, and shift `(SCOTCH_Num) 1`.",
   "patch_sketch": "-  if ((hdim = atoi (argv[i])) < 1)\n+  if (((hdim = atoi (argv[i])) < 1) || (hdim > (SCOTCH_Num) ((sizeof (SCOTCH_Num) << 3) - 3)))\n     errorPrint (\"main: invalid dimension '%s'\", argv[i]);\n ...\n-  hnbr = 1 << hdim;\n+  hnbr = ((SCOTCH_Num) 1) << hdim;",
   "tradeoffs": "Removes the UB for all inputs and keeps the shifts cheap; the maximum dimension then depends on SCOTCH_Num (30 for 32-bit, 61 for 64-bit), which is still far beyond anything that can be generated.",
   "preferred": true
  },
  {
   "label": "Only widen the shifts",
   "summary": "Replace `1 <<` by `((SCOTCH_Num) 1) <<` without bounding.",
   "patch_sketch": "-  hnbr = 1 << hdim;\n+  hnbr = ((SCOTCH_Num) 1) << hdim;",
   "tradeoffs": "Fixes dims 31 on 64-bit builds only; shifts >= 64 and 32-bit SCOTCH_Num remain UB and the arithmetic (4*ubnbr-6, ccdim*(1<<ccdim)) still overflows - incomplete.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/CLI/diffs/ if any; harness sources alongside)
