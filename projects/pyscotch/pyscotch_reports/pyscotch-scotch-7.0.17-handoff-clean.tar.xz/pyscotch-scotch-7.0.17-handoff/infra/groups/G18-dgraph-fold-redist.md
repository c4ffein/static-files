# G18-dgraph-fold-redist

Items: DGR-01, DGR-02, DGR-22, PS-DGR-4, DGR-04, DGR-14, DGR-10, API-04



===================================================================
## DGR-01

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-01",
 "area": "DGR",
 "our_title": "Fold receiver aborts after senders posted edge data; requests undrained, peers hang",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_fold.c:463-465 (alloc), 762-799 (fail3/fail4)",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nSource (7.0.17, dgraph_fold.c:463-465): `if ((fldgrafptr->edgeloctax = memAlloc (...)) == NULL) { errorPrint (\"dgraphFold2: out of memory (6)\"); goto fail3; }` executed after the receiver posted the TAGVLBLLOCTAB/TAGVERTLOCTAB Irecvs (l.438-448) and after the senders posted ALL their Isends (l.340-398, incl. edge data) unconditionally. fail3 (l.762) -> `goto fail4` (l.774) skips `MPI_Waitall (requnbr, requtab, ...)` and `memFree (fldvertidxtab)` (l.788-798); fail4 then only does dgraphExit(fldgrafptr), which frees vertloctax that still is the target of a pending MPI_Irecv. fldcommdattab, fldvertidxtab(+requtab) and the compacted orgvertloctax are leaked on every fail3 path (never freed after fail1).\nRun: `LIBDIR=../fi/lib ./scan2.sh fold 4 0 0 4 0 6 0` (np=4, path graph, base 0, partval 0, failure injected on receiver rank 0): nth=5 -> `(0): ERROR: dgraphFold2: out of memory (6)`, `r0 mode=fold rc=1`, the other receiver r1 never returns -> HANG (timeout). Same HANG for nth=0..4 (failures at 'out of memory (1)', 'FoldComm (1)(2)', '(3)', '(5)') because in a non-SCOTCH_DEBUG_DGRAPH1 build the first agreement is `chekglbval = cheklocval` (local only, l.296-298). The use-after-free of the pending Irecv target and the leaks are source-read only (MPI writes into freed memory are invisible to ASan).",
 "upstream_change": "",
 "review_accuracy": "Mechanism accurate. Imprecise on two points: (1) 'receivers sit in MPI_Allreduce' only holds with SCOTCH_DEBUG_DGRAPH1; in release builds both Allreduces are compiled out, so peers hang in dgraphBuild4/Finalize instead. (2) The review's second fix ('have the fail3 path complete every posted request before fail4') is not sufficient: the senders' edge-data Isends were already posted and the failing receiver has no buffer to match them with, so senders still block (large messages) in their final MPI_Waitall; only the request the receiver itself posted can be drained. Line numbers were right at 7.0.16 (463-465, 762-810) and moved by <=1.",
 "fix_options": [
  {
   "label": "Collective allocation-status gate before edge data is posted (tested)",
   "summary": "Senders post only the edge-count and vertex Isends, then every process calls one MPI_Allreduce(MAX) on orggrafptr->proccomm: pure receivers contribute the status of the l.463 edge-array allocation (done after the counts are known), senders/sender-receivers contribute 0. If the result is non-zero, receivers MPI_Waitall their posted vertex Irecvs, senders MPI_Waitall their count+vertex Isends, everyone frees fldcommdattab/fldvertidxtab/compacted vertex array and jumps to fail4 (return 1 on all processes). Also makes the first (fail1) agreement unconditional so release builds do not start communicating when one peer failed its private allocations.",
   "patch_sketch": "--- a/src/libscotch/dgraph_fold.c\n+++ b/src/libscotch/dgraph_fold.c\n@@ -140,6 +140,8 @@\n   Gnum * restrict               fldvertdlttab;    /* Array of index adjustments for original global indices           */\n   int                           cheklocval;\n   int                           chekglbval;\n+  int                           gatelocval;       /* Allocation status gate before edge data is exchanged */\n+  int                           gateglbval;\n   int                           commmax;\n   int                           commnbr;\n   int                           requnbr;\n@@ -287,14 +290,10 @@\n \n   cheklocval = 0;                                 /* Everything went well */\n fail1:\n-#ifdef SCOTCH_DEBUG_DGRAPH1                       /* Communication cannot be merged with a useful one */\n-  if (MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, orggrafptr->proccomm) != MPI_SUCCESS) {\n+  if (MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, orggrafptr->proccomm) != MPI_SUCCESS) { /* Needed in release mode too: peers must not start communicating alone */\n     errorPrint (\"dgraphFold2: communication error (1)\");\n     chekglbval = 1;\n   }\n-#else /* SCOTCH_DEBUG_DGRAPH1 */\n-  chekglbval = cheklocval;\n-#endif /* SCOTCH_DEBUG_DGRAPH1 */\n   if (chekglbval != 0) {\n     if ((fldcommtypval & DGRAPHFOLDCOMMRECV) != 0) {\n       if (fldvertidxtab != NULL)\n@@ -346,6 +345,21 @@\n         goto fail2;\n       }\n     }\n+    gatelocval = 0;                               /* Senders have nothing left that can fail before edge data is sent */\n+    if (MPI_Allreduce (&gatelocval, &gateglbval, 1, MPI_INT, MPI_MAX, orggrafptr->proccomm) != MPI_SUCCESS) {\n+      errorPrint (\"dgraphFold2: communication error (23)\");\n+      gateglbval = 1;\n+    }\n+    if (gateglbval != 0) {                        /* If some receiver could not allocate its edge arrays: no edge data will be sent */\n+      MPI_Waitall (requnbr, requtab, MPI_STATUSES_IGNORE); /* Complete edge count and vertex sends, which receivers have matched          */\n+      memFree (fldcommdattab);\n+      memFree (fldvertidxtab);                    /* Free group leader including request array */\n+      if (orgvertloctax != orggrafptr->vertloctax)\n+        memFree (orgvertloctax + orggrafptr->baseval);\n+      cheklocval = 1;\n+      goto fail4;\n+    }\n+\n     for (commnum = 0; commnum < commnbr; commnum ++) { /* Send edge data */\n       if (MPI_Isend (orgedgeloctax + fldedgeidxtab[commnum],\n                      fldedgecnttab[commnum], GNUM_MPI, fldcommdattab[commnum].procnum,\n@@ -460,11 +474,26 @@\n       fldgrafptr->edgelocsiz = fldedgelocsiz;\n \n       fldedlolocsiz = ((orgedloloctax != NULL) ? fldedgelocsiz : 0);\n+      gatelocval = 0;\n       if ((fldgrafptr->edgeloctax = memAlloc ((fldedgelocsiz + fldedlolocsiz) * sizeof (Gnum))) == NULL) { /* Allocate single array for both edge arrays */\n         errorPrint (\"dgraphFold2: out of memory (6)\");\n-        goto fail3;\n+        gatelocval = 1;\n+      }\n+      else\n+        fldgrafptr->edgeloctax -= orggrafptr->baseval; /* Do not care about the validity of edloloctax at this stage */\n+      if (MPI_Allreduce (&gatelocval, &gateglbval, 1, MPI_INT, MPI_MAX, orggrafptr->proccomm) != MPI_SUCCESS) { /* Senders are waiting for this status before posting edge data */\n+        errorPrint (\"dgraphFold2: communication error (24)\");\n+        gateglbval = 1;\n+      }\n+      if (gateglbval != 0) {                      /* If some process could not allocate its edge arrays: no edge data will be sent */\n+        MPI_Waitall (commnbr, &requtab[DGRAPHFOLDTAGVERT * commmax], MPI_STATUSES_IGNORE); /* Complete vertex receives before their target array is freed */\n+        memFree (fldcommdattab);\n+        memFree (fldvertidxtab);                  /* Free group leader including request array */\n+        if (orgvertloctax != orggrafptr->vertloctax)\n+          memFree (orgvertloctax + orggrafptr->baseval);\n+        cheklocval = 1;\n+        goto fail4;\n       }\n-      fldgrafptr->edgeloctax -= orggrafptr->baseval; /* Do not care about the validity of edloloctax at this stage */\n \n       for (commnum = 0; commnum < commnbr; commnum ++) { /* Receive edge adjacency data */\n         if (MPI_Irecv (fldgrafptr->edgeloctax + fldedgeidxtab[commnum],\n",
   "tradeoffs": "Behaviour: fold now returns 1 on every rank on OOM instead of hanging. Cost: one extra small MPI_Allreduce on the original communicator per fold (plus one more if the fail1 agreement is made unconditional - fail1 is currently debug-only 'cannot be merged with a useful one'). Risk: moderate (control flow of a 700-line function); needs the fault-injection reproducer above, which now gives rc=1 on all 4 ranks for nth=0..5 and rc=0 for nth>=6 (verified, also for baseval 1, failing sender rank 2, and dgpart -np 4 on bump.grf still exits 0 with ASan).",
   "preferred": true
  },
  {
   "label": "Per-pair TAGOK/TAGBAD handshake (dgraphLoadCent idiom)",
   "summary": "After allocating its edge array, each receiver sends a zero-byte TAGOK/TAGBAD message to each of its senders; senders post the edge-data Isends only after receiving TAGOK from that receiver and otherwise abort. Receivers answer TAGBAD, drain their own posted requests and fail.",
   "patch_sketch": "/* receiver, after the l.463 allocation */\nfor (commnum = 0; commnum < commnbr; commnum ++)\n  MPI_Send (NULL, 0, MPI_INT, fldcommdattab[commnum].procnum, (cheklocval != 0) ? TAGBAD : TAGOK, orggrafptr->proccomm);\n/* sender, before 'Send edge data' */\nfor (commnum = 0; commnum < commnbr; commnum ++) {\n  MPI_Recv (NULL, 0, MPI_INT, fldcommdattab[commnum].procnum, MPI_ANY_TAG, orggrafptr->proccomm, &stat);\n  if (stat.MPI_TAG != TAGOK) { /* wait for count/vertex Isends, free, cheklocval = 1 */ }\n}\n/* still needs a final global agreement so that all processes return the same value */",
   "tradeoffs": "No new collective, mirrors dgraphLoadCent (dgraph_io_load.c:446,~590 TAGOK/TAGBAD). But failure is only pairwise: processes not talking to the failing receiver would still return 0 and the folded graph would be incomplete, so a global agreement is needed anyway (back to option 1). More messages (one per sender/receiver pair). Not compiled or tested.",
   "preferred": false
  },
  {
   "label": "Receiver-only cleanup (drain own requests, free leaks) - partial",
   "summary": "On the fail3 path, MPI_Waitall the receiver's posted count/vertex requests before dgraphExit and free fldcommdattab/fldvertidxtab/orgvertloctax compaction.",
   "patch_sketch": "fail3:\n  ...\n  if (chekglbval != 0) {\n    MPI_Waitall (commnbr, &requtab[DGRAPHFOLDTAGVERT * commmax], MPI_STATUSES_IGNORE);\n    memFree (fldcommdattab); memFree (fldvertidxtab);\n    if (orgvertloctax != orggrafptr->vertloctax) memFree (orgvertloctax + orggrafptr->baseval);\n    goto fail4;\n  }",
   "tradeoffs": "Fixes the use-after-free of the vertex Irecv target and the leaks, but NOT the hang (senders' edge Isends stay unmatched; peers still need an agreed error). Smallest diff; only acceptable together with option 1 or 2.",
   "preferred": false
  }
 ],
 "notes": "Depends on DGR-02 (baseval) for dgraphExit(fldgrafptr) to be valid on this path. The same non-collective release-mode agreement affects every failure point of dgraphFold2 (nth=0..4 above), which the gate patch also covers by making the fail1 reduction unconditional. Review's 'dgraphGhst/dgraphFold handle this correctly' is only true of the debug configuration of dgraphFold.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-02",
 "area": "DGR",
 "our_title": "Folded graph header keeps baseval 0 while arrays are offset; early-failure free misaddressed",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_fold.c:194 (memSet), 751 (baseval set), dgraph.c:104-125 (dgraphFree2)",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\nSource: l.194 `memSet (fldgrafptr, 0, sizeof (Dgraph));` leaves baseval==0 while vertloctax/vnumloctax/edgeloctax are later offset by orggrafptr->baseval (l.237-239,251,466); real baseval is stored only at l.751. flagval = DGRAPHFREEALL|... so dgraphExit(fldgrafptr) executes `memFree (grafptr->vertloctax + grafptr->baseval)` (dgraph.c:108) with baseval 0 on the offset pointer.\nRun: `LIBDIR=../fi/lib ./scan2.sh fold 4 0 1 4 0 7 0` (np=4, baseval 1, failure on receiver rank 0): nth=4 and nth=5 -> `(0): ERROR: dgraphFold2: out of memory (5)/(6)` then `ERROR: AddressSanitizer: attempting free on address which was not malloc()-ed: 0x50700000c2cc in thread T0` (same run with baseval 0 does not crash, only hangs: see DGR-01).",
 "upstream_change": "",
 "review_accuracy": "Accurate (mechanism, location, baseval=1 condition). Review says 'on every receiver': true for every receiver whose failure happens after the vertex group was allocated (l.239) - an earlier failure (l.209/215) is harmless because vertloctax is still NULL. The ordering of the Dgraph header init vs arrays is the root cause.",
 "fix_options": [
  {
   "label": "Set fldgrafptr->baseval right after the memSet (tested)",
   "summary": "One-line fix as suggested by the review; makes dgraphExit() on any early failure use the right offset.",
   "patch_sketch": "--- a/src/libscotch/dgraph_fold.c\n+++ b/src/libscotch/dgraph_fold.c\n@@ -192,6 +194,7 @@\n #endif /* SCOTCH_DEBUG_DGRAPH2 */\n \n     memSet (fldgrafptr, 0, sizeof (Dgraph));      /* Pre-initialize graph fields */\n+    fldgrafptr->baseval = orggrafptr->baseval;    /* Arrays are based; baseval is needed by dgraphExit() on error */\n \n     fldgrafptr->proccomm   = fldproccomm;\n     fldgrafptr->procglbnbr = fldprocglbnbr;\n",
   "tradeoffs": "No behaviour change on success paths (the same value is stored again at l.751). Verified: baseval=1 runs for nth=4,5 no longer trigger the invalid free. Trivial risk.",
   "preferred": true
  },
  {
   "label": "Free arrays explicitly in the fail path instead of dgraphExit()",
   "summary": "In fail4 free fldgrafptr->vertloctax/edgeloctax with orggrafptr->baseval and clear the structure, never calling dgraphExit on a half-built graph.",
   "patch_sketch": "if ((fldcommtypval & DGRAPHFOLDCOMMRECV) != 0) {\n  if (fldgrafptr->vertloctax != NULL) memFree (fldgrafptr->vertloctax + orggrafptr->baseval);\n  if (fldgrafptr->edgeloctax != NULL) memFree (fldgrafptr->edgeloctax + orggrafptr->baseval);\n  if (fldgrafptr->procdsptab != NULL) memFree (fldgrafptr->procdsptab);\n  if (*flddataptr ...) ...\n}",
   "tradeoffs": "Duplicates knowledge of the group layout (DGRAPHVERTGROUP/EDGEGROUP, flddata, DGRAPHFREECOMM) that dgraphExit already encodes; easy to get out of sync. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: structures are initialised completely before any array is attached (dgraphInit memSet + baseval). The same ordering is already used by dgraphInduce2 (`indgrafptr->baseval = baseval;` before the memAllocGroup calls, dgraph_induce.c:~108) and dgraphBand (`bandgrafptr->baseval = grafptr->baseval;` before its allocations).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-22

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-22",
 "area": "DGR",
 "our_title": "Gnum lengths passed as int MPI counts and int totals; Waitall unchecked",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "source-read",
 "needs": "64bit-build",
 "needs_note": "Needs a 64-bit-Gnum build moving over 2^31 items in one fold/redistribution message (about 16 GB per rank).",
 "location": "src/libscotch/dgraph_fold.c:343,351,360,370,383,445,471,481,493,508 (counts), 452 (unchecked Waitall); dgraph_redist.c:217-219,239-240,295,307-338 (int totals)",
 "evidence": "Not runnable here (needs messages > 2^31 Gnum items = 16 GB per message with INTSIZE64). Source (7.0.17): dgraph_fold.c:343 `fldcommdattab[commnum].vertnbr, GNUM_MPI, ...` and :351 `fldedgecnttab[commnum], GNUM_MPI, ...` pass Gnum (64-bit with INTSIZE64) values straight to MPI_Isend's `int count`; l.383 `vertsndnbr = (int) fldcommdattab[commnum].vertnbr;`; the receiver sizes its arrays from the Gnum values (l.468-474: `fldedgelocsiz = fldedgelocbas - orggrafptr->baseval` and Irecv with fldedgecnttab[commnum]) so a truncated count yields MPI_ERR_TRUNCATE or silently short transfers; l.452 `MPI_Waitall (commnbr, &requtab[DGRAPHFOLDTAGESIZ * commmax], MPI_STATUSES_IGNORE);` has no return check (the later Waitalls at l.744/788 are checked). dgraph_redist.c: `int drcvdatnbr, dsnddatnbr, drcvdatidx` (l.217-219), `int dstvertloctmp, dstedgeloctmp` (l.239-240), `dsndcnttab[2*procngbnum+1] += (int) (srcvendloctax[...] - srcvertloctax[...])` (l.295), `dsndcntval = dsndcnttab[...] * flveval + dsndcnttab[...] * fledval` in int (l.307-313), MPI_Alltoall(v) of int counts.",
 "upstream_change": "",
 "review_accuracy": "Accurate. Realistic only for 64-bit builds with > ~2 billion items moved from one process to another in a single fold/redistribution (~16 GB of Gnum per message); the redist int totals overflow even earlier (data = flveval*vertices + fledval*edges per destination).",
 "fix_options": [
  {
   "label": "Reject over-large counts collectively up front",
   "summary": "Fold the maximum message length (vertnbr, edgecnt, redist totals) into an existing reduction (dgraphFold2's first agreement, dgraphRedist2's Alltoall of counts) and fail on all processes with a clear error if any exceeds INT_MAX; check MPI_Waitall's return at l.452.",
   "patch_sketch": "if ((fldcommdattab[commnum].vertnbr > (Gnum) INT_MAX) || (fldedgecnttab[commnum] > (Gnum) INT_MAX)) cheklocval = 1;   /* before the first agreement */\nif (MPI_Waitall (commnbr, &requtab[DGRAPHFOLDTAGESIZ * commmax], MPI_STATUSES_IGNORE) != MPI_SUCCESS) { errorPrint (\"dgraphFold2: communication error (25)\"); goto fail3; }",
   "tradeoffs": "Behaviour: huge folds now fail cleanly instead of corrupting; edge counts are only known after the count exchange so that check sits at the gate of DGR-01's fix. Not compiled.",
   "preferred": true
  },
  {
   "label": "Split messages into INT_MAX-sized chunks or use a derived datatype",
   "summary": "Send as ceil(n / INT_MAX) messages, or wrap a block of 2^20 Gnum in MPI_Type_contiguous (the library already builds such types: dgraph_allreduce.c:72, dgraph_coarsen.c:1462) and send n / 2^20 + remainder.",
   "patch_sketch": "MPI_Type_contiguous (1 << 20, GNUM_MPI, &blktype); MPI_Isend (buf, n >> 20, blktype, ...); MPI_Isend (buf + ((n >> 20) << 20), n & ((1 << 20) - 1), GNUM_MPI, ...);",
   "tradeoffs": "Truly supports > INT_MAX; touches every send/recv pair and the redist int arithmetic (displacements are ints in Alltoallv anyway, so redist would need point-to-point). Large change.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: the library uses plain `int` MPI counts everywhere (e.g. commAllgatherv with int arrays); a global 'counts fit in int' policy check is the lowest-risk compatible approach. MPI-4 large-count (_c) routines are not used anywhere in 7.0.17.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## PS-DGR-4

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-DGR-4",
 "our_title": "Release builds skip collective error agreement in fold and gather; ranks hang or disagree",
 "severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/dgraph_fold.c:290-298; dgraph_gather_all.c:200-207",
 "evidence": "Under #else of SCOTCH_DEBUG_DGRAPH1 both set chekglbval = cheklocval (local only). Fault shim: fold np=4 nth=0..4 all HANG after the failing rank returns 1; gather np=2 with failing root gives rank0 rc=1, rank1 rc=0. Making the fold reduction unconditional (my patch) removes the hangs.",
 "related_review_ids": [
  "DGR-01",
  "DGR-10",
  "DGR-13"
 ],
 "fix_options": [
  {
   "label": "Make the reduction unconditional",
   "summary": "Remove the #ifdef around the MPI_Allreduce.",
   "patch_sketch": "MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, comm);",
   "tradeoffs": "One small allreduce per call; tested for fold only.",
   "preferred": true
  },
  {
   "label": "Piggy-back on an existing collective",
   "summary": "Carry the flag in a later reduction the routine already does.",
   "patch_sketch": "/* encode error as negative count in the next Allgather */",
   "tradeoffs": "No extra collective but later code must handle it on all ranks. Not compiled.",
   "preferred": false
  }
 ],
 "area": "DGR"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-04",
 "area": "DGR",
 "our_title": "Caller-permuted redistribution unpacks edges in destination order over shared in-place buffer",
 "claimed_severity": "high",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_redist.c:352-360 (group alloc), 425-469 (unpack), library_dgraph_redist.c:100-107",
 "evidence": "Reproducer redist.c (mine): np=2, cycle of N vertices, all vertices held by rank 0, every vertex sent to rank 1 (part=1), user permgsttab = reversed order inside the destination (with halo values filled in), SCOTCH_dgraphRedist(&g, part, perm, 0, 0, &r), then SCOTCH_dgraphCheck(&r) and an adjacency check against the expected cycle. Command: `LD_LIBRARY_PATH=../fi/lib ASAN_OPTIONS=detect_leaks=0 mpirun --oversubscribe -np 2 ./redist 4 1 0 1`.\nN=4 (the review's reversed 4-cycle): `ERROR: AddressSanitizer: memcpy-param-overlap: memory ranges [0x508000017238,0x508000017240) and [0x508000017234, 0x50800001723c) overlap  #1 dgraphRedist2 dgraph_redist.c:469 #2 dgraphRedist dgraph_redist.c:189 #3 SCOTCH_dgraphRedist library_dgraph_redist.c:104`.\nN=8 (no overlap reported by ASan but silently wrong): `./redist 8 1 0 1` -> `dgraphCheck: arc data do not match`, r1 `dst check=1`, 2 vertices with wrong adjacency. Controls: identical runs with the identity permutation (`./redist 8 0 0 1`) or with the internal MPI_Scan permutation give check=0, bad=0. Cause (source): the destination edge array, send buffer and receive buffer are one memAllocGroup block (l.352-360), the destination area being only `dstedlolocsiz + MAX (dstedgelocdlt, degrglbmax)` words long; the unpack loop (l.449-470) writes edges in DESTINATION vertex order (`dstvertlocnum` ascending) while reading them from the receive buffer at the position recorded in RECEIVE order (dstvlblloctax[v] = drcvdatidx, l.436), so for a non-monotone permutation a write can overrun not-yet-read records ('TRICK: will never overlap' is only true for the receive-order permutation).",
 "upstream_change": "",
 "review_accuracy": "Accurate, including the example (reversed 4-cycle to an empty rank) and the release-build silent corruption (N=8 fails SCOTCH_dgraphCheck). Imprecise: the suggested fix 'compute destination offsets by prefix sum and unpack in receive order' still writes into the shared block and would still overlap; a separate edge array (or a monotonicity check + fallback) is required. The related abs() issue of DGR-14 is fixed in 7.0.17 but the assertion it guards is debug-only and would not have prevented this.",
 "fix_options": [
  {
   "label": "Separate full-size edge array when the permutation is user-provided (tested)",
   "summary": "Pass a flag from dgraphRedist (srcpermgsttax != NULL) to dgraphRedist2; when set, size the first member of the memAllocGroup as `dstedgelocsiz + dstedlolocsiz` words instead of `dstedlolocsiz + MAX (dstedgelocdlt, degrglbmax)`, so the destination never overlaps the send/receive buffers; the final memRealloc already shrinks the block to `dstedgelocsiz * fledval`.",
   "patch_sketch": "--- a/src/libscotch/dgraph_redist.c\n+++ b/src/libscotch/dgraph_redist.c\n@@ -186,7 +186,7 @@\n   else\n     permgsttmp = srcpermgsttax;\n \n-  o = dgraphRedist2 (srcgrafptr, srcpartloctax, permgsttmp, procdsptab, procvrttab, 0, dstedgelocdlt, dstgrafptr);\n+  o = dgraphRedist2 (srcgrafptr, srcpartloctax, permgsttmp, procdsptab, procvrttab, 0, dstedgelocdlt, (srcpermgsttax != NULL) ? 1 : 0, dstgrafptr);\n \n   memFree (procvrttab);                           /* Free group leader */\n \n@@ -203,6 +203,7 @@\n const Gnum * const          dstprocvrttab,        /* New distribution of graph vertices */\n const Gnum                  dstvertlocdlt,        /* Extra size of local vertex array   */\n const Gnum                  dstedgelocdlt,        /* Extra size of local edge array     */\n+const int                   permusrflg,           /* Non-zero if permutation provided by user (not in receive order) */\n Dgraph * restrict const     dstgrafptr)           /* Destination distributed graph      */\n {\n   Gnum                      baseval;\n@@ -351,8 +352,10 @@\n            dstveloloctax  = ((srcgrafptr->veloloctax != NULL) ? dstveloloctax - baseval : NULL),\n            dstvlblloctax -= baseval,\n            memAllocGroup ((void **) (void *)\n-                          &dstedgeloctax, (size_t) ((dstedlolocsiz +  /* TRICK: extra space required only if edge loads                                */\n-                                                     MAX (dstedgelocdlt, srcgrafptr->degrglbmax)) * sizeof (Gnum)), /* TRICK: degrmax to avoid overlap */\n+                          &dstedgeloctax, (size_t) (((permusrflg != 0)  /* User permutation: unpacking order differs from receive order, so no in-place TRICK */\n+                                                     ? (dstedgelocsiz + dstedlolocsiz)\n+                                                     : (dstedlolocsiz +  /* TRICK: extra space required only if edge loads                                */\n+                                                        MAX (dstedgelocdlt, srcgrafptr->degrglbmax))) * sizeof (Gnum)), /* TRICK: degrmax to avoid overlap */\n                           &dsnddattab,    (size_t) (dsnddatnbr * sizeof (Gnum)), /* TRICK: send space will be edgeloctab or edloloctab                 */\n                           &drcvdattab,    (size_t) (drcvdatnbr * sizeof (Gnum)), NULL) == NULL) { /* TRICK: Remaining space will be freed              */\n     errorPrint (\"dgraphRedist2: out of memory (3)\");\n--- a/src/libscotch/dgraph_redist.h\n+++ b/src/libscotch/dgraph_redist.h\n@@ -51,7 +51,7 @@\n */\n \n #ifdef SCOTCH_DGRAPH_REDIST\n-static int                  dgraphRedist2       (Dgraph * restrict const, const Gnum * restrict const, const Gnum * restrict const, const Gnum * const, const Gnum * const, const Gnum, const Gnum, Dgraph * restrict const);\n+static int                  dgraphRedist2       (Dgraph * restrict const, const Gnum * restrict const, const Gnum * restrict const, const Gnum * const, const Gnum * const, const Gnum, const Gnum, const int, Dgraph * restrict const);\n #endif /* SCOTCH_DGRAPH_REDIST */\n \n int                         dgraphRedist        (Dgraph * restrict const, const Gnum * restrict const, const Gnum * restrict const, const Gnum, const Gnum, Dgraph * restrict const);\n",
   "tradeoffs": "Static function only (prototype in dgraph_redist.h). User-permutation path uses about dstedgelocnbr*fledval more words at peak; internal path unchanged. Verified: all six cases (N=4,8,20, base 0/1, reversed and identity) give check=0 and bad-adjacency=0.",
   "preferred": true
  },
  {
   "label": "Always use a separate edge array (drop the in-place TRICK)",
   "summary": "Allocate dstedgeloctax independently of dsnddattab/drcvdattab in all cases and free the buffers after unpacking.",
   "patch_sketch": "-   &dstedgeloctax, (size_t) ((dstedlolocsiz + MAX (dstedgelocdlt, srcgrafptr->degrglbmax)) * sizeof (Gnum)),\n+   &dstedgeloctax, (size_t) ((dstedgelocsiz + dstedlolocsiz) * sizeof (Gnum)),",
   "tradeoffs": "Simplest code, removes a fragile invariant (and the debug-only overlap asserts become unnecessary); costs extra peak memory for the default path too (this is exactly what the TRICK was written to avoid).",
   "preferred": false
  },
  {
   "label": "Detect non-monotone permutation after the first unpack loop and fall back to a temporary array",
   "summary": "After the loop at l.449-457 check that the dstvertlocnum values appeared in increasing order; only then keep the in-place copy, else memAlloc a temporary edge array.",
   "patch_sketch": "/* in first loop */ if (dstvertlocnum < dstvertlocprv) monoflag = 0; dstvertlocprv = dstvertlocnum;\n/* before second loop */ if (monoflag == 0) { allocate dstedgetmp (dstedgelocsiz*fledval) ; dstedgeloctax = dstedgetmp - baseval; ... }",
   "tradeoffs": "Keeps optimal memory in the common case but adds a second code path and a failure point after the collective exchange (needs collective error handling). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: dgraphRedist already branches on `srcpermgsttax != NULL` ('Do not allocate permutation array if already provided', l.107-116), so a user-permutation flag is natural; the memory TRICK is documented only for the internal order. A test for SCOTCH_dgraphRedist with a user permgsttab (none exists in src/check/test_scotch_dgraph_redist.c, which only passes NULL) would have caught it - candidate for upstream/QUESTIONS_FOR_SCOTCH_TEAM.md.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-14",
 "area": "DGR",
 "our_title": "Debug overlap assertion used int-sized abs on pointer difference; now type-generic ABS",
 "claimed_severity": "low",
 "status": "fixed",
 "method": "source-read",
 "needs": "none-found",
 "needs_note": "Source diff shows the type-generic macro; nothing to run.",
 "location": "src/libscotch/dgraph_redist.c:455,464",
 "evidence": "7.0.17 dgraph_redist.c:455 `if (ABS ((dstedloloctax + dstedgelocnum) - (drcvdattab + drcvdatidx)) < dstdegrval)` and :464 `if (ABS ((dstedgeloctax + dstedgelocnum) - (drcvdattab + drcvdatidx)) < dstdegrval)`; common.h:197 `#define ABS(x) MAX ((x), -(x))` is type-generic (ptrdiff_t stays 64-bit). 7.0.16 used `abs (...)`. `git diff v7.0.16 v7.0.17 -- src/libscotch/dgraph_redist.c` shows exactly these two replacements.",
 "upstream_change": "f545452 'Bugfix: use size-agnostic macro instead of bounded-size library ABS routine [report R. Perry]'",
 "review_accuracy": "Accurate for 7.0.16 (abs() on ptrdiff_t, -Wabsolute-value). Caveat for context: the guarded assertion is SCOTCH_DEBUG_DGRAPH2-only, and as DGR-04 shows its premise (memory areas never overlap) is false for user permutations, so the check could never have protected the release path.",
 "fix_options": [],
 "notes": "No fix options needed. The asserted condition `ABS (dst - rcv) < dstdegrval` still only compares start addresses, i.e. it would not detect the overlap of DGR-04 in general.",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## DGR-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "DGR-10",
 "area": "DGR",
 "our_title": "Gather cleanup dereferences absent graph on non-roots, frees uninitialised counter array",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/dgraph_gather_all.c:154-217 (error block l.208-217; recvcnttab used uninitialised l.210)",
 "evidence": "Harness (mine, in work/DGR/t): ASan+UBSan copy of pristine 7.0.17 (work/DGR/fi) built with -include fi.h, a malloc/realloc shim where fi_cnt=N makes the N-th allocation after arming fail on a chosen rank; driver scan2.sh MODE NP FAILRANK BASE NL NTH_FROM NTH_TO (12 s timeout per run, 'HANG' = timeout).\n(a) NULL deref: SCOTCH_dgraphGather(&dg, rank==0 ? &cg : NULL), np=2, failure of the small `recvcnttab` group allocation on NON-root rank 1: `LD_LIBRARY_PATH=../fi/lib ./scan.sh gather 2 1 0 4 4`: nth=0 `ERROR: AddressSanitizer: SEGV on unknown address ... dgraph_gather_all.c:212:16: runtime error: member access within null pointer of type 'struct Graph'` (`cgrfptr->verttax` with cgrfptr==NULL).\n(b) uninitialised recvcnttab: failure of the ROOT's graph group (nth=0, rank 0) skips the recvcnttab allocation (l.188-199 is guarded by `cheklocval == 0`), so `if (recvcnttab != NULL) memFree (recvcnttab);` (l.210) reads an uninitialised local. With the object recompiled with -ftrivial-auto-var-init=pattern and preloaded: `(0): ERROR: dgraphGatherAll2: out of memory (1)` then `ERROR: AddressSanitizer: BUS on unknown address (pc ...) bp 0xfefefefefefefeee ... #3 free ... #4 _SCOTCHdgraphGatherAll2 dgraph_gather_all.c:211 #5 SCOTCH_dgraphGather library_dgraph_gather.c:124`.\nObservation not in the review: in release builds `chekglbval = cheklocval` (l.206) so the error is NOT agreed: with the root failing, rank 1 returned rc=0 while rank 0 returned 1 (nth=0..2 above).",
 "upstream_change": "library_dgraph_gather.c touched in 7.0.17 (unrelated pass-through macro change); dgraph_gather_all.c unchanged.",
 "review_accuracy": "Accurate on both claims. Missing: release builds do not agree on the error either (see evidence), so after the crash fixes the ranks can still disagree on the result.",
 "fix_options": [
  {
   "label": "NULL-init recvcnttab and guard cgrfptr (tested)",
   "summary": "`recvcnttab = NULL;` before the guarded allocation; test `cgrfptr != NULL` before dereferencing cgrfptr->verttax in the error block.",
   "patch_sketch": "--- a/src/libscotch/dgraph_gather_all.c\n+++ b/src/libscotch/dgraph_gather_all.c\n@@ -188,6 +188,7 @@\n     edgelocnbr = dgrfptr->edgelocnbr;\n   }\n \n+  recvcnttab = NULL;                              /* In case of error before group allocation */\n   if (cheklocval == 0) {\n     if (memAllocGroup ((void **) (void *)\n                        &recvcnttab, (size_t) (dgrfptr->procglbnbr * sizeof (Gnum)), /* Allocated for non-roots too but don't care as these are very small */\n@@ -209,7 +210,8 @@\n   if (chekglbval != 0) {\n     if (recvcnttab != NULL)\n       memFree (recvcnttab);\n-    if (cgrfptr->verttax != NULL) {\n+    if ((cgrfptr != NULL) &&                      /* Non-root processes have no centralized graph */\n+        (cgrfptr->verttax != NULL)) {\n       if (cgrfptr->edgetax != NULL)\n         memFree (cgrfptr->edgetax);               /* Arrays are not based yet */\n       memFree (cgrfptr->verttax);\n",
   "tradeoffs": "Pure bug fix. Verified: non-root failure no longer segfaults; root failure with pattern-init shows no bad free. Ranks may still return different codes in release builds.",
   "preferred": true
  },
  {
   "label": "Make the error agreement unconditional",
   "summary": "Drop the #ifdef SCOTCH_DEBUG_DGRAPH1 around the MPI_Allreduce at l.200-207 so every process returns the same value; keeps fix 1 as well.",
   "patch_sketch": "-#ifdef SCOTCH_DEBUG_DGRAPH1 ... #else chekglbval = cheklocval; #endif\n+  MPI_Allreduce (&cheklocval, &chekglbval, 1, MPI_INT, MPI_MAX, dgrfptr->proccomm) ...",
   "tradeoffs": "One extra tiny allreduce per gather (gathers are collective and heavy anyway); fixes the rc disagreement but changes a deliberate 'cannot be merged with a useful one' optimisation. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Maintainers' idiom: initialise group-leader pointers to NULL before conditional allocation (dgraph_band_grow.c:131 'procvgbtab = NULL; /* In case of error */').",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/DGR/diffs/ if any; harness sources alongside)


===================================================================
## API-04

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-04",
 "area": "API",
 "our_title": "Gather wrapper passes normalised NULL for non-root ranks, leaving local Dgraph untouched",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_dgraph_gather.c:78-90, 121-125",
 "evidence": "7.0.17 normalises once into 'Graph * srccgrfptr' (CONTEXTOBJECT(cgrfptr) for roots, NULL otherwise) and passes srccgrfptr to dgraphGatherAll2 in both branches. Ran work/API/dga.c with mpirun -np 2 (rank 0 passes a Graph, rank 1 passes its own Dgraph as 'not root'): both ranks r=0, dgraphCheck=0, gathered vertnbr=16 edgenbr=30, no sanitizer report.",
 "upstream_change": "04c85e9 Bugfix: make sure roots are properly identified when called from Fortran [report R. Perry]",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)
