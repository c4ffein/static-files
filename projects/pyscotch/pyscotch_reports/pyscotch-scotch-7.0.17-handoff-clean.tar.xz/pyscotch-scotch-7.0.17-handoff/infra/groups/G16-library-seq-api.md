# G16-library-seq-api

Items: API-03, API-14, API-16, PS-API-1, API-19, API-21, API-18, PS-API-7



===================================================================
## API-03

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-03",
 "area": "API",
 "our_title": "Map view keeps caller's part array intact via private renumbered index array",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_map_view.c:289-303, 465-470",
 "evidence": "7.0.17 renumbers into a private pidxtax array (added to the memAllocGroup) and keeps parttax = lmapptr->parttab untouched; archDomTerm uses parttax. Reproducer work/API/mv.c (8-path, parttab {0,0,0,0,7,7,7,7}, mesh2D 8x1) on ASan 7.0.17: 'CommDilat=1.000000 (7)', 'CommLoad[7]=0.142857', parttab after = '0 0 0 0 7 7 7 7' (was renumbered to 0..1 in 7.0.16).",
 "upstream_change": "d604eb1 Bugfix: preserve parttax array by using auxiliary part index array [report R. Perry]",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "Side effect: the separate parotax/domnold bugs in the same function were NOT touched, see API-16 (including a new base-1 out-of-bounds read).",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-14

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-14",
 "area": "API",
 "our_title": "Part diameter helper starts distances at one and skips last vertex as root for base 1",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_map_view.c:129-134 (rootnum vs vertnbr), 136 (connval = ++distmax), 178 (return distmax), 543 (diamsum += diamval)",
 "evidence": "Unchanged logic (variables renamed only). work/API/diam.c on ASan 7.0.17: 4-vertex path single part: 'PartDiam min=4 max=4' (true 3) for base 0 and base 1; path2 base 1 with parts {0,1}: 'min=0 max=1 avg=0.5' vs base 0 'min=1 max=1' (last vertex never becomes a root because rootnum (base-adjusted) is compared to vertnbr); graphMapView3 returns -1 on OOM and the caller adds it unchecked ('diamsum += diamval').",
 "upstream_change": "",
 "review_accuracy": "accurate. Nuance: for several connected components the value is sum of (diameter+1) per component, which looks intentional ('components laid end to end'); only the constant +1 is wrong.",
 "fix_options": [
  {
   "label": "Fix bound, offset and error propagation inside graphMapView3 / caller",
   "summary": "rootnum compared with vertnnd; return distmax-1 (clamped at 0 so it can never equal the -1 error code); caller checks diamval<0 and returns 1.",
   "patch_sketch": "--- library_graph_map_view.c\n+++ library_graph_map_view.c\n@@ -126,11 +126,11 @@\n   for (passnum = 1, rootnum = grafptr->baseval; ; passnum ++) { /* For all connected components */\n     Gnum                diamnum;                  /* Vertex which achieves diameter             */\n \n-    while ((rootnum < grafptr->vertnbr) &&\n+    while ((rootnum < grafptr->vertnnd) &&\n            ((vexxtax[rootnum].passnum != 0) ||    /* Find first unallocated vertex */\n             (parttax[rootnum] != partval)))\n       rootnum ++;\n-    if (rootnum >= grafptr->vertnbr)              /* Exit if all of graph processed */\n+    if (rootnum >= grafptr->vertnnd)              /* Exit if all of graph processed */\n       break;\n \n     connval = ++ distmax;                         /* Start from previous distance */\n@@ -176,7 +176,7 @@\n \n   memFree (queudat.qtab);                         /* Free group leader */\n \n-  return (distmax);\n+  return ((distmax > 0) ? (distmax - 1) : 0);     /* Distances were counted from 1; never return -1, which is the error code */\n }\n \n /* This routine writes standard or raw\n@@ -269,7 +269,7 @@\n \n   if (libmapoptr != NULL) {\n     lmaoptr = (LibMapping *) libmapoptr;\n-    parotax = lmaoptr->parttab;\n+    parotax = lmaoptr->parttab - grafptr->baseval; /* Base old part array */\n   }\n   else {\n     lmaoptr = NULL;\n@@ -487,7 +487,7 @@\n         continue;\n       if (parotax[vertnum] != parttax[vertnum]) {\n         migrnbr ++;\n-        archDomTerm (archptr, &domnorg, parotax[vertnum]); /* Get terminal domains */\n+        archDomTerm (archptr, &domnorg, parttax[vertnum]); /* Get terminal domains */\n         archDomTerm (archptr, &domnold, parotax[vertnum]);\n         migrdistavg += archDomDist (archptr, &domnorg, &domnold);\n         migrloadavg += (grafptr->velotax == NULL) ? 1 : grafptr->velotax[vertnum];\n@@ -538,7 +538,11 @@\n     do {\n       Gnum                diamval;\n \n-      diamval  = graphMapView3 (grafptr, pidxtax, mapnum);\n+      diamval = graphMapView3 (grafptr, pidxtax, mapnum);\n+      if (diamval < 0) {                          /* If out of memory */\n+        memFree (domntab);                        /* Free group leader */\n+        return (1);\n+      }\n       diamsum += diamval;\n       if (diamval < diammin)\n         diammin = diamval;\n@@ -714,6 +718,7 @@\n                      &compsize, (size_t) (partnbr * sizeof (Gnum)),\n                      &listtab,  (size_t) ((partnbr + 1) * sizeof (GraphMapViewList)), NULL) == NULL) {\n     errorPrint (STRINGIFY (SCOTCH_graphPartOvlView) \": out of memory\");\n+    return (1);\n   }\n   listtab ++;                                     /* TRICK: Trim array so that listtab[-1] is valid */\n   memSet (listtab, ~0, partnbr * sizeof (GraphMapViewList)); /* Set vertex indices to ~0            */\n",
   "tradeoffs": "Tested (64-bit ASan build): 4-path -> 3 for both bases, {0,0,1,1} -> 1/1, path2 base1 -> 0/0 like base 0, gmap -vm on an 8x8 grid in 4 squares now prints PartDiam 6 (was 7). Changes printed statistics (one lower everywhere), which may affect golden outputs in tests/CI that grep PartDiam.",
   "preferred": true
  },
  {
   "label": "Start distances at 0 instead of subtracting at the end",
   "summary": "Initialise distmax=-1 (first connval=0) and make the error code a separate out-parameter (int *errflag) rather than a negative Gnum.",
   "patch_sketch": "Gnum graphMapView3 (..., int * const errptr); distmax = -1; ... *errptr = 1; return 0;",
   "tradeoffs": "Cleaner semantics (no clamp), removes the overloaded -1, but changes the helper's signature and every call site.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-16

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-16",
 "area": "API",
 "our_title": "Remap view computes both domains from the old mapping, giving zero migration distance",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_map_view.c:488-492",
 "evidence": "Unchanged: 'archDomTerm (archptr, &domnorg, parotax[vertnum]); archDomTerm (archptr, &domnold, parotax[vertnum]);'. work/API/mv.c --remap on ASan 7.0.17: new {0,0,0,0,7,7,7,7} vs old {7,7,7,7,0,0,0,0} on mesh2D 8x1: 'MigrNbr=8(100.000000 %)', 'AvgMigrDist=0.000000' (true 7). NEW finding in the same loop: parotax = lmaoptr->parttab is never base-adjusted while vertnum is base-adjusted, so with baseval=1 the loop reads parotax[vertnnd-1+...] one element past the old-mapping array: ASan 'stack-buffer-overflow READ of size 4 ... graphMapView2 library_graph_map_view.c:486' (work/API/mv.c, 'remap base1').",
 "upstream_change": "",
 "review_accuracy": "accurate (and the 7.0.16 line numbers moved by d604eb1). Review's Fix 'domnorg from parttax[vertnum] using the original part numbers' is now correct since 7.0.17 no longer renumbers parttax.",
 "fix_options": [
  {
   "label": "domnorg from the new mapping, and base the old array",
   "summary": "archDomTerm(domnorg, parttax[vertnum]); parotax = lmaoptr->parttab - grafptr->baseval.",
   "patch_sketch": "--- library_graph_map_view.c (graphMapView2)\n@@ -269,7 +269,7 @@\n   if (libmapoptr != NULL) {\n     lmaoptr = (LibMapping *) libmapoptr;\n-    parotax = lmaoptr->parttab;\n+    parotax = lmaoptr->parttab - grafptr->baseval; /* Base old part array */\n@@ -487,7 +487,7 @@\n         migrnbr ++;\n-        archDomTerm (archptr, &domnorg, parotax[vertnum]); /* Get terminal domains */\n+        archDomTerm (archptr, &domnorg, parttax[vertnum]); /* Get terminal domains */\n         archDomTerm (archptr, &domnold, parotax[vertnum]);\n",
   "tradeoffs": "Tested: AvgMigrDist=7.000000 for the 8-path example in base 0 and base 1, and the base-1 ASan overflow disappears. Changes printed AvgMigrDist (was meaningless 0).",
   "preferred": true
  },
  {
   "label": "Compute the migration distance once up front",
   "summary": "Build per-vertex terminal domains for old and new mappings in the pidxtax pass and take the distance from precomputed ArchDom pairs.",
   "patch_sketch": "/* when building pidxtax, also fill ArchDom * domntax / domotax */",
   "tradeoffs": "More invasive and memory-hungry (two ArchDom arrays), but removes repeated archDomTerm calls; no functional advantage.",
   "preferred": false
  }
 ],
 "notes": "Both distinct bugs (zero distance; unbased old array) are fixed by the 2-line preferred patch.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-1

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-1",
 "our_title": "Old-mapping array is not base-adjusted in remap view; base-1 graphs read out of bounds",
 "severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "location_7_0_17": "src/libscotch/library_graph_map_view.c:272, 486-491",
 "evidence": "parotax = lmaoptr->parttab (unbased) is indexed with vertnum in [baseval, vertnnd). work/API/mv.c 'remap base1' on ASan 7.0.17: stack-buffer-overflow READ of size 4 at library_graph_map_view.c:486 in graphMapView2.",
 "related_review_ids": [
  "API-16"
 ],
 "fix_options": [
  {
   "label": "Base the old array",
   "summary": "parotax = lmaoptr->parttab - grafptr->baseval;",
   "patch_sketch": "-    parotax = lmaoptr->parttab;\n+    parotax = lmaoptr->parttab - grafptr->baseval;",
   "tradeoffs": "Tested: overflow gone, AvgMigrDist correct.",
   "preferred": true
  },
  {
   "label": "Index with vertnum - baseval",
   "summary": "Leave parotax unbased and subscript with (vertnum - grafptr->baseval) in the three uses.",
   "patch_sketch": "parotax[vertnum - grafptr->baseval]",
   "tradeoffs": "More edits, easy to miss one use.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-19

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-19",
 "area": "API",
 "our_title": "Edge load sum counts arcs when weighted but half the arcs when unweighted",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph.c:495-515 (weighted: arc sum; unweighted: edgenbr / 2); library_dgraph_stat.c:222-267 (unweighted: edgeglbnbr / 2)",
 "evidence": "Unchanged. work/API/st.c on ASan 7.0.17 (4-path, 6 arcs): edlotab=NULL -> 'edlosum=3'; edlotab all 1 -> 'edlosum=6' (avg=1 in both). Internal convention in graph.h:148 is 'Sum of edge (in fact arc) loads' and graph_io.c:184 uses edgenbr for the unweighted case, so the '/ 2' branch is the odd one.",
 "upstream_change": "",
 "review_accuracy": "accurate on the inconsistency; the review leaves open which convention is right. The doc (s_l.tex:3772) says only 'sum of all edge loads'.",
 "fix_options": [
  {
   "label": "Use the arc convention in the unweighted branch",
   "summary": "edlosum = edgenbr (resp. edgeglbnbr); matches Graph.edlosum and the weighted branch.",
   "patch_sketch": "--- library_graph.c\n+++ library_graph.c\n@@ -507,7 +507,7 @@\n     else {\n       edlomin =\n       edlomax = 1;\n-      edlosum = srcgrafptr->edgenbr / 2;\n+      edlosum = srcgrafptr->edgenbr;              /* Same convention as weighted case: sum over arcs */\n       edloavg = 1.0L;\n     }\n   }\n--- library_dgraph_stat.c\n+++ library_dgraph_stat.c\n@@ -262,7 +262,7 @@\n     else {\n       srclstadat.edlomin =\n       srclstadat.edlomax = 1;\n-      edloglbsum         = srcgrafptr->edgeglbnbr / 2;\n+      edloglbsum         = srcgrafptr->edgeglbnbr;  /* Same convention as weighted case: sum over arcs */\n       edloglbavg         = 1.0L;\n     }\n   }\n",
   "tradeoffs": "Tested (64-bit build): both cases now report 6. Changes gtst/dgtst output for unweighted graphs (sum doubles); callers of SCOTCH_graphStat that relied on edgenbr/2 break. Consistent with internal data structures.",
   "preferred": true
  },
  {
   "label": "Use the edge-once convention in the weighted branch",
   "summary": "Divide the weighted edlosum by 2 (and edloglbsum) so both report undirected-edge sums.",
   "patch_sketch": "*edlosumptr = (SCOTCH_Num) (edlosum / 2);",
   "tradeoffs": "Matches the human reading of 'sum of all edge loads' and keeps unweighted output unchanged, but silently halves currently reported weighted sums, and avg (edlosum/edgenbr) would then need a x2 to stay =1 for unit weights, so more places change.",
   "preferred": false
  }
 ],
 "notes": "Maintainers decide semantics; I recommend asking the Scotch team which convention they document (add to upstream/QUESTIONS_FOR_SCOTCH_TEAM.md).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-21

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-21",
 "area": "API",
 "our_title": "Mapping table loader reads sorted-mapping array at its end index after last match",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_graph_map_io.c:163-171",
 "evidence": "Unchanged. After 'mappsorttab[mappfilenum ++].num' consumes the last entry, the next vertex iteration evaluates 'mappsorttab[mappfilenum].labl' with mappfilenum == mappfilenbr. With unique vertex labels the stray element is vertsorttab[0] (adjacent in the same memAllocGroup) so ASan is silent and the result is accidentally right ('goto skip' fires). With duplicate vertex labels (graphCheck accepts them) it yields a wrong part: work/API/tl.c with labels {0,0,1,2}, mapping file '1\\n0 5' -> parttab = 5 0 -1 -1 (vertex 1 got garbage 0 instead of -1). Same on 32- and 64-bit builds.",
 "upstream_change": "",
 "review_accuracy": "accurate. 'Duplicate labels' means duplicates in the GRAPH vertex labels (duplicate mapping labels are rejected earlier).",
 "fix_options": [
  {
   "label": "Bound the vertex loop by the mapping data",
   "summary": "Add '&& (mappfilenum < mappfilenbr)' to the for-condition.",
   "patch_sketch": "--- library_graph_map_io.c\n+++ library_graph_map_io.c\n@@ -160,7 +160,7 @@\n     if (vertsortflag != 1)                        /* If graph label data not sorted     */\n       intSort2asc1 (vertsorttab, vertnbr);        /* Sort sort area by ascending labels */\n \n-    for (vertsortnum = 0, mappfilenum = 0; vertsortnum < vertnbr; vertsortnum ++) { /* For all vertices in graph */\n+    for (vertsortnum = 0, mappfilenum = 0; (vertsortnum < vertnbr) && (mappfilenum < mappfilenbr); vertsortnum ++) { /* For all vertices in graph while mapping data remains */\n       while (mappsorttab[mappfilenum].labl < vertsorttab[vertsortnum].labl) {\n         mappfilenum ++;                           /* Search mapping vertex with same label */\n         if (mappfilenum >= mappfilenbr)           /* If all mapping data processed         */\n",
   "tradeoffs": "Tested: duplicate-label case now gives 5 -1 -1 -1; unique-label case unchanged. Minimal.",
   "preferred": true
  },
  {
   "label": "Sentinel entry",
   "summary": "Allocate mappfilenbr+1 entries and set mappsorttab[mappfilenbr].labl = GNUMMAX (precedent: 'TRICK: avoid testing (i+1)' ARCHDOMNOTTERM sentinel in graphMapView2).",
   "patch_sketch": "&mappsorttab, (size_t) ((mappfilenbr + 1) * sizeof (VertSort)), ...\nmappsorttab[mappfilenbr].labl = GNUMMAX;",
   "tradeoffs": "Keeps the inner loop branch-free; slightly less obvious and a vertex label equal to GNUMMAX would still match.",
   "preferred": false
  }
 ],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## API-18

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-18",
 "area": "API",
 "our_title": "Distributed mapping view prints edge count over twice load, ignoring expansion and dilation",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_dgraph_map_view.c:145-148",
 "evidence": "Unchanged. Code: ': ((double) grafptr->edgeglbnbr) / (double) (cmlosum * 2)'. work/API/dmv.c (mpirun -np 2, 8x8 grid, 4 vertex parts on archCmplt(4), every edge weight 3) on ASan 7.0.17: SCOTCH_dgraphMapStat gives cmlosum=336 cmdisum=16 cmexsum=48; SCOTCH_dgraphMapView prints 'CommDelta=0.333333' while the sequential formula (expansion*edgenbr)/(load*dilation) gives 1.000000. With unit edge weights both agree (1.0) because expansion==dilation there, so the defect only shows with edge weights.",
 "upstream_change": "",
 "review_accuracy": "Diagnosis accurate, but the suggested fix '(cmexsum * edgeglbnbr) / (cmlosum * cmdisum)' is wrong by a factor 2: dgraphMapStat halves the sums (each edge once, 'Arcs have been accounted for twice' /2), so the sequential-equivalent value is (cmexsum * edgeglbnbr) / (2 * cmlosum * cmdisum); the review's formula prints 2.0 in the example.",
 "fix_options": [
  {
   "label": "Sequential-equivalent formula in doubles",
   "summary": "(cmexsum * edgeglbnbr) / (cmlosum * cmdisum * 2.0), keep the zero guard.",
   "patch_sketch": "--- library_dgraph_map_view.c\n+++ library_dgraph_map_view.c\n@@ -145,7 +145,8 @@\n   fprintf (stream, \"M\\tCommDelta=%f\\n\",\n            (((double) cmlosum  * (double) cmdisum) == 0.0L)\n            ? (double) 0.0L\n-           : ((double) grafptr->edgeglbnbr) / (double) (cmlosum * 2));\n+           : ((double) cmexsum * (double) grafptr->edgeglbnbr) / /* Sums count each edge once; sequential formula counts arcs */\n+             ((double) cmlosum * (double) cmdisum * 2.0));\n \n   for (cdstnum = 0; cdstnum <= cdstmax; cdstnum ++) /* Print distance histogram */\n     fprintf (stream, \"M\\tCmlosum[\" ANUMSTRING \"]=%f\\n\",\n",
   "tradeoffs": "Verified: dmv.c now prints CommDelta=1.000000 = sequential value. Use doubles (not Gnum products) to avoid overflow. Pitfall found while testing: do not use a long double literal (2.0L) here, it turns the ?: into long double passed to %f. Changes printed numbers only for weighted graphs.",
   "preferred": true
  },
  {
   "label": "Have dgraphMapStat return arc sums and halve in the view",
   "summary": "Return unhalved sums from the stat routine's internal API and let each viewer pick; or add a SCOTCH_dgraphMapView helper that rebuilds the sequential statistics.",
   "patch_sketch": "/* library_dgraph_map_stat.c: keep cdstglbtab[256+i] unhalved for an internal variant */",
   "tradeoffs": "Would make seq/dist views share one formula, but changes the public meaning of cmlosum/cmdisum/cmexsum (documented as edge-once) -> ABI/semantic risk; not recommended.",
   "preferred": false
  }
 ],
 "notes": "Also: the histogram loop divides by cmlosum without the zero guard used elsewhere (division by zero prints nan).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)


===================================================================
## PS-API-7

### (New defect found by the first pass, not in the review)
```json
{
 "local_id": "PS-API-7",
 "our_title": "Distributed mapping view divides histogram by communication load without zero guard",
 "severity": "low",
 "status": "still-present",
 "method": "source-read",
 "location_7_0_17": "src/libscotch/library_dgraph_map_view.c:152-155",
 "evidence": "Loop prints (double) cdsttab[cdstnum] / (double) cmlosum while the other lines guard cmlosum == 0.",
 "related_review_ids": [
  "API-18"
 ],
 "fix_options": [
  {
   "label": "Guard like neighbours",
   "summary": "Use (cmlosum == 0) ? 0.0 : ...",
   "patch_sketch": "(cmlosum == 0) ? 0.0 : (double) cdsttab[cdstnum] / (double) cmlosum",
   "tradeoffs": "Prints 0 instead of nan.",
   "preferred": true
  },
  {
   "label": "Skip the histogram",
   "summary": "Do not print when cmlosum == 0.",
   "patch_sketch": "if (cmlosum != 0) for (...)",
   "tradeoffs": "Output shape changes.",
   "preferred": false
  }
 ],
 "area": "API"
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)
