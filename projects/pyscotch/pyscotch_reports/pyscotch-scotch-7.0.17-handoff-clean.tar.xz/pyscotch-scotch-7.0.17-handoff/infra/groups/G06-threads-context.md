# G06-threads-context

Items: COR-09, COR-10, COR-11, COR-24, API-02



===================================================================
## COR-09

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-09",
 "area": "COR",
 "our_title": "Thread creation failure lowers thread count while started threads still wait on original barrier",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/common_thread.c:128-147 (desctab alloc, creation loop, failure path calls threadContextExit with reduced thrdnbr), threadWait at ~306",
 "evidence": "Injected pthread_create failures with an LD_PRELOAD shim (work/COR/shim.c, FAIL_AT=n makes the n-th pthread_create return EAGAIN) and ctx.c (SCOTCH_contextAlloc/Init/BindGraph with SCOTCH_PTHREAD_NUMBER=4, linked to libscotcherr so errorPrint does not exit):\n- FAIL_AT=3 SCOTCH_PTHREAD_NUMBER=4 LD_PRELOAD=libasan.so:shim.so ./ctx g88.grf -> prints 'threadCreate: cannot launch thread (3)' then hangs (timeout 20 -> 'Terminated').\n- FAIL_AT=1 -> returns (bind ret=1) but LeakSanitizer reports 'Direct leak ... allocated from _SCOTCHthreadContextInit common_thread.c:128' (desctab) and the mutex/cond are never destroyed.\nMechanism: the two already-started threads sit in threadContextBarrier() waiting for barrnbr == contptr->thrdnbr (original 4); the failure path lowers thrdnbr to 3, then threadContextExit2 sets DWN and spins on barrnbr == thrdnbr-1, but the started threads never leave the start-up barrier (main never joined it).",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Release the start-up barrier with the reduced count, then shut down",
   "summary": "On failure set contptr->thrdnbr = thrdnum under the lock, let main join threadContextBarrier() (so the started threads copy their descriptors and reach their wait loop), free desctab, destroy lock features when no slave exists, then threadContextExit().",
   "patch_sketch": "   errorPrint (\"threadContextInit: cannot create thread (%d)\", thrdnum);\n+  pthread_mutex_lock (&contptr->lockdat); contptr->thrdnbr = thrdnum; pthread_mutex_unlock (&contptr->lockdat);\n+  threadContextBarrier (contptr);          /* started threads + main complete the barrier */\n+  memFree (desctab);\n+  if (thrdnum == 1) { pthread_cond_destroy (&contptr->conddat); pthread_mutex_destroy (&contptr->lockdat); }\n   threadContextExit (contptr);\n   return (1);",
   "tradeoffs": "Tested: FAIL_AT=1,2,3 now return bind ret=1 promptly, no hang, no desctab leak; FAIL_AT=4 (nothing fails at this count) unaffected. Keeps the existing barrier protocol. Depends on the started threads being reachable by the barrier (true: they only block in it).",
   "preferred": true
  },
  {
   "label": "B. Two-phase start: create all threads parked on a private 'go' flag",
   "summary": "Threads wait on a go/abort flag (not the shared barrier); main sets go=1 only when all creations succeeded, otherwise abort=1 and joins the started threads.",
   "patch_sketch": "ThreadContext += 'int goflag;' ; threadWait: wait until goflag != 0, exit if goflag < 0 ; threadContextInit: on failure goflag = -1, broadcast, wait for exits.",
   "tradeoffs": "Cleaner semantics (shutdown independent of the barrier, as the review suggests), but changes threadWait and the context layout (ThreadContext is internal, but contextThreadImport/Split also use threadWait). More testing needed. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: smallest change reusing threadContextBarrier()/threadContextExit() exactly like the success path (which already uses 'Ensure all slave threads have started before cleaning-up resources').",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-10

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-10",
 "area": "COR",
 "our_title": "Zero thread count allocates empty descriptor array then writes its first element",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/common_thread.c:111-155 (threadContextInit), common_context.c:222 (envGetInt)",
 "evidence": "Command: SCOTCH_PTHREAD_NUMBER=0 gpart 4 g88.grf /dev/null (ASan build) -> 'AddressSanitizer: heap-buffer-overflow WRITE of size 4 ... #0 _SCOTCHthreadContextInit common_thread.c:150 #1 contextThreadInit2 common_context.c:201 #2 contextThreadInit common_context.c:227 #3 contextCommit common_context.c:127 #4 SCOTCH_contextBindGraph library_context_graph.c:98 #5 main gmap.c:436'. Under ASan this is an OOB write (desctab has 0 bytes, then desctab[0].contptr = ... at line 150), not a hang; in a non-ASan build the same write corrupts the heap and the later barrier on thrdnbr==0 never completes (review's hang). SCOTCH_PTHREAD_NUMBER=1,2,-1 work. Source: only 'thrdnbr < 0' (-> corenbr) and 'thrdnbr == 1' are special-cased; README.md:111 documents only a positive count or -1.",
 "upstream_change": "",
 "review_accuracy": "accurate (symptom differs under ASan: heap-buffer-overflow instead of hang)",
 "fix_options": [
  {
   "label": "A. Clamp 0 to 1 inside threadContextInit",
   "summary": "Treat a null count as 'main thread only'.",
   "patch_sketch": "   if (thrdnbr < 0) thrdnbr = corenbr;\n+  else if (thrdnbr == 0) thrdnbr = 1;",
   "tradeoffs": "Tested: SCOTCH_PTHREAD_NUMBER=0 gpart now runs and exits 0. Protects all callers (env var, compile-time SCOTCH_PTHREAD_NUMBER, SCOTCH_contextThreadSpawn). Silent: someone passing 0 expecting 'auto' gets 1.",
   "preferred": true
  },
  {
   "label": "B. Reject 0 with an error",
   "summary": "if (thrdnbr == 0) { errorPrint (\"threadContextInit: invalid number of threads\"); return (1); }",
   "patch_sketch": "same location",
   "tradeoffs": "Explicit, but a mis-set environment variable would now abort a run that formerly 'worked' by luck; for env vars Scotch's convention (envGetInt) is to take whatever is given. Not tested.",
   "preferred": false
  },
  {
   "label": "C. Treat <= 0 as 'auto'",
   "summary": "Change 'if (thrdnbr < 0)' to 'if (thrdnbr <= 0)' (0 = all cores as in OpenMP's default-ish convention).",
   "patch_sketch": "-  if (thrdnbr < 0)\n+  if (thrdnbr <= 0)",
   "tradeoffs": "Changes the documented meaning of the knob (only -1 is documented as 'auto'). Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A (idiomatic: the function already silently normalises thrdnbr<0 and ==1).",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-11

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-11",
 "area": "COR",
 "our_title": "Imported thread context restores CPU affinity from a never-captured buffer on exit",
 "claimed_severity": "medium",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/common_thread.c:592-607 (threadContextImport1), 203-211 (threadContextExit -> threadProcessStateRestore), library_context.c:196-220; common_context.c:94",
 "evidence": "Test imp.c (work/COR): contextAlloc/Init, SCOTCH_contextThreadImport1(c,2), a second pthread calls SCOTCH_contextThreadImport2(c,1), main calls Import2(c,0), then SCOTCH_contextExit(c); prints sched_getaffinity before/after.\nASan build (malloc fill 0xbe): 'before: ncpus=8 first: 0 1 2 3 4 5 6 7 / after exit: ncpus=6 first: 1 2 3 4 5 7' (CPU 0 and 6 dropped: affinity set from uninitialised heap bytes). With ASAN_OPTIONS=malloc_fill_byte=0 the restore gets an empty mask, setaffinity fails with EINVAL and the affinity is unchanged (so the effect depends on heap garbage; with a non-zero heap it re-pins the caller).\nSource: threadContextImport1 never calls threadProcessStateSave; contextExit (common_context.c:94) calls threadContextExit which does threadProcessStateRestore (pthread_setaffinity_np with contptr->savedat.cpusdat).",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Save the master's state at import",
   "summary": "Call threadProcessStateSave() at the top of threadContextImport1 so the later restore is a no-op (the caller's own mask).",
   "patch_sketch": "threadContextImport1 (...) {\n+  threadProcessStateSave (contptr);  /* Save state of master thread */\n   contptr->thrdnbr = thrdnbr; ...",
   "tradeoffs": "Tested: imp_f shows 'after exit' mask identical to 'before'. Also harmless for the split sub-contexts (they use threadContextExit2 which does not restore). One pthread_getaffinity_np call per import.",
   "preferred": true
  },
  {
   "label": "B. Skip the restore for imported contexts",
   "summary": "Mark imported contexts (e.g. a flag in ThreadContext set by Import1) and make threadContextExit() skip threadProcessStateRestore for them.",
   "patch_sketch": "ThreadContext += 'int impoflg;' ; Import1: impoflg = 1; threadContextExit: if (!impoflg) threadProcessStateRestore (contptr);",
   "tradeoffs": "Semantically exact (an imported context never changed affinity), but adds a field and a branch. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Preferred A: one line; threadContextInit has the identical first statement ('threadProcessStateSave (contptr);').",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## COR-24

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "COR-24",
 "area": "COR",
 "our_title": "Explicit CPU list reduced modulo mask size, pinning threads outside the process affinity mask",
 "claimed_severity": "low",
 "status": "still-present",
 "method": "reproduced",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/common_thread.c:140, 151 (coretab[i] % corenbr), 789-803 (threadCreate: setaffinity result ignored)",
 "evidence": "Test core.c: 'taskset -c 4-7 ./core' then SCOTCH_contextThreadSpawn(c, 4, coretab = {4,5,6,7}); main thread (thread 0 is pinned from coretab[0]) afterwards reports affinity '0' - i.e. CPU 0 which is outside the process mask 4-7 (corenbr = CPU_COUNT(mask) = 4, 4 % 4 = 0). Automatic placement (coretab == NULL) goes through threadProcessCoreNum which walks the saved mask and would pick CPU 4. pthread_setaffinity_np's result is not checked in threadCreate.",
 "upstream_change": "",
 "review_accuracy": "accurate",
 "fix_options": [
  {
   "label": "A. Interpret coretab as physical CPU ids, validated against the process mask",
   "summary": "Use coretab[i] directly when the CPU is in the saved mask; otherwise report an error (or fall back to the automatic choice).",
   "patch_sketch": "corenum = (coretab != NULL) ? coretab[thrdnum] : threadProcessCoreNum (...);\n+ if (coretab != NULL && !CPU_ISSET (corenum, &contptr->savedat.cpusdat)) -> errorPrint + return (1) (or fallback)",
   "tradeoffs": "Matches what the SCOTCH_contextThreadSpawn documentation implies for users who pass explicit CPU ids; changes behaviour for callers who relied on 'modulo number of cores' on unrestricted machines (corenbr == online CPUs: identical result there). Not tested.",
   "preferred": true
  },
  {
   "label": "B. Treat coretab as logical indices into the process mask",
   "summary": "Map coretab[i] through the same mask-based lookup as automatic placement: corenum = threadProcessCoreNum (contptr, coretab[i]).",
   "patch_sketch": "corenum = (coretab != NULL) ? threadProcessCoreNum (contptr, coretab[thrdnum]) : threadProcessCoreNum (contptr, thrdnum);",
   "tradeoffs": "Consistent numbering with auto mode and the review's suggestion; but then {4,5,6,7} under taskset 4-7 means CPUs 8.. wrapped (4%4=0 -> first CPU = 4, 5%4=1 -> 5 ...) i.e. works only for 0-based logical ids. Docs must say which one is meant. Not tested.",
   "preferred": false
  }
 ],
 "notes": "Not tested because the intended semantics of coretab (physical vs logical) is a design question for the Scotch team; preferred A follows 'core numbers' naming in the API.",
 "history": {
  "reported": "reported",
  "7.0.17": "still-present"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/COR/diffs/ if any; harness sources alongside)


===================================================================
## API-02

### Third-party review entry (verbatim lead; cite its id, never copy its text into the report)
(the review's text is omitted here: it is cited by id, never redistributed; the auditing agents had it)

### First pass (previous agent) entry
```json
{
 "id": "API-02",
 "area": "API",
 "our_title": "Context option setter dispatches on option number; deterministic option now forces fixed seed",
 "claimed_severity": "high",
 "status": "fixed",
 "method": "both",
 "needs": "",
 "needs_note": "",
 "location": "src/libscotch/library_context.c:306-323, 368-384",
 "evidence": "7.0.17 has 'switch (optinum)', returns 'o || contextValuesSetInt(...)', and SCOTCH_contextOptionParse now does 'o |= SCOTCH_contextOptionSetNum(...)' and 'return (o)'. Ran work/API/ctx.c on ASan build: SetNum(DETERMINISTIC,1)=0, Parse(\"d\")=0, and afterwards GetNum(RANDOMFIXEDSEED)=1 on a fresh context that only got DETERMINISTIC=1.",
 "upstream_change": "0f793bf Bugfix: dynamic option setting strategy sets the proper parameters and returns the proper error value",
 "review_accuracy": "accurate",
 "fix_options": [],
 "notes": "",
 "history": {
  "reported": "reported",
  "7.0.17": "fixed"
 }
}
```

### First-pass work dir: /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/  (diffs in /tmp/claude-1000/-home-dev-workspace-pyscotch/2360bf25-430d-4f09-8fe2-45595bf8047f/scratchpad/work/API/diffs/ if any; harness sources alongside)
