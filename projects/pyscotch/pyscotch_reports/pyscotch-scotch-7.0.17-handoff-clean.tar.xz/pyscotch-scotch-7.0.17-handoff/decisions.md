# Decisions for the 7.0.17 series (collected from the 30 group audits, 13 oct 2026)

The series ships the recommended option in every case; the alternatives are real diffs under alt/<group>/.
"Settle once" items recur across groups and should get one answer for the whole report.

## A. Policy questions to settle once

1. **Release-build agreements between MPI ranks.** The maintainer deliberately compiles the collective error
   agreements out of release builds ("communication cannot be merged with a useful one"). The series reverses
   that where a single rank's failure otherwise hangs or crashes the job: G18 (fold/gather/redist), G07 0004
   (comm.c wrappers), G19 0005 (labelled builds), G21 0002/0008 (band/grow, coarsening), G22 0002 (gather),
   G24 0002/0008 (ordering leaves, nested dissection). Cost: one small Allreduce/Bcast per call or level.
   Alternatives in alt/ keep his idiom and keep the hangs. Recommendation: accept; this is what makes every
   injected allocation failure return on all ranks (G18/G19/G21/G22/G24 fault-injection evidence).
2. **Unconditional checks where he uses debug guards.** G27 CLI-11 (graphInduceList list check, alt/CLI-11-c),
   G21 0002 (dgraphGrow distance parameter), the architecture loaders/builders (G01/G02/G03) and the loaders
   (G14/G11/G20) all check user input in release builds. Recommendation: accept for anything reachable from a
   file or a public argument.
3. **Determinism semantics.** PS2-G06-1: the run-time fixed-seed option is never read; alt/PS2-G06-1-a makes
   `-Cd`, `-Cf`, SCOTCH_DETERMINISTIC=1 work in builds without COMMON_RANDOM_FIXED_SEED but reseeds per
   context init: choose once-per-process or per-context semantics (not committed). G09 0007 (genetic method
   honours the option) is a separate, droppable commit. G12 0009 + G15 0006 (no context split when deterministic)
   are committed and give 1 == 2 == 4 threads for gpart and gord.

## B. Behaviour and format changes to confirm before sending

4. **Statistics output (G16).** Edge-load sums now count edges, not arcs (A, shipped; alt B keeps arcs): weighted
   gtst/dgtst/graphStat sums halve. Part pseudo-diameters start at 0 (every PartDiam drops by 1), the remap
   migration distance is now non-zero, and dgmap -v prints the same lines as gmap -v. PyScotch's own tests pin
   the old values (test_interop.py, test_graph*.py, hypothesis test_graph_properties.py) and must change either
   way. Keep 0008 (output labels "Cmlosum" -> "CommLoad") or not.
5. **Mesh file labels (G11 0011).** Labels must now be unique across elements and nodes; labelled mesh files
   never round-tripped before. Droppable last commit.
6. **Stricter acceptance.** G19 0010: SCOTCH_dgraphCheck rejects zero edge loads and out-of-range edge ends.
   G12 GRA-23: remapping with terminals outside the target is rejected instead of computing on garbage.
   G05 API-07: strategy builders reject negative and non-finite ratios. G25: ubvec[0] <= 1.0 is
   METIS_ERROR_INPUT (shipped test changed 0.05 -> 1.05); OBJTYPE=VOL honoured for PartGraphRecursive too.
   G07 COR-15: intLoad rejects -INTVALMAX-1 (alt B accepts it). G04: integer-literal overflow is an error,
   `m{vert=}` is rejected, nested-error messages name the enclosing parameter.
7. **Orderings that may change.** G10 0008 removes the `hashmax *= 4` shield in the mesh FM resize (ship001
   slightly better, m2_300_300 unchanged; option c keeps it). G15 0007 block ordering on weighted graphs
   (blocks 24..16930 -> 954..1577: a correctness fix, but outputs move). G26 0002: PartMeshDual objective from
   OBJTYPE only (twin of G25's CLI-19).
8. **Distributed bipartitioning (G22).** 0008 rewrites the unreachable external-gain merge (~200 lines): merge
   now or hold until external gains exist (alt/DMO-19-B fails loudly). 0001 tolerates partial sequential
   failures in release (alt/DMO-03-B keeps the hard check).
9. **Halo synchronisation out-of-memory hang (PS-DGR-2, G20).** Still the one injected failure that hangs
   (seen by G18, G19, G21, G23, G24). Alt A (tested) adds an Allreduce on a hot path; alt B (preferred, zero
   cost) lives in G19's dgraph_ghst.c and is untested. Recommendation: a small follow-up to commit alt B and
   re-run G21's injection scan.
10. **PT-Scotch tools on error (G28 0004).** MPI_Abort from libptscotcherrexit so peers do not hang on a bad
    file; separable; could not be reproduced under Open MPI 5 which kills the job itself.
11. **Thread count 0 (G06 COR-10).** 0 now means automatic (precedent in test_common_thread.c); alt rejects it.
12. **Mapping onto non-complete targets (G24 DMO-17).** Doc-only fix shipped; alt/DMO-17-C rejects them early.

## C. Build, CI and documentation

13. **CMake minimum (G29 BLD-13).** 3.18 shipped (CI already needs 3.21); alt b: 3.14 with a workaround.
    BLD-25: host vs target system name for the FreeBSD test.
14. **CI secrets (G30 BLD-03).** SONAR_TOKEN via job variables needs SonarScanner CLI >= 4.7 on the runner,
    else alt/BLD-03-b (-Dsonar.token). The token archived in past artifacts must be rotated (not a commit).
    BLD-14 adds 3 Makefile and 2 CMake jobs: drop rows if CI time matters.
15. **Manuals (G17).** `integer*1` vs `character` for SCOTCH_GraphPart2 (patch uses integer*1); whether to
    document the 12 wrappers that have no manual entry (PS2-G17-5, not written). gout.1 (G28) is regenerated
    with the current txt2man, which renders one line differently from the stale committed file.
16. **Authorship.** G10's new test file header says "AUTHOR: PyScotch project"; set the real author.
17. **Parser toolchain (G04).** The parser series needs bison >= 3.6; last_resort parser files are not
    regenerated (the maintainer does that at release time; local flex output differs only in #line numbers).

## D. Reported, not patched (follow-ups or maintainer design calls)

- PS2-G09-4: the diffusion abort/barrier flaws fixed in bgraph_bipart_df.c also exist in kgraph_map_df.c (alt only).
- PS2-G26-1: the vertex-array double free on OOM has one more instance in metis_graph_part.c (G25's file).
- G10 extras: hmesh_induce.c:362 unchecked memRealloc, hmesh_order_cp.c:386 leak, bgraph_bipart_fm.c:599 use
  after free on resize failure (compile-checked diffs in work/G10/alt/).
- PS2-G15-4: unchecked shrinking memRealloc, 8 sites tree-wide (G19, G21, G24 fixed theirs; the rest are open).
- PS2-G21-3: CONTEXTINIT() drops contextOptionsInit()'s result. PS2-G24-1/-3: API-level local failures and
  dorderSave waiting forever on an incomplete ordering.
- PS2-G22-5 / PS2-G24-2: dgmap cannot read a centralized target file with np >= 2 and has no check target
  (verified identical on pristine: not a regression).
- COR-05 option C (remove the unused `dist` architecture, 14 files), GRA-19 (delete the dead empty-part code,
  shipped, vs designing a correct freeze), PS-API-5 (graphCheck may allocate: A shipped), PS2-G14-1 (bound
  header counts), SEP-17 (which part a lost vertex joins: lightest, shipped), PS2-G06-1 (above).
- Caveat for the report text: the first pass's MPI drivers used MPI_Init instead of
  MPI_Init_thread(MPI_THREAD_MULTIPLE); its hang readings were unreliable (G23, G24 redid theirs).
